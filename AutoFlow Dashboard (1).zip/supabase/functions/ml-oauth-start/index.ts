import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const auth = req.headers.get('Authorization');
    if (!auth) throw new Error('No autenticado');

    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY') ?? Deno.env.get('SUPABASE_PUBLISHABLE_KEY')!, { global: { headers: { Authorization: auth } } });
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('No autenticado');

    // Prefer user-provided credentials, fallback to project secrets
    const { data: creds } = await supabase.from('ml_credentials').select('app_id,client_secret').eq('user_id', user.id).maybeSingle();
    const ML_APP_ID = creds?.app_id || Deno.env.get('ML_APP_ID');
    if (!ML_APP_ID) throw new Error('Faltan credenciales de Mercado Libre. Configurá tu App ID en Canales > Mercado Libre o en los secretos del proyecto.');

    const projectRef = Deno.env.get('SUPABASE_URL')!.split('//')[1].split('.')[0];
    const redirect = `https://${projectRef}.supabase.co/functions/v1/ml-oauth-callback`;
    const url = `https://auth.mercadolibre.com.ar/authorization?response_type=code&client_id=${ML_APP_ID}&redirect_uri=${encodeURIComponent(redirect)}&state=${user.id}`;
    return new Response(JSON.stringify({ url }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
