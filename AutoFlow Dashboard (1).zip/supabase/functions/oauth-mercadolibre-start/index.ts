import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { admin, HttpError, json, requireUser } from '../_shared/publisher.ts';
import { codeChallenge, createState, randomVerifier } from '../_shared/oauth-state.ts';

/** Devuelve la URL de autorización de Mercado Libre con un state de un solo uso. */
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const user = await requireUser(req);
    const db = admin();
    const body = await req.json().catch(() => ({}));

    const { data: creds } = await db.from('ml_credentials')
      .select('app_id,client_secret').eq('user_id', user.id).maybeSingle();
    const clientId = creds?.app_id || Deno.env.get('ML_APP_ID');
    if (!clientId) {
      throw new HttpError(400, 'Falta configurar la aplicación de Mercado Libre (App ID / Client ID).');
    }

    const redirectUri = `${Deno.env.get('SUPABASE_URL')}/functions/v1/oauth-mercadolibre-callback`;
    const verifier = randomVerifier();
    const state = await createState(db, user.id, 'mercadolibre', body?.return_to, verifier);
    const params = new URLSearchParams({
      response_type: 'code',
      client_id: clientId,
      redirect_uri: redirectUri,
      state,
      code_challenge: await codeChallenge(verifier),
      code_challenge_method: 'S256',
    });

    return json({
      authorizationUrl: `https://auth.mercadolibre.com.ar/authorization?${params}`,
      redirectUri,
    }, 200, corsHeaders);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message }, status, corsHeaders);
  }
});
