import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const key = Deno.env.get("LOVABLE_API_KEY");
    if (!key) {
      return new Response(JSON.stringify({ error: "Falta la configuración de IA" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const b = await req.json() as Record<string, any>;
    if (!b?.marca || !b?.modelo || !b?.anio) {
      return new Response(JSON.stringify({ error: "Cargá al menos marca, modelo y año" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const prompt = `Sos un experto en venta de autos usados en Argentina y copywriter comercial.
Con los datos del vehículo, completá la ficha técnica típica de esa versión (si no estás seguro de un dato, dejalo vacío: NUNCA inventes km, precio, color, patente ni dominio) y escribí los textos de publicación.

Respondé SOLO un JSON válido, sin backticks, con esta forma exacta:
{
 "titulo":"",
 "ficha":{"version":"","carroceria":"","combustible":"","transmision":"","motor":"","cilindrada":"","potencia":"","traccion":"","puertas":0,"cilindros":0,"color":"","direccion_asistida":""},
 "equipamiento":["",""],
 "descripcion_publica":"",
 "ml_text":"",
 "fb_text":"",
 "ig_text":"",
 "whatsapp_text":"",
 "hashtags":["#auto"],
 "faltantes":""
}

Reglas:
- "titulo": máx 60 caracteres, sin emojis, formato Marca Modelo Versión Año.
- "descripcion_publica": 4-6 líneas, tono profesional, para el catálogo web.
- "ml_text": descripción larga para Mercado Libre / Marketplace (8-15 líneas, sin emojis, sin teléfono, sin links).
- "fb_text": tono comercial medio largo, puede tener 1-2 emojis.
- "ig_text": caption corto y atractivo con 1-3 emojis.
- "whatsapp_text": mensaje breve listo para enviar a un cliente, con precio si está.
- "faltantes": lista breve en español de los datos importantes que faltan cargar.
- Escribí todo en español rioplatense.

Datos del vehículo:
- Patente/Dominio: ${b.patente || "-"}
- VIN: ${b.vin || "-"}
- Marca: ${b.marca}
- Modelo: ${b.modelo}
- Versión: ${b.version || "-"}
- Año: ${b.anio}
- Kilómetros: ${b.kilometros ?? "-"}
- Color: ${b.color || "-"}
- Condición: ${b.condicion || "usado"}
- Precio: ${b.precio_venta || "-"} ${b.moneda || "ARS"}
- Ubicación: ${b.ubicacion || "-"}
- Agencia: ${b.agencia || "-"}
- Notas del vendedor: ${b.notas || "-"}
- Cantidad de fotos cargadas: ${b.fotos ?? 0}`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Lovable-API-Key": key },
      body: JSON.stringify({
        model: "google/gemini-3.5-flash",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      }),
    });

    if (!res.ok) {
      const detail = await res.text();
      const message = res.status === 429
        ? "La IA está saturada, probá de nuevo en unos segundos."
        : res.status === 402
        ? "Se agotaron los créditos de IA del espacio de trabajo."
        : "La IA no pudo generar la publicación.";
      return new Response(JSON.stringify({ error: message, details: detail }), {
        status: res.status, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await res.json();
    const raw = data.choices?.[0]?.message?.content ?? "{}";
    let p: any = {};
    try { p = typeof raw === "string" ? JSON.parse(raw) : raw; } catch { p = {}; }

    const s = (v: any) => (typeof v === "string" ? v.trim() : "");
    const n = (v: any) => { const x = Number(v); return Number.isFinite(x) && x > 0 ? x : null; };
    const f = p.ficha || {};

    return new Response(JSON.stringify({
      titulo: s(p.titulo).slice(0, 60),
      ficha: {
        version: s(f.version),
        carroceria: s(f.carroceria),
        combustible: s(f.combustible),
        transmision: s(f.transmision),
        motor: s(f.motor),
        cilindrada: s(f.cilindrada),
        potencia: s(f.potencia),
        traccion: s(f.traccion),
        puertas: n(f.puertas),
        cilindros: n(f.cilindros),
        color: s(f.color),
        direccion_asistida: s(f.direccion_asistida),
      },
      equipamiento: Array.isArray(p.equipamiento) ? p.equipamiento.map(s).filter(Boolean).slice(0, 30) : [],
      descripcion_publica: s(p.descripcion_publica),
      ml_text: s(p.ml_text),
      fb_text: s(p.fb_text),
      ig_text: s(p.ig_text),
      whatsapp_text: s(p.whatsapp_text),
      hashtags: Array.isArray(p.hashtags) ? p.hashtags.map(s).filter(Boolean).slice(0, 15) : [],
      faltantes: s(p.faltantes),
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
