import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const LOVABLE_AI_URL = "https://ai.gateway.lovable.dev/v1/chat/completions";

async function getScopeUserIds(supabase: any, userId: string): Promise<{ ids: string[]; scope: string; agencyName?: string }> {
  // ¿Es CEO?
  const { data: roles } = await supabase.from("user_roles").select("role,agency_id").eq("user_id", userId);
  const isCeo = (roles || []).some((r: any) => r.role === "ceo");

  if (isCeo) {
    // CEO: ve TODO el sistema
    const { data: allUsers } = await supabase.from("user_roles").select("user_id");
    const ids = Array.from(new Set([...(allUsers || []).map((u: any) => u.user_id), userId]));
    return { ids, scope: "global (todas las agencias)" };
  }

  // Buscar agencia del usuario
  const agencyId = (roles || []).find((r: any) => r.agency_id)?.agency_id;
  if (!agencyId) return { ids: [userId], scope: "personal" };

  const { data: mates } = await supabase.from("user_roles").select("user_id").eq("agency_id", agencyId);
  const { data: agency } = await supabase.from("agencies").select("nombre").eq("id", agencyId).maybeSingle();
  const ids = Array.from(new Set([...(mates || []).map((m: any) => m.user_id), userId]));
  return { ids, scope: `agencia ${agency?.nombre || agencyId}`, agencyName: agency?.nombre };
}

async function gatherBusinessContext(supabase: any, userIds: string[]) {
  const today = new Date();
  const monthStart = new Date(today.getFullYear(), today.getMonth(), 1).toISOString();
  const last30 = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString();

  const [carsRes, salesRes, leadsRes, expensesRes, cashRes, pubsRes, alertsRes, analysesRes] = await Promise.all([
    supabase.from("cars").select("id,marca,modelo,anio,precio_venta,kilometros,estado,created_at,user_id").in("user_id", userIds),
    supabase.from("sales").select("*").in("user_id", userIds).gte("created_at", last30),
    supabase.from("leads").select("id,nombre,estado,canal,created_at,car_id").in("user_id", userIds).gte("created_at", last30),
    supabase.from("car_expenses").select("car_id,monto,categoria,created_at").in("user_id", userIds).gte("created_at", monthStart),
    supabase.from("cash_movements").select("tipo,monto,categoria,created_at").in("user_id", userIds).gte("created_at", monthStart),
    supabase.from("vehicle_publications").select("car_id,platform,status,created_at").in("user_id", userIds),
    supabase.from("market_alerts").select("*").in("user_id", userIds).eq("read", false).order("created_at", { ascending: false }).limit(20),
    supabase.from("market_analyses").select("car_id,price_avg,price_recommended,my_position,created_at").in("user_id", userIds).order("created_at", { ascending: false }).limit(20),
  ]);

  const cars = carsRes.data || [];
  const sales = salesRes.data || [];
  const leads = leadsRes.data || [];
  const expenses = expensesRes.data || [];
  const cash = cashRes.data || [];
  const pubs = pubsRes.data || [];
  const alerts = alertsRes.data || [];
  const analyses = analysesRes.data || [];

  const ingresos = cash.filter((m: any) => m.tipo === "ingreso").reduce((s: number, m: any) => s + Number(m.monto || 0), 0);
  const egresos = cash.filter((m: any) => m.tipo === "egreso").reduce((s: number, m: any) => s + Number(m.monto || 0), 0);
  const ventasMes = sales.reduce((s: number, v: any) => s + Number(v.precio_venta || v.precio || 0), 0);
  const gastosVehiculos = expenses.reduce((s: number, e: any) => s + Number(e.monto || 0), 0);

  const leadsPorCanal: Record<string, number> = {};
  leads.forEach((l: any) => { leadsPorCanal[l.canal || "otro"] = (leadsPorCanal[l.canal || "otro"] || 0) + 1; });

  const leadsPorAuto: Record<string, number> = {};
  leads.forEach((l: any) => { if (l.car_id) leadsPorAuto[l.car_id] = (leadsPorAuto[l.car_id] || 0) + 1; });
  const topAutoId = Object.entries(leadsPorAuto).sort((a, b) => b[1] - a[1])[0]?.[0];
  const topAuto = cars.find((c: any) => c.id === topAutoId);

  const disponibles = cars.filter((c: any) => !c.estado || ["disponible", "publicado", "stock"].includes((c.estado || "").toLowerCase()));
  const vendidos = cars.filter((c: any) => (c.estado || "").toLowerCase() === "vendido");

  return {
    fecha_actual: today.toISOString().slice(0, 10),
    stock: {
      total_vehiculos: cars.length,
      disponibles: disponibles.length,
      vendidos: vendidos.length,
      valor_stock: disponibles.reduce((s: number, c: any) => s + Number(c.precio_venta || 0), 0),
      lista_vehiculos: cars.slice(0, 40).map((c: any) => `${c.marca} ${c.modelo} ${c.anio || ""} - ${c.kilometros || "?"}km - $${c.precio_venta || 0} - ${c.estado || "disponible"}`),
    },
    ventas_ultimos_30d: { cantidad: sales.length, total: ventasMes },
    leads_ultimos_30d: { cantidad: leads.length, por_canal: leadsPorCanal, vehiculo_mas_consultado: topAuto ? `${topAuto.marca} ${topAuto.modelo}` : null },
    finanzas_mes: { ingresos, egresos, gastos_vehiculos: gastosVehiculos, ganancia_estimada: ingresos - egresos },
    publicaciones: { total: pubs.length, activas: pubs.filter((p: any) => p.status === "published" || p.status === "active").length },
    alertas_mercado_no_leidas: alerts.slice(0, 10),
    ultimos_analisis_mercado: analyses.slice(0, 5),
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const userSb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: authHeader } } });
    const { data: { user } } = await userSb.auth.getUser();
    if (!user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const { conversation_id, message } = await req.json();
    if (!message?.trim()) return new Response(JSON.stringify({ error: "Mensaje vacío" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    let convId = conversation_id;
    if (!convId) {
      const { data: newConv } = await supabase.from("ceo_conversations").insert({ user_id: user.id, title: message.slice(0, 60) }).select().single();
      convId = newConv!.id;
    }

    await supabase.from("ceo_messages").insert({ conversation_id: convId, user_id: user.id, role: "user", content: message });

    const { data: history } = await supabase.from("ceo_messages").select("role,content").eq("conversation_id", convId).order("created_at", { ascending: true }).limit(30);

    const { ids, scope } = await getScopeUserIds(supabase, user.id);
    const context = await gatherBusinessContext(supabase, ids);

    const systemPrompt = `Eres la IA Ejecutiva de la concesionaria. Respondés en español, claro, directo, accionable y profesional. Tenés acceso a los datos REALES del negocio (alcance: ${scope}) en formato JSON. Usá siempre números concretos y hacé recomendaciones específicas.

DATOS ACTUALES DEL NEGOCIO:
${JSON.stringify(context, null, 2)}

Reglas:
- Respondé con datos concretos del contexto.
- Si te preguntan algo que no está en los datos, decilo claramente.
- Sé conciso. Usá bullets cuando ayude.
- Cuando recomiendes acciones, ordenálas por impacto.`;

    const messages = [
      { role: "system", content: systemPrompt },
      ...(history || []).map((m: any) => ({ role: m.role, content: m.content })),
    ];

    const aiRes = await fetch(LOVABLE_AI_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${Deno.env.get("LOVABLE_API_KEY")}` },
      body: JSON.stringify({ model: "google/gemini-2.5-flash", messages }),
    });

    if (!aiRes.ok) {
      const errText = await aiRes.text();
      return new Response(JSON.stringify({ error: "AI error", detail: errText }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const aiData = await aiRes.json();
    const reply = aiData.choices?.[0]?.message?.content || "Sin respuesta";

    await supabase.from("ceo_messages").insert({ conversation_id: convId, user_id: user.id, role: "assistant", content: reply });
    await supabase.from("ceo_conversations").update({ updated_at: new Date().toISOString() }).eq("id", convId);

    return new Response(JSON.stringify({ conversation_id: convId, reply, scope }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e: any) {
    return new Response(JSON.stringify({ error: e?.message || String(e) }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
