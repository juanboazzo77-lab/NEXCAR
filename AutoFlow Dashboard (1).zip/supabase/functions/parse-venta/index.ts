import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const key = Deno.env.get("LOVABLE_API_KEY");
    if (!key) {
      return new Response(JSON.stringify({ error: "Missing LOVABLE_API_KEY" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json() as { text?: string; cars?: { id: string; label: string }[] };
    const text = (body.text || "").slice(0, 6000).trim();
    const cars = Array.isArray(body.cars) ? body.cars.slice(0, 300) : [];

    if (!text) {
      return new Response(JSON.stringify({ error: "text required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const carList = cars.map((c) => `${c.id} => ${c.label}`).join("\n");

    const prompt = `Sos un asistente de una agencia de autos en Argentina. El vendedor te escribe en lenguaje natural los datos de una venta.
Extraé los datos y devolvé SOLO un JSON válido, sin backticks ni texto extra, con esta forma exacta:
{"comprador_nombre":"","comprador_dni":"","comprador_domicilio":"","comprador_telefono":"","forma_pago":"","lugar":"","monto":0,"moneda":"ARS","cotizacion_usd":0,"sena":0,"monto_financiar":0,"cuotas":0,"parte_pago":"","parte_pago_valor":0,"valor_transferencia":0,"transferencia_incluida":true,"patente":"","car_id":"","fecha":"","notas_faltantes":""}

Reglas:
- Si un dato no aparece, dejá string vacío o 0. No inventes datos.
- Los montos son números sin puntos ni símbolos (ej: 15000000).
- "moneda" es "ARS" o "USD". Si habla de dólares/USD poné "USD".
- El DNI son solo números sin puntos.
- "fecha" en formato YYYY-MM-DD si la menciona, si no vacío.
- "transferencia_incluida": true si el precio ya incluye la transferencia, false si se paga aparte.
- "notas_faltantes": lista breve en español de los datos importantes que faltan para el boleto.
- Elegí "car_id" SOLO si el auto mencionado coincide claramente con uno de la lista. Si no, dejalo vacío.

Autos en stock (id => descripción):
${carList || "(sin autos)"}

Texto del vendedor:
"""${text}"""`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Lovable-API-Key": key },
      body: JSON.stringify({
        model: "google/gemini-3.5-flash",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      }),
    });

    if (!res.ok) {
      const t = await res.text();
      return new Response(JSON.stringify({ error: "AI error", details: t }), {
        status: res.status, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await res.json();
    const raw = data.choices?.[0]?.message?.content ?? "{}";
    let p: any = {};
    try { p = typeof raw === "string" ? JSON.parse(raw) : raw; } catch { p = {}; }

    const num = (v: any) => {
      const n = Number(String(v ?? "").replace(/[^\d.-]/g, ""));
      return Number.isFinite(n) ? n : 0;
    };
    const validCar = cars.find((c) => c.id === p.car_id)?.id || "";

    return new Response(JSON.stringify({
      comprador_nombre: p.comprador_nombre || "",
      comprador_dni: String(p.comprador_dni || "").replace(/\D/g, ""),
      comprador_domicilio: p.comprador_domicilio || "",
      comprador_telefono: p.comprador_telefono || "",
      forma_pago: p.forma_pago || "",
      lugar: p.lugar || "",
      monto: num(p.monto),
      moneda: p.moneda === "USD" ? "USD" : "ARS",
      cotizacion_usd: num(p.cotizacion_usd),
      sena: num(p.sena),
      monto_financiar: num(p.monto_financiar),
      cuotas: num(p.cuotas),
      parte_pago: p.parte_pago || "",
      parte_pago_valor: num(p.parte_pago_valor),
      valor_transferencia: num(p.valor_transferencia),
      transferencia_incluida: p.transferencia_incluida !== false,
      patente: String(p.patente || "").toUpperCase(),
      car_id: validCar,
      fecha: /^\d{4}-\d{2}-\d{2}$/.test(p.fecha || "") ? p.fecha : "",
      notas_faltantes: p.notas_faltantes || "",
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
