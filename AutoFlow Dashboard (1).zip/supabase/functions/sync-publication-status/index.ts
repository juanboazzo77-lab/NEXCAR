import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { GRAPH, HttpError, admin, getConnection, json, requireUser } from '../_shared/publisher.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const user = await requireUser(req);
    const { vehicleId } = await req.json().catch(() => ({}));
    const db = admin();

    let query = db.from('publications').select('*').eq('user_id', user.id).not('external_id', 'is', null);
    if (vehicleId) query = query.eq('vehicle_id', vehicleId);
    const { data: rows } = await query;

    const updated: any[] = [];
    for (const row of rows || []) {
      try {
        if (row.channel === 'mercadolibre') {
          const { token } = await getConnection(db, user.id, 'mercadolibre');
          const res = await fetch(`https://api.mercadolibre.com/items/${row.external_id}`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          const item = await res.json();
          if (!res.ok) continue;
          const status = item.status === 'active' ? 'published' : item.status === 'paused' ? 'paused' : item.status === 'closed' ? 'closed' : row.status;
          await db.from('publications').update({ status, external_url: item.permalink || row.external_url, response_snapshot: item }).eq('id', row.id);
          updated.push({ id: row.id, channel: row.channel, status });
        } else {
          const { token } = await getConnection(db, user.id, row.channel);
          const fields = row.channel === 'instagram' ? 'permalink' : 'permalink_url';
          const res = await fetch(`${GRAPH}/${row.external_id}?fields=${fields}&access_token=${token}`);
          const jsonRes = await res.json();
          if (!res.ok) continue;
          const url = jsonRes.permalink || jsonRes.permalink_url || row.external_url;
          await db.from('publications').update({ external_url: url }).eq('id', row.id);
          updated.push({ id: row.id, channel: row.channel, status: row.status });
        }
      } catch {
        // Un canal caído no debe frenar la sincronización del resto.
      }
    }

    return json({ updated }, 200, corsHeaders);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message }, status, corsHeaders);
  }
});
