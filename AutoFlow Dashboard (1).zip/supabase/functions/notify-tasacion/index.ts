// Envía por WhatsApp la info de una nueva tasación (trade-in) + las fotos cargadas.
// Público: lo llama el formulario del sitio de clientes con el id de la solicitud.
import { createClient } from 'npm:@supabase/supabase-js@2';
import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

async function waAccount(admin: any, userId: string) {
  const { data } = await admin
    .from('channel_accounts')
    .select('access_token, external_id')
    .eq('user_id', userId)
    .eq('platform', 'whatsapp')
    .not('access_token', 'is', null)
    .order('estado', { ascending: true })
    .limit(1)
    .maybeSingle();
  return data;
}

async function sendText(acc: any, to: string, body: string) {
  const res = await fetch(`https://graph.facebook.com/v21.0/${acc.external_id}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${acc.access_token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ messaging_product: 'whatsapp', to, type: 'text', text: { body } }),
  });
  return { ok: res.ok, data: await res.json() };
}

async function sendImage(acc: any, to: string, link: string, caption?: string) {
  const res = await fetch(`https://graph.facebook.com/v21.0/${acc.external_id}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${acc.access_token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ messaging_product: 'whatsapp', to, type: 'image', image: { link, caption } }),
  });
  return { ok: res.ok, data: await res.json() };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  const json = (b: unknown, status = 200) =>
    new Response(JSON.stringify(b), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

  try {
    const body = await req.json().catch(() => ({}));
    const requestId = String(body?.request_id ?? '');
    if (!UUID_RE.test(requestId)) return json({ error: 'request_id inválido' }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE_KEY);
    const { data: r } = await admin.from('trade_in_requests').select('*').eq('id', requestId).maybeSingle();
    if (!r) return json({ error: 'Solicitud no encontrada' }, 404);

    // Dueño: el de la solicitud, o el del sitio público por defecto
    let ownerId: string | null = r.owner_user_id;
    if (!ownerId) {
      const { data: st } = await admin
        .from('public_settings')
        .select('owner_user_id')
        .not('owner_user_id', 'is', null)
        .order('is_default', { ascending: false })
        .limit(1)
        .maybeSingle();
      ownerId = st?.owner_user_id ?? null;
    }
    if (!ownerId) return json({ ok: false, reason: 'sin dueño configurado' });

    const { data: phones } = await admin.from('notification_phones').select('phone').eq('user_id', ownerId);
    if (!phones?.length) return json({ ok: false, reason: 'sin teléfonos configurados' });

    const acc = await waAccount(admin, ownerId);
    if (!acc?.access_token || !acc?.external_id) return json({ ok: false, reason: 'sin cuenta de WhatsApp conectada' });

    const fotos: string[] = Array.isArray(r.fotos) ? (r.fotos as string[]).slice(0, 8) : [];
    const lines = [
      '🚙 *Nueva tasación recibida*',
      '',
      `👤 ${r.cliente_nombre}`,
      r.cliente_telefono ? `📞 ${r.cliente_telefono}` : null,
      r.cliente_email ? `✉️ ${r.cliente_email}` : null,
      '',
      `🚗 ${[r.marca, r.modelo, r.version].filter(Boolean).join(' ')}${r.anio ? ` (${r.anio})` : ''}`,
      r.kilometros != null ? `📏 ${Number(r.kilometros).toLocaleString('es-AR')} km` : null,
      [r.combustible, r.caja].filter(Boolean).join(' · ') || null,
      r.estado_general ? `🔧 Estado: ${r.estado_general}` : null,
      r.precio_pretendido != null ? `💰 Pretende: $${Number(r.precio_pretendido).toLocaleString('es-AR')}` : null,
      r.observaciones ? `📝 ${r.observaciones}` : null,
      fotos.length ? `\n📷 ${fotos.length} foto(s) a continuación` : '\n📷 Sin fotos',
    ].filter(Boolean);
    const text = lines.join('\n');

    const results: any[] = [];
    for (const p of phones) {
      const to = String(p.phone).replace(/\D/g, '');
      const t = await sendText(acc, to, text);
      results.push({ phone: to, text: t.ok, error: t.ok ? undefined : t.data });
      for (const url of fotos) {
        const img = await sendImage(acc, to, url);
        if (!img.ok) results.push({ phone: to, image: url, error: img.data });
      }
    }

    return json({ ok: true, sent: results.length, results });
  } catch (e) {
    console.error('notify-tasacion', e);
    return json({ error: (e as Error).message }, 500);
  }
});
