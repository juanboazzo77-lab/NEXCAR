import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { CHANNELS, Channel, HttpError, admin, getOwnVehicle, json, publishingEnabled, requireUser } from '../_shared/publisher.ts';
import { validateVehicle } from '../_shared/publisher-validate.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const user = await requireUser(req);
    const body = await req.json();
    const vehicleId = body?.vehicleId;
    const channels: Channel[] = Array.isArray(body?.channels)
      ? body.channels.filter((c: Channel) => CHANNELS.includes(c))
      : CHANNELS;
    if (!vehicleId) throw new HttpError(400, 'Falta el vehículo');

    const db = admin();
    const vehicle = await getOwnVehicle(db, user.id, vehicleId);
    const result = await validateVehicle(db, vehicle, channels);

    // Token de confirmación de un solo uso: sólo si la validación pasó.
    let confirmationToken: string | null = null;
    if (result.ok && channels.length) {
      confirmationToken = crypto.randomUUID();
      await db.from('publish_confirmations').insert({
        user_id: user.id, vehicle_id: vehicleId, token: confirmationToken, channels,
      });
    }

    return json({ ...result, channels, confirmationToken, publishingEnabled: publishingEnabled() }, 200, corsHeaders);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message }, status, corsHeaders);
  }
});
