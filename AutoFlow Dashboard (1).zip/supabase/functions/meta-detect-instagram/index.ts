import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { admin, GRAPH, requireUser, json } from '../_shared/publisher.ts';

/**
 * Revisa las Páginas de Facebook ya conectadas y detecta la cuenta profesional
 * de Instagram vinculada (sin volver a hacer todo el OAuth).
 */
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const user = await requireUser(req);
    const db = admin();

    const { data: pages } = await db.from('connected_accounts')
      .select('*').eq('user_id', user.id).eq('platform', 'facebook');

    if (!pages?.length) {
      return json({ ok: false, error: 'No hay ninguna Página de Facebook conectada.' }, 200, corsHeaders);
    }

    const details: any[] = [];
    let found = 0;

    for (const page of pages) {
      const token = page.access_token;
      const res = await fetch(
        `${GRAPH}/${page.account_external_id}?fields=name,instagram_business_account{id,username},connected_instagram_account{id,username}&access_token=${token}`,
      );
      const data = await res.json();
      if (!res.ok) {
        details.push({ page: page.account_name, ok: false, error: data?.error?.message });
        continue;
      }
      const ig = data.instagram_business_account || data.connected_instagram_account;
      if (!ig?.id) {
        details.push({
          page: data.name || page.account_name,
          ok: false,
          error: 'La Página no tiene una cuenta profesional de Instagram vinculada, o falta el permiso instagram_basic.',
        });
        continue;
      }
      found++;
      const payload = {
        user_id: user.id,
        platform: 'instagram',
        account_name: ig.username || data.name,
        account_external_id: ig.id,
        access_token: token,
        expires_at: page.expires_at,
        meta: { ig_user_id: ig.id, page_id: page.account_external_id, ig_username: ig.username, selected: true },
        status: 'conectado',
      };
      const { data: existing } = await db.from('connected_accounts').select('id')
        .eq('user_id', user.id).eq('platform', 'instagram')
        .eq('account_external_id', ig.id).maybeSingle();
      if (existing?.id) await db.from('connected_accounts').update(payload).eq('id', existing.id);
      else await db.from('connected_accounts').insert(payload);

      await db.from('connected_accounts')
        .update({ meta: { ...(page.meta || {}), ig_user_id: ig.id } })
        .eq('id', page.id);

      details.push({ page: data.name || page.account_name, ok: true, instagram: ig.username || ig.id });
    }

    return json({ ok: found > 0, found, details }, 200, corsHeaders);
  } catch (e) {
    const status = (e as any).status || 500;
    return json({ ok: false, error: (e as Error).message }, status, corsHeaders);
  }
});
