// Envía un mensaje de WhatsApp usando la Cloud API con el token del channel_account.
import { createClient } from 'npm:@supabase/supabase-js@2';
import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: authHeader } } });
    const token = authHeader.replace('Bearer ', '');
    const { data: claims } = await supabase.auth.getClaims(token);
    if (!claims?.claims) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    const userId = claims.claims.sub as string;

    const { conversation_id, text } = await req.json();
    if (!conversation_id || !text) return new Response(JSON.stringify({ error: 'Faltan datos' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

    const { data: conv } = await supabase.from('inbox_conversations').select('*, channel_accounts(*)').eq('id', conversation_id).eq('user_id', userId).maybeSingle();
    if (!conv) return new Response(JSON.stringify({ error: 'Conversación no encontrada' }), { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    const acc = conv.channel_accounts;
    if (!acc) return new Response(JSON.stringify({ error: 'Sin cuenta vinculada' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

    if (acc.platform === 'whatsapp') {
      if (!acc.access_token || !acc.external_id) return new Response(JSON.stringify({ error: 'Cuenta WhatsApp sin token o phone_number_id' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      const res = await fetch(`https://graph.facebook.com/v21.0/${acc.external_id}/messages`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${acc.access_token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ messaging_product: 'whatsapp', to: conv.external_contact_id, type: 'text', text: { body: text } }),
      });
      const data = await res.json();
      if (!res.ok) return new Response(JSON.stringify({ error: `Meta ${res.status}: ${JSON.stringify(data)}` }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      const extId = data?.messages?.[0]?.id;
      await supabase.from('inbox_messages').insert({ user_id: userId, conversation_id, direction: 'out', body: text, external_message_id: extId, sent_at: new Date().toISOString() });
      await supabase.from('inbox_conversations').update({ last_message_text: text, last_message_at: new Date().toISOString() }).eq('id', conversation_id);
      return new Response(JSON.stringify({ ok: true }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    if (acc.platform === 'instagram') {
      if (!acc.access_token) return new Response(JSON.stringify({ error: 'Cuenta IG sin access_token' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      const res = await fetch(`https://graph.facebook.com/v21.0/me/messages?access_token=${acc.access_token}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recipient: { id: conv.external_contact_id }, message: { text } }),
      });
      const data = await res.json();
      if (!res.ok) return new Response(JSON.stringify({ error: `Meta ${res.status}: ${JSON.stringify(data)}` }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      await supabase.from('inbox_messages').insert({ user_id: userId, conversation_id, direction: 'out', body: text, external_message_id: data?.message_id, sent_at: new Date().toISOString() });
      await supabase.from('inbox_conversations').update({ last_message_text: text, last_message_at: new Date().toISOString() }).eq('id', conversation_id);
      return new Response(JSON.stringify({ ok: true }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    return new Response(JSON.stringify({ error: 'Plataforma no soportada para envío' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (e) {
    console.error('send error', e);
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
