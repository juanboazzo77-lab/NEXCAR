// IA del Inbox Comercial:
//   action: 'analyze'        -> analiza UNA conversación, guarda en conversation_analyses y actualiza score en inbox_conversations
//   action: 'reply'          -> genera respuesta sugerida para UNA conversación (opcional template_id)
//   action: 'recommend'      -> recomienda plantilla y devuelve versión personalizada
//   action: 'ask'            -> Q&A sobre uno o varios chats seleccionados

import { createClient } from 'npm:@supabase/supabase-js@2';
import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';

const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY')!;
const MODEL = 'google/gemini-2.5-flash';

async function llm(messages: Array<{ role: string; content: string }>, json = false) {
  const res = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: MODEL,
      messages,
      ...(json ? { response_format: { type: 'json_object' } } : {}),
    }),
  });
  if (res.status === 429) throw new Error('Límite de uso de IA alcanzado, intentá más tarde.');
  if (res.status === 402) throw new Error('Sin créditos de IA. Agregá créditos en Lovable AI.');
  const data = await res.json();
  if (!res.ok) throw new Error(`AI ${res.status}: ${JSON.stringify(data)}`);
  return data?.choices?.[0]?.message?.content ?? '';
}

async function loadConversation(supabase: any, userId: string, convId: string) {
  const { data: conv } = await supabase
    .from('inbox_conversations').select('*').eq('id', convId).eq('user_id', userId).maybeSingle();
  if (!conv) throw new Error('Conversación no encontrada');
  const { data: msgs } = await supabase
    .from('inbox_messages').select('*').eq('conversation_id', convId).order('sent_at', { ascending: true });
  return { conv, msgs: msgs ?? [] };
}

function fmtChat(conv: any, msgs: any[]) {
  const header = `Conversación con ${conv.contact_name ?? conv.contact_handle ?? 'cliente'} (${conv.platform})`;
  const lines = msgs.map((m: any) => `${m.direction === 'in' ? 'Cliente' : 'Vendedor'}: ${m.body ?? ''}`);
  return header + '\n' + lines.join('\n');
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: authHeader } } });
    const token = authHeader.replace('Bearer ', '');
    const { data: claims } = await supabase.auth.getClaims(token);
    if (!claims?.claims) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    const userId = claims.claims.sub as string;

    const body = await req.json();
    const action = body.action as string;

    if (action === 'analyze') {
      const { conv, msgs } = await loadConversation(supabase, userId, body.conversation_id);
      const text = fmtChat(conv, msgs);
      const sys = `Sos un analista comercial. Analizá la conversación y devolvé SOLO un JSON con esta forma exacta:
{"resumen":"","intencion":"","servicio_interes":"","problema":"","nivel_interes":"bajo|medio|alto","nivel_urgencia":"baja|media|alta","presupuesto":"","objeciones":"","proximos_pasos":"","probabilidad_cierre":0-100,"lead_score":0-100,"clasificacion":"frio|tibio|caliente"}`;
      const raw = await llm([{ role: 'system', content: sys }, { role: 'user', content: text }], true);
      let parsed: any = {};
      try { parsed = JSON.parse(raw); } catch { parsed = { resumen: raw }; }
      const { data: saved } = await supabase.from('conversation_analyses').insert({
        user_id: userId,
        conversation_id: conv.id,
        resumen: parsed.resumen,
        intencion: parsed.intencion,
        servicio_interes: parsed.servicio_interes,
        problema: parsed.problema,
        nivel_interes: parsed.nivel_interes,
        nivel_urgencia: parsed.nivel_urgencia,
        presupuesto: parsed.presupuesto,
        objeciones: parsed.objeciones,
        proximos_pasos: parsed.proximos_pasos,
        probabilidad_cierre: Number(parsed.probabilidad_cierre) || null,
        lead_score: Number(parsed.lead_score) || null,
        clasificacion: parsed.clasificacion,
        modelo: MODEL,
        raw_response: parsed,
      }).select('*').single();
      await supabase.from('inbox_conversations').update({
        lead_score: Number(parsed.lead_score) || null,
        lead_classification: parsed.clasificacion ?? null,
      }).eq('id', conv.id);
      return new Response(JSON.stringify({ analysis: saved }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    if (action === 'reply') {
      const { conv, msgs } = await loadConversation(supabase, userId, body.conversation_id);
      let templateContent = '';
      if (body.template_id) {
        const { data: t } = await supabase.from('message_templates').select('contenido').eq('id', body.template_id).maybeSingle();
        templateContent = t?.contenido ?? '';
      }
      const sys = `Sos vendedor profesional, cordial y directo (Argentina). Generá UNA respuesta sugerida para enviar al cliente. Máximo 4 líneas. Sin emojis excesivos.${templateContent ? ` Basate en esta plantilla y adaptala: "${templateContent}"` : ''}`;
      const reply = await llm([{ role: 'system', content: sys }, { role: 'user', content: fmtChat(conv, msgs) }]);
      return new Response(JSON.stringify({ reply: reply.trim() }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    if (action === 'recommend') {
      const { conv, msgs } = await loadConversation(supabase, userId, body.conversation_id);
      const { data: templates } = await supabase.from('message_templates').select('id, categoria, titulo, contenido').eq('user_id', userId);
      if (!templates?.length) return new Response(JSON.stringify({ error: 'No hay plantillas creadas' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      const list = templates.map((t: any, i: number) => `${i + 1}. [${t.categoria}] ${t.titulo}: ${t.contenido}`).join('\n');
      const sys = `Sos asistente comercial. Elegí la mejor plantilla para responder este chat y adaptala al contexto. Devolvé JSON: {"template_index":N,"personalized":"texto adaptado"}`;
      const raw = await llm([
        { role: 'system', content: sys },
        { role: 'user', content: `PLANTILLAS:\n${list}\n\nCHAT:\n${fmtChat(conv, msgs)}` },
      ], true);
      let parsed: any = {}; try { parsed = JSON.parse(raw); } catch { parsed = {}; }
      const chosen = templates[Math.max(0, Math.min(templates.length - 1, (Number(parsed.template_index) || 1) - 1))];
      return new Response(JSON.stringify({ template: chosen, personalized: parsed.personalized ?? '' }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    if (action === 'ask') {
      const ids: string[] = body.conversation_ids ?? [];
      const question: string = body.question;
      if (!ids.length || !question) return new Response(JSON.stringify({ error: 'Faltan datos' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      const chunks: string[] = [];
      for (const id of ids.slice(0, 30)) {
        try {
          const { conv, msgs } = await loadConversation(supabase, userId, id);
          chunks.push(`--- CHAT ${conv.contact_name ?? conv.contact_handle} ---\n${fmtChat(conv, msgs)}`);
        } catch { /* skip */ }
      }
      const sys = `Sos analista comercial. Respondé la pregunta usando SOLO los chats que se te pasan. Sé concreto y mencioná nombres cuando corresponda.`;
      const answer = await llm([
        { role: 'system', content: sys },
        { role: 'user', content: `CHATS:\n${chunks.join('\n\n')}\n\nPREGUNTA:\n${question}` },
      ]);
      return new Response(JSON.stringify({ answer: answer.trim() }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    return new Response(JSON.stringify({ error: 'Acción inválida' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (e) {
    console.error('inbox-ai error', e);
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
