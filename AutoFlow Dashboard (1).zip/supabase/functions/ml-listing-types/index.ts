import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import { getValidMlAccount } from '../_shared/ml-auth.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const auth = req.headers.get('Authorization');
    if (!auth) throw new Error('No autenticado');
    const userSupa = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: auth } } });
    const { data: { user } } = await userSupa.auth.getUser();
    if (!user) throw new Error('No autenticado');

    const { account_id, category_id } = await req.json().catch(() => ({}));
    const categoryId = /^ML[A-Z]\d+$/.test(String(category_id || '')) ? String(category_id) : 'MLA1744';

    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const acc = await getValidMlAccount(admin, user.id, account_id);

    const siteId = (acc.meta as any)?.site_id || 'MLA';
    const mlUserId = (acc.meta as any)?.ml_user_id || acc.account_external_id;

    const [siteResponse, availableResponse] = await Promise.all([
      fetch(`https://api.mercadolibre.com/sites/${siteId}/listing_types`),
      fetch(`https://api.mercadolibre.com/users/${mlUserId}/available_listing_types?category_id=${categoryId}`, {
        headers: { Authorization: `Bearer ${acc.access_token}` },
      }),
    ]);
    const allTypes: any[] = siteResponse.ok ? await siteResponse.json() : [];
    const availableBody = await availableResponse.json();
    if (!availableResponse.ok) throw new Error(availableBody?.message || 'No se pudieron consultar los tipos de publicación de la cuenta');
    const list = Array.isArray(availableBody)
      ? availableBody
      : (availableBody?.available || availableBody?.available_listing_types || []);
    const results: any[] = list.map((it: any) => {
      const id = it.id || it.listing_type_id;
      const siteType = allTypes.find((type: any) => type.id === id);
      // remaining_listings === null significa cupo ilimitado (publicaciones pagas)
      const remaining = it.remaining_listings ?? it.available_listings ?? it.available_quantity ?? null;
      return {
        listing_type_id: id,
        name: it.name || siteType?.name || id,
        available_quantity: remaining,
        used_quantity: it.used_listings ?? 0,
        currency: it.currency_id || 'ARS',
        active: remaining === null || Number(remaining) > 0,
        raw: it,
      };
    });


    // Fallback: si la cuenta no devolvió cupos, mostramos los tipos del site
    const final = results.length ? results : allTypes.map((type: any) => ({
      listing_type_id: type.id,
      name: type.name,
      available_quantity: null,
      used_quantity: 0,
      currency: 'ARS',
      active: true,
      raw: type,
    }));

    // Cachear en DB
    await admin.from('ml_listing_types').delete().eq('publishing_account_id', acc.id);
    if (final.length > 0) {
      await admin.from('ml_listing_types').insert(final.map(f => ({
        user_id: user.id,
        publishing_account_id: acc.id,
        listing_type_id: f.listing_type_id,
        name: f.name,
        available_quantity: f.available_quantity ?? 0,
        used_quantity: f.used_quantity ?? 0,
        currency: f.currency,
        active: f.active,
        raw: f.raw,
      })));
    }

    return new Response(JSON.stringify({ category_id: categoryId, account_id: acc.id, listing_types: final }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
