import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';

const GRAPH_VERSION = 'v23.0';

const encode = (value: string) =>
  btoa(value).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '');

const sign = async (value: string, secret: string) => {
  const key = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'],
  );
  const signature = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(value));
  return encode(String.fromCharCode(...new Uint8Array(signature)));
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const url = new URL(req.url);
    const auth = req.headers.get('Authorization');
    if (!auth?.startsWith('Bearer ')) throw new Error('Sesión requerida');
    const client = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: auth } } },
    );
    const { data: { user } } = await client.auth.getUser();
    if (!user) throw new Error('Sesión inválida');

    const appId = Deno.env.get('META_APP_ID');
    const appSecret = Deno.env.get('META_APP_SECRET');
    const fbConfigId = Deno.env.get('META_FB_CONFIG_ID');
    if (!appId || !appSecret) throw new Error('Meta no está configurado');
    const redirect = `${Deno.env.get('SUPABASE_URL')}/functions/v1/meta-oauth-callback`;
    const requestedReturnTo = url.searchParams.get('return_to') ?? '';
    let returnTo = 'https://grupo-boazzo-control.lovable.app/canales';
    try {
      const candidate = new URL(requestedReturnTo);
      const allowed = candidate.protocol === 'https:' && (
        candidate.hostname === 'grupo-boazzo-control.lovable.app' ||
        candidate.hostname.endsWith('.lovable.app')
      );
      if (allowed) returnTo = `${candidate.origin}/canales`;
    } catch { /* use the published app */ }

    const statePayload = encode(JSON.stringify({ uid: user.id, returnTo, exp: Date.now() + 10 * 60_000 }));
    const state = `${statePayload}.${await sign(statePayload, appSecret)}`;
    const scope = [
      'pages_show_list', 'pages_manage_posts', 'pages_read_engagement',
      'instagram_basic', 'instagram_content_publish', 'business_management'
    ].join(',');
    const configParam = fbConfigId ? `&config_id=${encodeURIComponent(fbConfigId)}` : '';
    const authUrl = `https://www.facebook.com/${GRAPH_VERSION}/dialog/oauth?client_id=${appId}&redirect_uri=${encodeURIComponent(redirect)}&state=${encodeURIComponent(state)}&scope=${scope}&response_type=code&auth_type=rerequest${configParam}`;
    return new Response(JSON.stringify({ url: authUrl }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
