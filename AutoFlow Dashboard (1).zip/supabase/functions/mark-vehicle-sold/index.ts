import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { HttpError, admin, getConnection, getOwnVehicle, json, requireUser } from '../_shared/publisher.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const user = await requireUser(req);
    const { vehicleId, mercadolibreAction } = await req.json();
    if (!vehicleId) throw new HttpError(400, 'Falta el vehículo');
    if (mercadolibreAction && !['none', 'paused', 'closed'].includes(mercadolibreAction))
      throw new HttpError(400, 'Acción inválida para Mercado Libre');

    const db = admin();
    await getOwnVehicle(db, user.id, vehicleId);
    await db.from('vehicles').update({ status: 'sold' }).eq('id', vehicleId).eq('user_id', user.id);

    let mercadolibre: any = { action: mercadolibreAction || 'none' };
    if (mercadolibreAction && mercadolibreAction !== 'none') {
      const { data: pub } = await db.from('publications').select('*')
        .eq('vehicle_id', vehicleId).eq('channel', 'mercadolibre').maybeSingle();
      if (pub?.external_id) {
        const { token } = await getConnection(db, user.id, 'mercadolibre');
        const res = await fetch(`https://api.mercadolibre.com/items/${pub.external_id}`, {
          method: 'PUT',
          headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: mercadolibreAction }),
        });
        const item = await res.json().catch(() => ({}));
        if (res.ok) {
          await db.from('publications').update({ status: mercadolibreAction }).eq('id', pub.id);
          mercadolibre.ok = true;
        } else {
          mercadolibre.ok = false;
          mercadolibre.error = item?.message || 'Mercado Libre rechazó el cambio de estado';
        }
      } else {
        mercadolibre.ok = false;
        mercadolibre.error = 'No hay un aviso de Mercado Libre para este vehículo';
      }
    }

    // Las publicaciones de Instagram y Facebook no se borran automáticamente.
    return json({ ok: true, mercadolibre }, 200, corsHeaders);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message }, status, corsHeaders);
  }
});
