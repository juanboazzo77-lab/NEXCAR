import { admin } from '../_shared/publisher.ts';
import { connectionsUrl, consumeState, redirectTo, safeOrigin } from '../_shared/oauth-state.ts';

/** Callback de Instagram Login (sin Facebook): canjea el código y guarda la cuenta profesional. */
Deno.serve(async (req) => {
  const db = admin();
  let origin = safeOrigin(null);
  try {
    const url = new URL(req.url);
    const code = url.searchParams.get('code');
    const state = url.searchParams.get('state') ?? '';
    const igError = url.searchParams.get('error_description') || url.searchParams.get('error');
    if (igError) {
      console.error('oauth-instagram-callback authorization_failed', igError);
      return redirectTo(connectionsUrl(origin, { provider: 'instagram', connected: '0', error: 'authorization_failed' }));
    }
    if (!code) throw new Error('Instagram no devolvió el código de autorización.');

    const consumed = await consumeState(db, state, 'instagram');
    origin = consumed.returnTo;
    const userId = consumed.userId;

    const appId = Deno.env.get('INSTAGRAM_APP_ID')!;
    const appSecret = Deno.env.get('INSTAGRAM_APP_SECRET')!;
    const redirectUri = Deno.env.get('INSTAGRAM_REDIRECT_URI')
      || `${Deno.env.get('SUPABASE_URL')}/functions/v1/oauth-instagram-callback`;

    const tokenRes = await fetch('https://api.instagram.com/oauth/access_token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: appId,
        client_secret: appSecret,
        grant_type: 'authorization_code',
        redirect_uri: redirectUri,
        code: code.replace(/#_$/, ''),
      }),
    });
    const short = await tokenRes.json();
    if (!tokenRes.ok || !short?.access_token) {
      throw new Error(short?.error_message || 'Instagram rechazó la autorización.');
    }

    // Token de larga duración (60 días).
    const longRes = await fetch(
      `https://graph.instagram.com/access_token?grant_type=ig_exchange_token&client_secret=${appSecret}&access_token=${short.access_token}`,
    );
    const long = await longRes.json().catch(() => ({}));
    const token = long?.access_token || short.access_token;
    const expiresAt = long?.expires_in
      ? new Date(Date.now() + Number(long.expires_in) * 1000).toISOString() : null;

    const meRes = await fetch(`https://graph.instagram.com/v23.0/me?fields=user_id,username&access_token=${token}`);
    const me = await meRes.json();
    if (!meRes.ok) throw new Error(me?.error?.message || 'No pudimos leer tu cuenta de Instagram.');
    const igId = String(me.user_id || short.user_id);

    const payload = {
      user_id: userId,
      platform: 'instagram',
      account_name: me.username || 'Instagram',
      account_external_id: igId,
      access_token: token,
      expires_at: expiresAt,
      meta: { ig_user_id: igId, ig_username: me.username, selected: true, login_type: 'instagram_login' },
      status: 'conectado',
    };
    const { data: existing } = await db.from('connected_accounts').select('id')
      .eq('user_id', userId).eq('platform', 'instagram').eq('account_external_id', igId).maybeSingle();
    if (existing?.id) await db.from('connected_accounts').update(payload).eq('id', existing.id);
    else await db.from('connected_accounts').insert(payload);

    return redirectTo(connectionsUrl(origin, { provider: 'instagram', connected: '1' }));
  } catch (e) {
    console.error('oauth-instagram-callback', (e as Error).message);
    return redirectTo(connectionsUrl(origin, { provider: 'instagram', connected: '0', error: 'authorization_failed' }));
  }
});
