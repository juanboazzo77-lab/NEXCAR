import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';

const GRAPH = 'https://graph.facebook.com/v23.0';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    const userSupa = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user } } = await userSupa.auth.getUser();
    if (!user) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

    const { code, waba_id, phone_number_id, responsable, nombre_interno } = await req.json();
    if (!code || !waba_id || !phone_number_id) {
      return new Response(JSON.stringify({ error: 'Faltan datos (code/waba_id/phone_number_id)' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    const appId = Deno.env.get('META_APP_ID')!;
    const appSecret = Deno.env.get('META_APP_SECRET')!;

    // 1) Exchange code → access_token (Business Integration System User Token)
    const tokRes = await fetch(`${GRAPH}/oauth/access_token?client_id=${appId}&client_secret=${appSecret}&code=${code}`);
    const tok = await tokRes.json();
    if (!tokRes.ok) throw new Error(`Token error: ${JSON.stringify(tok)}`);
    const accessToken: string = tok.access_token;

    // 2) Subscribe our app to the WABA so webhooks llegan
    const subRes = await fetch(`${GRAPH}/${waba_id}/subscribed_apps`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${accessToken}` },
    });
    const subJson = await subRes.json();
    if (!subRes.ok) console.warn('subscribed_apps warn', subJson);

    // 3) Register the phone number (Cloud API) — pin opcional, dejamos default 000000 si no se pasa
    const regRes = await fetch(`${GRAPH}/${phone_number_id}/register`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${accessToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ messaging_product: 'whatsapp', pin: '000000' }),
    });
    const regJson = await regRes.json();
    // No fallar si ya está registrado
    if (!regRes.ok && regJson?.error?.code !== 133005) console.warn('register warn', regJson);

    // 4) Fetch phone info (display number)
    const phoneRes = await fetch(`${GRAPH}/${phone_number_id}?fields=display_phone_number,verified_name&access_token=${accessToken}`);
    const phone = await phoneRes.json();

    // 5) Upsert channel_account con service role
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const display = phone?.display_phone_number || '';
    const vname = phone?.verified_name || '';

    const { data: existing } = await admin.from('channel_accounts')
      .select('id').eq('user_id', user.id).eq('platform', 'whatsapp').eq('external_id', phone_number_id).maybeSingle();

    const payload: any = {
      user_id: user.id,
      platform: 'whatsapp',
      nombre_interno: nombre_interno?.trim() || vname || `WhatsApp ${display}`,
      responsable: responsable || null,
      estado: 'conectado',
      external_id: phone_number_id,
      phone_number: display,
      waba_id,
      access_token: accessToken,
      fecha_conexion: new Date().toISOString(),
    };

    if (existing?.id) {
      await admin.from('channel_accounts').update(payload).eq('id', existing.id);
    } else {
      await admin.from('channel_accounts').insert(payload);
    }

    return new Response(JSON.stringify({ ok: true, phone: display, verified_name: vname }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
