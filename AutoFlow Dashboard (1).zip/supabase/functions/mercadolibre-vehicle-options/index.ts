import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { admin, HttpError, json, requireUser } from '../_shared/publisher.ts';
import { getValidMlAccount } from '../_shared/ml-auth.ts';

type Known = { id: string; value_id?: string; value_name?: string };
type Body = {
  categoryId?: string;
  domainId?: string;
  attributeId: 'BRAND' | 'MODEL' | 'VEHICLE_YEAR' | 'TRIM';
  knownAttributes?: Known[];
  search?: string;
};

const DEFAULT_DOMAIN = 'MLA-CARS_AND_VANS';
const DEFAULT_CATEGORY = 'MLA1744'; // Autos, Camionetas y 4x4
const ATTRS = ['BRAND', 'MODEL', 'VEHICLE_YEAR', 'TRIM', 'SPECS'];

/** Atributos de ficha técnica que intentamos completar solos al elegir la versión. */
const SPEC_ATTRS = [
  'FUEL_TYPE', 'TRANSMISSION', 'ENGINE', 'ENGINE_DISPLACEMENT', 'HORSEPOWER',
  'DOORS', 'VEHICLE_BODY_TYPE', 'TRACTION_CONTROL', 'PASSENGER_CAPACITY',
];

const norm = (s: string) =>
  s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();

function dedupe(options: { id: string | null; name: string }[]) {
  const map = new Map<string, { id: string | null; name: string }>();
  for (const o of options) {
    const name = String(o.name || '').trim();
    if (!name) continue;
    const key = norm(name);
    if (!map.has(key)) map.set(key, { id: o.id || null, name });
  }
  return [...map.values()].sort((a, b) => a.name.localeCompare(b.name, 'es'));
}

/** Valores oficiales que vienen dentro de la categoría (cuando existen). */
async function categoryValues(categoryId: string, attributeId: string) {
  const res = await fetch(`https://api.mercadolibre.com/categories/${categoryId}/attributes`);
  if (!res.ok) return null;
  const attrs = await res.json();
  const attr = Array.isArray(attrs) ? attrs.find((a: any) => a.id === attributeId) : null;
  if (!attr?.values?.length) return null;
  return attr.values.map((v: any) => ({ id: v.id ?? null, name: v.name }));
}

/** top_values del dominio: es lo que usa Mercado Libre para los selectores encadenados. */
async function topValues(domainId: string, attributeId: string, known: Known[], token?: string) {
  // Cuando tenemos el value_id oficial mandamos sólo eso: ML filtra mucho mejor.
  const knownAttributes = known.map((k) =>
    k.value_id ? { id: k.id, value_id: k.value_id } : { id: k.id, value_name: k.value_name }
  );
  const res = await fetch(
    `https://api.mercadolibre.com/catalog_domains/${domainId}/attributes/${attributeId}/top_values?limit=1000`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify(knownAttributes.length ? { known_attributes: knownAttributes } : {}),
    },
  );
  if (!res.ok) return [];
  const data = await res.json().catch(() => []);
  const list = Array.isArray(data) ? data : (data?.values || data?.top_values || []);
  return (list as any[]).map((v: any) => ({
    id: v.id ?? v.value_id ?? null,
    name: String(v.name ?? v.value_name ?? ''),
  }));
}

/** Años 1950 → próximo, por si ML no devuelve VEHICLE_YEAR para ese modelo. */
function fallbackYears() {
  const max = new Date().getFullYear() + 1;
  return Array.from({ length: max - 1949 }, (_, i) => ({ id: null, name: String(max - i) }));
}


Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const user = await requireUser(req);
    const body = (await req.json()) as Body;
    if (!ATTRS.includes(body?.attributeId)) throw new HttpError(400, 'Atributo no soportado');

    const domainId = body.domainId || DEFAULT_DOMAIN;
    // El token nunca sale al navegador: sólo se usa acá.
    let token: string | undefined;
    let authError: string | undefined;
    try {
      token = (await getValidMlAccount(admin(), user.id)).access_token as string;
    } catch (e) {
      authError = (e as Error).message;
    }

    const known = (body.knownAttributes || []).filter(
      (k) => k?.id && (k.value_id || k.value_name),
    );


    if (body.attributeId === 'SPECS') {
      const specs: Record<string, string> = {};
      await Promise.all(SPEC_ATTRS.map(async (attr) => {
        const values = await topValues(domainId, attr, known, token);
        const clean = dedupe(values);
        if (clean.length === 1) specs[attr] = clean[0].name;
      }));
      return json({ specs }, 200, corsHeaders);
    }

    let options: { id: string | null; name: string }[] = [];
    let source: 'category_values' | 'top_values' | 'fallback' = 'top_values';

    // El catálogo encadenado siempre sale de top_values (respeta marca → modelo → año → versión).
    const top = await topValues(domainId, body.attributeId, known, token);
    if (top.length) options = top;

    // Sólo la marca puede salir de la categoría (lista oficial completa).
    if (body.attributeId === 'BRAND' && options.length < 2) {
      const values = await categoryValues(body.categoryId || DEFAULT_CATEGORY, 'BRAND');
      if (values?.length) { options = values; source = 'category_values'; }
    }
    if (body.attributeId === 'VEHICLE_YEAR' && !options.length) {
      options = fallbackYears();
      source = 'fallback';
    }

    const search = norm(body.search || '');
    if (search) options = options.filter((o) => norm(o.name).includes(search));

    let result = dedupe(options);
    if (body.attributeId === 'VEHICLE_YEAR') {
      result = result.sort((a, b) => Number(b.name) - Number(a.name));
    }

    const needsAuth = !token && !result.length;
    return json(
      {
        options: result,
        source,
        domainId,
        categoryId: body.categoryId,
        needsAuth,
        error: needsAuth
          ? 'Conectá (o reconectá) tu cuenta de Mercado Libre para ver el catálogo oficial.'
          : undefined,
        authError: token ? undefined : authError,
      },
      200,
      corsHeaders,
    );

  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message, options: [] }, status, corsHeaders);
  }
});
