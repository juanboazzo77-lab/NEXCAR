import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { admin, buildPayload, Channel, overallStatus, requireUser, runJob } from '../_shared/publish-core.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const { user, authHeader } = await requireUser(req);
    const { job_id, car_id, channel: chIn, ...opts } = await req.json();
    const db = admin();

    let channel: Channel | undefined = chIn;
    let carId: string = car_id;
    let batchId: string | null = null;
    let attempt = 1;

    if (job_id) {
      const { data: prev } = await db
        .from('publication_jobs').select('*').eq('id', job_id).eq('user_id', user.id).maybeSingle();
      if (!prev) throw new Error('Trabajo no encontrado');
      if (['en_cola', 'publicando'].includes(prev.status)) throw new Error('Este canal ya se está publicando');
      channel = prev.channel as Channel;
      carId = prev.car_id;
      batchId = prev.batch_id;
      attempt = (prev.attempt_number ?? 1) + 1;
    }
    if (!channel || !carId) throw new Error('Faltan datos');

    const { data: car } = await db.from('cars').select('*').eq('id', carId).eq('user_id', user.id).maybeSingle();
    if (!car) throw new Error('Vehículo no encontrado');

    const payload = await buildPayload(db, channel, car, opts);
    const { data: job, error } = await db
      .from('publication_jobs')
      .insert({
        user_id: user.id, batch_id: batchId, car_id: carId, channel,
        action: 'retry', status: 'en_cola', attempt_number: attempt, payload,
        idempotency_key: `${carId}:${channel}:retry:${attempt}:${Date.now()}`,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);

    const result = await runJob({ db, authHeader, userId: user.id, carId, jobId: job.id, channel, payload });

    if (batchId) {
      const { data: all } = await db.from('publication_jobs').select('status, channel, created_at').eq('batch_id', batchId);
      const latest = new Map<string, string>();
      for (const j of all || []) latest.set(j.channel, j.status);
      await db.from('publication_batches')
        .update({ overall_status: overallStatus([...latest.values()].map((s) => ({ status: s }))) })
        .eq('id', batchId);
    }

    return new Response(JSON.stringify(result), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
