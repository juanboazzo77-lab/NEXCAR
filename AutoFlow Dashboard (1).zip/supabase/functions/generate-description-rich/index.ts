import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const auth = req.headers.get('Authorization');
    if (!auth) throw new Error('No autenticado');
    const userSupa = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: auth } } });
    const { data: { user } } = await userSupa.auth.getUser();
    if (!user) throw new Error('No autenticado');

    const { car_id } = await req.json();
    if (!car_id) throw new Error('car_id requerido');

    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const { data: car } = await admin.from('cars').select('*').eq('id', car_id).eq('user_id', user.id).maybeSingle();
    if (!car) throw new Error('Auto no encontrado');

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) throw new Error('LOVABLE_API_KEY no configurada');

    const prompt = `Generá descripciones de venta para este vehículo. Respondé SOLO con JSON válido (sin markdown) con esta forma:
{
  "titulo": "Título atractivo y corto (máx 60 caracteres, sin emojis)",
  "ml_desc": "Descripción larga y profesional para Mercado Libre (8-15 líneas, datos claros, sin emojis, sin teléfono)",
  "ig_caption": "Caption para Instagram (corto, con 1-3 emojis, incluí precio si está, incluí WhatsApp si está)",
  "fb_caption": "Caption para Facebook (medio largo, tono comercial)",
  "hashtags": ["#auto","#marca","#modelo","#argentina"]
}

NO inventes datos que no estén acá. Usá solo lo que te paso:
- Marca: ${car.marca}
- Modelo: ${car.modelo}
- Versión: ${car.version || '-'}
- Año: ${car.anio}
- Kilómetros: ${car.kilometros ?? '-'}
- Color: ${car.color || '-'}
- Combustible: ${car.combustible || '-'}
- Transmisión: ${car.transmision || '-'}
- Motor: ${car.motor || '-'}
- Carrocería: ${car.carroceria || '-'}
- Puertas: ${car.puertas || '-'}
- Condición: ${car.condicion || 'usado'}
- Precio: ${car.precio_venta || '-'} ${car.moneda || 'ARS'}
- Ubicación: ${car.ubicacion || '-'}
- Equipamiento: ${JSON.stringify(car.equipamiento || [])}
- Notas del vendedor: ${car.descripcion_manual || '-'}
- WhatsApp contacto: ${car.vendedor_whatsapp || car.vendedor_telefono || '-'}`;

    const res = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${LOVABLE_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: 'Sos un copywriter experto en venta de autos usados en Argentina. Respondés solo JSON válido.' },
          { role: 'user', content: prompt },
        ],
        response_format: { type: 'json_object' },
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(`AI ${res.status}: ${JSON.stringify(data)}`);
    const raw = data?.choices?.[0]?.message?.content ?? '{}';
    let parsed: any = {};
    try { parsed = JSON.parse(raw); } catch { parsed = { titulo: '', ml_desc: raw, ig_caption: raw, fb_caption: raw, hashtags: [] }; }

    await admin.from('ai_generated_descriptions').insert({
      user_id: user.id, car_id,
      titulo: parsed.titulo, ml_desc: parsed.ml_desc, ig_caption: parsed.ig_caption, fb_caption: parsed.fb_caption,
      hashtags: parsed.hashtags || [],
    });

    return new Response(JSON.stringify(parsed), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
