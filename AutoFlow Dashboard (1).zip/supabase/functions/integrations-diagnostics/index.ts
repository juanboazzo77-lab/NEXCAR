import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { admin, HttpError, json, publishingEnabled, requireUser } from '../_shared/publisher.ts';

type Check = { id: string; label: string; ok: boolean; detail: string; fix?: string };

/** Diagnóstico de integraciones. Nunca revela secretos: sólo si están cargados. */
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const user = await requireUser(req);
    const db = admin();
    const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
    const checks: Check[] = [];

    const mlRedirect = `${supabaseUrl}/functions/v1/oauth-mercadolibre-callback`;
    const metaRedirect = Deno.env.get('META_REDIRECT_URI') || `${supabaseUrl}/functions/v1/oauth-meta-callback`;

    const { data: creds } = await db.from('ml_credentials')
      .select('app_id,client_secret').eq('user_id', user.id).maybeSingle();
    const mlId = creds?.app_id || Deno.env.get('ML_APP_ID');
    const mlSecret = creds?.client_secret || Deno.env.get('ML_CLIENT_SECRET');

    checks.push({
      id: 'ml_credentials', label: 'Credenciales de Mercado Libre',
      ok: !!(mlId && mlSecret),
      detail: mlId && mlSecret ? 'App ID y Client Secret cargados.' : 'Falta el App ID o el Client Secret.',
      fix: 'Creá la app en Mercado Libre Developers y cargá App ID y Secret Key.',
    });
    checks.push({
      id: 'ml_redirect', label: 'Redirect URI de Mercado Libre', ok: !!supabaseUrl,
      detail: mlRedirect,
      fix: 'Pegá esta URL, carácter por carácter, en la Redirect URI de tu app de Mercado Libre.',
    });

    const metaId = Deno.env.get('META_APP_ID');
    const metaSecret = Deno.env.get('META_APP_SECRET');
    checks.push({
      id: 'meta_credentials', label: 'Credenciales de Meta',
      ok: !!(metaId && metaSecret),
      detail: metaId && metaSecret ? 'App ID y App Secret cargados.' : 'Falta el App ID o el App Secret de Meta.',
      fix: 'Creá la app en Meta for Developers y cargá META_APP_ID y META_APP_SECRET.',
    });
    checks.push({
      id: 'meta_redirect', label: 'Callback de Meta', ok: !!metaRedirect,
      detail: metaRedirect,
      fix: 'Agregá esta URL exacta (sin barra final) en "Valid OAuth Redirect URIs" de Facebook Login.',
    });
    checks.push({
      id: 'graph_version', label: 'Versión de Graph API', ok: true,
      detail: Deno.env.get('META_GRAPH_VERSION') || 'v23.0 (por defecto)',
    });

    const metaMissing = [
      !metaId && 'META_APP_ID',
      !metaSecret && 'META_APP_SECRET',
      !Deno.env.get('META_REDIRECT_URI') && 'META_REDIRECT_URI',
      !Deno.env.get('META_GRAPH_VERSION') && 'META_GRAPH_VERSION (usa el valor por defecto)',
    ].filter(Boolean) as string[];

    // Modo de la app (Desarrollo / Producción) usando el app access token.
    let appMode: string | null = null;
    if (metaId && metaSecret) {
      try {
        const gv = Deno.env.get('META_GRAPH_VERSION') || 'v23.0';
        const r = await fetch(`https://graph.facebook.com/${gv}/${metaId}?fields=name,app_type&access_token=${metaId}|${metaSecret}`);
        const j = await r.json();
        appMode = r.ok ? (j?.app_type === 0 ? 'Desarrollo o sin publicar' : 'Activa') : 'No pudimos leer el estado de la app';
      } catch { appMode = null; }
    }

    checks.push({
      id: 'meta_diagnostico', label: 'Diagnóstico de Meta',
      ok: !!(metaId && metaSecret) && metaMissing.length === 0,
      detail: [
        `App ID termina en …${(metaId || '').slice(-4) || '—'}`,
        `Graph API ${Deno.env.get('META_GRAPH_VERSION') || 'v23.0'}`,
        `Redirect URI: ${metaRedirect}`,
        metaMissing.length ? `Faltan variables: ${metaMissing.join(', ')}` : 'No faltan variables',
        appMode ? `Estado de la app: ${appMode}` : 'Estado de la app: desconocido',
      ].join(' · '),
      fix: 'Si la app está en Desarrollo, tu cuenta de Facebook debe ser administrador, desarrollador o tester y haber aceptado la invitación. La app no puede estar restringida y el dominio debe usar HTTPS.',
    });


    // Tablas y bucket
    const tableCheck = async (table: string) => {
      const { error } = await db.from(table).select('id', { count: 'exact', head: true }).limit(1);
      return !error;
    };
    const tablesOk = (await Promise.all(
      ['vehicles', 'vehicle_media', 'channel_connections', 'publications', 'publish_confirmations'].map(tableCheck),
    )).every(Boolean);
    checks.push({
      id: 'tables', label: 'Tablas del publicador', ok: tablesOk,
      detail: tablesOk ? 'vehicles, vehicle_media, channel_connections, publications y confirmaciones disponibles.' : 'Falta alguna tabla del publicador.',
    });

    const { data: buckets } = await db.storage.listBuckets();
    const bucketOk = (buckets || []).some((b: any) => b.name === 'car-photos');
    checks.push({
      id: 'storage', label: 'Bucket de fotos', ok: bucketOk,
      detail: bucketOk ? 'car-photos disponible.' : 'Falta el bucket car-photos.',
    });

    checks.push({
      id: 'publishing', label: 'Publicación real', ok: true,
      detail: publishingEnabled()
        ? 'PUBLISHING_ENABLED activo: las publicaciones se envían de verdad.'
        : 'Modo prueba: PUBLISHING_ENABLED=false bloquea publicaciones reales.',
    });

    // Estado de cuentas
    const { data: accounts } = await db.from('connected_accounts')
      .select('platform, account_name, expires_at, status, updated_at, meta').eq('user_id', user.id);
    const byPlatform = (p: string) => (accounts || []).filter((a: any) => a.platform === p);
    const mlAccounts = byPlatform('mercadolibre').sort((a: any, b: any) => {
      const aValid = a.status === 'conectado' && (!a.expires_at || new Date(a.expires_at).getTime() > Date.now());
      const bValid = b.status === 'conectado' && (!b.expires_at || new Date(b.expires_at).getTime() > Date.now());
      if (aValid !== bValid) return aValid ? -1 : 1;
      return new Date(b.updated_at || 0).getTime() - new Date(a.updated_at || 0).getTime();
    });
    const ml = mlAccounts[0];
    const fbSelected = byPlatform('facebook').find((a: any) => a.meta?.selected);
    const igSelected = byPlatform('instagram').find((a: any) => a.meta?.selected);

    checks.push({
      id: 'ml_account', label: 'Cuenta de Mercado Libre', ok: !!ml,
      detail: ml ? `Conectada: ${ml.account_name}${ml.expires_at ? ` (vence ${new Date(ml.expires_at).toLocaleString('es-AR')})` : ''}` : 'Sin conectar.',
      fix: 'Tocá "Conectar Mercado Libre".',
    });
    checks.push({
      id: 'fb_page', label: 'Página de Facebook elegida', ok: !!fbSelected,
      detail: fbSelected ? `Página: ${fbSelected.account_name}` : `${byPlatform('facebook').length} Páginas disponibles, ninguna elegida.`,
      fix: 'Conectá Meta y elegí la Página donde querés publicar.',
    });
    checks.push({
      id: 'ig_account', label: 'Instagram profesional', ok: !!igSelected,
      detail: igSelected ? `Cuenta: ${igSelected.account_name}` : 'Esta Página no tiene una cuenta profesional de Instagram vinculada',
      fix: 'Vinculá la cuenta profesional a la Página desde Meta Business Suite y volvé a actualizar.',
    });

    return json({ checks, publishingEnabled: publishingEnabled() }, 200, corsHeaders);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message }, status, corsHeaders);
  }
});
