// Public AI Advisor - anonymous endpoint
// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const { message, history = [] } = await req.json();
    if (!message || typeof message !== "string") {
      return new Response(JSON.stringify({ error: "missing message" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: cars } = await supabase
      .from("cars")
      .select("id,slug,marca,modelo,version,anio,kilometros,precio_venta,moneda,combustible,transmision,carroceria,puertas,color,equipamiento,estado")
      .eq("mostrar_publico", true)
      .in("estado", ["Disponible", "Reservado"])
      .limit(80);

    const stock = (cars || []).map((c: any) => ({
      id: c.id, marca: c.marca, modelo: c.modelo, version: c.version, anio: c.anio,
      km: c.kilometros, precio: c.precio_venta, moneda: c.moneda || "ARS",
      combustible: c.combustible, transmision: c.transmision, carroceria: c.carroceria,
      puertas: c.puertas, color: c.color,
    }));

    const system = `Sos un asesor comercial de una agencia de autos. Recomendá únicamente vehículos del STOCK proporcionado (por su id exacto). NUNCA inventes vehículos. Si nada encaja bien, decilo honestamente y pedí más datos.
Respondé en español rioplatense, breve y amable. Devolvés JSON con: {"reply": string, "recommendations": [{"car_id": string (id exacto del stock), "reason": string}]}. Máximo 3 recomendaciones.`;

    const userPayload = `STOCK DISPONIBLE (JSON):\n${JSON.stringify(stock)}\n\nCONSULTA DEL CLIENTE: ${message}`;

    const aiResp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${Deno.env.get("LOVABLE_API_KEY")}`,
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: system },
          ...history.slice(-6),
          { role: "user", content: userPayload },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (!aiResp.ok) {
      const t = await aiResp.text();
      return new Response(JSON.stringify({ error: "ai_failed", detail: t }), { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const aiJson = await aiResp.json();
    const raw = aiJson?.choices?.[0]?.message?.content ?? "{}";
    let parsed: any = {};
    try { parsed = JSON.parse(raw); } catch { parsed = { reply: String(raw), recommendations: [] }; }

    const validIds = new Set(stock.map((c) => c.id));
    const recs = Array.isArray(parsed.recommendations)
      ? parsed.recommendations.filter((r: any) => r && validIds.has(r.car_id)).slice(0, 3)
      : [];
    const recCars = (cars || []).filter((c: any) => recs.some((r: any) => r.car_id === c.id))
      .map((c: any) => ({ id: c.id, slug: c.slug, marca: c.marca, modelo: c.modelo, version: c.version, anio: c.anio, kilometros: c.kilometros, precio_venta: c.precio_venta, moneda: c.moneda }));

    return new Response(JSON.stringify({
      reply: parsed.reply || "Estas opciones podrían interesarte.",
      recommendations: recs,
      cars: recCars,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e: any) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
