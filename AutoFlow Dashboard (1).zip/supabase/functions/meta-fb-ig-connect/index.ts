import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';

const GRAPH = 'https://graph.facebook.com/v23.0';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const auth = req.headers.get('Authorization');
    if (!auth?.startsWith('Bearer ')) throw new Error('Unauthorized');
    const userSupa = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: auth } } });
    const { data: { user } } = await userSupa.auth.getUser();
    if (!user) throw new Error('Unauthorized');

    const { user_access_token, responsable } = await req.json();
    if (!user_access_token) throw new Error('Falta user_access_token');

    const appId = Deno.env.get('META_APP_ID')!;
    const appSecret = Deno.env.get('META_APP_SECRET')!;

    // 1) Long-lived user token (60d)
    const longRes = await fetch(`${GRAPH}/oauth/access_token?grant_type=fb_exchange_token&client_id=${appId}&client_secret=${appSecret}&fb_exchange_token=${user_access_token}`);
    const longJson = await longRes.json();
    if (!longRes.ok) throw new Error(longJson.error?.message || 'Meta rechazó la autorización');
    const userToken = longJson.access_token || user_access_token;

    // 2) Listar páginas (incluye token de página y IG vinculado)
    const pagesRes = await fetch(`${GRAPH}/me/accounts?fields=id,name,access_token,instagram_business_account&access_token=${userToken}`);
    const pagesJson = await pagesRes.json();
    if (!pagesRes.ok) throw new Error(pagesJson.error?.message || 'No se pudieron leer las páginas');
    const pages = pagesJson.data || [];
    if (!pages.length) throw new Error('No tenés páginas de Facebook administradas con esta cuenta.');

    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const results = { facebook: 0, instagram: 0, pages: [] as string[] };

    const upsertConn = async (payload: any) => {
      const { data: ex } = await admin.from('connected_accounts').select('id')
        .eq('user_id', payload.user_id).eq('platform', payload.platform)
        .eq('account_external_id', payload.account_external_id).maybeSingle();
      if (ex?.id) await admin.from('connected_accounts').update(payload).eq('id', ex.id);
      else await admin.from('connected_accounts').insert(payload);
    };

    for (const p of pages) {
      await upsertConn({
        user_id: user.id, platform: 'facebook', account_name: p.name,
        account_external_id: p.id, access_token: p.access_token,
        meta: { page_id: p.id }, status: 'conectado',
      });
      results.facebook++;
      results.pages.push(p.name);

      if (p.instagram_business_account?.id) {
        const igId = p.instagram_business_account.id;
        const igRes = await fetch(`${GRAPH}/${igId}?fields=username,name&access_token=${p.access_token}`);
        const ig = await igRes.json();
        await fetch(`${GRAPH}/${p.id}/subscribed_apps?subscribed_fields=messages,messaging_postbacks&access_token=${p.access_token}`, { method: 'POST' }).catch(() => {});

        const { data: existing } = await admin.from('channel_accounts')
          .select('id').eq('user_id', user.id).eq('platform', 'instagram').eq('external_id', igId).maybeSingle();
        const payload: any = {
          user_id: user.id, platform: 'instagram',
          nombre_interno: `Instagram ${ig.username || ig.name || p.name}`.trim(),
          responsable: responsable || null, estado: 'conectado', external_id: igId,
          ig_username: ig.username || null, page_id: p.id, access_token: p.access_token,
          fecha_conexion: new Date().toISOString(),
        };
        if (existing?.id) await admin.from('channel_accounts').update(payload).eq('id', existing.id);
        else await admin.from('channel_accounts').insert(payload);
        results.instagram++;

        await upsertConn({
          user_id: user.id, platform: 'instagram',
          account_name: ig.username || p.name, account_external_id: igId,
          access_token: p.access_token,
          meta: { ig_user_id: igId, page_id: p.id }, status: 'conectado',
        });
      }
    }

    return new Response(JSON.stringify({ ok: true, ...results }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
