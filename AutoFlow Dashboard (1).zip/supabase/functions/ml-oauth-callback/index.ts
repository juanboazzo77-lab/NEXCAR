import { createClient } from 'npm:@supabase/supabase-js@2';

/** Vuelve a la aplicación con un resultado legible (nunca con tokens ni errores técnicos). */
function backToApp(params: Record<string, string>) {
  const appUrl = Deno.env.get('APP_URL');
  if (!appUrl) throw new Error('APP_URL no configurada');
  const destination = new URL('/settings/connections', appUrl);
  destination.searchParams.set('provider', 'mercadolibre');
  for (const [k, v] of Object.entries(params)) destination.searchParams.set(k, v);
  return new Response(null, {
    status: 302,
    headers: {
      Location: destination.toString(),
      'Cache-Control': 'no-store',
      Pragma: 'no-cache',
    },
  });
}

Deno.serve(async (req) => {
  try {
    const url = new URL(req.url);
    const code = url.searchParams.get('code');
    const userId = url.searchParams.get('state');
    if (!code || !userId) return backToApp({ connected: '0', error: 'authorization_failed' });

    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

    // Preferimos las credenciales del usuario; si no, las del proyecto.
    const { data: creds } = await admin.from('ml_credentials').select('app_id,client_secret').eq('user_id', userId).maybeSingle();
    const ML_APP_ID = creds?.app_id || Deno.env.get('ML_APP_ID');
    const ML_CLIENT_SECRET = creds?.client_secret || Deno.env.get('ML_CLIENT_SECRET');
    if (!ML_APP_ID || !ML_CLIENT_SECRET) {
      console.error('ml-oauth-callback: faltan credenciales de Mercado Libre');
      return backToApp({ connected: '0', error: 'missing_credentials' });
    }

    const projectRef = Deno.env.get('SUPABASE_URL')!.split('//')[1].split('.')[0];
    const redirect = `https://${projectRef}.supabase.co/functions/v1/ml-oauth-callback`;

    const tokenRes = await fetch('https://api.mercadolibre.com/oauth/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' },
      body: new URLSearchParams({
        grant_type: 'authorization_code', client_id: ML_APP_ID, client_secret: ML_CLIENT_SECRET, code, redirect_uri: redirect,
      }),
    });
    const tok = await tokenRes.json();
    if (!tokenRes.ok || !tok?.access_token) {
      console.error('ml-oauth-callback token_exchange_failed', tokenRes.status, JSON.stringify(tok));
      return backToApp({ connected: '0', error: 'token_exchange_failed' });
    }

    const meRes = await fetch('https://api.mercadolibre.com/users/me', { headers: { Authorization: `Bearer ${tok.access_token}` } });
    const me = await meRes.json();
    if (!meRes.ok) {
      console.error('ml-oauth-callback users_me_failed', meRes.status, JSON.stringify(me));
      return backToApp({ connected: '0', error: 'token_verification_failed' });
    }

    const extId = String(tok.user_id);
    const { data: existing } = await admin.from('connected_accounts').select('id').eq('user_id', userId).eq('platform', 'mercadolibre').eq('account_external_id', extId).maybeSingle();
    const payload = {
      user_id: userId,
      platform: 'mercadolibre',
      account_name: me.nickname || me.email,
      account_external_id: extId,
      access_token: tok.access_token,
      refresh_token: tok.refresh_token,
      expires_at: new Date(Date.now() + (tok.expires_in * 1000)).toISOString(),
      meta: { ml_user_id: tok.user_id, site_id: me.site_id, nickname: me.nickname },
      status: 'conectado',
    };
    if (existing) await admin.from('connected_accounts').update(payload).eq('id', existing.id);
    else await admin.from('connected_accounts').insert(payload);

    return backToApp({ connected: '1' });
  } catch (e) {
    console.error('ml-oauth-callback error', (e as Error).message);
    try {
      return backToApp({ connected: '0', error: 'unexpected_error' });
    } catch {
      return new Response('APP_URL no configurada', { status: 500 });
    }
  }
});
