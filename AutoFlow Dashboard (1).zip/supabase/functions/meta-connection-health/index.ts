import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { admin, HttpError, json, requireUser } from '../_shared/publisher.ts';
import { metaHealth, REQUIRED_SCOPES } from '../_shared/meta-health.ts';

/** Chequeo de salud de la conexión con Meta con soluciones concretas. */
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const user = await requireUser(req);
    const health = await metaHealth(admin(), user.id);

    const fixes: string[] = [];
    if (!health.connected) fixes.push('Tocá "Conectar Facebook e Instagram" y autorizá la app.');
    if (health.connected && !health.pages.some((p: any) => p.selected))
      fixes.push('Elegí la Página de Facebook donde querés publicar.');
    if (health.missingScopes?.length)
      fixes.push(`Faltan permisos (${health.missingScopes.join(', ')}). Reconectá y autorizá todos.`);
    if (health.connected && !(health.instagram as any)?.ok)
      fixes.push('Vinculá una cuenta profesional de Instagram a la Página desde Meta Business Suite y actualizá.');

    return json({ ...health, requiredScopes: REQUIRED_SCOPES, fixes }, 200, corsHeaders);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message }, status, corsHeaders);
  }
});
