import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import { getValidMlAccount } from '../_shared/ml-auth.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const auth = req.headers.get('Authorization');
    if (!auth) throw new Error('No autenticado');
    const token = auth.replace('Bearer ', '');
    const admin0 = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const { data: { user }, error: userErr } = await admin0.auth.getUser(token);
    if (userErr || !user) throw new Error('No autenticado');

    const { car_id, descripcion, precio, fotos, account_id, listing_type_id, titulo, combustible, transmision, puertas, condicion } = await req.json();
    if (!car_id || !precio) throw new Error('Datos incompletos');

    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const acc = await getValidMlAccount(admin, user.id, account_id);

    const { data: car } = await admin.from('cars').select('*').eq('id', car_id).eq('user_id', user.id).single();
    if (!car) throw new Error('Auto no encontrado');

    const pubRow = await admin.from('vehicle_publications').insert({
      user_id: user.id, car_id, platform: 'mercadolibre',
      publishing_account_id: acc.id, listing_type: listing_type_id || 'silver',
      status: 'publicando',
    }).select().single();

    try {
      const siteId = (acc.meta as any)?.site_id || 'MLA';
      const categoryId = 'MLA1744';
      const attributesResponse = await fetch(`https://api.mercadolibre.com/categories/${categoryId}/attributes`);
      const categoryAttributes = attributesResponse.ok ? await attributesResponse.json() : [];
      const catalogValue = (attributeId: string, name: string | null | undefined) => {
        if (!name || !Array.isArray(categoryAttributes)) return undefined;
        const attribute = categoryAttributes.find((item: any) => item.id === attributeId);
        return attribute?.values?.find((value: any) => value.name?.localeCompare(name, 'es', { sensitivity: 'base' }) === 0);
      };
      const brand = catalogValue('BRAND', car.marca);
      const model = catalogValue('MODEL', car.modelo);
      const attribute = (id: string, value: string | number | null | undefined, catalog?: any) => catalog?.id
        ? { id, value_id: catalog.id, value_name: catalog.name }
        : value != null && String(value).trim() ? { id, value_name: String(value) } : null;
      const body = {
        title: (titulo || `${car.marca} ${car.modelo} ${car.version || ''} ${car.anio}`).trim().slice(0, 60),
        category_id: categoryId,
        price: Number(precio),
        currency_id: car.moneda || 'ARS',
        available_quantity: 1,
        buying_mode: 'classified',
        listing_type_id: listing_type_id || 'silver',
        condition: String(condicion || car.condicion || '').toLowerCase() === 'nuevo' ? 'new' : 'used',
        description: { plain_text: descripcion || `${car.marca} ${car.modelo} ${car.anio}` },
        pictures: (fotos || []).slice(0, 12).map((url: string) => ({ source: url })),
        attributes: [
          attribute('BRAND', car.marca, brand),
          attribute('MODEL', car.modelo, model),
          attribute('VEHICLE_YEAR', car.anio),
          ...(car.kilometros ? [{ id: 'KILOMETERS', value_name: `${car.kilometros} km` }] : []),
          ...(car.color ? [{ id: 'COLOR', value_name: car.color }] : []),
          ...(combustible || car.combustible ? [{ id: 'FUEL_TYPE', value_name: combustible || car.combustible }] : []),
          ...(transmision || car.transmision ? [{ id: 'TRANSMISSION', value_name: transmision || car.transmision }] : []),
          ...(puertas || car.puertas ? [{ id: 'DOORS', value_name: String(puertas || car.puertas) }] : []),
        ].filter(Boolean),
        site_id: siteId,
      };

      const res = await fetch('https://api.mercadolibre.com/items', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${acc.access_token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const json = await res.json();
      if (!res.ok) {
        const causes = Array.isArray(json.cause) ? json.cause.map((cause: any) => cause.message || cause.code).filter(Boolean).join(' · ') : '';
        throw new Error(causes || json.message || json.error || `Mercado Libre respondió ${res.status}`);
      }

      await admin.from('vehicle_publications').update({
        status: 'publicado', external_id: json.id, external_url: json.permalink, published_at: new Date().toISOString(), payload: json,
      }).eq('id', pubRow.data?.id);
      await admin.from('cars').update({ publicado_ml: true }).eq('id', car_id);

      return new Response(JSON.stringify({ id: json.id, url: json.permalink }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    } catch (err: any) {
      if (pubRow.data?.id) await admin.from('vehicle_publications').update({ status: 'error', error_message: err.message }).eq('id', pubRow.data.id);
      throw err;
    }
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
