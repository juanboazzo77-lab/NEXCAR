import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { CHANNELS, HttpError, admin, getConnection, json, publishingEnabled, requireUser } from '../_shared/publisher.ts';

/** Devuelve el estado de cada canal SIN exponer tokens. */
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const user = await requireUser(req);
    const db = admin();
    const connections = [];

    for (const channel of CHANNELS) {
      try {
        const { meta, raw } = await getConnection(db, user.id, channel);
        connections.push({
          channel,
          connected: true,
          account_name: raw.account_name,
          expires_at: raw.expires_at,
          expired: raw.expires_at ? new Date(raw.expires_at).getTime() < Date.now() : false,
          details: {
            page_id: meta?.page_id ? 'configurada' : null,
            ig_user_id: meta?.ig_user_id ? 'vinculada' : null,
            site_id: meta?.site_id || null,
          },
        });
      } catch (e) {
        connections.push({ channel, connected: false, message: (e as Error).message });
      }
    }

    return json({ connections, publishingEnabled: publishingEnabled() }, 200, corsHeaders);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message }, status, corsHeaders);
  }
});
