import { admin } from '../_shared/publisher.ts';
import { connectionsUrl, consumeState, redirectTo, safeOrigin } from '../_shared/oauth-state.ts';


/** Callback de Mercado Libre: valida el state, canjea el código y guarda los tokens. */
Deno.serve(async (req) => {
  const db = admin();
  let origin = safeOrigin(null);
  try {
    const url = new URL(req.url);
    const code = url.searchParams.get('code');
    const state = url.searchParams.get('state') ?? '';
    if (!code) throw new Error('Mercado Libre no devolvió el código de autorización.');


    const consumed = await consumeState(db, state, 'mercadolibre');
    origin = consumed.returnTo;
    const userId = consumed.userId;

    const { data: creds } = await db.from('ml_credentials')
      .select('app_id,client_secret').eq('user_id', userId).maybeSingle();
    const clientId = creds?.app_id || Deno.env.get('ML_APP_ID');
    const clientSecret = creds?.client_secret || Deno.env.get('ML_CLIENT_SECRET');
    if (!clientId || !clientSecret) throw new Error('Faltan las credenciales de la aplicación de Mercado Libre.');

    const redirectUri = `${Deno.env.get('SUPABASE_URL')}/functions/v1/oauth-mercadolibre-callback`;
    const tokenRes = await fetch('https://api.mercadolibre.com/oauth/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
      body: new URLSearchParams({
        grant_type: 'authorization_code', client_id: clientId,
        client_secret: clientSecret, code, redirect_uri: redirectUri,
        ...(consumed.codeVerifier ? { code_verifier: consumed.codeVerifier } : {}),
      }),
    });
    const token = await tokenRes.json();
    if (!tokenRes.ok) {
      const detail = String(token?.message || token?.error || '').includes('redirect')
        ? 'La Redirect URI de tu app no coincide con la del sistema.'
        : 'Mercado Libre rechazó la autorización.';
      throw new Error(detail);
    }

    const meRes = await fetch('https://api.mercadolibre.com/users/me', {
      headers: { Authorization: `Bearer ${token.access_token}` },
    });
    const me = await meRes.json();

    const externalId = String(token.user_id);
    const payload = {
      user_id: userId, platform: 'mercadolibre',
      account_name: me?.nickname || me?.email || externalId,
      account_external_id: externalId,
      access_token: token.access_token,
      refresh_token: token.refresh_token,
      expires_at: new Date(Date.now() + Number(token.expires_in || 21600) * 1000).toISOString(),
      meta: { ml_user_id: token.user_id, site_id: me?.site_id || 'MLA', nickname: me?.nickname },
      status: 'conectado',
    };
    const { data: existing } = await db.from('connected_accounts').select('id')
      .eq('user_id', userId).eq('platform', 'mercadolibre')
      .eq('account_external_id', externalId).maybeSingle();
    if (existing?.id) await db.from('connected_accounts').update(payload).eq('id', existing.id);
    else await db.from('connected_accounts').insert(payload);

    return redirectTo(connectionsUrl(origin, {
      provider: 'mercadolibre', connected: '1',
    }));
  } catch (e) {
    console.error('oauth-mercadolibre-callback', (e as Error).message);
    return redirectTo(connectionsUrl(origin, {
      provider: 'mercadolibre', connected: '0', error: 'token_exchange_failed',
    }));
  }
});
