import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { admin, HttpError, json, requireUser, type AdminClient } from '../_shared/publisher.ts';
import { getValidMlAccount } from '../_shared/ml-auth.ts';
import { metaHealth } from '../_shared/meta-health.ts';

/** Prueba NO destructiva de Mercado Libre: /users/me. */
async function testMercadoLibre(db: AdminClient, userId: string) {
  const account = await getValidMlAccount(db, userId);
  const res = await fetch('https://api.mercadolibre.com/users/me', {
    headers: { Authorization: `Bearer ${account.access_token}` },
  });
  const me = await res.json();
  if (!res.ok) throw new HttpError(400, me?.message || 'Mercado Libre rechazó el token. Reconectá la cuenta.');
  return { ok: true, message: `Conectado como: ${me.nickname || me.id}`, account: me.nickname, site_id: me.site_id };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const user = await requireUser(req);
    const db = admin();
    const { action, page_id, platform } = await req.json().catch(() => ({ action: 'health' }));

    if (action === 'test_mercadolibre') {
      return json(await testMercadoLibre(db, user.id), 200, corsHeaders);
    }

    if (action === 'meta_health') {
      return json(await metaHealth(db, user.id), 200, corsHeaders);
    }

    if (action === 'select_page') {
      if (!page_id) throw new HttpError(400, 'Falta la Página.');
      const { data: rows } = await db.from('connected_accounts').select('*')
        .eq('user_id', user.id).in('platform', ['facebook', 'instagram']);
      for (const row of rows || []) {
        const isTarget = row.platform === 'facebook'
          ? row.account_external_id === page_id
          : (row.meta as any)?.page_id === page_id;
        await db.from('connected_accounts')
          .update({ meta: { ...(row.meta as any), selected: isTarget } })
          .eq('id', row.id);
      }
      return json(await metaHealth(db, user.id), 200, corsHeaders);
    }

    if (action === 'disconnect') {
      const targets = platform === 'meta' ? ['facebook', 'instagram'] : [platform];
      if (!targets[0]) throw new HttpError(400, 'Falta la plataforma.');
      await db.from('connected_accounts').delete().eq('user_id', user.id).in('platform', targets);
      await db.from('channel_connections').delete().eq('user_id', user.id).in('channel', targets);
      return json({ ok: true, message: 'Cuenta desconectada. Vas a tener que autorizar de nuevo.' }, 200, corsHeaders);
    }

    throw new HttpError(400, 'Acción desconocida');
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message }, status, corsHeaders);
  }
});
