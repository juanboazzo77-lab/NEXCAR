import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { admin, buildPayload, Channel, CHANNELS, overallStatus, requireUser, runJob } from '../_shared/publish-core.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const { user, authHeader } = await requireUser(req);
    const body = await req.json();
    const carId: string = body.car_id;
    const channels: Channel[] = (body.channels || []).filter((c: Channel) => CHANNELS.includes(c));
    if (!carId || channels.length === 0) throw new Error('Faltan datos: vehículo y canales');

    const db = admin();
    const { data: car } = await db.from('cars').select('*').eq('id', carId).eq('user_id', user.id).maybeSingle();
    if (!car) throw new Error('Vehículo no encontrado');

    const { data: batch, error: batchErr } = await db
      .from('publication_batches')
      .insert({
        user_id: user.id, car_id: carId, selected_channels: channels,
        overall_status: 'procesando', started_at: new Date().toISOString(),
      })
      .select()
      .single();
    if (batchErr) throw new Error(batchErr.message);

    const jobs = await Promise.all(
      channels.map(async (channel) => {
        const payload = await buildPayload(db, channel, car, body);
        const { data: job } = await db
          .from('publication_jobs')
          .insert({
            user_id: user.id, batch_id: batch.id, car_id: carId, channel,
            action: 'create', status: 'en_cola', payload,
            idempotency_key: `${batch.id}:${channel}:create`,
          })
          .select()
          .single();
        return { job, channel, payload };
      }),
    );

    const results = await Promise.all(
      jobs.map(({ job, channel, payload }) =>
        runJob({ db, authHeader, userId: user.id, carId, jobId: job!.id, channel, payload }),
      ),
    );

    const { data: finalJobs } = await db.from('publication_jobs').select('status').eq('batch_id', batch.id);
    const overall = overallStatus(finalJobs || []);
    await db
      .from('publication_batches')
      .update({ overall_status: overall, completed_at: new Date().toISOString() })
      .eq('id', batch.id);

    return new Response(JSON.stringify({ batch_id: batch.id, overall_status: overall, results }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
