// Envía por WhatsApp un resumen del día (calendario + cuotas por vencer)
// Modos:
//  - POST con Authorization: envía solo al usuario autenticado (botón manual).
//  - POST con header x-cron-key === CRON_KEY: itera todos los usuarios con teléfonos guardados (cron).
import { createClient } from 'npm:@supabase/supabase-js@2';
import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY')!;
const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY')!;

function todayISO_AR(): string {
  // Argentina UTC-3, sin DST
  const now = new Date(Date.now() - 3 * 3600 * 1000);
  return now.toISOString().slice(0, 10);
}

function addMonthsISO(iso: string, n: number): string {
  const [y, m, d] = iso.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1 + n, d));
  return dt.toISOString().slice(0, 10);
}

async function buildSummary(admin: any, userId: string, today: string) {
  const items: string[] = [];

  // Eventos del calendario de hoy
  const { data: evs } = await admin
    .from('calendar_events')
    .select('titulo, hora, tipo, descripcion')
    .eq('user_id', userId)
    .eq('fecha', today);
  for (const e of evs ?? []) {
    const h = e.hora ? String(e.hora).slice(0, 5) + ' ' : '';
    items.push(`• ${h}${e.titulo}${e.descripcion ? ' — ' + e.descripcion : ''} [${e.tipo ?? 'evento'}]`);
  }

  // Cuotas: proyectar vencimientos = fecha_venta + (n) meses, para todas las ventas con cuotas
  const { data: sales } = await admin
    .from('sales')
    .select('id, fecha, cuotas, monto_financiar, monto, marca_modelo, patente, vendedor')
    .eq('user_id', userId);
  const { data: pays } = await admin
    .from('sale_payments')
    .select('sale_id')
    .eq('user_id', userId);
  const paidCount: Record<string, number> = {};
  for (const p of pays ?? []) paidCount[p.sale_id] = (paidCount[p.sale_id] ?? 0) + 1;

  for (const s of sales ?? []) {
    const cuotas = Number(s.cuotas ?? 0);
    if (!cuotas || !s.fecha) continue;
    const pagadas = paidCount[s.id] ?? 0;
    const restantes = cuotas - pagadas;
    if (restantes <= 0) continue;
    const proxima = addMonthsISO(s.fecha, pagadas + 1);
    if (proxima === today) {
      const monto = Number(s.monto_financiar ?? s.monto ?? 0) / cuotas;
      const label = `${s.marca_modelo ?? ''} ${s.patente ?? ''}`.trim() || 'venta';
      items.push(`• Cuota ${pagadas + 1}/${cuotas} de ${label} (${s.vendedor ?? 'cliente'}) ~ $${Math.round(monto).toLocaleString('es-AR')}`);
    }
  }

  return items;
}

async function generateMessage(items: string[], today: string): Promise<string> {
  if (items.length === 0) {
    return `📅 Resumen del día (${today})\n\nHoy no tenés eventos ni cuotas por cobrar. ¡Buen día! 🚗`;
  }
  const prompt = `Sos un asistente para una agencia de autos. Redactá un mensaje corto y cordial de WhatsApp (máx 500 caracteres, español rioplatense, con 1-2 emojis) resumiendo las tareas del día. Empezá con "📅 Hoy ${today}:" y listá los ítems tal cual. No inventes datos.\n\nÍtems:\n${items.join('\n')}`;
  try {
    const r = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Lovable-API-Key': LOVABLE_API_KEY },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [{ role: 'user', content: prompt }],
      }),
    });
    if (r.ok) {
      const j = await r.json();
      const txt = j?.choices?.[0]?.message?.content;
      if (txt) return txt.trim();
    }
  } catch (e) {
    console.error('AI error', e);
  }
  return `📅 Hoy ${today}:\n${items.join('\n')}`;
}

async function sendWhatsapp(admin: any, userId: string, to: string, body: string): Promise<{ ok: boolean; error?: string }> {
  const { data: acc } = await admin
    .from('channel_accounts')
    .select('*')
    .eq('user_id', userId)
    .eq('platform', 'whatsapp')
    .eq('estado', 'activa')
    .limit(1)
    .maybeSingle();
  if (!acc?.access_token || !acc?.external_id) {
    return { ok: false, error: 'Sin cuenta de WhatsApp Business conectada (Canales).' };
  }
  const cleanTo = to.replace(/[^0-9]/g, '');
  const res = await fetch(`https://graph.facebook.com/v21.0/${acc.external_id}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${acc.access_token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ messaging_product: 'whatsapp', to: cleanTo, type: 'text', text: { body } }),
  });
  const data = await res.json();
  if (!res.ok) return { ok: false, error: `Meta ${res.status}: ${JSON.stringify(data)}` };
  return { ok: true };
}

async function runForUser(admin: any, userId: string) {
  const today = todayISO_AR();
  const { data: phones } = await admin
    .from('notification_phones')
    .select('phone')
    .eq('user_id', userId);
  if (!phones || phones.length === 0) return { userId, sent: 0, reason: 'sin teléfonos' };

  const items = await buildSummary(admin, userId, today);
  const message = await generateMessage(items, today);
  const results: any[] = [];
  for (const p of phones) {
    const r = await sendWhatsapp(admin, userId, p.phone, message);
    results.push({ phone: p.phone, ...r });
  }
  return { userId, sent: results.filter(r => r.ok).length, total: results.length, message, results };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const admin = createClient(SUPABASE_URL, SERVICE_KEY);
    const cronKey = req.headers.get('x-cron-key');
    const isCron = cronKey && cronKey === Deno.env.get('DAILY_SUMMARY_CRON_KEY');

    if (isCron) {
      const { data: users } = await admin
        .from('notification_phones')
        .select('user_id');
      const ids = Array.from(new Set((users ?? []).map((u: any) => u.user_id)));
      const results = [];
      for (const uid of ids) results.push(await runForUser(admin, uid));
      return new Response(JSON.stringify({ ok: true, results }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // Modo manual - requiere JWT
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    const userClient = createClient(SUPABASE_URL, ANON_KEY, { global: { headers: { Authorization: authHeader } } });
    const { data: claims } = await userClient.auth.getClaims(authHeader.replace('Bearer ', ''));
    if (!claims?.claims) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    const userId = claims.claims.sub as string;

    const result = await runForUser(admin, userId);
    return new Response(JSON.stringify({ ok: true, ...result }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
