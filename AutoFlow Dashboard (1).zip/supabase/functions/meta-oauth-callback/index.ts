import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';

const GRAPH = 'https://graph.facebook.com/v23.0';

const decode = (value: string) => {
  const normalized = value.replaceAll('-', '+').replaceAll('_', '/');
  return atob(normalized + '='.repeat((4 - normalized.length % 4) % 4));
};

const encode = (value: string) =>
  btoa(value).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '');

const sign = async (value: string, secret: string) => {
  const key = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'],
  );
  const signature = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(value));
  return encode(String.fromCharCode(...new Uint8Array(signature)));
};

const safeReturn = (value?: string) => {
  try {
    const url = new URL(value ?? '');
    if (url.protocol === 'https:' && (url.hostname === 'grupo-boazzo-control.lovable.app' || url.hostname.endsWith('.lovable.app'))) {
      return `${url.origin}/canales`;
    }
  } catch { /* use fallback */ }
  return 'https://grupo-boazzo-control.lovable.app/canales';
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const url = new URL(req.url);
    const code = url.searchParams.get('code');
    const state = url.searchParams.get('state') ?? '';
    const appId = Deno.env.get('META_APP_ID') ?? '';
    const appSecret = Deno.env.get('META_APP_SECRET') ?? '';
    const [payload, receivedSignature] = state.split('.');
    if (!code || !payload || !receivedSignature || !appId || !appSecret) throw new Error('La autorización llegó incompleta');
    const expectedSignature = await sign(payload, appSecret);
    if (receivedSignature !== expectedSignature) throw new Error('La autorización no es válida');
    const stateData = JSON.parse(decode(payload));
    if (!stateData.uid || !stateData.exp || Date.now() > stateData.exp) throw new Error('La autorización venció; volvé a intentarlo');
    const userId = stateData.uid as string;
    const returnTo = safeReturn(stateData.returnTo);
    const redirect = `${Deno.env.get('SUPABASE_URL')}/functions/v1/meta-oauth-callback`;

    // 1) short-lived token
    const tokenRes = await fetch(`${GRAPH}/oauth/access_token?client_id=${appId}&client_secret=${appSecret}&redirect_uri=${encodeURIComponent(redirect)}&code=${code}`);
    const tokenJson = await tokenRes.json();
    if (!tokenRes.ok) throw new Error(tokenJson.error?.message || 'Error token');

    // 2) long-lived token
    const longRes = await fetch(`${GRAPH}/oauth/access_token?grant_type=fb_exchange_token&client_id=${appId}&client_secret=${appSecret}&fb_exchange_token=${tokenJson.access_token}`);
    const longJson = await longRes.json();
    if (!longRes.ok) throw new Error(longJson.error?.message || 'Meta rechazó la autorización');
    const userToken = longJson.access_token || tokenJson.access_token;

    // 3) get pages
    const pagesRes = await fetch(`${GRAPH}/me/accounts?fields=id,name,access_token,instagram_business_account&access_token=${userToken}`);
    const pagesJson = await pagesRes.json();
    if (!pagesRes.ok) throw new Error(pagesJson.error?.message || 'No se pudieron consultar tus páginas de Facebook');
    const pages = pagesJson.data || [];
    if (!pages.length) throw new Error('Tu usuario no administra ninguna página de Facebook habilitada para esta aplicación.');

    const supa = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

    const save = async (payload: any) => {
      const { data: existing } = await supa.from('connected_accounts').select('id')
        .eq('user_id', userId).eq('platform', payload.platform)
        .eq('account_external_id', payload.account_external_id).maybeSingle();
      if (existing?.id) await supa.from('connected_accounts').update(payload).eq('id', existing.id);
      else await supa.from('connected_accounts').insert(payload);
    };
    for (const page of pages) {
      await save({
        user_id: userId, platform: 'facebook', account_name: page.name,
        account_external_id: page.id, access_token: page.access_token,
        meta: { page_id: page.id }, status: 'conectado',
      });
      const igId = page.instagram_business_account?.id;
      if (igId) {
        const igResponse = await fetch(`${GRAPH}/${igId}?fields=username,name&access_token=${page.access_token}`);
        const ig = await igResponse.json();
        await save({
          user_id: userId, platform: 'instagram', account_name: ig.username || ig.name || page.name,
          account_external_id: igId, access_token: page.access_token,
          meta: { ig_user_id: igId, page_id: page.id }, status: 'conectado',
        });
      }
    }

    return Response.redirect(`${returnTo}?meta_connected=1`, 302);
  } catch (e) {
    const fallback = 'https://grupo-boazzo-control.lovable.app/canales';
    return Response.redirect(`${fallback}?meta_error=${encodeURIComponent((e as Error).message)}`, 302);
  }
});
