import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { HttpError, json, requireUser } from '../_shared/publisher.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    await requireUser(req);
    const { q } = await req.json();
    if (!q || typeof q !== 'string' || q.trim().length < 3)
      throw new HttpError(400, 'Escribí al menos 3 caracteres para buscar la categoría');

    const res = await fetch(
      `https://api.mercadolibre.com/sites/MLA/domain_discovery/search?limit=8&q=${encodeURIComponent(q.trim())}`,
    );
    if (!res.ok) throw new HttpError(400, 'Mercado Libre no respondió al predictor de categorías');
    const list = (await res.json()) as any[];

    const results = list.map((item) => ({
      category_id: item.category_id,
      category_name: item.category_name,
      domain_id: item.domain_id,
      domain_name: item.domain_name,
      is_vehicle: /MLA-(CARS|PICKUPS|VANS|SUVS)|AUTOS|CAMIONETAS/i.test(item.domain_id || ''),
    }));

    return json({ results, suggested: results.find((r) => r.is_vehicle) || results[0] || null }, 200, corsHeaders);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message }, status, corsHeaders);
  }
});
