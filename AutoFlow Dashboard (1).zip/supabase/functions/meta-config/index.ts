import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';

Deno.serve((req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  return new Response(JSON.stringify({
    app_id: Deno.env.get('META_APP_ID') ?? '',
    wa_config_id: Deno.env.get('META_WA_CONFIG_ID') ?? '',
    fb_config_id: Deno.env.get('META_FB_CONFIG_ID') ?? '',
  }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
});
