import { createClient } from 'npm:@supabase/supabase-js@2';
import { getValidMlAccount } from './ml-auth.ts';

export type Channel = 'mercadolibre' | 'instagram' | 'facebook';
export const CHANNELS: Channel[] = ['mercadolibre', 'instagram', 'facebook'];

export const GRAPH_VERSION = Deno.env.get('META_GRAPH_VERSION') || 'v23.0';
export const GRAPH = `https://graph.facebook.com/${GRAPH_VERSION}`;
export const publishingEnabled = () =>
  (Deno.env.get('PUBLISHING_ENABLED') ?? 'true').toLowerCase() !== 'false';

export const admin = () =>
  createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

export type AdminClient = ReturnType<typeof admin>;

/** Valida el JWT del request y devuelve el usuario. Nunca confía en un user_id del body. */
export async function requireUser(req: Request) {
  const header = req.headers.get('Authorization');
  if (!header?.startsWith('Bearer ')) throw new HttpError(401, 'No autenticado');
  const { data, error } = await admin().auth.getUser(header.replace('Bearer ', ''));
  if (error || !data.user) throw new HttpError(401, 'No autenticado');
  return data.user;
}

export class HttpError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export function json(body: unknown, status = 200, cors: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, 'Content-Type': 'application/json' },
  });
}

/** Trae el vehículo verificando que sea del usuario (defensa contra cambio de UUID). */
export async function getOwnVehicle(db: AdminClient, userId: string, vehicleId: string) {
  const { data, error } = await db
    .from('vehicles').select('*').eq('id', vehicleId).eq('user_id', userId).maybeSingle();
  if (error) throw new HttpError(500, error.message);
  if (!data) throw new HttpError(404, 'El vehículo no existe o no es tuyo');
  return data as any;
}

export async function getMedia(db: AdminClient, vehicleId: string) {
  const { data } = await db
    .from('vehicle_media').select('*').eq('vehicle_id', vehicleId)
    .order('is_cover', { ascending: false }).order('sort_order', { ascending: true });
  return (data || []) as any[];
}

/**
 * Resuelve la conexión vigente de un canal.
 * Usa `connected_accounts` (donde vive el OAuth real) y espeja el estado
 * en `channel_connections` para que la UI lo muestre sin exponer tokens.
 */
export async function getConnection(db: AdminClient, userId: string, channel: Channel) {
  if (channel === 'mercadolibre') {
    const account = await getValidMlAccount(db, userId); // refresca el token si hace falta
    await mirrorConnection(db, userId, channel, {
      external_account_id: account.account_external_id || String((account.meta as any)?.user_id ?? ''),
      external_account_name: account.account_name,
      expires_at: account.expires_at,
      metadata: { site_id: (account.meta as any)?.site_id || 'MLA' },
    });
    return { token: account.access_token as string, meta: (account.meta || {}) as any, raw: account };
  }

  const { data: accounts } = await db.from('connected_accounts').select('*')
    .eq('user_id', userId).eq('platform', channel);
  // Preferimos la Página/cuenta que el usuario eligió explícitamente.
  const account = (accounts || []).find((a: any) => (a.meta || {})?.selected) || accounts?.[0];
  if (!account) {
    throw new HttpError(400, channel === 'facebook'
      ? 'Conectá una Página de Facebook antes de publicar.'
      : 'Conectá una cuenta profesional de Instagram antes de publicar.');
  }
  await mirrorConnection(db, userId, channel, {
    external_account_id: (account.meta as any)?.page_id || (account.meta as any)?.ig_user_id || account.account_external_id,
    external_account_name: account.account_name,
    expires_at: account.expires_at,
    metadata: { has_page: !!(account.meta as any)?.page_id, has_ig: !!(account.meta as any)?.ig_user_id },
  });
  return { token: account.access_token as string, meta: (account.meta || {}) as any, raw: account };
}

export async function mirrorConnection(
  db: AdminClient, userId: string, channel: Channel,
  patch: Record<string, unknown>,
) {
  await db.from('channel_connections').upsert(
    { user_id: userId, channel, secret_ref: `connected_accounts:${channel}`, ...patch },
    { onConflict: 'user_id,channel' },
  );
}

/** Traduce errores técnicos a mensajes accionables en español. */
export function humanError(channel: Channel, raw: string) {
  const t = (raw || '').toLowerCase();
  if (t.includes('token') || t.includes('expired') || t.includes('190') || t.includes('invalid access'))
    return { code: 'auth', message: `La conexión con ${label(channel)} venció o fue revocada. Reconectá la cuenta.` };
  if (t.includes('conect') && t.includes('antes de publicar'))
    return { code: 'not_connected', message: raw };
  if (t.includes('image') || t.includes('picture') || t.includes('media') || t.includes('foto'))
    return { code: 'media', message: `${label(channel)} rechazó las imágenes: ${raw}` };
  if (t.includes('attribute') || t.includes('categor'))
    return { code: 'attributes', message: `Falta información obligatoria de la categoría: ${raw}` };
  if (t.includes('price') || t.includes('precio'))
    return { code: 'price', message: `El precio no es válido para ${label(channel)}: ${raw}` };
  return { code: 'platform', message: `${label(channel)} rechazó la publicación: ${raw}` };
}

export const label = (c: Channel) =>
  c === 'mercadolibre' ? 'Mercado Libre' : c === 'facebook' ? 'Facebook' : 'Instagram';

/** Convierte la respuesta de error de Mercado Libre en texto legible. */
export function mlErrorText(payload: any, status: number) {
  const causes = Array.isArray(payload?.cause)
    ? payload.cause.map((c: any) => `${c.code ? `[${c.code}] ` : ''}${c.message || JSON.stringify(c)}`).join(' · ')
    : '';
  return [payload?.message || payload?.error || `HTTP ${status}`, causes].filter(Boolean).join(' — ');
}
