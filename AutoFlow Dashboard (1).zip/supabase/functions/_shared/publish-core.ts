import { createClient } from 'npm:@supabase/supabase-js@2';

export type Channel = 'website' | 'mercadolibre' | 'facebook' | 'instagram';

export const CHANNELS: Channel[] = ['website', 'mercadolibre', 'facebook', 'instagram'];

export const admin = () =>
  createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

export async function requireUser(req: Request) {
  const auth = req.headers.get('Authorization');
  if (!auth?.startsWith('Bearer ')) throw new Error('No autenticado');
  const { data, error } = await admin().auth.getUser(auth.replace('Bearer ', ''));
  if (error || !data.user) throw new Error('No autenticado');
  return { user: data.user, authHeader: auth };
}

export async function hashPayload(payload: unknown) {
  const buf = new TextEncoder().encode(JSON.stringify(payload));
  const digest = await crypto.subtle.digest('SHA-256', buf);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

/** Traduce errores técnicos a mensajes comprensibles en español. */
export function humanError(channel: Channel, raw: string): { message: string; code: string } {
  const t = (raw || '').toLowerCase();
  const code = /code[^0-9]*(\d+)/.exec(t)?.[1] ?? '';
  if (t.includes('190') || t.includes('token') || t.includes('expired') || t.includes('invalid access'))
    return {
      code: code || 'auth',
      message:
        channel === 'mercadolibre'
          ? 'La conexión con Mercado Libre venció. Volvé a conectar la cuenta para continuar.'
          : `La conexión con ${channel === 'facebook' ? 'Facebook' : 'Instagram'} venció o fue revocada. Reconectá la cuenta para continuar.`,
    };
  if (t.includes('conect') && t.includes('primero'))
    return { code: 'not_connected', message: 'Todavía no hay una cuenta conectada para este canal.' };
  if (t.includes('foto') || t.includes('image') || t.includes('media'))
    return { code: code || 'media', message: 'Las imágenes no cumplen con el formato o tamaño que pide la plataforma.' };
  if (t.includes('categor') || t.includes('attribute') || t.includes('atribut'))
    return { code: code || 'attributes', message: 'Falta completar información obligatoria que pide la categoría de Mercado Libre.' };
  if (t.includes('price') || t.includes('precio'))
    return { code: code || 'price', message: 'El precio cargado no es válido para esta plataforma.' };
  return { code: code || 'platform', message: `La plataforma rechazó la publicación: ${raw}` };
}

export function overallStatus(jobs: { status: string }[]) {
  if (jobs.some((j) => ['en_cola', 'publicando', 'validando', 'procesando'].includes(j.status))) return 'procesando';
  const ok = jobs.filter((j) => ['publicado', 'actualizado', 'sin_cambios'].includes(j.status)).length;
  if (ok === jobs.length) return 'publicado_completo';
  if (ok > 0) return 'publicado_parcial';
  return 'error_total';
}

type RunArgs = {
  db: ReturnType<typeof admin>;
  authHeader: string;
  userId: string;
  carId: string;
  jobId: string;
  channel: Channel;
  payload: any;
};

/** Ejecuta un job de un canal. Nunca lanza: siempre deja el job en un estado final. */
export async function runJob({ db, authHeader, userId, carId, jobId, channel, payload }: RunArgs) {
  const setJob = (patch: Record<string, unknown>) => db.from('publication_jobs').update(patch).eq('id', jobId);
  await setJob({ status: 'publicando', started_at: new Date().toISOString() });

  const payloadHash = await hashPayload(payload);
  const { data: existing } = await db
    .from('channel_publications')
    .select('*')
    .eq('car_id', carId)
    .eq('channel', channel)
    .maybeSingle();

  // Idempotencia: mismo payload ya publicado con éxito -> no rehacer nada.
  if (existing?.external_publication_id && existing.payload_hash === payloadHash && existing.status === 'publicado') {
    await setJob({ status: 'sin_cambios', finished_at: new Date().toISOString() });
    return { channel, ok: true, skipped: true, url: existing.external_url };
  }

  try {
    let externalId: string | null = null;
    let externalUrl: string | null = null;
    let response: any = null;

    if (channel === 'website') {
      const { data: car, error } = await db
        .from('cars')
        .update({ mostrar_publico: true, estado_publicacion: 'publicado' })
        .eq('id', carId)
        .eq('user_id', userId)
        .select('slug')
        .single();
      if (error) throw new Error(error.message);
      externalId = car?.slug ?? carId;
      externalUrl = `/catalogo/${car?.slug ?? carId}`;
      response = { slug: car?.slug };
    } else {
      const base = `${Deno.env.get('SUPABASE_URL')}/functions/v1`;
      const headers = { 'Content-Type': 'application/json', Authorization: authHeader };
      const res =
        channel === 'mercadolibre'
          ? await fetch(`${base}/ml-publish`, { method: 'POST', headers, body: JSON.stringify(payload) })
          : await fetch(`${base}/meta-publish`, { method: 'POST', headers, body: JSON.stringify(payload) });
      response = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(response?.error || `HTTP ${res.status}`);
      externalId = response.id ?? null;
      externalUrl = response.url ?? null;
    }

    const row = {
      user_id: userId,
      car_id: carId,
      channel,
      external_publication_id: externalId,
      external_url: externalUrl,
      status: 'publicado',
      payload_hash: payloadHash,
      last_successful_payload: payload,
      last_response: response,
      published_at: new Date().toISOString(),
    };
    if (existing?.id) await db.from('channel_publications').update(row).eq('id', existing.id);
    else await db.from('channel_publications').insert(row);

    await setJob({
      status: existing?.external_publication_id ? 'actualizado' : 'publicado',
      response,
      finished_at: new Date().toISOString(),
      error_code: null,
      error_message: null,
      technical_error: null,
    });
    return { channel, ok: true, id: externalId, url: externalUrl };
  } catch (e) {
    const raw = (e as Error).message;
    const { message, code } = humanError(channel, raw);
    await setJob({
      status: code === 'auth' ? 'error_autorizacion' : code === 'attributes' ? 'requiere_correccion' : 'error_plataforma',
      error_code: code,
      error_message: message,
      technical_error: raw,
      finished_at: new Date().toISOString(),
    });
    if (existing?.id) await db.from('channel_publications').update({ status: 'error' }).eq('id', existing.id);
    else
      await db.from('channel_publications').insert({
        user_id: userId, car_id: carId, channel, status: 'error',
      });
    return { channel, ok: false, error: message };
  }
}

/** Arma el payload que espera cada edge function de publicación. */
export async function buildPayload(db: ReturnType<typeof admin>, channel: Channel, car: any, opts: any) {
  const { data: photos } = await db
    .from('car_photos')
    .select('url, orden, es_portada')
    .eq('car_id', car.id)
    .order('es_portada', { ascending: false })
    .order('orden', { ascending: true });
  const fotos = (photos || []).map((p: any) => p.url);

  if (channel === 'mercadolibre')
    return {
      car_id: car.id,
      titulo: opts.titulo,
      descripcion: opts.ml_text,
      precio: car.precio_venta,
      fotos,
      account_id: opts.ml_account_id,
      listing_type_id: opts.listing_type_id,
    };
  if (channel === 'facebook')
    return { platform: 'facebook', car_id: car.id, descripcion: opts.fb_text, fotos, account_id: opts.fb_account_id };
  if (channel === 'instagram')
    return {
      platform: 'instagram', car_id: car.id, descripcion: opts.ig_text, fotos,
      account_id: opts.ig_account_id, carousel: opts.carousel ?? fotos.length > 1,
    };
  return { car_id: car.id, fotos };
}
