import type { AdminClient } from './publisher.ts';

const APP_ORIGIN = Deno.env.get('APP_URL') || 'https://grupo-boazzo-control.lovable.app';

export async function sha256(value: string) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

/** Origen seguro al que podemos volver después del OAuth. */
export function safeOrigin(candidate?: string | null) {
  try {
    const url = new URL(candidate ?? '');
    if (url.protocol === 'https:' && url.hostname.endsWith('.lovable.app')) return url.origin;
  } catch { /* fallback */ }
  return APP_ORIGIN;
}

export function resultUrl(origin: string, params: Record<string, string>) {
  const qs = new URLSearchParams(params).toString();
  return `${safeOrigin(origin)}/oauth/result?${qs}`;
}

/** Vuelta a la pantalla de conexiones con un resultado no sensible. */
export function connectionsUrl(origin: string, params: Record<string, string>) {
  const url = new URL('/settings/connections', safeOrigin(origin));
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  return url.toString();
}

export function redirectTo(location: string) {
  return new Response(null, {
    status: 302,
    headers: { Location: location, 'Cache-Control': 'no-store', Pragma: 'no-cache' },
  });
}


/** Crea un state de un solo uso y devuelve el valor que viaja al proveedor. */
export function randomVerifier() {
  const bytes = crypto.getRandomValues(new Uint8Array(48));
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/** code_challenge S256 requerido por Mercado Libre (PKCE). */
export async function codeChallenge(verifier: string) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier));
  return btoa(String.fromCharCode(...new Uint8Array(digest)))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export async function createState(
  db: AdminClient, userId: string, provider: 'mercadolibre' | 'meta' | 'instagram', returnTo: string,
  codeVerifier?: string,
) {
  const state = crypto.randomUUID();
  const { error } = await db.from('oauth_states').insert({
    state_hash: await sha256(state),
    user_id: userId,
    provider,
    return_to: safeOrigin(returnTo),
    code_verifier: codeVerifier ?? null,
    expires_at: new Date(Date.now() + 10 * 60_000).toISOString(),
  });
  if (error) throw new Error(error.message);
  return state;
}

/** Valida y consume el state. Lanza si no existe, venció o ya fue usado. */
export async function consumeState(
  db: AdminClient, state: string, provider: 'mercadolibre' | 'meta' | 'instagram',
) {
  const hash = await sha256(state || '');
  const { data } = await db.from('oauth_states').select('*').eq('state_hash', hash).maybeSingle();
  if (!data || data.provider !== provider) throw new Error('La autorización no es válida. Volvé a intentar desde Conexiones.');
  if (data.consumed_at) throw new Error('Esta autorización ya fue usada. Volvé a intentar desde Conexiones.');
  if (new Date(data.expires_at).getTime() < Date.now()) throw new Error('La autorización venció. Volvé a intentar desde Conexiones.');
  await db.from('oauth_states').update({ consumed_at: new Date().toISOString() }).eq('state_hash', hash);
  return {
    userId: data.user_id as string,
    returnTo: safeOrigin(data.return_to as string),
    codeVerifier: (data.code_verifier as string | null) ?? undefined,
  };
}
