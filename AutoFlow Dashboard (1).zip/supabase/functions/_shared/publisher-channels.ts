import { AdminClient, GRAPH, HttpError, getConnection, getMedia, mlErrorText } from './publisher.ts';
import { baseAttributes, fetchCategoryAttributes, mergeAttributes } from './publisher-validate.ts';

type Ctx = { db: AdminClient; userId: string; vehicle: any };

const photoUrls = (media: any[]) => media.map((m) => m.public_url).filter(Boolean) as string[];

/** Limpia teléfonos/URLs de la descripción de Mercado Libre. */
const cleanMlDescription = (text: string) =>
  text.replace(/https?:\/\/\S+/g, '').replace(/\b\d[\d\s.-]{6,}\b/g, '').replace(/\n{3,}/g, '\n\n').trim();

export async function publishMercadoLibre({ db, userId, vehicle }: Ctx, existing: any) {
  const { token, meta } = await getConnection(db, userId, 'mercadolibre');
  const media = await getMedia(db, vehicle.id);
  const pictures = photoUrls(media).slice(0, 12).map((source) => ({ source }));

  // Revalidar atributos vigentes antes de publicar
  const attrsSpec = await fetchCategoryAttributes(vehicle.ml_category_id);
  const merged = mergeAttributes(vehicle.ml_attributes || [], baseAttributes(vehicle));
  const validIds = new Set(attrsSpec.map((a: any) => a.id));
  const attributes = merged.filter((a) => validIds.has(a.id));

  const loc = vehicle.location || {};
  const payload: Record<string, unknown> = {
    title: String(vehicle.title).trim().slice(0, 60),
    category_id: vehicle.ml_category_id,
    price: Number(vehicle.price),
    currency_id: vehicle.currency_id || 'ARS',
    available_quantity: 1,
    buying_mode: 'classified',
    listing_type_id: vehicle.ml_listing_type_id || 'silver',
    condition: vehicle.condition === 'new' ? 'new' : 'used',
    channels: ['marketplace'],
    pictures,
    location: {
      address_line: loc.address || loc.direccion || undefined,
      zip_code: loc.zip || loc.codigo_postal || undefined,
      city: { name: loc.city || loc.ciudad },
      state: { name: loc.state || loc.provincia },
      country: { id: 'AR' },
      latitude: loc.latitude ?? undefined,
      longitude: loc.longitude ?? undefined,
    },
    attributes,
    sale_terms: vehicle.financing
      ? [
          { id: 'WITH_FINANCING_OPTIONS', value_id: '242085', value_name: 'Sí' },
          ...(vehicle.initial_payment
            ? [{
                id: 'INITIAL_PAYMENT_AMOUNT',
                value_name: `${vehicle.initial_payment} ${vehicle.currency_id || 'ARS'}`,
                value_struct: { number: Number(vehicle.initial_payment), unit: vehicle.currency_id || 'ARS' },
              }]
            : []),
        ]
      : [{ id: 'WITH_FINANCING_OPTIONS', value_id: '242084', value_name: 'No' }],
  };

  let itemId: string | null = existing?.external_id || null;
  let itemJson: any = null;

  if (!itemId) {
    const res = await fetch('https://api.mercadolibre.com/items', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    itemJson = await res.json().catch(() => ({}));
    if (!res.ok) throw new HttpError(400, mlErrorText(itemJson, res.status));
    itemId = itemJson.id;
  }

  // La descripción se agrega SOLO después de crear el ítem.
  const descRes = await fetch(`https://api.mercadolibre.com/items/${itemId}/description`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ plain_text: cleanMlDescription(vehicle.description || '') }),
  });
  const url = itemJson?.permalink || `https://articulo.mercadolibre.com.ar/${String(itemId).replace('MLA', 'MLA-')}`;
  if (!descRes.ok) {
    const descJson = await descRes.json().catch(() => ({}));
    return {
      partial: true,
      externalId: itemId,
      externalUrl: url,
      response: { item: itemJson, description_error: descJson, site_id: meta?.site_id },
      error: `El aviso se creó pero falló la descripción: ${mlErrorText(descJson, descRes.status)}. Reintentá sólo la descripción.`,
    };
  }
  return { partial: false, externalId: itemId, externalUrl: url, response: { item: itemJson } };
}

/**
 * Sube una foto a la Página. Primero manda los bytes (multipart) porque Facebook
 * suele rechazar URLs que no puede descargar; si falla, reintenta con la URL.
 */
async function uploadFacebookPhoto(
  pageId: string, token: string, url: string, opts: { published: boolean; caption?: string },
) {
  try {
    const img = await fetch(url);
    if (img.ok) {
      const type = img.headers.get('content-type') || 'image/jpeg';
      const ext = type.includes('png') ? 'png' : type.includes('webp') ? 'webp' : 'jpg';
      const form = new FormData();
      form.append('source', new Blob([await img.arrayBuffer()], { type }), `foto.${ext}`);
      form.append('published', String(opts.published));
      if (opts.caption) form.append('caption', opts.caption);
      const res = await fetch(`${GRAPH}/${pageId}/photos`, {
        method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: form,
      });
      const json = await res.json();
      if (res.ok && json.id) return { ok: true as const, json };
    }
  } catch { /* reintentamos con la URL */ }

  const res = await fetch(`${GRAPH}/${pageId}/photos`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ url, published: opts.published, ...(opts.caption ? { caption: opts.caption } : {}) }),
  });
  const json = await res.json();
  if (res.ok && json.id) return { ok: true as const, json };
  return { ok: false as const, error: json.error?.error_user_msg || json.error?.message || 'Facebook rechazó la foto' };
}

export async function publishFacebook({ db, userId, vehicle }: Ctx) {
  const { token, meta } = await getConnection(db, userId, 'facebook');
  const pageId = meta?.page_id;
  if (!pageId) throw new HttpError(400, 'No hay una Página de Facebook seleccionada en la conexión.');
  const media = await getMedia(db, vehicle.id);
  const urls = photoUrls(media);
  const message = (vehicle.facebook_message || vehicle.description || '').trim();

  if (!urls.length) {
    const res = await fetch(`${GRAPH}/${pageId}/feed`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ message }),
    });
    const json = await res.json();
    if (!res.ok) throw new HttpError(400, json.error?.error_user_msg || json.error?.message || 'Facebook rechazó la publicación');
    const id = json.post_id || json.id;
    return { partial: false, externalId: id, externalUrl: `https://www.facebook.com/${id}`, response: json };
  }

  if (urls.length === 1) {
    const up = await uploadFacebookPhoto(pageId, token, urls[0], { published: true, caption: message });
    if (!up.ok) throw new HttpError(400, up.error);
    const id = up.json.post_id || up.json.id;
    return { partial: false, externalId: id, externalUrl: `https://www.facebook.com/${id}`, response: up.json };
  }

  const attached: { media_fbid: string }[] = [];
  const failed: string[] = [];
  for (const url of urls.slice(0, 10)) {
    const up = await uploadFacebookPhoto(pageId, token, url, { published: false });
    if (up.ok) attached.push({ media_fbid: up.json.id });
    else failed.push(up.error);
  }
  if (!attached.length) throw new HttpError(400, `Ninguna foto pudo subirse a Facebook: ${failed.join(' · ')}`);


  const res = await fetch(`${GRAPH}/${pageId}/feed`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ message, attached_media: attached }),
  });
  const json = await res.json();
  if (!res.ok) throw new HttpError(400, json.error?.error_user_msg || json.error?.message || 'Facebook rechazó la publicación');
  const id = json.post_id || json.id;
  return {
    partial: failed.length > 0,
    externalId: id,
    externalUrl: `https://www.facebook.com/${id}`,
    response: { ...json, fotos_fallidas: failed },
    error: failed.length ? `Se publicó sin ${failed.length} foto(s) que Facebook rechazó.` : undefined,
  };
}

async function waitContainer(igId: string, containerId: string, token: string) {
  for (let i = 0; i < 12; i++) {
    const res = await fetch(`${GRAPH}/${containerId}?fields=status_code,status&access_token=${token}`);
    const json = await res.json().catch(() => ({}));
    if (json.status_code === 'FINISHED') return;
    if (json.status_code === 'ERROR') throw new HttpError(400, `Instagram no pudo procesar una imagen: ${json.status || ''}`);
    await new Promise((r) => setTimeout(r, 2000));
  }
}

export async function publishInstagram({ db, userId, vehicle }: Ctx) {
  const { token, meta } = await getConnection(db, userId, 'instagram');
  const igId = meta?.ig_user_id;
  if (!igId) throw new HttpError(400, 'La conexión no tiene una cuenta profesional de Instagram vinculada a la Página.');
  const media = await getMedia(db, vehicle.id);
  const urls = photoUrls(media).slice(0, 10);
  if (!urls.length) throw new HttpError(400, 'Instagram necesita al menos una foto con URL pública.');
  const hashtags = (vehicle.hashtags || []).map((h: string) => (h.startsWith('#') ? h : `#${h}`)).join(' ');
  const caption = [(vehicle.instagram_caption || vehicle.description || '').trim(), hashtags].filter(Boolean).join('\n\n').slice(0, 2200);

  let creationId: string;
  if (urls.length > 1) {
    const children: string[] = [];
    for (const url of urls) {
      const res = await fetch(`${GRAPH}/${igId}/media`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image_url: url, is_carousel_item: true, access_token: token }),
      });
      const json = await res.json();
      if (!res.ok) throw new HttpError(400, `Instagram rechazó la foto ${urls.indexOf(url) + 1}: ${json.error?.message || 'formato o tamaño inválido'}`);
      await waitContainer(igId, json.id, token);
      children.push(json.id);
    }
    const res = await fetch(`${GRAPH}/${igId}/media`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ media_type: 'CAROUSEL', children: children.join(','), caption, access_token: token }),
    });
    const json = await res.json();
    if (!res.ok) throw new HttpError(400, json.error?.message || 'Instagram rechazó el carrusel');
    creationId = json.id;
  } else {
    const res = await fetch(`${GRAPH}/${igId}/media`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ image_url: urls[0], caption, access_token: token }),
    });
    const json = await res.json();
    if (!res.ok) throw new HttpError(400, json.error?.message || 'Instagram rechazó la imagen');
    creationId = json.id;
  }
  await waitContainer(igId, creationId, token);

  const pubRes = await fetch(`${GRAPH}/${igId}/media_publish`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ creation_id: creationId, access_token: token }),
  });
  const pubJson = await pubRes.json();
  if (!pubRes.ok) throw new HttpError(400, pubJson.error?.message || 'Instagram rechazó la publicación');
  const permalinkRes = await fetch(`${GRAPH}/${pubJson.id}?fields=permalink&access_token=${token}`);
  const permalink = await permalinkRes.json().catch(() => ({}));
  return { partial: false, externalId: pubJson.id, externalUrl: permalink.permalink || null, response: pubJson };
}
