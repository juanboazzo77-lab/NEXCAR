import { createClient } from 'npm:@supabase/supabase-js@2';

type AdminClient = ReturnType<typeof createClient>;

export async function getValidMlAccount(admin: AdminClient, userId: string, accountId?: string) {
  let query = admin.from('connected_accounts').select('*')
    .eq('user_id', userId).eq('platform', 'mercadolibre');
  if (accountId) query = query.eq('id', accountId);
  const { data: accounts, error } = await query
    .order('updated_at', { ascending: false })
    .limit(accountId ? 1 : 20);
  if (error) throw new Error(error.message);
  const account = accountId
    ? accounts?.[0]
    : accounts?.find((candidate) => candidate.status === 'conectado'
      && (!candidate.expires_at || new Date(candidate.expires_at).getTime() > Date.now()))
      || accounts?.find((candidate) => candidate.refresh_token)
      || accounts?.[0];
  if (!account) throw new Error('Cuenta de Mercado Libre no conectada');

  const expiresAt = account.expires_at ? new Date(account.expires_at).getTime() : 0;
  if (!expiresAt || expiresAt > Date.now() + 60_000) return account;
  if (!account.refresh_token) {
    await admin.from('connected_accounts').update({ status: 'vencido' }).eq('id', account.id);
    throw new Error('La conexión de Mercado Libre venció. Reconectá la cuenta para continuar.');
  }

  const { data: credentials } = await admin.from('ml_credentials')
    .select('app_id,client_secret').eq('user_id', userId).maybeSingle();
  const appId = credentials?.app_id || Deno.env.get('ML_APP_ID');
  const clientSecret = credentials?.client_secret || Deno.env.get('ML_CLIENT_SECRET');
  if (!appId || !clientSecret) throw new Error('Faltan las credenciales de la aplicación de Mercado Libre');

  const response = await fetch('https://api.mercadolibre.com/oauth/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
    body: new URLSearchParams({
      grant_type: 'refresh_token', client_id: appId,
      client_secret: clientSecret, refresh_token: account.refresh_token,
    }),
  });
  const token = await response.json();
  if (!response.ok) {
    await admin.from('connected_accounts').update({ status: 'vencido' }).eq('id', account.id);
    throw new Error(token?.message || 'Mercado Libre rechazó la renovación. Reconectá la cuenta.');
  }

  const patch = {
    access_token: token.access_token,
    refresh_token: token.refresh_token || account.refresh_token,
    expires_at: new Date(Date.now() + Number(token.expires_in || 21600) * 1000).toISOString(),
    status: 'conectado',
  };
  const { data: updated, error: updateError } = await admin.from('connected_accounts')
    .update(patch).eq('id', account.id).select('*').single();
  if (updateError) throw new Error(updateError.message);
  return updated;
}