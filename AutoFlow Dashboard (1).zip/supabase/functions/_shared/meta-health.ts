import { GRAPH, type AdminClient } from './publisher.ts';

export const REQUIRED_SCOPES = [
  'pages_show_list', 'pages_read_engagement', 'pages_manage_posts',
  'instagram_basic', 'instagram_content_publish',
];

export const mask = (id?: string | null) => (id ? `••••${String(id).slice(-4)}` : null);

/** Estado real de la conexión con Meta. Pruebas NO destructivas: sólo lecturas. */
export async function metaHealth(db: AdminClient, userId: string) {
  const { data: fbRows } = await db.from('connected_accounts').select('*')
    .eq('user_id', userId).eq('platform', 'facebook');
  const { data: igRows } = await db.from('connected_accounts').select('*')
    .eq('user_id', userId).eq('platform', 'instagram');

  const pages = (fbRows || []).map((p: any) => ({
    id: p.account_external_id, name: p.account_name,
    masked_id: mask(p.account_external_id),
    selected: !!p.meta?.selected,
    instagram: p.meta?.ig_user_id
      ? {
          id: p.meta.ig_user_id, masked_id: mask(p.meta.ig_user_id),
          username: (igRows || []).find((i: any) => i.account_external_id === p.meta.ig_user_id)?.account_name,
        }
      : null,
  }));

  if (!pages.length) {
    return {
      connected: false, pages: [],
      facebook: { ok: false, message: 'Todavía no conectaste Meta.' },
      instagram: { ok: false, message: 'Todavía no conectaste Meta.' },
      grantedScopes: [], missingScopes: REQUIRED_SCOPES, appMode: null,
      canPublish: false,
    };
  }

  const selectedPage = (fbRows || []).find((p: any) => p.meta?.selected) || null;
  const facebook: Record<string, unknown> = selectedPage
    ? { ok: false, message: 'Página elegida, falta probar la conexión.' }
    : { ok: false, message: 'Elegí en qué Página querés publicar.' };
  let instagram: Record<string, unknown> = { ok: false, message: 'Elegí primero una Página de Facebook.' };
  let grantedScopes: string[] = [];
  let missingScopes: string[] = [];
  let mode: string | null = null;

  if (selectedPage) {
    const pageRes = await fetch(`${GRAPH}/${selectedPage.account_external_id}?fields=id,name,instagram_business_account{id,username}&access_token=${selectedPage.access_token}`);
    const page = await pageRes.json();
    if (!pageRes.ok) {
      facebook.message = String(page?.error?.code) === '190'
        ? 'La conexión con Facebook venció o fue revocada. Reconectá Meta.'
        : page?.error?.message || 'No pudimos leer la Página.';
    } else {
      facebook.ok = true;
      facebook.message = `Facebook conectado a la Página: ${page.name}`;
      facebook.page = { name: page.name, masked_id: mask(page.id) };

      const igId = page.instagram_business_account?.id || selectedPage.meta?.ig_user_id;
      if (!igId) {
        instagram = { ok: false, message: 'Esta Página no tiene una cuenta profesional de Instagram vinculada' };
      } else {
        const igRes = await fetch(`${GRAPH}/${igId}?fields=id,username&access_token=${selectedPage.access_token}`);
        const ig = await igRes.json();
        instagram = igRes.ok
          ? { ok: true, message: `Instagram conectado: @${ig.username}`, account: { username: ig.username, masked_id: mask(ig.id) } }
          : { ok: false, message: ig?.error?.message || 'No pudimos leer la cuenta de Instagram.' };
      }
    }

    const permRes = await fetch(`${GRAPH}/me/permissions?access_token=${selectedPage.access_token}`);
    const perms = await permRes.json();
    grantedScopes = (perms?.data || []).filter((p: any) => p.status === 'granted').map((p: any) => p.permission);
    missingScopes = REQUIRED_SCOPES.filter((s) => grantedScopes.length > 0 && !grantedScopes.includes(s));
    const appRes = await fetch(`${GRAPH}/${Deno.env.get('META_APP_ID')}?fields=link&access_token=${selectedPage.access_token}`);
    mode = appRes.ok ? 'accesible' : 'sin acceso a los datos de la app (puede estar en modo desarrollo)';
  }

  return {
    connected: true, pages, facebook, instagram, grantedScopes, missingScopes,
    appMode: mode, canPublish: !!facebook.ok,
  };
}
