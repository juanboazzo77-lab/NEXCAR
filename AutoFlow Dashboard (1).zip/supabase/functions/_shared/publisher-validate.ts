import { AdminClient, Channel, HttpError, getMedia } from './publisher.ts';

export type ChannelIssues = { channel: Channel | 'general'; missing: string[]; warnings: string[] };

export async function fetchCategoryAttributes(categoryId: string) {
  const res = await fetch(`https://api.mercadolibre.com/categories/${categoryId}/attributes`);
  if (!res.ok) throw new HttpError(400, `No se pudieron leer los atributos de la categoría ${categoryId}`);
  return (await res.json()) as any[];
}

/** Prioriza el value_id oficial del catálogo de Mercado Libre cuando existe. */
function mlAttribute(id: string, valueId: string | null | undefined, valueName: unknown) {
  const name = valueName == null ? '' : String(valueName);
  return valueId ? { id, value_id: valueId, value_name: name } : { id, value_name: name };
}

/** Atributos base derivados de la ficha del vehículo. */
export function baseAttributes(vehicle: any) {
  const list: any[] = [
    mlAttribute('BRAND', vehicle.brand_value_id, vehicle.brand),
    mlAttribute('MODEL', vehicle.model_value_id, vehicle.model),
    mlAttribute('TRIM', vehicle.trim_value_id, vehicle.trim),
    mlAttribute('VEHICLE_YEAR', vehicle.year_value_id, vehicle.vehicle_year ? String(vehicle.vehicle_year) : ''),
  ];
  if (vehicle.mileage_km != null) list.push({ id: 'KILOMETERS', value_name: `${vehicle.mileage_km} km` });
  if (vehicle.fuel_type) list.push({ id: 'FUEL_TYPE', value_name: vehicle.fuel_type });
  if (vehicle.transmission) list.push({ id: 'TRANSMISSION', value_name: vehicle.transmission });
  if (vehicle.doors) list.push({ id: 'DOORS', value_name: String(vehicle.doors) });
  if (vehicle.engine) list.push({ id: 'ENGINE', value_name: vehicle.engine });
  if (vehicle.traction) list.push({ id: 'TRACTION_CONTROL', value_name: vehicle.traction });
  if (vehicle.exterior_color) list.push({ id: 'COLOR', value_name: vehicle.exterior_color });
  return list.filter((a) => a.value_name && String(a.value_name).trim());
}

export function mergeAttributes(saved: any[], base: any[]) {
  const map = new Map<string, any>();
  for (const a of base) map.set(a.id, a);
  for (const a of saved || []) if (a?.id && (a.value_id || a.value_name)) map.set(a.id, a);
  return [...map.values()];
}

/** Valida el vehículo para los canales pedidos. No publica nada. */
export async function validateVehicle(db: AdminClient, vehicle: any, channels: Channel[]) {
  const media = await getMedia(db, vehicle.id);
  const issues: ChannelIssues[] = [];
  const general: ChannelIssues = { channel: 'general', missing: [], warnings: [] };

  if (!vehicle.title?.trim()) general.missing.push('Título comercial');
  if (!vehicle.brand?.trim()) general.missing.push('Marca');
  if (!vehicle.model?.trim()) general.missing.push('Modelo');
  if (!vehicle.vehicle_year) general.missing.push('Año');
  if (!vehicle.price || Number(vehicle.price) <= 0) general.missing.push('Precio');
  if (!vehicle.description?.trim()) general.missing.push('Descripción');
  if (!media.length) general.missing.push('Al menos una foto');
  if (media.length && !media.some((m) => m.is_cover)) general.warnings.push('No hay foto de portada elegida');
  issues.push(general);

  for (const channel of channels) {
    const entry: ChannelIssues = { channel, missing: [], warnings: [] };

    if (channel === 'mercadolibre') {
      if (!vehicle.ml_category_id) entry.missing.push('Categoría de Mercado Libre');
      if (!vehicle.trim?.trim()) entry.missing.push('Versión / TRIM');
      if (!vehicle.location?.city && !vehicle.location?.ciudad) entry.missing.push('Ciudad');
      if (!vehicle.location?.state && !vehicle.location?.provincia) entry.missing.push('Provincia');
      if (vehicle.ml_category_id) {
        try {
          const attrs = await fetchCategoryAttributes(vehicle.ml_category_id);
          const merged = mergeAttributes(vehicle.ml_attributes || [], baseAttributes(vehicle));
          const has = (id: string) => merged.some((a) => a.id === id && (a.value_id || String(a.value_name || '').trim()));
          for (const attr of attrs) {
            const tags = attr.tags || {};
            if ((tags.required || tags.catalog_required) && !tags.read_only && !has(attr.id)) {
              entry.missing.push(`Mercado Libre exige: ${attr.name}`);
            }
          }
        } catch (e) {
          entry.warnings.push((e as Error).message);
        }
      }
      if (/(https?:\/\/|@|\b\d{6,}\b)/.test(vehicle.description || ''))
        entry.warnings.push('La descripción de Mercado Libre no debe incluir teléfonos ni links: se quitarán.');
    }

    if (channel === 'instagram') {
      if (!media.length) entry.missing.push('Instagram necesita al menos 1 foto');
      if (media.length > 10) entry.warnings.push('Instagram publica hasta 10 fotos: se usarán las primeras 10');
      const caption = vehicle.instagram_caption || vehicle.description || '';
      if (!caption.trim()) entry.missing.push('Texto para Instagram');
      if (caption.length > 2200) entry.missing.push('El texto de Instagram supera los 2200 caracteres');
      if (media.some((m) => !m.public_url)) entry.missing.push('Hay fotos sin URL pública accesible para Instagram');
    }

    if (channel === 'facebook') {
      const message = vehicle.facebook_message || vehicle.description || '';
      if (!message.trim()) entry.missing.push('Texto para Facebook');
      if (media.some((m) => !m.public_url)) entry.warnings.push('Hay fotos sin URL pública: se omitirán');
    }

    entry.missing.push(...general.missing.map((m) => m));
    entry.missing = [...new Set(entry.missing)];
    issues.push(entry);
  }

  const ok = issues.every((i) => i.missing.length === 0);
  return { ok, issues, photos: media.length };
}
