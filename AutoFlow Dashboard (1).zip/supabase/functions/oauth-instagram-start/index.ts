import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { admin, HttpError, json, requireUser } from '../_shared/publisher.ts';
import { createState } from '../_shared/oauth-state.ts';

/** Permisos de "Instagram API con Instagram Login" (no dependen de Facebook). */
export const IG_SCOPES = [
  'instagram_business_basic',
  'instagram_business_content_publish',
];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const user = await requireUser(req);
    const db = admin();
    const body = await req.json().catch(() => ({}));

    const appId = Deno.env.get('INSTAGRAM_APP_ID');
    const appSecret = Deno.env.get('INSTAGRAM_APP_SECRET');
    const missing = [
      !appId && 'INSTAGRAM_APP_ID',
      !appSecret && 'INSTAGRAM_APP_SECRET',
    ].filter(Boolean) as string[];
    if (!appId || !appSecret) {
      throw new HttpError(400, `Falta configurar Instagram: ${missing.join(', ')}.`);
    }

    const redirectUri = Deno.env.get('INSTAGRAM_REDIRECT_URI')
      || `${Deno.env.get('SUPABASE_URL')}/functions/v1/oauth-instagram-callback`;

    const state = await createState(db, user.id, 'instagram', body?.return_to);

    const configId = Deno.env.get('INSTAGRAM_CONFIG_ID');
    const authUrl = new URL('https://www.instagram.com/oauth/authorize');
    const params = new URLSearchParams({
      client_id: appId,
      redirect_uri: redirectUri,
      response_type: 'code',
      state,
    });
    // Si hay una configuración de Instagram Login for Business, los permisos salen de ahí.
    if (configId) params.set('config_id', configId);
    else params.set('scope', IG_SCOPES.join(','));
    authUrl.search = params.toString();

    return json({
      authorizationUrl: authUrl.toString(),
      redirectUri,
      scopes: configId ? [] : IG_SCOPES,
      diagnostics: { app_id_last4: appId.slice(-4), config_id: configId || null, redirect_uri: redirectUri, missing_vars: missing },
    }, 200, corsHeaders);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message }, status, corsHeaders);
  }
});
