// deno-lint-ignore-file no-explicit-any
import { createClient } from 'npm:@supabase/supabase-js@2';
import { getValidMlAccount } from '../_shared/ml-auth.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
});

type Value = { id: string; name: string };

const DOMAIN = 'MLA-CARS_AND_VANS';

async function topValues(attribute: string, known: { id: string; value_name: string }[], token?: string): Promise<Value[]> {
  const url = new URL(`https://api.mercadolibre.com/catalog_domains/${DOMAIN}/attributes/${attribute}/top_values`);
  url.searchParams.set('limit', '500');
  if (known.length) url.searchParams.set('known_attributes', JSON.stringify(known));
  const response = await fetch(url.toString(), {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });
  if (!response.ok) return [];
  const data = await response.json();
  const list = Array.isArray(data) ? data : (data?.values || data?.top_values || []);
  return (list as any[])
    .map((item) => ({ id: String(item.id ?? item.value_id ?? item.name), name: String(item.name ?? item.value_name ?? '') }))
    .filter((item) => item.name);
}

async function categoryValues(attributeId: string): Promise<Value[]> {
  const response = await fetch('https://api.mercadolibre.com/categories/MLA1744/attributes');
  const attributes = await response.json();
  if (!response.ok || !Array.isArray(attributes)) return [];
  const attribute = attributes.find((item: { id: string }) => item.id === attributeId);
  return (attribute?.values || []).map((value: Value) => ({ id: String(value.id), name: value.name }));
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const url = new URL(req.url);
    const brand = url.searchParams.get('brand')?.trim() || '';
    const model = url.searchParams.get('model')?.trim() || '';

    // Intentamos usar el token de Mercado Libre del usuario (habilita el catálogo filtrado)
    let token: string | undefined;
    try {
      const authHeader = req.headers.get('Authorization') || '';
      if (authHeader) {
        const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
        const { data: userData } = await admin.auth.getUser(authHeader.replace('Bearer ', ''));
        if (userData?.user) {
          const account: any = await getValidMlAccount(admin, userData.user.id);
          token = account?.access_token || undefined;
        }
      }
    } catch (_) { /* sin token: usamos el catálogo público */ }

    const currentYear = new Date().getFullYear() + 1;
    const years = Array.from({ length: currentYear - 1949 }, (_, index) => ({
      id: String(currentYear - index), name: String(currentYear - index),
    }));

    if (!brand) {
      let brands = token ? await topValues('BRAND', [], token) : [];
      if (!brands.length) brands = await categoryValues('BRAND');
      return json({ brands, models: [], trims: [], years });
    }

    if (!model) {
      const models = await topValues('MODEL', [{ id: 'BRAND', value_name: brand }], token);
      return json({ brands: [], models, trims: [], years });
    }

    const trims = await topValues('TRIM', [
      { id: 'BRAND', value_name: brand },
      { id: 'MODEL', value_name: model },
    ], token);
    return json({ brands: [], models: [], trims, years });
  } catch (error) {
    return json({ error: (error as Error).message, brands: [], models: [], trims: [], years: [] }, 200);
  }
});
