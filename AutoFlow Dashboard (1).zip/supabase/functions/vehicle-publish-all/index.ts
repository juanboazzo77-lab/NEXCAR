import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';

type Target = {
  platform: 'mercadolibre' | 'facebook' | 'instagram';
  account_id: string;
  listing_type_id?: string;
  carousel?: boolean;
  descripcion: string;
  titulo?: string;
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const auth = req.headers.get('Authorization');
    if (!auth) throw new Error('No autenticado');
    const userSupa = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: auth } } });
    const { data: { user } } = await userSupa.auth.getUser();
    if (!user) throw new Error('No autenticado');

    const { car_id, targets } = await req.json() as { car_id: string; targets: Target[] };
    if (!car_id || !Array.isArray(targets) || targets.length === 0) throw new Error('Faltan datos');

    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const { data: car } = await admin.from('cars').select('*').eq('id', car_id).eq('user_id', user.id).maybeSingle();
    if (!car) throw new Error('Auto no encontrado');
    const { data: photos } = await admin.from('car_photos').select('url, orden, es_portada').eq('car_id', car_id).order('es_portada', { ascending: false }).order('orden', { ascending: true });
    const fotos = (photos || []).map(p => p.url);

    const baseUrl = `${Deno.env.get('SUPABASE_URL')}/functions/v1`;
    const headers = { 'Content-Type': 'application/json', 'Authorization': auth };

    const runOne = async (t: Target) => {
      try {
        let res: Response;
        if (t.platform === 'mercadolibre') {
          res = await fetch(`${baseUrl}/ml-publish`, {
            method: 'POST', headers,
            body: JSON.stringify({ car_id, descripcion: t.descripcion, titulo: t.titulo, precio: car.precio_venta, fotos, account_id: t.account_id, listing_type_id: t.listing_type_id }),
          });
        } else {
          res = await fetch(`${baseUrl}/meta-publish`, {
            method: 'POST', headers,
            body: JSON.stringify({ platform: t.platform, descripcion: t.descripcion, fotos, car_id, account_id: t.account_id, carousel: t.carousel }),
          });
        }
        const json = await res.json();
        if (!res.ok) return { platform: t.platform, ok: false, error: json.error || `HTTP ${res.status}` };
        return { platform: t.platform, ok: true, id: json.id, url: json.url };
      } catch (e) {
        return { platform: t.platform, ok: false, error: (e as Error).message };
      }
    };

    const results = await Promise.all(targets.map(runOne));
    return new Response(JSON.stringify({ results }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
