import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { admin, getOwnVehicle, HttpError, json, requireUser } from '../_shared/publisher.ts';

type Tone = 'default' | 'shorter' | 'salesy' | 'formal';

const TONE_HINT: Record<Tone, string> = {
  default: 'Tono equilibrado y profesional.',
  shorter: 'Hacelo notoriamente más corto y directo, sin perder los datos clave.',
  salesy: 'Tono más vendedor y entusiasta, pero sin inventar nada ni exagerar el estado.',
  formal: 'Tono formal y sobrio, sin emojis.',
};

const SYSTEM = `Sos redactor especializado en venta de autos en Argentina. Escribí únicamente
con los datos recibidos. No inventes estado mecánico, dueño, service, garantía,
consumo, potencia, financiación ni equipamiento. No digas "impecable" o "sin
detalles" salvo que figure explícitamente. Usá español rioplatense profesional.
El precio debe conservar número y moneda. No incluyas patente, VIN, dirección
exacta ni datos privados. Máximo 4 emojis en Instagram y ninguno en Facebook.
Devolvé JSON válido según el esquema solicitado.`;

/** Ficha pública: nunca se envían VIN, patente ni dirección exacta a la IA. */
function publicFacts(v: any) {
  const loc = v.location || {};
  return {
    title: v.title, condition: v.condition, brand: v.brand, model: v.model, trim: v.trim,
    year: v.vehicle_year, price: Number(v.price), currency: v.currency_id || 'ARS',
    mileageKm: v.mileage_km ?? undefined, bodyType: v.body_type ?? undefined,
    fuelType: v.fuel_type ?? undefined, transmission: v.transmission ?? undefined,
    engine: v.engine ?? undefined, traction: v.traction ?? undefined,
    color: v.exterior_color ?? undefined,
    equipment: Array.isArray(v.equipment) ? v.equipment : [],
    safety: Array.isArray(v.safety) ? v.safety : [],
    observations: v.observations ?? undefined,
    city: loc.city || loc.ciudad || undefined,
    province: loc.state || loc.provincia || undefined,
    financing: !!v.financing, acceptsTrade: !!v.accepts_trade,
  };
}

/** Verificación determinística: los números del texto tienen que existir en la ficha. */
function checkCopy(text: string, v: any) {
  const warnings: string[] = [];
  const plain = text.toLowerCase();
  const numbers = (text.match(/\d[\d.,]{2,}/g) || [])
    .map((n) => Number(n.replace(/[.,]/g, '')))
    .filter((n) => Number.isFinite(n));
  const allowed = new Set<number>([
    Number(v.price), Math.round(Number(v.price)), Number(v.vehicle_year),
    ...(v.mileage_km ? [Number(v.mileage_km), Number(v.mileage_km) * 1000] : []),
    ...(v.initial_payment ? [Number(v.initial_payment)] : []),
  ]);
  for (const n of numbers) {
    if (n < 1900) continue;
    if (![...allowed].some((a) => Math.abs(a - n) <= Math.max(1, a * 0.001)))
      warnings.push(`El texto menciona el número ${n.toLocaleString('es-AR')} y no figura en la ficha.`);
  }
  if (!v.financing && /(financiaci|cuotas|financiad)/.test(plain))
    warnings.push('Menciona financiación pero el auto no la tiene habilitada.');
  if (!v.accepts_trade && /permuta/.test(plain))
    warnings.push('Menciona permuta pero el auto no acepta permuta.');
  if (v.license_plate && plain.includes(String(v.license_plate).toLowerCase()))
    warnings.push('El texto incluye la patente: hay que quitarla.');
  if (v.vin && plain.includes(String(v.vin).toLowerCase()))
    warnings.push('El texto incluye el VIN: hay que quitarlo.');
  return [...new Set(warnings)];
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const user = await requireUser(req);
    const db = admin();
    const { vehicleId, tone = 'default' } = await req.json();
    if (!vehicleId) throw new HttpError(400, 'Falta el auto');

    const vehicle = await getOwnVehicle(db, user.id, vehicleId);
    const apiKey = Deno.env.get('LOVABLE_API_KEY');
    if (!apiKey) throw new HttpError(500, 'Falta configurar la IA en el backend.');

    const res = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: `${SYSTEM}\n${TONE_HINT[(tone as Tone)] || TONE_HINT.default}` },
          { role: 'user', content: JSON.stringify(publicFacts(vehicle)) },
        ],
        tools: [{
          type: 'function',
          function: {
            name: 'entregar_textos',
            description: 'Devuelve los textos para Instagram y Facebook.',
            parameters: {
              type: 'object',
              properties: {
                instagram: {
                  type: 'object',
                  properties: {
                    caption: { type: 'string' },
                    hashtags: { type: 'array', items: { type: 'string' } },
                  },
                  required: ['caption', 'hashtags'], additionalProperties: false,
                },
                facebook: {
                  type: 'object',
                  properties: { message: { type: 'string' } },
                  required: ['message'], additionalProperties: false,
                },
                factsUsed: { type: 'array', items: { type: 'string' } },
              },
              required: ['instagram', 'facebook', 'factsUsed'], additionalProperties: false,
            },
          },
        }],
        tool_choice: { type: 'function', function: { name: 'entregar_textos' } },
      }),
    });

    if (res.status === 429) throw new HttpError(429, 'La IA está saturada. Probá de nuevo en un minuto.');
    if (res.status === 402) throw new HttpError(402, 'Se agotaron los créditos de IA del espacio de trabajo.');
    if (!res.ok) throw new HttpError(400, `La IA no respondió correctamente (${res.status}).`);

    const data = await res.json();
    const args = data?.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments;
    if (!args) throw new HttpError(400, 'La IA no devolvió textos válidos.');
    const parsed = JSON.parse(args);

    const caption = String(parsed?.instagram?.caption || '').slice(0, 2200);
    const message = String(parsed?.facebook?.message || '').slice(0, 5000);
    const hashtags = (parsed?.instagram?.hashtags || [])
      .map((h: string) => (h.startsWith('#') ? h : `#${h}`))
      .filter((h: string) => /^#[\p{L}\p{N}_]+$/u.test(h))
      .slice(0, 15);

    if (caption.length < 40 || message.length < 40)
      throw new HttpError(400, 'La IA devolvió textos demasiado cortos. Probá de nuevo.');

    const warnings = [...checkCopy(caption, vehicle), ...checkCopy(message, vehicle)];

    return json({
      instagram: { caption, hashtags },
      facebook: { message },
      factsUsed: parsed?.factsUsed || [],
      warnings,
    }, 200, corsHeaders);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message }, status, corsHeaders);
  }
});
