// Meta Webhook: recibe mensajes de WhatsApp Cloud API e Instagram Messaging
// GET: verificación (hub.challenge) — devuelve el challenge si el token coincide.
// POST: eventos de mensajes — los guarda en inbox_conversations/inbox_messages.

import { createClient } from 'npm:@supabase/supabase-js@2';
import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';

const VERIFY_TOKEN = Deno.env.get('META_WEBHOOK_VERIFY_TOKEN') ?? 'boazzo-meta-verify';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

async function upsertConversation(args: {
  userId: string;
  channelAccountId: string;
  platform: 'whatsapp' | 'instagram';
  externalContactId: string;
  contactName?: string | null;
  contactHandle?: string | null;
  lastMessageText: string;
  sentAt: string;
}) {
  // Find existing
  const { data: existing } = await supabase
    .from('inbox_conversations')
    .select('id, unread_count')
    .eq('channel_account_id', args.channelAccountId)
    .eq('external_contact_id', args.externalContactId)
    .maybeSingle();

  if (existing) {
    await supabase.from('inbox_conversations').update({
      last_message_text: args.lastMessageText,
      last_message_at: args.sentAt,
      unread_count: (existing.unread_count ?? 0) + 1,
      contact_name: args.contactName ?? undefined,
      contact_handle: args.contactHandle ?? undefined,
    }).eq('id', existing.id);
    return existing.id as string;
  }
  const { data: created, error } = await supabase.from('inbox_conversations').insert({
    user_id: args.userId,
    channel_account_id: args.channelAccountId,
    platform: args.platform,
    external_contact_id: args.externalContactId,
    contact_name: args.contactName,
    contact_handle: args.contactHandle,
    last_message_text: args.lastMessageText,
    last_message_at: args.sentAt,
    unread_count: 1,
    estado: 'nuevo',
  }).select('id').single();
  if (error) throw error;
  return created!.id as string;
}

async function insertMessage(args: {
  userId: string;
  conversationId: string;
  direction: 'in' | 'out';
  body: string;
  messageType?: string;
  externalMessageId?: string;
  sentAt: string;
}) {
  await supabase.from('inbox_messages').insert({
    user_id: args.userId,
    conversation_id: args.conversationId,
    direction: args.direction,
    body: args.body,
    message_type: args.messageType ?? 'text',
    external_message_id: args.externalMessageId,
    sent_at: args.sentAt,
  });
}

async function findAccount(platform: 'whatsapp' | 'instagram', externalId: string) {
  const { data } = await supabase
    .from('channel_accounts')
    .select('id, user_id')
    .eq('platform', platform)
    .eq('external_id', externalId)
    .maybeSingle();
  return data;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  const url = new URL(req.url);

  // Verify challenge
  if (req.method === 'GET') {
    const mode = url.searchParams.get('hub.mode');
    const token = url.searchParams.get('hub.verify_token');
    const challenge = url.searchParams.get('hub.challenge');
    if (mode === 'subscribe' && token === VERIFY_TOKEN && challenge) {
      return new Response(challenge, { status: 200 });
    }
    return new Response('Forbidden', { status: 403 });
  }

  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });

  try {
    const body = await req.json();
    // WhatsApp Cloud API payload
    if (body.object === 'whatsapp_business_account') {
      for (const entry of body.entry ?? []) {
        for (const change of entry.changes ?? []) {
          const value = change.value ?? {};
          const phoneNumberId = value?.metadata?.phone_number_id;
          if (!phoneNumberId) continue;
          const account = await findAccount('whatsapp', phoneNumberId);
          if (!account) continue;
          const contacts = value.contacts ?? [];
          const messages = value.messages ?? [];
          for (const msg of messages) {
            const from = msg.from as string;
            const contact = contacts.find((c: any) => c.wa_id === from);
            const text = msg.text?.body ?? `[${msg.type ?? 'msg'}]`;
            const sentAt = new Date(Number(msg.timestamp) * 1000).toISOString();
            const convId = await upsertConversation({
              userId: account.user_id,
              channelAccountId: account.id,
              platform: 'whatsapp',
              externalContactId: from,
              contactName: contact?.profile?.name ?? null,
              contactHandle: from,
              lastMessageText: text,
              sentAt,
            });
            await insertMessage({
              userId: account.user_id,
              conversationId: convId,
              direction: 'in',
              body: text,
              messageType: msg.type ?? 'text',
              externalMessageId: msg.id,
              sentAt,
            });
          }
        }
      }
    }
    // Instagram Messaging payload
    else if (body.object === 'instagram') {
      for (const entry of body.entry ?? []) {
        const igUserId = entry.id as string;
        const account = await findAccount('instagram', igUserId);
        if (!account) continue;
        for (const m of entry.messaging ?? []) {
          if (!m.message || m.message.is_echo) continue;
          const senderId = m.sender?.id as string;
          if (senderId === igUserId) continue;
          const text = m.message?.text ?? '[media]';
          const sentAt = new Date(Number(m.timestamp ?? Date.now())).toISOString();
          const convId = await upsertConversation({
            userId: account.user_id,
            channelAccountId: account.id,
            platform: 'instagram',
            externalContactId: senderId,
            contactName: null,
            contactHandle: senderId,
            lastMessageText: text,
            sentAt,
          });
          await insertMessage({
            userId: account.user_id,
            conversationId: convId,
            direction: 'in',
            body: text,
            messageType: 'text',
            externalMessageId: m.message?.mid,
            sentAt,
          });
        }
      }
    }
    return new Response('EVENT_RECEIVED', { status: 200 });
  } catch (e) {
    console.error('webhook error', e);
    return new Response('error', { status: 200 }); // 200 para que Meta no reintente en loop
  }
});
