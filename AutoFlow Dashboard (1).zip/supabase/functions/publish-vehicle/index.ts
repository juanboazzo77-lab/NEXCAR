import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import {
  CHANNELS, Channel, HttpError, admin, getOwnVehicle, humanError, json, label, publishingEnabled, requireUser,
} from '../_shared/publisher.ts';
import { validateVehicle } from '../_shared/publisher-validate.ts';
import { publishFacebook, publishInstagram, publishMercadoLibre } from '../_shared/publisher-channels.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const user = await requireUser(req);
    const body = await req.json();
    const vehicleId: string = body?.vehicleId;
    const confirmationToken: string = body?.confirmationToken;
    const retry: boolean = !!body?.retry;
    const channels: Channel[] = (Array.isArray(body?.channels) ? body.channels : []).filter((c: Channel) =>
      CHANNELS.includes(c),
    );
    if (!vehicleId || !channels.length) throw new HttpError(400, 'Elegí el vehículo y al menos un canal');
    if (!publishingEnabled())
      throw new HttpError(403, 'La publicación real está desactivada (PUBLISHING_ENABLED=false).');

    const db = admin();
    const vehicle = await getOwnVehicle(db, user.id, vehicleId);

    // Confirmación explícita de un solo uso
    if (!retry) {
      if (!confirmationToken) throw new HttpError(400, 'Falta la confirmación explícita para publicar');
      const { data: confirmation } = await db.from('publish_confirmations').select('*')
        .eq('token', confirmationToken).eq('user_id', user.id).eq('vehicle_id', vehicleId).maybeSingle();
      if (!confirmation) throw new HttpError(400, 'La confirmación no es válida');
      if (confirmation.used_at) throw new HttpError(409, 'Esa confirmación ya fue usada. Volvé a confirmar.');
      if (new Date(confirmation.expires_at).getTime() < Date.now())
        throw new HttpError(400, 'La confirmación venció. Revisá la vista previa y confirmá de nuevo.');
      await db.from('publish_confirmations').update({ used_at: new Date().toISOString() }).eq('id', confirmation.id);
    }

    const validation = await validateVehicle(db, vehicle, channels);
    if (!validation.ok) return json({ error: 'Faltan datos obligatorios', validation }, 422, corsHeaders);

    const results = [];
    for (const channel of channels) {
      const idempotencyKey = `${vehicleId}:${channel}`;
      // Fila única por vehículo+canal (evita duplicados por doble clic o timeout)
      const { data: existing } = await db.from('publications').select('*')
        .eq('idempotency_key', idempotencyKey).maybeSingle();

      if (existing && ['publishing', 'queued'].includes(existing.status)) {
        results.push({ channel, status: existing.status, message: `Ya hay una publicación en curso en ${label(channel)}` });
        continue;
      }
      if (existing && existing.status === 'published' && !retry) {
        results.push({ channel, status: 'published', external_url: existing.external_url, skipped: true });
        continue;
      }

      const base = {
        vehicle_id: vehicleId, user_id: user.id, channel, idempotency_key: idempotencyKey,
        status: 'publishing' as const, attempts: (existing?.attempts || 0) + 1,
        error_code: null, error_message: null,
      };
      if (existing) await db.from('publications').update(base).eq('id', existing.id);
      else await db.from('publications').insert(base);

      const { data: row } = await db.from('publications').select('*').eq('idempotency_key', idempotencyKey).single();

      try {
        const ctx = { db, userId: user.id, vehicle };
        const out =
          channel === 'mercadolibre' ? await publishMercadoLibre(ctx, existing)
          : channel === 'facebook' ? await publishFacebook(ctx)
          : await publishInstagram(ctx);

        await db.from('publications').update({
          status: out.partial ? 'partial' : 'published',
          external_id: out.externalId,
          external_url: out.externalUrl,
          request_snapshot: { channel, vehicle_id: vehicleId },
          response_snapshot: out.response,
          error_message: out.error ?? null,
          error_code: out.partial ? 'partial' : null,
          published_at: new Date().toISOString(),
        }).eq('id', row!.id);

        results.push({ channel, status: out.partial ? 'partial' : 'published', external_url: out.externalUrl, message: out.error });
      } catch (e) {
        const raw = (e as Error).message;
        const { code, message } = humanError(channel, raw);
        await db.from('publications').update({
          status: 'failed', error_code: code, error_message: message,
          response_snapshot: { technical_error: raw },
        }).eq('id', row!.id);
        results.push({ channel, status: 'failed', message, technical_error: raw });
      }
    }

    const published = results.filter((r) => r.status === 'published').length;
    const overall = published === results.length ? 'published' : published > 0 ? 'partial' : 'failed';
    return json({ overall, results }, 200, corsHeaders);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message }, status, corsHeaders);
  }
});
