import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const userSb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: authHeader } } });
    const { data: { user } } = await userSb.auth.getUser();
    if (!user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    // Verificar CEO
    const { data: isCeo } = await admin.rpc("is_ceo", { _user_id: user.id });
    if (!isCeo) return new Response(JSON.stringify({ error: "Solo el CEO puede usar este endpoint" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const body = await req.json();
    const action = body.action;

    if (action === "create_agency") {
      const { name, plan, notes, slug } = body;
      if (!name) return new Response(JSON.stringify({ error: "Nombre requerido" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      const { data, error } = await admin.from("agencies").insert({ name, plan: plan || "standard", notes, slug: slug || name.toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 60) }).select().single();
      if (error) throw error;
      return new Response(JSON.stringify(data), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "update_agency") {
      const { id } = body;
      if (!id) return new Response(JSON.stringify({ error: "id requerido" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      const ALLOWED = ["name", "slug", "status", "plan", "notes", "owner_user_id", "marketplace_visible"];
      const fields: Record<string, any> = {};
      for (const k of ALLOWED) if (body[k] !== undefined) fields[k] = body[k];
      if (!Object.keys(fields).length) return new Response(JSON.stringify({ error: "Nada para actualizar" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      const { data, error } = await admin.from("agencies").update(fields).eq("id", id).select().single();
      if (error) throw error;


      // Downgrade controlado: nunca borra vehículos, sólo recorta el excedente ORO.
      const GOLD: Record<string, number> = { common: 0, advanced: 10, pro: 30 };
      if (typeof fields.plan === "string" && fields.plan in GOLD) {
        const maxGold = GOLD[fields.plan];
        const { data: golds } = await admin.from("cars")
          .select("id,created_at").eq("agency_id", id).eq("marketplace_tier", "gold")
          .order("created_at", { ascending: true });
        const excess = (golds || []).slice(maxGold).map((c: any) => c.id);
        if (excess.length) await admin.from("cars").update({ marketplace_tier: "silver" }).in("id", excess);
      }
      return new Response(JSON.stringify(data), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "delete_agency") {
      const { error } = await admin.from("agencies").delete().eq("id", body.id);
      if (error) throw error;
      return new Response(JSON.stringify({ ok: true }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "create_user") {
      const { email, password, role, agency_id } = body;
      if (!email || !password || !role) return new Response(JSON.stringify({ error: "email, password y role requeridos" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      const { data: created, error } = await admin.auth.admin.createUser({
        email, password, email_confirm: true,
      });
      if (error) throw error;
      const newUserId = created.user!.id;
      await admin.from("user_roles").insert({ user_id: newUserId, role, agency_id: agency_id || null });
      if (role === "owner" && agency_id) {
        await admin.from("agencies").update({ owner_user_id: newUserId }).eq("id", agency_id);
      }
      return new Response(JSON.stringify({ user_id: newUserId, email }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "list_users") {
      const { data: roles } = await admin.from("user_roles").select("user_id,role,agency_id,created_at");
      const ids = Array.from(new Set((roles || []).map((r: any) => r.user_id)));
      const usersMap: Record<string, any> = {};
      for (const id of ids) {
        const { data } = await admin.auth.admin.getUserById(id);
        if (data?.user) usersMap[id] = { id: data.user.id, email: data.user.email, created_at: data.user.created_at };
      }
      return new Response(JSON.stringify({ roles, users: usersMap }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "global_metrics") {
      const [agencies, cars, sales, leads, cash] = await Promise.all([
        admin.from("agencies").select("id,name,status,plan,created_at"),
        admin.from("cars").select("user_id,precio,estado"),
        admin.from("sales").select("user_id,precio_venta,created_at"),
        admin.from("leads").select("user_id,canal,created_at"),
        admin.from("cash_movements").select("user_id,tipo,monto,created_at"),
      ]);
      const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).getTime();
      const ventasMes = (sales.data || []).filter((s: any) => new Date(s.created_at).getTime() >= monthStart);
      const ingresosMes = (cash.data || []).filter((m: any) => m.tipo === "ingreso" && new Date(m.created_at).getTime() >= monthStart).reduce((s: number, m: any) => s + Number(m.monto), 0);
      const egresosMes = (cash.data || []).filter((m: any) => m.tipo === "egreso" && new Date(m.created_at).getTime() >= monthStart).reduce((s: number, m: any) => s + Number(m.monto), 0);
      return new Response(JSON.stringify({
        agencies_total: (agencies.data || []).length,
        agencies_active: (agencies.data || []).filter((a: any) => a.status === "active").length,
        cars_total: (cars.data || []).length,
        valor_stock: (cars.data || []).reduce((s: number, c: any) => s + Number(c.precio || 0), 0),
        ventas_mes: ventasMes.length,
        ventas_total_mes: ventasMes.reduce((s: number, v: any) => s + Number(v.precio_venta || 0), 0),
        leads_total: (leads.data || []).length,
        ingresos_mes: ingresosMes,
        egresos_mes: egresosMes,
        ganancia_mes: ingresosMes - egresosMes,
        agencies: agencies.data || [],
      }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "plans_usage") {
      const [ags, cars, plans] = await Promise.all([
        admin.from("agencies").select("id,name,plan,status"),
        admin.from("cars").select("agency_id,marketplace_tier,mostrar_publico,estado"),
        admin.from("plans").select("code,name,features,max_vehicles"),
      ]);
      const LIMITS: Record<string, { max: number | null; gold: number }> = {
        common: { max: 15, gold: 0 },
        advanced: { max: 35, gold: 10 },
        pro: { max: null, gold: 30 },
      };
      const usage = (ags.data || []).map((a: any) => {
        const own = (cars.data || []).filter((c: any) =>
          c.agency_id === a.id && c.mostrar_publico && ["Disponible", "Reservado"].includes(c.estado));
        const gold = own.filter((c: any) => c.marketplace_tier === "gold").length;
        const lim = LIMITS[a.plan] || LIMITS.pro;
        return {
          agency_id: a.id, name: a.name, plan: a.plan, status: a.status,
          marketplace_used: own.length, gold_used: gold, silver_used: own.length - gold,
          max_marketplace: lim.max, max_gold: lim.gold,
          max_silver: lim.max == null ? null : lim.max - lim.gold,
        };
      });
      return new Response(JSON.stringify({ usage, plans: plans.data || [] }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ error: "action desconocida" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e: any) {
    return new Response(JSON.stringify({ error: e?.message || String(e) }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
