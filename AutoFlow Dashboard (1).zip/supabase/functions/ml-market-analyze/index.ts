import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const ML_SITE = "MLA";
const CARS_CATEGORY = "MLA1744";

function median(nums: number[]) {
  if (!nums.length) return 0;
  const s = [...nums].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}

function normalize(s: string) {
  return (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const userId = user.id;

    const { car_id } = await req.json();
    if (!car_id) return new Response(JSON.stringify({ error: "car_id requerido" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const { data: car, error: carErr } = await supabase.from("cars").select("*").eq("id", car_id).maybeSingle();
    if (carErr || !car) throw new Error("Auto no encontrado");

    const { data: mlAcc } = await supabase
      .from("connected_accounts")
      .select("access_token")
      .eq("platform", "mercadolibre")
      .eq("status", "active")
      .limit(1)
      .maybeSingle();

    const q = [car.marca, car.modelo, car.version].filter(Boolean).join(" ").trim();
    const headers: Record<string, string> = {};
    if (mlAcc?.access_token) headers["Authorization"] = `Bearer ${mlAcc.access_token}`;

    // Pedimos hasta 100 resultados (2 páginas)
    const fetchPage = async (offset: number) => {
      const url = new URL(`https://api.mercadolibre.com/sites/${ML_SITE}/search`);
      url.searchParams.set("category", CARS_CATEGORY);
      url.searchParams.set("q", q);
      url.searchParams.set("limit", "50");
      url.searchParams.set("offset", String(offset));
      if (car.anio) url.searchParams.append("VEHICLE_YEAR", String(car.anio));
      const resp = await fetch(url.toString(), { headers });
      if (!resp.ok) throw new Error(`ML API ${resp.status}: ${(await resp.text()).slice(0, 200)}`);
      const j = await resp.json();
      return Array.isArray(j.results) ? j.results : [];
    };
    const all = [...(await fetchPage(0)), ...(await fetchPage(50).catch(() => []))];

    const kmMin = car.kilometros ? Math.max(0, car.kilometros * 0.6) : 0;
    const kmMax = car.kilometros ? car.kilometros * 1.4 : Infinity;

    const marcaNorm = normalize(car.marca || "");
    const modeloNorm = normalize(car.modelo || "");
    const modeloTokens = modeloNorm.split(" ").filter(Boolean);

    let items = all
      .map((r: any) => {
        const attrs: any[] = r.attributes || [];
        const get = (id: string) => attrs.find((a) => a.id === id)?.value_name;
        const km = parseInt((get("KILOMETERS") || "").replace(/[^0-9]/g, "") || "0", 10);
        const year = parseInt(get("VEHICLE_YEAR") || "0", 10);
        const itemBrand = normalize(get("BRAND") || "");
        const itemModel = normalize(get("MODEL") || "");
        const titleNorm = normalize(r.title || "");
        return {
          id: r.id,
          title: r.title,
          price: Number(r.price) || 0,
          currency: r.currency_id,
          permalink: r.permalink,
          thumbnail: r.thumbnail,
          km,
          year,
          condition: r.condition,
          location: r.address?.state_name || r.seller_address?.state?.name,
          marca: get("BRAND") || car.marca,
          modelo: get("MODEL") || car.modelo,
          version: get("TRIM"),
          _titleNorm: titleNorm,
          _itemBrand: itemBrand,
          _itemModel: itemModel,
        };
      })
      .filter((x: any) => x.price > 0)
      // Marca: por atributo o título
      .filter((x: any) => !marcaNorm || x._itemBrand === marcaNorm || x._titleNorm.includes(marcaNorm))
      // Modelo EXACTO: el atributo MODEL coincide, o TODOS los tokens del modelo aparecen en el título
      .filter((x: any) => {
        if (!modeloNorm) return true;
        if (x._itemModel && x._itemModel === modeloNorm) return true;
        return modeloTokens.every((t) => x._titleNorm.includes(t));
      })
      .filter((x: any) => !car.anio || !x.year || Math.abs(x.year - car.anio) <= 1)
      .filter((x: any) => !car.kilometros || x.km === 0 || (x.km >= kmMin && x.km <= kmMax));

    const myCurrency = car.moneda || "ARS";
    const itemsSameCurrency = items.filter((x: any) => x.currency === myCurrency);
    let useItems = itemsSameCurrency.length >= 3 ? itemsSameCurrency : items;

    // Descartar OUTLIERS de precio muy bajo (publicaciones con precio simbólico, anticipos, autos chocados, etc.)
    // Regla: descartar todo lo que esté por debajo del 60% de la mediana inicial o 50% de mi precio.
    let pricesInit = useItems.map((x: any) => x.price);
    const medInit = median(pricesInit);
    const myPriceVal = Number(car.precio_venta) || 0;
    const floor = Math.max(medInit * 0.6, myPriceVal > 0 ? myPriceVal * 0.5 : 0);
    const ceiling = medInit > 0 ? medInit * 2.5 : Infinity;
    const filtered = useItems.filter((x: any) => x.price >= floor && x.price <= ceiling);
    const outliersDescartados = useItems.length - filtered.length;
    if (filtered.length >= 3) useItems = filtered;

    const prices = useItems.map((x: any) => Number(x.price)).filter((n) => n > 0);
    const min = prices.length ? Math.min(...prices) : 0;
    const max = prices.length ? Math.max(...prices) : 0;
    const avg = prices.length ? prices.reduce((a, b) => a + b, 0) / prices.length : 0;
    const med = median(prices);
    const myPrice = myPriceVal;
    const recommended = Math.round((med * 0.97) * 100) / 100;
    const diffPct = avg > 0 && myPrice > 0 ? Math.round(((myPrice - avg) / avg) * 1000) / 10 : 0;

    const sortedAsc = [...useItems].sort((a, b) => a.price - b.price);
    let myPos = 0;
    if (myPrice > 0) myPos = sortedAsc.filter((x: any) => x.price <= myPrice).length + 1;

    const competitiveness =
      diffPct <= -5 ? "Alta (barato)" :
      diffPct <= 5 ? "Media" :
      diffPct <= 15 ? "Baja (caro)" : "Muy baja (muy caro)";

    // IA: analiza los items reales y razona como un humano que entra a ML
    let recommendation = "";
    try {
      const aiKey = Deno.env.get("LOVABLE_API_KEY");
      if (aiKey) {
        const top10 = sortedAsc.slice(0, 10).map((x: any) => `- ${x.title} | ${x.currency} ${x.price} | ${x.year || "?"} | ${x.km || "?"}km | ${x.location || ""}`).join("\n");
        const aiResp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: { "Content-Type": "application/json", "Lovable-API-Key": aiKey },
          body: JSON.stringify({
            model: "google/gemini-2.5-flash",
            messages: [
              { role: "system", content: "Sos un analista experto del mercado automotor argentino que acaba de revisar publicaciones reales de Mercado Libre. Respondés en español, conciso (máx 5 frases), accionable, sin saludos. Descartá publicaciones con precios irreales (muy bajos)." },
              { role: "user", content: `MI VEHÍCULO: ${car.marca} ${car.modelo} ${car.version || ""} ${car.anio || ""} ${car.kilometros || "?"}km. Mi precio: ${myCurrency} ${myPrice}.

MERCADO (${useItems.length} publicaciones similares de ML, descartados ${outliersDescartados} outliers): min ${myCurrency} ${min}, prom ${myCurrency} ${Math.round(avg)}, mediana ${myCurrency} ${med}, max ${myCurrency} ${max}. Mi posición: ${myPos} de ${useItems.length}.

TOP 10 MÁS BARATOS DEL MERCADO:
${top10}

Analizá: ¿mi precio es competitivo? ¿conviene bajarlo? ¿a cuánto? ¿hay publicaciones sospechosamente baratas que descartarías? Recomendá un precio concreto para vender rápido y otro para maximizar margen.` },
            ],
          }),
        });
        if (aiResp.ok) {
          const aj = await aiResp.json();
          recommendation = aj.choices?.[0]?.message?.content?.trim() || "";
        }
      }
    } catch (_e) { /* sin IA, seguimos */ }
    if (!recommendation) {
      if (diffPct > 10) recommendation = `Tu precio está ${diffPct}% por encima del promedio. Considerá bajar a ${myCurrency} ${Math.round(recommended)} para entrar en el top.`;
      else if (diffPct < -10) recommendation = `Tu precio está ${Math.abs(diffPct)}% por debajo del promedio. Podés subirlo a ${myCurrency} ${Math.round(recommended)}.`;
      else recommendation = `Estás alineado al mercado. Precio sugerido: ${myCurrency} ${Math.round(recommended)}.`;
    }

    const cleanItems = useItems.map(({ _titleNorm, _itemBrand, _itemModel, ...rest }: any) => rest);

    const { data: saved, error: saveErr } = await supabase.from("market_analyses").insert({
      user_id: userId,
      car_id,
      query_used: q,
      total_results: useItems.length,
      price_min: min,
      price_max: max,
      price_avg: avg,
      price_median: med,
      price_recommended: recommended,
      my_price: myPrice,
      my_position: myPos,
      diff_pct: diffPct,
      competitiveness,
      recommendation,
      items: cleanItems.slice(0, 50),
      summary: { currency: myCurrency, kmRange: [kmMin, kmMax === Infinity ? null : kmMax], outliers_descartados: outliersDescartados, total_crudo: all.length },
    }).select().single();
    if (saveErr) throw saveErr;

    const alerts: any[] = [];
    if (myPrice > 0 && min > 0 && min < myPrice * 0.9) {
      alerts.push({
        user_id: userId, car_id, alert_type: "competitor_cheaper", severity: "warning",
        title: "Hay un competidor más barato",
        message: `Apareció una publicación a ${myCurrency} ${min} (${Math.round((1 - min / myPrice) * 100)}% más barata).`,
        data: { min, mine: myPrice },
      });
    }
    if (diffPct > 15) {
      alerts.push({
        user_id: userId, car_id, alert_type: "overpriced", severity: "warning",
        title: "Tu auto está sobrevaluado",
        message: `Estás ${diffPct}% por encima del promedio del mercado.`,
        data: { diffPct, avg },
      });
    }
    if (myPrice > 0 && useItems.length > 10 && myPos > useItems.length * 0.75) {
      alerts.push({
        user_id: userId, car_id, alert_type: "out_of_top", severity: "info",
        title: "Fuera del top competitivo",
        message: `Tu publicación está en la posición ${myPos} de ${useItems.length}.`,
        data: { myPos, total: useItems.length },
      });
    }
    if (alerts.length) await supabase.from("market_alerts").insert(alerts);

    return new Response(JSON.stringify({ ok: true, analysis: saved, alerts_created: alerts.length, outliers_descartados: outliersDescartados }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e: any) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
