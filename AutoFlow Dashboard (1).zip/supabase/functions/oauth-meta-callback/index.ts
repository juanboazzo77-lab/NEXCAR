import { admin, GRAPH } from '../_shared/publisher.ts';
import { connectionsUrl, consumeState, redirectTo, safeOrigin } from '../_shared/oauth-state.ts';

/** Callback de Meta: valida el state, canjea el token y guarda las Páginas disponibles. */
Deno.serve(async (req) => {
  const db = admin();
  let origin = safeOrigin(null);
  try {
    const url = new URL(req.url);
    const code = url.searchParams.get('code');
    const state = url.searchParams.get('state') ?? '';
    const metaError = url.searchParams.get('error')
      || url.searchParams.get('error_reason')
      || url.searchParams.get('error_description');
    // Si Meta rechazó la autorización no hay código para canjear.
    if (metaError) {
      console.error('oauth-meta-callback authorization_failed', metaError);
      return redirectTo(connectionsUrl(origin, {
        provider: 'meta', connected: '0', error: 'authorization_failed',
      }));
    }
    if (!code) throw new Error('Meta no devolvió el código de autorización.');

    const consumed = await consumeState(db, state, 'meta');
    origin = consumed.returnTo;
    const userId = consumed.userId;

    const appId = Deno.env.get('META_APP_ID')!;
    const appSecret = Deno.env.get('META_APP_SECRET')!;
    const redirectUri = Deno.env.get('META_REDIRECT_URI')
      || `${Deno.env.get('SUPABASE_URL')}/functions/v1/oauth-meta-callback`;


    const shortRes = await fetch(
      `${GRAPH}/oauth/access_token?client_id=${appId}&client_secret=${appSecret}&redirect_uri=${encodeURIComponent(redirectUri)}&code=${code}`,
    );
    const short = await shortRes.json();
    if (!shortRes.ok) {
      throw new Error(String(short?.error?.message || '').toLowerCase().includes('redirect')
        ? 'La URL de callback no coincide con la configurada en Meta.'
        : short?.error?.message || 'Meta rechazó la autorización.');
    }

    const longRes = await fetch(
      `${GRAPH}/oauth/access_token?grant_type=fb_exchange_token&client_id=${appId}&client_secret=${appSecret}&fb_exchange_token=${short.access_token}`,
    );
    const long = await longRes.json();
    const userToken = long?.access_token || short.access_token;

    const pagesRes = await fetch(
      `${GRAPH}/me/accounts?fields=id,name,access_token,instagram_business_account{id,username}&access_token=${userToken}`,
    );
    const pagesJson = await pagesRes.json();
    if (!pagesRes.ok) throw new Error(pagesJson?.error?.message || 'No pudimos leer tus Páginas de Facebook.');
    const pages = pagesJson.data || [];
    if (!pages.length) {
      throw new Error('Tu usuario no administra ninguna Página de Facebook habilitada para esta aplicación.');
    }

    const expiresAt = long?.expires_in
      ? new Date(Date.now() + Number(long.expires_in) * 1000).toISOString() : null;

    const save = async (payload: Record<string, unknown>) => {
      const { data: existing } = await db.from('connected_accounts').select('id')
        .eq('user_id', userId).eq('platform', payload.platform as string)
        .eq('account_external_id', payload.account_external_id as string).maybeSingle();
      if (existing?.id) await db.from('connected_accounts').update(payload).eq('id', existing.id);
      else await db.from('connected_accounts').insert(payload);
    };

    // Guardamos todas las Páginas; el usuario elige después cuál usar.
    const { data: prev } = await db.from('connected_accounts').select('account_external_id, meta')
      .eq('user_id', userId).eq('platform', 'facebook');
    const alreadySelected = (prev || []).some((p: any) => p?.meta?.selected);

    for (const [index, page] of pages.entries()) {
      const selected = alreadySelected
        ? (prev || []).some((p: any) => p.account_external_id === page.id && p?.meta?.selected)
        : pages.length === 1 && index === 0;
      await save({
        user_id: userId, platform: 'facebook', account_name: page.name,
        account_external_id: page.id, access_token: page.access_token,
        expires_at: expiresAt,
        meta: { page_id: page.id, selected, user_token_scopes: 'oauth', ig_user_id: page.instagram_business_account?.id ?? null },
        status: 'conectado',
      });
      const ig = page.instagram_business_account;
      if (ig?.id) {
        await save({
          user_id: userId, platform: 'instagram',
          account_name: ig.username || page.name,
          account_external_id: ig.id, access_token: page.access_token,
          expires_at: expiresAt,
          meta: { ig_user_id: ig.id, page_id: page.id, ig_username: ig.username, selected },
          status: 'conectado',
        });
      }
    }

    // Facebook queda "conectado" sólo cuando hay una Página elegida;
    // Instagram, sólo si esa Página tiene cuenta profesional vinculada.
    const chosen = pages.find((p: any, i: number) => (alreadySelected
      ? (prev || []).some((x: any) => x.account_external_id === p.id && x?.meta?.selected)
      : pages.length === 1 && i === 0));
    return redirectTo(connectionsUrl(origin, {
      provider: 'meta',
      connected: chosen ? '1' : '0',
      pages: String(pages.length),
      ...(chosen ? {} : { error: 'page_selection_required' }),
      ...(chosen && !chosen.instagram_business_account?.id ? { ig: '0' } : {}),
    }));
  } catch (e) {
    console.error('oauth-meta-callback', (e as Error).message);
    return redirectTo(connectionsUrl(origin, {
      provider: 'meta', connected: '0', error: 'authorization_failed',
    }));
  }
});
