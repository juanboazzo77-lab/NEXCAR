import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';

const GRAPH = 'https://graph.facebook.com/v23.0';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const { platform, descripcion, fotos, car_id, account_id, carousel } = await req.json();
    if (!['facebook', 'instagram'].includes(platform) || !descripcion?.trim()) throw new Error('Faltan la plataforma o la descripción');

    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) throw new Error('No autenticado');
    const userSupa = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: authHeader } } });
    const { data: { user } } = await userSupa.auth.getUser();
    if (!user) throw new Error('No autenticado');

    const supa = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    let q = supa.from('connected_accounts').select('*').eq('user_id', user.id).eq('platform', platform);
    if (account_id) q = q.eq('id', account_id);
    const { data: accs } = await q.limit(1);
    const acc = accs?.[0];
    if (!acc) throw new Error(`Conectá ${platform} primero`);

    const token = acc.access_token;
    const meta = acc.meta || {};
    let pubId: string | null = null;
    if (car_id) {
      const ins = await supa.from('vehicle_publications').insert({
        user_id: user.id, car_id, platform, publishing_account_id: acc.id, status: 'publicando',
      }).select().single();
      pubId = ins.data?.id || null;
    }

    const finalize = async (ok: boolean, ext?: { id?: string; url?: string }, err?: string) => {
      if (!pubId) return;
      await supa.from('vehicle_publications').update({
        status: ok ? 'publicado' : 'error',
        external_id: ext?.id, external_url: ext?.url,
        published_at: ok ? new Date().toISOString() : null,
        error_message: err,
      }).eq('id', pubId);
    };

    try {
      if (platform === 'facebook') {
        const pageId = meta.page_id;
        if (!pageId) throw new Error('No hay página de Facebook conectada');
        let endpoint = `${GRAPH}/${pageId}/feed`;
        const body: any = { message: descripcion.trim() };
        if (fotos?.[0]) { endpoint = `${GRAPH}/${pageId}/photos`; body.url = fotos[0]; body.caption = descripcion.trim(); delete body.message; }
        const res = await fetch(endpoint, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
        const json = await res.json();
        if (!res.ok) throw new Error(`${json.error?.message || 'Facebook rechazó la publicación'}${json.error?.error_user_msg ? `: ${json.error.error_user_msg}` : ''}`);
        const externalId = json.post_id || json.id;
        const url = `https://www.facebook.com/${externalId}`;
        await finalize(true, { id: json.id, url });
        if (car_id) await supa.from('cars').update({ publicado_fb: true }).eq('id', car_id);
        return new Response(JSON.stringify({ id: json.id, url }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }

      if (platform === 'instagram') {
        const igId = meta.ig_user_id;
        if (!igId) throw new Error('Sin cuenta Instagram Business vinculada');
        if (!fotos?.[0]) throw new Error('Instagram requiere al menos 1 foto');

        let creationId: string;
        if (carousel && fotos.length > 1) {
          // Crear cada item como contenedor IS_CAROUSEL_ITEM
          const items: string[] = [];
          for (const url of fotos.slice(0, 10)) {
            const r = await fetch(`${GRAPH}/${igId}/media`, {
              method: 'POST', headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ image_url: url, is_carousel_item: true, access_token: token }),
            });
            const j = await r.json();
            if (!r.ok) throw new Error(j.error?.message || 'Error IG item');
            items.push(j.id);
          }
          const r2 = await fetch(`${GRAPH}/${igId}/media`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ media_type: 'CAROUSEL', children: items.join(','), caption: descripcion, access_token: token }),
          });
          const j2 = await r2.json();
          if (!r2.ok) throw new Error(j2.error?.message || 'Error IG carrusel');
          creationId = j2.id;
        } else {
          const createRes = await fetch(`${GRAPH}/${igId}/media`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ image_url: fotos[0], caption: descripcion, access_token: token }),
          });
          const cj = await createRes.json();
          if (!createRes.ok) throw new Error(cj.error?.message || 'Error IG container');
          creationId = cj.id;
        }

        const pubRes = await fetch(`${GRAPH}/${igId}/media_publish`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ creation_id: creationId, access_token: token }),
        });
        const pubJson = await pubRes.json();
        if (!pubRes.ok) throw new Error(pubJson.error?.message || 'Error IG publish');
        const mediaRes = await fetch(`${GRAPH}/${pubJson.id}?fields=permalink&access_token=${token}`);
        const media = await mediaRes.json().catch(() => ({}));
        const url = media.permalink || `https://www.instagram.com/`;
        await finalize(true, { id: pubJson.id, url });
        if (car_id) await supa.from('cars').update({ publicado_ig: true }).eq('id', car_id);
        return new Response(JSON.stringify({ id: pubJson.id, url }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }

      throw new Error('Plataforma no soportada');
    } catch (err: any) {
      await finalize(false, undefined, err.message);
      throw err;
    }
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});
