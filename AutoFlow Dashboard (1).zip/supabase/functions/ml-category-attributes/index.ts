import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { HttpError, json, requireUser } from '../_shared/publisher.ts';
import { fetchCategoryAttributes } from '../_shared/publisher-validate.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    await requireUser(req);
    const { category_id } = await req.json();
    if (!category_id || !/^ML[A-Z]\d+$/.test(category_id)) throw new HttpError(400, 'Categoría inválida');

    const attributes = await fetchCategoryAttributes(category_id);
    const simplified = attributes
      .filter((a: any) => !a.tags?.read_only && !a.tags?.hidden)
      .map((a: any) => ({
        id: a.id,
        name: a.name,
        value_type: a.value_type,
        required: !!(a.tags?.required || a.tags?.catalog_required),
        allow_variations: !!a.tags?.allow_variations,
        values: (a.values || []).slice(0, 200).map((v: any) => ({ id: v.id, name: v.name })),
        hint: a.hint || a.tooltip || null,
        unit: a.default_unit || null,
      }));

    return json({ category_id, attributes: simplified }, 200, corsHeaders);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message }, status, corsHeaders);
  }
});
