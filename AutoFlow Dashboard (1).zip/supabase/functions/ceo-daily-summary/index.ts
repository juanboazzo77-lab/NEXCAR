import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

async function getScopeUserIds(supabase: any, userId: string): Promise<string[]> {
  const { data: roles } = await supabase.from("user_roles").select("role,agency_id").eq("user_id", userId);
  const isCeo = (roles || []).some((r: any) => r.role === "ceo");
  if (isCeo) {
    const { data: allUsers } = await supabase.from("user_roles").select("user_id");
    return Array.from(new Set([...(allUsers || []).map((u: any) => u.user_id), userId]));
  }
  const agencyId = (roles || []).find((r: any) => r.agency_id)?.agency_id;
  if (!agencyId) return [userId];
  const { data: mates } = await supabase.from("user_roles").select("user_id").eq("agency_id", agencyId);
  return Array.from(new Set([...(mates || []).map((m: any) => m.user_id), userId]));
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const userSb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: authHeader } } });
    const { data: { user } } = await userSb.auth.getUser();
    if (!user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const today = new Date().toISOString().slice(0, 10);
    const { data: existing } = await supabase.from("ceo_daily_summaries").select("*").eq("user_id", user.id).eq("summary_date", today).maybeSingle();
    if (existing) return new Response(JSON.stringify(existing), { headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const ids = await getScopeUserIds(supabase, user.id);
    const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString();

    const [cars, sales, leads, cash, alerts] = await Promise.all([
      supabase.from("cars").select("estado,precio_venta").in("user_id", ids),
      supabase.from("sales").select("precio_venta,created_at").in("user_id", ids).gte("created_at", monthStart),
      supabase.from("leads").select("canal,created_at").in("user_id", ids).gte("created_at", since),
      supabase.from("cash_movements").select("tipo,monto").in("user_id", ids).gte("created_at", monthStart),
      supabase.from("market_alerts").select("*").in("user_id", ids).eq("read", false),
    ]);

    const metrics = {
      stock_total: (cars.data || []).length,
      ventas_mes: (sales.data || []).length,
      ventas_total_mes: (sales.data || []).reduce((s: number, v: any) => s + Number(v.precio_venta || 0), 0),
      leads_24h: (leads.data || []).length,
      ingresos_mes: (cash.data || []).filter((m: any) => m.tipo === "ingreso").reduce((s: number, m: any) => s + Number(m.monto), 0),
      egresos_mes: (cash.data || []).filter((m: any) => m.tipo === "egreso").reduce((s: number, m: any) => s + Number(m.monto), 0),
      alertas_pendientes: (alerts.data || []).length,
    };

    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${Deno.env.get("LOVABLE_API_KEY")}` },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: "Eres un asistente ejecutivo. Genera un resumen diario breve (máx 6 bullets) en español, profesional, con foco en acción. Usa los números provistos." },
          { role: "user", content: `Métricas del día (${today}): ${JSON.stringify(metrics)}. Genera el resumen ejecutivo.` },
        ],
      }),
    });
    const aiData = await aiRes.json();
    const summary = aiData.choices?.[0]?.message?.content || "Sin resumen";

    const { data: saved } = await supabase.from("ceo_daily_summaries").insert({ user_id: user.id, summary_date: today, summary, metrics }).select().single();

    return new Response(JSON.stringify(saved), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e: any) {
    return new Response(JSON.stringify({ error: e?.message || String(e) }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
