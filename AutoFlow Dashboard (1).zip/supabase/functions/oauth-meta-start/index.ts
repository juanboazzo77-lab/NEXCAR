import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';
import { admin, GRAPH_VERSION, HttpError, json, requireUser } from '../_shared/publisher.ts';
import { createState } from '../_shared/oauth-state.ts';

/** Permisos mínimos, definidos en un único lugar. */
export const META_SCOPES = [
  'pages_show_list',
  'pages_read_engagement',
  'pages_manage_posts',
  'instagram_basic',
  'instagram_content_publish',
];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const user = await requireUser(req);
    const db = admin();
    const body = await req.json().catch(() => ({}));

    const appId = Deno.env.get('META_APP_ID');
    const appSecret = Deno.env.get('META_APP_SECRET');
    const missing = [
      !appId && 'META_APP_ID',
      !appSecret && 'META_APP_SECRET',
      !Deno.env.get('META_REDIRECT_URI') && 'META_REDIRECT_URI',
    ].filter(Boolean) as string[];
    if (!appId || !appSecret) {
      throw new HttpError(400, `Falta configurar la aplicación de Meta: ${missing.join(', ')}.`);
    }
    if (!/^v\d+\.\d+$/.test(GRAPH_VERSION)) {
      throw new HttpError(400, `La versión de Graph API configurada no es válida: ${GRAPH_VERSION}.`);
    }
    const redirectUri = Deno.env.get('META_REDIRECT_URI')
      || `${Deno.env.get('SUPABASE_URL')}/functions/v1/oauth-meta-callback`;
    if (!redirectUri.startsWith('https://')) {
      throw new HttpError(400, 'La Redirect URI de Meta debe usar HTTPS.');
    }
    // state aleatorio, opaco, de un solo uso y con vencimiento (sólo el hash queda en la base).
    const state = await createState(db, user.id, 'meta', body?.return_to);
    const configId = Deno.env.get('META_FB_CONFIG_ID');

    const authUrl = new URL(`https://www.facebook.com/${GRAPH_VERSION}/dialog/oauth`);
    const params = new URLSearchParams({
      client_id: appId,
      redirect_uri: redirectUri,
      state,
      response_type: 'code',
    });
    // Con Facebook Login for Business los permisos vienen de la configuración (config_id).
    // Enviar "scope" en ese caso provoca "Invalid Scopes".
    if (configId) params.set('config_id', configId);
    else params.set('scope', META_SCOPES.join(','));

    authUrl.search = params.toString();

    return json({
      authorizationUrl: authUrl.toString(),
      redirectUri,
      scopes: META_SCOPES,
      diagnostics: {
        app_id_last4: appId.slice(-4),
        graph_version: GRAPH_VERSION,
        redirect_uri: redirectUri,
        missing_vars: missing,
      },
    }, 200, corsHeaders);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 400;
    return json({ error: (e as Error).message }, status, corsHeaders);
  }
});
