-- Trigger-only functions: never called directly via the API
REVOKE ALL ON FUNCTION public.enforce_car_plan() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.enforce_sale_plan() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.set_agency_id() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.set_agency_id_from_car() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.generate_car_slug() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.update_updated_at_column() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.update_ml_credentials_updated_at() FROM PUBLIC, anon, authenticated;

-- Helper wrappers should not be callable anonymously
REVOKE ALL ON FUNCTION public.is_ceo(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_ceo(uuid) TO authenticated;

-- RPCs that keep their own authorization checks: signed-in only
REVOKE ALL ON FUNCTION public.agency_plan_usage(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.agency_plan_usage(uuid) TO authenticated, service_role;
REVOKE ALL ON FUNCTION public.reconcile_agency_gold(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.reconcile_agency_gold(uuid) TO authenticated, service_role;

-- Internal (private schema) helpers: not part of the exposed API
REVOKE ALL ON FUNCTION private.car_is_public(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION private.get_user_agency(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION private.has_role(uuid, public.app_role) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION private.is_ceo(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION private.is_staff(uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION private.plan_code_of_agency(uuid) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION private.plan_feature(uuid, text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION private.plan_limit(uuid, text) FROM PUBLIC, anon, authenticated;