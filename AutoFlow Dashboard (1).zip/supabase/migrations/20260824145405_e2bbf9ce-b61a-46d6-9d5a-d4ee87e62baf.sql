REVOKE ALL ON FUNCTION public.agency_plan_usage(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.reconcile_agency_gold(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.agency_plan_usage(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.reconcile_agency_gold(uuid) TO authenticated, service_role;