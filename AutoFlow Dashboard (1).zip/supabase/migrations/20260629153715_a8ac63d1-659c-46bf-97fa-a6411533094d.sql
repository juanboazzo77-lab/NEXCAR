
CREATE OR REPLACE FUNCTION public.is_ceo(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY INVOKER SET search_path = public
AS $$ SELECT private.is_ceo(_user_id) $$;
REVOKE ALL ON FUNCTION public.is_ceo(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_ceo(uuid) TO authenticated, service_role;
