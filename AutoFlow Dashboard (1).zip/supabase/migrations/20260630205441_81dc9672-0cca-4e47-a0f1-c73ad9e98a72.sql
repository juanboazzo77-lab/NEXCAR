
-- Campos públicos en cars
ALTER TABLE public.cars
  ADD COLUMN IF NOT EXISTS mostrar_publico boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS slug text UNIQUE,
  ADD COLUMN IF NOT EXISTS descripcion_publica text;

CREATE INDEX IF NOT EXISTS cars_mostrar_publico_idx ON public.cars(mostrar_publico) WHERE mostrar_publico = true;

-- Slug autogenerado
CREATE OR REPLACE FUNCTION public.generate_car_slug()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  base text;
BEGIN
  IF NEW.slug IS NULL OR NEW.slug = '' THEN
    base := lower(regexp_replace(
      coalesce(NEW.marca,'') || '-' || coalesce(NEW.modelo,'') || '-' ||
      coalesce(NEW.version,'') || '-' || coalesce(NEW.anio::text,''),
      '[^a-zA-Z0-9]+', '-', 'g'));
    base := trim(both '-' from base);
    NEW.slug := base || '-' || substr(replace(NEW.id::text, '-', ''), 1, 8);
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS cars_set_slug ON public.cars;
CREATE TRIGGER cars_set_slug BEFORE INSERT OR UPDATE ON public.cars
FOR EACH ROW EXECUTE FUNCTION public.generate_car_slug();

-- Backfill slugs en autos existentes
UPDATE public.cars SET slug = NULL WHERE slug IS NULL;
UPDATE public.cars SET marca = marca WHERE slug IS NULL; -- trigger fill

-- Acceso público anónimo a stock publicado
GRANT SELECT ON public.cars TO anon;
GRANT SELECT ON public.car_photos TO anon;

DROP POLICY IF EXISTS "Public can view published cars" ON public.cars;
CREATE POLICY "Public can view published cars"
  ON public.cars FOR SELECT
  TO anon, authenticated
  USING (mostrar_publico = true AND estado IN ('Disponible','Reservado'));

DROP POLICY IF EXISTS "Public can view published car photos" ON public.car_photos;
CREATE POLICY "Public can view published car photos"
  ON public.car_photos FOR SELECT
  TO anon, authenticated
  USING (EXISTS (SELECT 1 FROM public.cars c WHERE c.id = car_photos.car_id AND c.mostrar_publico = true));

-- Configuración pública global
CREATE TABLE IF NOT EXISTS public.public_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  whatsapp_number text NOT NULL DEFAULT '+5491165361978',
  transferencia_porcentaje numeric NOT NULL DEFAULT 4,
  mostrar_vendidos boolean NOT NULL DEFAULT false,
  nombre_agencia text DEFAULT 'Grupo Boazzo',
  logo_url text,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS public_settings_default_idx
  ON public.public_settings((1)) WHERE is_default = true;

GRANT SELECT ON public.public_settings TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.public_settings TO authenticated;
GRANT ALL ON public.public_settings TO service_role;

ALTER TABLE public.public_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read settings"
  ON public.public_settings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Owner manages own settings"
  ON public.public_settings FOR ALL TO authenticated
  USING (auth.uid() = owner_user_id OR private.is_ceo(auth.uid()))
  WITH CHECK (auth.uid() = owner_user_id OR private.is_ceo(auth.uid()));

CREATE TRIGGER public_settings_updated_at BEFORE UPDATE ON public.public_settings
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Configuración por defecto
INSERT INTO public.public_settings (is_default, whatsapp_number, transferencia_porcentaje, nombre_agencia)
SELECT true, '+5491165361978', 4, 'Grupo Boazzo'
WHERE NOT EXISTS (SELECT 1 FROM public.public_settings WHERE is_default = true);
