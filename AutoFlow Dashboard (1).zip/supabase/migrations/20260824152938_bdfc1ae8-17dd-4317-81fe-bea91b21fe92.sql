CREATE OR REPLACE FUNCTION private.car_is_public(_car_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.cars c WHERE c.id = _car_id AND c.mostrar_publico = true)
$$;

DROP POLICY IF EXISTS "Public can view published car photos" ON public.car_photos;
CREATE POLICY "Public can view published car photos"
ON public.car_photos FOR SELECT
TO anon, authenticated
USING (private.car_is_public(car_id));