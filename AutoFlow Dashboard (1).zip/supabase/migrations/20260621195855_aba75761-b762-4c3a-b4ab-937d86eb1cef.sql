
-- 1) Restrict inbox + channel_accounts policies to authenticated role
DROP POLICY IF EXISTS "own channel_accounts" ON public.channel_accounts;
CREATE POLICY "own channel_accounts" ON public.channel_accounts FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "own inbox_conversations" ON public.inbox_conversations;
CREATE POLICY "own inbox_conversations" ON public.inbox_conversations FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "own inbox_messages" ON public.inbox_messages;
CREATE POLICY "own inbox_messages" ON public.inbox_messages FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "own message_templates" ON public.message_templates;
CREATE POLICY "own message_templates" ON public.message_templates FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "own conversation_analyses" ON public.conversation_analyses;
CREATE POLICY "own conversation_analyses" ON public.conversation_analyses FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 2) Revoke EXECUTE on SECURITY DEFINER trigger function from API roles
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

-- 3) Restrict broad SELECT on storage.objects for car-photos bucket.
-- Public URLs still work because the bucket is public; this only blocks list() API.
DROP POLICY IF EXISTS "Car photos publicly readable" ON storage.objects;
CREATE POLICY "Car photos readable by authenticated" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'car-photos' AND auth.uid()::text = (storage.foldername(name))[1]);
