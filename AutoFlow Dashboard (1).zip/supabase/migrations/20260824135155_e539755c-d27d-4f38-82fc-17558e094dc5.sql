-- Catálogo público con datos de la agencia
DROP VIEW IF EXISTS public.cars_public;
CREATE VIEW public.cars_public AS
SELECT c.id, c.marca, c.modelo, c.version, c.anio, c.color, c.kilometros, c.combustible,
       c.transmision, c.motor, c.carroceria, c.puertas, c.condicion, c.ubicacion, c.moneda,
       c.precio_venta, c.estado, c.slug, c.descripcion_publica, c.equipamiento,
       c.mostrar_publico, c.created_at, c.updated_at,
       c.provincia, c.ciudad, c.acepta_permuta, c.financiacion_disponible, c.garantia,
       c.agency_id,
       a.name AS agency_name, a.slug AS agency_slug, a.logo_url AS agency_logo,
       a.ciudad AS agency_ciudad, a.provincia AS agency_provincia,
       a.whatsapp AS agency_whatsapp, a.lat AS agency_lat, a.lng AS agency_lng,
       a.marketplace_visible AS agency_marketplace_visible
FROM public.cars c
LEFT JOIN public.agencies a ON a.id = c.agency_id
WHERE c.mostrar_publico = true
  AND c.estado = ANY (ARRAY['Disponible','Reservado','Vendido'])
  AND (a.id IS NULL OR a.status = 'active');

GRANT SELECT ON public.cars_public TO anon, authenticated;

-- Planes
CREATE TABLE IF NOT EXISTS public.plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  price_monthly numeric NOT NULL DEFAULT 0,
  max_vehicles integer,
  max_users integer,
  marketplace_enabled boolean NOT NULL DEFAULT true,
  advanced_stats boolean NOT NULL DEFAULT false,
  features jsonb NOT NULL DEFAULT '{}'::jsonb,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.plans TO anon, authenticated;
GRANT ALL ON public.plans TO service_role;
ALTER TABLE public.plans ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anyone reads active plans" ON public.plans FOR SELECT TO anon, authenticated USING (active = true);
CREATE POLICY "ceo manages plans" ON public.plans FOR ALL TO authenticated USING (private.is_ceo(auth.uid())) WITH CHECK (private.is_ceo(auth.uid()));
CREATE TRIGGER plans_updated_at BEFORE UPDATE ON public.plans FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Suscripciones
CREATE TABLE IF NOT EXISTS public.subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agency_id uuid NOT NULL REFERENCES public.agencies(id) ON DELETE CASCADE,
  plan_id uuid REFERENCES public.plans(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'trial',
  started_at timestamptz NOT NULL DEFAULT now(),
  current_period_end timestamptz,
  cancelled_at timestamptz,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS subscriptions_agency_key ON public.subscriptions (agency_id);
GRANT SELECT ON public.subscriptions TO authenticated;
GRANT ALL ON public.subscriptions TO service_role;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "agency reads own subscription" ON public.subscriptions FOR SELECT TO authenticated
  USING (agency_id = private.get_user_agency(auth.uid()));
CREATE POLICY "ceo manages subscriptions" ON public.subscriptions FOR ALL TO authenticated
  USING (private.is_ceo(auth.uid())) WITH CHECK (private.is_ceo(auth.uid()));
CREATE TRIGGER subscriptions_updated_at BEFORE UPDATE ON public.subscriptions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.plans (code, name, price_monthly, max_vehicles, max_users, marketplace_enabled, advanced_stats)
VALUES ('trial','Prueba',0,20,2,true,false),
       ('standard','Standard',0,150,5,true,true),
       ('pro','Pro',0,NULL,NULL,true,true)
ON CONFLICT (code) DO NOTHING;

INSERT INTO public.subscriptions (agency_id, plan_id, status, current_period_end)
SELECT a.id, (SELECT id FROM public.plans WHERE code = COALESCE(a.plan,'standard')), 'active', now() + interval '30 days'
FROM public.agencies a
ON CONFLICT (agency_id) DO NOTHING;