
CREATE OR REPLACE VIEW public.cars_public AS
SELECT id, marca, modelo, version, anio, color, kilometros, combustible,
       transmision, motor, carroceria, puertas, condicion, ubicacion,
       moneda, precio_venta, estado, slug, descripcion_publica,
       equipamiento, mostrar_publico, created_at, updated_at
FROM public.cars
WHERE mostrar_publico = true
  AND estado = ANY (ARRAY['Disponible'::text, 'Reservado'::text, 'Vendido'::text]);

GRANT SELECT ON public.cars_public TO anon, authenticated;
