-- 1. Kilómetros en stock
ALTER TABLE public.cars ADD COLUMN IF NOT EXISTS kilometros integer DEFAULT 0;

-- 2. Fotos de autos
CREATE TABLE IF NOT EXISTS public.car_photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  car_id uuid NOT NULL REFERENCES public.cars(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  url text NOT NULL,
  storage_path text,
  orden integer NOT NULL DEFAULT 0,
  es_portada boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.car_photos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own car_photos" ON public.car_photos FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users insert own car_photos" ON public.car_photos FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own car_photos" ON public.car_photos FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users delete own car_photos" ON public.car_photos FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_car_photos_car ON public.car_photos(car_id);

-- 3. Cuentas conectadas a redes
CREATE TABLE IF NOT EXISTS public.connected_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  platform text NOT NULL, -- 'mercadolibre' | 'instagram' | 'facebook' | 'whatsapp'
  account_name text,
  access_token text,
  refresh_token text,
  expires_at timestamptz,
  meta jsonb DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'conectado',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, platform)
);
ALTER TABLE public.connected_accounts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own accounts" ON public.connected_accounts FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users insert own accounts" ON public.connected_accounts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own accounts" ON public.connected_accounts FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users delete own accounts" ON public.connected_accounts FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE TRIGGER update_connected_accounts_updated_at BEFORE UPDATE ON public.connected_accounts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 4. Publicaciones
CREATE TABLE IF NOT EXISTS public.car_publications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  car_id uuid NOT NULL REFERENCES public.cars(id) ON DELETE CASCADE,
  platform text NOT NULL,
  status text NOT NULL DEFAULT 'pendiente', -- pendiente | publicado | error
  external_id text,
  external_url text,
  descripcion text,
  error_msg text,
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.car_publications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own pubs" ON public.car_publications FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users insert own pubs" ON public.car_publications FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own pubs" ON public.car_publications FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users delete own pubs" ON public.car_publications FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE TRIGGER update_car_publications_updated_at BEFORE UPDATE ON public.car_publications FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 5. Bucket de fotos
INSERT INTO storage.buckets (id, name, public) VALUES ('car-photos', 'car-photos', true) ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Car photos publicly readable" ON storage.objects FOR SELECT USING (bucket_id = 'car-photos');
CREATE POLICY "Users upload own car photos" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'car-photos' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users update own car photos" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'car-photos' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users delete own car photos" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'car-photos' AND auth.uid()::text = (storage.foldername(name))[1]);