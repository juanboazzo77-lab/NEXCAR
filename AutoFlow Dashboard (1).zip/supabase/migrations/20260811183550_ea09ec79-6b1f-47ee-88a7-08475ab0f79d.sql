ALTER TABLE public.vehicles
  ADD COLUMN IF NOT EXISTS ml_domain_id text,
  ADD COLUMN IF NOT EXISTS brand_value_id text,
  ADD COLUMN IF NOT EXISTS model_value_id text,
  ADD COLUMN IF NOT EXISTS year_value_id text,
  ADD COLUMN IF NOT EXISTS trim_value_id text;