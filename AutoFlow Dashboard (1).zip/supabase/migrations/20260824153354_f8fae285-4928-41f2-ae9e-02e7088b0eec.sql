-- Plan usage: run with the caller's own permissions (RLS already scopes cars per agency)
CREATE OR REPLACE FUNCTION public.agency_plan_usage(_agency_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY INVOKER
SET search_path TO 'public', 'private'
AS $function$
DECLARE
  used int; gold int; lim int; glim int; code text;
BEGIN
  IF _agency_id IS NULL THEN RETURN NULL; END IF;
  IF NOT (private.is_ceo(auth.uid()) OR private.get_user_agency(auth.uid()) = _agency_id) THEN
    RAISE EXCEPTION 'No autorizado';
  END IF;
  code := private.plan_code_of_agency(_agency_id);
  SELECT count(*), count(*) FILTER (WHERE marketplace_tier = 'gold')
    INTO used, gold
  FROM public.cars
  WHERE agency_id = _agency_id AND mostrar_publico = true AND estado IN ('Disponible','Reservado');
  lim := private.plan_limit(_agency_id, 'max_marketplace');
  glim := private.plan_limit(_agency_id, 'max_gold');
  RETURN jsonb_build_object(
    'plan', code,
    'marketplace_used', used,
    'gold_used', gold,
    'silver_used', used - gold,
    'max_marketplace', lim,
    'max_gold', glim,
    'max_silver', CASE WHEN lim IS NULL THEN NULL ELSE lim - COALESCE(glim,0) END
  );
END;
$function$;

REVOKE ALL ON FUNCTION public.agency_plan_usage(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.agency_plan_usage(uuid) TO authenticated, service_role;

-- Helpers needed by the invoker function (private schema is not exposed to the API)
GRANT EXECUTE ON FUNCTION private.plan_code_of_agency(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION private.plan_limit(uuid, text) TO authenticated;
GRANT EXECUTE ON FUNCTION private.is_ceo(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION private.get_user_agency(uuid) TO authenticated;

-- Gold reconciliation: internal/admin use only
REVOKE ALL ON FUNCTION public.reconcile_agency_gold(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.reconcile_agency_gold(uuid) TO service_role;