-- Enums
DO $$ BEGIN CREATE TYPE public.vehicle_status AS ENUM ('draft','available','reserved','sold'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.channel_name AS ENUM ('mercadolibre','instagram','facebook'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE public.publication_status AS ENUM ('draft','validating','queued','publishing','published','partial','failed','paused','closed'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- vehicles
CREATE TABLE public.vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  status public.vehicle_status NOT NULL DEFAULT 'draft',
  internal_title text,
  title text NOT NULL DEFAULT '',
  condition text NOT NULL DEFAULT 'used' CHECK (condition IN ('new','used')),
  brand text NOT NULL DEFAULT '',
  model text NOT NULL DEFAULT '',
  trim text NOT NULL DEFAULT '',
  vehicle_year int,
  price numeric(14,2),
  currency_id text NOT NULL DEFAULT 'ARS',
  mileage_km int,
  body_type text, doors int, passengers int,
  fuel_type text, transmission text, engine text, power text, traction text,
  exterior_color text, interior_color text,
  license_plate text, vin text,
  description text NOT NULL DEFAULT '',
  equipment jsonb NOT NULL DEFAULT '[]'::jsonb,
  safety jsonb NOT NULL DEFAULT '[]'::jsonb,
  observations text,
  accepts_trade boolean NOT NULL DEFAULT false,
  financing boolean NOT NULL DEFAULT false,
  initial_payment numeric(14,2),
  location jsonb NOT NULL DEFAULT '{}'::jsonb,
  contact jsonb NOT NULL DEFAULT '{}'::jsonb,
  ml_category_id text,
  ml_listing_type_id text DEFAULT 'silver',
  ml_attributes jsonb NOT NULL DEFAULT '[]'::jsonb,
  instagram_caption text,
  facebook_message text,
  hashtags text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vehicles TO authenticated;
GRANT ALL ON public.vehicles TO service_role;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "vehicles_own" ON public.vehicles FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX idx_vehicles_user ON public.vehicles(user_id);
CREATE INDEX idx_vehicles_status ON public.vehicles(user_id, status);
CREATE TRIGGER trg_vehicles_updated BEFORE UPDATE ON public.vehicles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- vehicle_media
CREATE TABLE public.vehicle_media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id uuid NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  storage_path text NOT NULL,
  public_url text,
  sort_order int NOT NULL DEFAULT 0,
  is_cover boolean NOT NULL DEFAULT false,
  alt_text text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vehicle_media TO authenticated;
GRANT ALL ON public.vehicle_media TO service_role;
ALTER TABLE public.vehicle_media ENABLE ROW LEVEL SECURITY;
CREATE POLICY "vehicle_media_own" ON public.vehicle_media FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX idx_vehicle_media_vehicle ON public.vehicle_media(vehicle_id, sort_order);

-- channel_connections
CREATE TABLE public.channel_connections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  channel public.channel_name NOT NULL,
  external_account_id text,
  external_account_name text,
  secret_ref text NOT NULL DEFAULT '',
  access_token text,
  refresh_token text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, channel)
);
GRANT SELECT, DELETE ON public.channel_connections TO authenticated;
GRANT ALL ON public.channel_connections TO service_role;
ALTER TABLE public.channel_connections ENABLE ROW LEVEL SECURITY;
CREATE POLICY "channel_connections_select_own" ON public.channel_connections FOR SELECT TO authenticated
  USING (auth.uid() = user_id);
CREATE POLICY "channel_connections_delete_own" ON public.channel_connections FOR DELETE TO authenticated
  USING (auth.uid() = user_id);
CREATE TRIGGER trg_channel_connections_updated BEFORE UPDATE ON public.channel_connections
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- publications
CREATE TABLE public.publications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id uuid NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  channel public.channel_name NOT NULL,
  status public.publication_status NOT NULL DEFAULT 'draft',
  idempotency_key text NOT NULL UNIQUE,
  external_id text,
  external_url text,
  request_snapshot jsonb,
  response_snapshot jsonb,
  error_code text,
  error_message text,
  attempts int NOT NULL DEFAULT 0,
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.publications TO authenticated;
GRANT ALL ON public.publications TO service_role;
ALTER TABLE public.publications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "publications_select_own" ON public.publications FOR SELECT TO authenticated
  USING (auth.uid() = user_id);
CREATE INDEX idx_publications_vehicle ON public.publications(vehicle_id);
CREATE INDEX idx_publications_user ON public.publications(user_id, created_at DESC);
CREATE TRIGGER trg_publications_updated BEFORE UPDATE ON public.publications
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- confirmation tokens (single-use) for publishing
CREATE TABLE public.publish_confirmations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  vehicle_id uuid NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  token text NOT NULL UNIQUE,
  channels text[] NOT NULL DEFAULT '{}',
  used_at timestamptz,
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '15 minutes'),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.publish_confirmations TO authenticated;
GRANT ALL ON public.publish_confirmations TO service_role;
ALTER TABLE public.publish_confirmations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "publish_confirmations_select_own" ON public.publish_confirmations FOR SELECT TO authenticated
  USING (auth.uid() = user_id);