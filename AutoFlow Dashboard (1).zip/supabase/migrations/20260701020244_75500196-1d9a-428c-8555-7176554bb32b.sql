ALTER TABLE public.sales
  ADD COLUMN IF NOT EXISTS comprador_nombre text,
  ADD COLUMN IF NOT EXISTS comprador_dni text,
  ADD COLUMN IF NOT EXISTS comprador_domicilio text,
  ADD COLUMN IF NOT EXISTS comprador_telefono text,
  ADD COLUMN IF NOT EXISTS forma_pago text,
  ADD COLUMN IF NOT EXISTS lugar text;