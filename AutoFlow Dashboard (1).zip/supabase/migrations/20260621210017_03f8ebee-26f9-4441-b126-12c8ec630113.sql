
CREATE TABLE public.ceo_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL DEFAULT 'Nueva conversación',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.ceo_conversations TO authenticated;
GRANT ALL ON public.ceo_conversations TO service_role;
ALTER TABLE public.ceo_conversations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own ceo convos" ON public.ceo_conversations FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_ceo_conversations_updated BEFORE UPDATE ON public.ceo_conversations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.ceo_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES public.ceo_conversations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user','assistant','system')),
  content TEXT NOT NULL,
  metadata JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.ceo_messages TO authenticated;
GRANT ALL ON public.ceo_messages TO service_role;
ALTER TABLE public.ceo_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own ceo msgs" ON public.ceo_messages FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX idx_ceo_messages_conv ON public.ceo_messages(conversation_id, created_at);

CREATE TABLE public.ceo_daily_summaries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  summary_date DATE NOT NULL,
  summary TEXT NOT NULL,
  metrics JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, summary_date)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.ceo_daily_summaries TO authenticated;
GRANT ALL ON public.ceo_daily_summaries TO service_role;
ALTER TABLE public.ceo_daily_summaries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own ceo summaries" ON public.ceo_daily_summaries FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
