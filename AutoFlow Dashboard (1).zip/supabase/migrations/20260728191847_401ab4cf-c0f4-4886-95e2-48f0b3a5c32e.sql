
-- 1) cars: remove blanket public row access, expose curated view instead
DROP POLICY IF EXISTS "Public can view published cars" ON public.cars;

CREATE OR REPLACE VIEW public.cars_public AS
SELECT id, marca, modelo, version, anio, color, kilometros, combustible,
       transmision, motor, carroceria, puertas, condicion, ubicacion,
       moneda, precio_venta, estado, slug, descripcion_publica,
       equipamiento, mostrar_publico, created_at, updated_at
FROM public.cars
WHERE mostrar_publico = true
  AND estado = ANY (ARRAY['Disponible'::text, 'Reservado'::text]);

GRANT SELECT ON public.cars_public TO anon, authenticated;

-- 2) profiles: only own profile (ceo policy already grants full access)
DROP POLICY IF EXISTS "Users can view all profiles" ON public.profiles;
CREATE POLICY "Users can view own profile"
  ON public.profiles FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

-- 3) staff helper
CREATE OR REPLACE FUNCTION private.is_staff(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT exists (select 1 from public.user_roles where user_id = _user_id) $$;

REVOKE ALL ON FUNCTION private.is_staff(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.is_staff(uuid) TO authenticated, service_role;

-- 4) trade_in_requests / vehicle_alerts: unclaimed rows only for staff
DROP POLICY IF EXISTS "Owner reads trade ins" ON public.trade_in_requests;
CREATE POLICY "Owner reads trade ins" ON public.trade_in_requests FOR SELECT TO authenticated
  USING (auth.uid() = owner_user_id OR (owner_user_id IS NULL AND private.is_staff(auth.uid())) OR private.is_ceo(auth.uid()));

DROP POLICY IF EXISTS "Owner updates trade ins" ON public.trade_in_requests;
CREATE POLICY "Owner updates trade ins" ON public.trade_in_requests FOR UPDATE TO authenticated
  USING (auth.uid() = owner_user_id OR (owner_user_id IS NULL AND private.is_staff(auth.uid())) OR private.is_ceo(auth.uid()))
  WITH CHECK (auth.uid() = owner_user_id OR (owner_user_id IS NULL AND private.is_staff(auth.uid())) OR private.is_ceo(auth.uid()));

DROP POLICY IF EXISTS "Owner deletes trade ins" ON public.trade_in_requests;
CREATE POLICY "Owner deletes trade ins" ON public.trade_in_requests FOR DELETE TO authenticated
  USING (auth.uid() = owner_user_id OR (owner_user_id IS NULL AND private.is_staff(auth.uid())) OR private.is_ceo(auth.uid()));

DROP POLICY IF EXISTS "Owner reads alerts" ON public.vehicle_alerts;
CREATE POLICY "Owner reads alerts" ON public.vehicle_alerts FOR SELECT TO authenticated
  USING (auth.uid() = owner_user_id OR (owner_user_id IS NULL AND private.is_staff(auth.uid())) OR private.is_ceo(auth.uid()));

DROP POLICY IF EXISTS "Owner updates alerts" ON public.vehicle_alerts;
CREATE POLICY "Owner updates alerts" ON public.vehicle_alerts FOR UPDATE TO authenticated
  USING (auth.uid() = owner_user_id OR (owner_user_id IS NULL AND private.is_staff(auth.uid())) OR private.is_ceo(auth.uid()))
  WITH CHECK (auth.uid() = owner_user_id OR (owner_user_id IS NULL AND private.is_staff(auth.uid())) OR private.is_ceo(auth.uid()));

DROP POLICY IF EXISTS "Owner deletes alerts" ON public.vehicle_alerts;
CREATE POLICY "Owner deletes alerts" ON public.vehicle_alerts FOR DELETE TO authenticated
  USING (auth.uid() = owner_user_id OR (owner_user_id IS NULL AND private.is_staff(auth.uid())) OR private.is_ceo(auth.uid()));
