
CREATE TABLE public.market_analyses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  car_id uuid not null references public.cars(id) on delete cascade,
  query_used text,
  total_results integer default 0,
  price_min numeric,
  price_max numeric,
  price_avg numeric,
  price_median numeric,
  price_recommended numeric,
  my_price numeric,
  my_position integer,
  diff_pct numeric,
  competitiveness text,
  recommendation text,
  items jsonb default '[]'::jsonb,
  summary jsonb default '{}'::jsonb,
  created_at timestamptz not null default now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.market_analyses TO authenticated;
GRANT ALL ON public.market_analyses TO service_role;
ALTER TABLE public.market_analyses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own market_analyses" ON public.market_analyses FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX market_analyses_car_idx ON public.market_analyses(car_id, created_at DESC);

CREATE TABLE public.market_alerts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  car_id uuid references public.cars(id) on delete cascade,
  alert_type text not null,
  severity text not null default 'info',
  title text not null,
  message text,
  data jsonb default '{}'::jsonb,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.market_alerts TO authenticated;
GRANT ALL ON public.market_alerts TO service_role;
ALTER TABLE public.market_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own market_alerts" ON public.market_alerts FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX market_alerts_user_idx ON public.market_alerts(user_id, read, created_at DESC);
