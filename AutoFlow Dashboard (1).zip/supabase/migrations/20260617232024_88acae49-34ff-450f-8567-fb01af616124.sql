
-- 1) CHANNEL ACCOUNTS (múltiples WhatsApp + Instagram, sin límite)
CREATE TABLE public.channel_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  platform TEXT NOT NULL CHECK (platform IN ('whatsapp','instagram')),
  nombre_interno TEXT NOT NULL,
  responsable TEXT,
  estado TEXT NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('conectado','desconectado','pendiente','error')),
  external_id TEXT,
  phone_number TEXT,
  ig_username TEXT,
  access_token TEXT,
  waba_id TEXT,
  page_id TEXT,
  webhook_verify_token TEXT,
  fecha_conexion TIMESTAMPTZ,
  notas TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.channel_accounts TO authenticated;
GRANT ALL ON public.channel_accounts TO service_role;
ALTER TABLE public.channel_accounts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own channel_accounts" ON public.channel_accounts FOR ALL
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 2) INBOX CONVERSATIONS
CREATE TABLE public.inbox_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  channel_account_id UUID REFERENCES public.channel_accounts(id) ON DELETE SET NULL,
  platform TEXT NOT NULL CHECK (platform IN ('whatsapp','instagram','manual')),
  external_contact_id TEXT,
  contact_name TEXT,
  contact_handle TEXT,
  last_message_text TEXT,
  last_message_at TIMESTAMPTZ,
  unread_count INT NOT NULL DEFAULT 0,
  estado TEXT NOT NULL DEFAULT 'nuevo' CHECK (estado IN ('nuevo','contactado','interesado','propuesta_enviada','negociacion','ganado','perdido')),
  tags TEXT[] NOT NULL DEFAULT '{}',
  vendedor_asignado TEXT,
  lead_score INT,
  lead_classification TEXT CHECK (lead_classification IN ('frio','tibio','caliente')),
  archived BOOLEAN NOT NULL DEFAULT false,
  ignored BOOLEAN NOT NULL DEFAULT false,
  saved_to_crm BOOLEAN NOT NULL DEFAULT false,
  lead_id UUID REFERENCES public.leads(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_inbox_conv_user_last ON public.inbox_conversations(user_id, last_message_at DESC);
CREATE UNIQUE INDEX uq_inbox_conv_external ON public.inbox_conversations(channel_account_id, external_contact_id) WHERE external_contact_id IS NOT NULL;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.inbox_conversations TO authenticated;
GRANT ALL ON public.inbox_conversations TO service_role;
ALTER TABLE public.inbox_conversations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own inbox_conversations" ON public.inbox_conversations FOR ALL
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 3) INBOX MESSAGES
CREATE TABLE public.inbox_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  conversation_id UUID NOT NULL REFERENCES public.inbox_conversations(id) ON DELETE CASCADE,
  direction TEXT NOT NULL CHECK (direction IN ('in','out')),
  message_type TEXT NOT NULL DEFAULT 'text',
  body TEXT,
  external_message_id TEXT,
  sent_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_inbox_msg_conv ON public.inbox_messages(conversation_id, sent_at);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.inbox_messages TO authenticated;
GRANT ALL ON public.inbox_messages TO service_role;
ALTER TABLE public.inbox_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own inbox_messages" ON public.inbox_messages FOR ALL
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 4) MESSAGE TEMPLATES
CREATE TABLE public.message_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  categoria TEXT NOT NULL,
  titulo TEXT NOT NULL,
  contenido TEXT NOT NULL,
  shortcut TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.message_templates TO authenticated;
GRANT ALL ON public.message_templates TO service_role;
ALTER TABLE public.message_templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own message_templates" ON public.message_templates FOR ALL
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 5) CONVERSATION ANALYSES (IA)
CREATE TABLE public.conversation_analyses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  conversation_id UUID NOT NULL REFERENCES public.inbox_conversations(id) ON DELETE CASCADE,
  resumen TEXT,
  intencion TEXT,
  servicio_interes TEXT,
  problema TEXT,
  nivel_interes TEXT,
  nivel_urgencia TEXT,
  presupuesto TEXT,
  objeciones TEXT,
  proximos_pasos TEXT,
  probabilidad_cierre INT,
  lead_score INT,
  clasificacion TEXT CHECK (clasificacion IN ('frio','tibio','caliente')),
  modelo TEXT,
  raw_response JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_conv_analyses_conv ON public.conversation_analyses(conversation_id, created_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.conversation_analyses TO authenticated;
GRANT ALL ON public.conversation_analyses TO service_role;
ALTER TABLE public.conversation_analyses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own conversation_analyses" ON public.conversation_analyses FOR ALL
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- updated_at triggers
CREATE TRIGGER trg_channel_accounts_upd BEFORE UPDATE ON public.channel_accounts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_inbox_conv_upd BEFORE UPDATE ON public.inbox_conversations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER trg_message_templates_upd BEFORE UPDATE ON public.message_templates
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
