
CREATE TABLE public.notification_phones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  phone text NOT NULL,
  label text,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.notification_phones TO authenticated;
GRANT ALL ON public.notification_phones TO service_role;

ALTER TABLE public.notification_phones ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own phones select" ON public.notification_phones FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own phones insert" ON public.notification_phones FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "own phones update" ON public.notification_phones FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "own phones delete" ON public.notification_phones FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE INDEX idx_notification_phones_user ON public.notification_phones(user_id);
