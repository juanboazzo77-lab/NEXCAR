DROP POLICY IF EXISTS "Owner reads trade ins" ON public.trade_in_requests;
DROP POLICY IF EXISTS "Owner updates trade ins" ON public.trade_in_requests;
DROP POLICY IF EXISTS "Owner deletes trade ins" ON public.trade_in_requests;
DROP POLICY IF EXISTS "Anyone can create trade in" ON public.trade_in_requests;
DROP POLICY IF EXISTS "Owner reads alerts" ON public.vehicle_alerts;
DROP POLICY IF EXISTS "Owner updates alerts" ON public.vehicle_alerts;
DROP POLICY IF EXISTS "Owner deletes alerts" ON public.vehicle_alerts;
DROP POLICY IF EXISTS "Anyone can create alert" ON public.vehicle_alerts;

CREATE POLICY "Public can create trade in" ON public.trade_in_requests
FOR INSERT WITH CHECK (owner_user_id IS NULL AND agency_id IS NOT NULL);

CREATE POLICY "CEO manages trade ins" ON public.trade_in_requests
FOR ALL USING (private.is_ceo(auth.uid())) WITH CHECK (private.is_ceo(auth.uid()));

CREATE POLICY "Public can create alert" ON public.vehicle_alerts
FOR INSERT WITH CHECK (owner_user_id IS NULL AND agency_id IS NOT NULL);

CREATE POLICY "CEO manages alerts" ON public.vehicle_alerts
FOR ALL USING (private.is_ceo(auth.uid())) WITH CHECK (private.is_ceo(auth.uid()));