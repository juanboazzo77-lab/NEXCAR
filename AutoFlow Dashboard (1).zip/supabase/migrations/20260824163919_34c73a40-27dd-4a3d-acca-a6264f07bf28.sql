-- ============ STOCK INTELLIGENCE ============
CREATE TABLE public.car_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  car_id uuid NOT NULL REFERENCES public.cars(id) ON DELETE CASCADE,
  agency_id uuid REFERENCES public.agencies(id) ON DELETE CASCADE,
  event_type text NOT NULL CHECK (event_type IN ('view','favorite','unfavorite','inquiry','whatsapp','reserve')),
  visitor_id text,
  source text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_car_events_car ON public.car_events(car_id, event_type);
CREATE INDEX idx_car_events_agency ON public.car_events(agency_id, created_at DESC);

GRANT INSERT ON public.car_events TO anon, authenticated;
GRANT SELECT ON public.car_events TO authenticated;
GRANT ALL ON public.car_events TO service_role;

ALTER TABLE public.car_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can log car events"
ON public.car_events FOR INSERT TO anon, authenticated
WITH CHECK (event_type IN ('view','favorite','unfavorite','inquiry','whatsapp','reserve'));

CREATE POLICY "Agency members read their car events"
ON public.car_events FOR SELECT TO authenticated
USING (private.is_ceo(auth.uid()) OR agency_id = private.get_user_agency(auth.uid()));

CREATE TRIGGER trg_car_events_agency
BEFORE INSERT ON public.car_events
FOR EACH ROW EXECUTE FUNCTION public.set_agency_id_from_car();

-- ============ RED B2B ============
ALTER TABLE public.cars
  ADD COLUMN IF NOT EXISTS b2b_disponible boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS b2b_precio numeric;

CREATE TABLE public.b2b_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agency_id uuid NOT NULL REFERENCES public.agencies(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  marca text,
  modelo text,
  version text,
  anio_desde integer,
  anio_hasta integer,
  km_max integer,
  presupuesto_max numeric,
  moneda text NOT NULL DEFAULT 'ARS',
  detalle text,
  contacto_nombre text,
  contacto_telefono text,
  estado text NOT NULL DEFAULT 'abierto' CHECK (estado IN ('abierto','cerrado')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.b2b_requests TO authenticated;
GRANT ALL ON public.b2b_requests TO service_role;
ALTER TABLE public.b2b_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Agencies read b2b requests"
ON public.b2b_requests FOR SELECT TO authenticated
USING (private.is_ceo(auth.uid()) OR private.get_user_agency(auth.uid()) IS NOT NULL);

CREATE POLICY "Agencies create own b2b requests"
ON public.b2b_requests FOR INSERT TO authenticated
WITH CHECK (agency_id = private.get_user_agency(auth.uid()) AND user_id = auth.uid());

CREATE POLICY "Agencies update own b2b requests"
ON public.b2b_requests FOR UPDATE TO authenticated
USING (private.is_ceo(auth.uid()) OR agency_id = private.get_user_agency(auth.uid()))
WITH CHECK (private.is_ceo(auth.uid()) OR agency_id = private.get_user_agency(auth.uid()));

CREATE POLICY "Agencies delete own b2b requests"
ON public.b2b_requests FOR DELETE TO authenticated
USING (private.is_ceo(auth.uid()) OR agency_id = private.get_user_agency(auth.uid()));

CREATE TRIGGER trg_b2b_requests_updated
BEFORE UPDATE ON public.b2b_requests
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.b2b_offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id uuid NOT NULL REFERENCES public.b2b_requests(id) ON DELETE CASCADE,
  agency_id uuid NOT NULL REFERENCES public.agencies(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  car_id uuid REFERENCES public.cars(id) ON DELETE SET NULL,
  mensaje text,
  precio numeric,
  moneda text NOT NULL DEFAULT 'ARS',
  contacto_telefono text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_b2b_offers_request ON public.b2b_offers(request_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.b2b_offers TO authenticated;
GRANT ALL ON public.b2b_offers TO service_role;
ALTER TABLE public.b2b_offers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Read offers of own agency or own requests"
ON public.b2b_offers FOR SELECT TO authenticated
USING (
  private.is_ceo(auth.uid())
  OR agency_id = private.get_user_agency(auth.uid())
  OR EXISTS (
    SELECT 1 FROM public.b2b_requests r
    WHERE r.id = request_id AND r.agency_id = private.get_user_agency(auth.uid())
  )
);

CREATE POLICY "Agencies create own offers"
ON public.b2b_offers FOR INSERT TO authenticated
WITH CHECK (agency_id = private.get_user_agency(auth.uid()) AND user_id = auth.uid());

CREATE POLICY "Agencies delete own offers"
ON public.b2b_offers FOR DELETE TO authenticated
USING (private.is_ceo(auth.uid()) OR agency_id = private.get_user_agency(auth.uid()));