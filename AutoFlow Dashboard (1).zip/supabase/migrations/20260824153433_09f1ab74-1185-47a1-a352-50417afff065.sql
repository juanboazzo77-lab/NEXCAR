CREATE OR REPLACE FUNCTION private.cars_public_rows()
RETURNS TABLE (
  id uuid, marca text, modelo text, version text, anio integer, color text, kilometros integer,
  combustible text, transmision text, motor text, carroceria text, puertas integer, condicion text,
  ubicacion text, moneda text, precio_venta numeric(12,2), estado text, slug text,
  descripcion_publica text, equipamiento jsonb, mostrar_publico boolean,
  created_at timestamptz, updated_at timestamptz, provincia text, ciudad text,
  acepta_permuta boolean, financiacion_disponible boolean, garantia text, agency_id uuid,
  marketplace_tier text, agency_name text, agency_slug text, agency_logo text, agency_ciudad text,
  agency_provincia text, agency_whatsapp text, agency_lat double precision, agency_lng double precision,
  agency_marketplace_visible boolean
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT c.id, c.marca, c.modelo, c.version, c.anio, c.color, c.kilometros, c.combustible,
         c.transmision, c.motor, c.carroceria, c.puertas, c.condicion, c.ubicacion, c.moneda,
         c.precio_venta, c.estado, c.slug, c.descripcion_publica, c.equipamiento, c.mostrar_publico,
         c.created_at, c.updated_at, c.provincia, c.ciudad, c.acepta_permuta,
         c.financiacion_disponible, c.garantia, c.agency_id,
         CASE WHEN c.marketplace_tier = 'gold'
                   AND COALESCE((p.features ->> 'marketplace_priority')::boolean, false)
              THEN 'gold' ELSE 'silver' END AS marketplace_tier,
         a.name, a.slug, a.logo_url, a.ciudad, a.provincia, a.whatsapp, a.lat, a.lng,
         a.marketplace_visible
  FROM public.cars c
  LEFT JOIN public.agencies a ON a.id = c.agency_id
  LEFT JOIN public.plans p ON p.code = a.plan
  WHERE c.mostrar_publico = true
    AND c.estado = ANY (ARRAY['Disponible','Reservado','Vendido'])
    AND (a.id IS NULL OR a.status = 'active');
$$;

REVOKE ALL ON FUNCTION private.cars_public_rows() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.cars_public_rows() TO anon, authenticated, service_role;

DROP VIEW IF EXISTS public.cars_public;
CREATE VIEW public.cars_public WITH (security_invoker = true) AS
  SELECT * FROM private.cars_public_rows();

GRANT SELECT ON public.cars_public TO anon, authenticated, service_role;