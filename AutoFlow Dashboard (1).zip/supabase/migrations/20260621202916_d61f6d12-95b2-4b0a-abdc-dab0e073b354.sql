
-- 1) Extender cars con campos del publicador
ALTER TABLE public.cars
  ADD COLUMN IF NOT EXISTS combustible text,
  ADD COLUMN IF NOT EXISTS transmision text,
  ADD COLUMN IF NOT EXISTS motor text,
  ADD COLUMN IF NOT EXISTS carroceria text,
  ADD COLUMN IF NOT EXISTS puertas integer,
  ADD COLUMN IF NOT EXISTS condicion text DEFAULT 'usado',
  ADD COLUMN IF NOT EXISTS ubicacion text,
  ADD COLUMN IF NOT EXISTS moneda text DEFAULT 'ARS',
  ADD COLUMN IF NOT EXISTS vendedor_nombre text,
  ADD COLUMN IF NOT EXISTS vendedor_telefono text,
  ADD COLUMN IF NOT EXISTS vendedor_whatsapp text,
  ADD COLUMN IF NOT EXISTS sucursal text,
  ADD COLUMN IF NOT EXISTS comision numeric(12,2),
  ADD COLUMN IF NOT EXISTS descripcion_manual text,
  ADD COLUMN IF NOT EXISTS notas_internas text,
  ADD COLUMN IF NOT EXISTS equipamiento jsonb DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS estado_publicacion text DEFAULT 'borrador';

-- 2) Permitir múltiples cuentas por plataforma (multi-account)
ALTER TABLE public.connected_accounts
  ADD COLUMN IF NOT EXISTS account_external_id text;

DO $$ BEGIN
  ALTER TABLE public.connected_accounts DROP CONSTRAINT connected_accounts_user_id_platform_key;
EXCEPTION WHEN undefined_object THEN NULL; END $$;

CREATE UNIQUE INDEX IF NOT EXISTS connected_accounts_user_platform_ext_uniq
  ON public.connected_accounts (user_id, platform, COALESCE(account_external_id, ''));

-- 3) Historial de publicaciones por plataforma
CREATE TABLE IF NOT EXISTS public.vehicle_publications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  car_id uuid NOT NULL REFERENCES public.cars(id) ON DELETE CASCADE,
  platform text NOT NULL,
  publishing_account_id uuid REFERENCES public.connected_accounts(id) ON DELETE SET NULL,
  listing_type text,
  status text NOT NULL DEFAULT 'pendiente',
  external_id text,
  external_url text,
  error_message text,
  payload jsonb DEFAULT '{}'::jsonb,
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vehicle_publications TO authenticated;
GRANT ALL ON public.vehicle_publications TO service_role;
ALTER TABLE public.vehicle_publications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "users manage own publications" ON public.vehicle_publications
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_vehicle_publications_car ON public.vehicle_publications(car_id);
CREATE TRIGGER update_vehicle_publications_updated_at BEFORE UPDATE ON public.vehicle_publications
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 4) Listing types de Mercado Libre por cuenta
CREATE TABLE IF NOT EXISTS public.ml_listing_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  publishing_account_id uuid NOT NULL REFERENCES public.connected_accounts(id) ON DELETE CASCADE,
  listing_type_id text NOT NULL,
  name text,
  available_quantity integer DEFAULT 0,
  used_quantity integer DEFAULT 0,
  currency text,
  active boolean NOT NULL DEFAULT true,
  raw jsonb DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (publishing_account_id, listing_type_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.ml_listing_types TO authenticated;
GRANT ALL ON public.ml_listing_types TO service_role;
ALTER TABLE public.ml_listing_types ENABLE ROW LEVEL SECURITY;
CREATE POLICY "users manage own listing types" ON public.ml_listing_types
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- 5) Descripciones generadas con IA
CREATE TABLE IF NOT EXISTS public.ai_generated_descriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  car_id uuid NOT NULL REFERENCES public.cars(id) ON DELETE CASCADE,
  titulo text,
  ml_desc text,
  ig_caption text,
  fb_caption text,
  hashtags jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.ai_generated_descriptions TO authenticated;
GRANT ALL ON public.ai_generated_descriptions TO service_role;
ALTER TABLE public.ai_generated_descriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "users manage own ai descriptions" ON public.ai_generated_descriptions
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_ai_desc_car ON public.ai_generated_descriptions(car_id);
