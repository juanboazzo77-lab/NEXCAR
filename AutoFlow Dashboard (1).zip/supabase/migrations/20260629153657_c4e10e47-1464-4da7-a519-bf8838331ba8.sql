
-- 1) Private schema for security helpers (not exposed by PostgREST)
CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM PUBLIC, anon, authenticated;
GRANT USAGE ON SCHEMA private TO postgres, service_role;

-- 2) Recreate helpers in private
CREATE OR REPLACE FUNCTION private.is_ceo(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = 'ceo') $$;

CREATE OR REPLACE FUNCTION private.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role) $$;

CREATE OR REPLACE FUNCTION private.get_user_agency(_user_id uuid)
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT agency_id FROM public.user_roles WHERE user_id = _user_id AND agency_id IS NOT NULL LIMIT 1 $$;

-- The functions in private are owned by postgres and not accessible by anon/authenticated directly.
-- RLS policies will reference them via fully qualified name; SECURITY DEFINER lets them run.
-- Grant EXECUTE to authenticated so RLS evaluation succeeds (function body is locked down).
GRANT EXECUTE ON FUNCTION private.is_ceo(uuid) TO authenticated, anon, service_role;
GRANT EXECUTE ON FUNCTION private.has_role(uuid, public.app_role) TO authenticated, anon, service_role;
GRANT EXECUTE ON FUNCTION private.get_user_agency(uuid) TO authenticated, anon, service_role;

-- 3) Recreate public RLS policies to use private.* and switch to authenticated role
DO $$
DECLARE r record;
BEGIN
  FOR r IN SELECT schemaname, tablename, policyname FROM pg_policies
           WHERE schemaname='public' AND policyname='ceo full access'
  LOOP
    EXECUTE format('DROP POLICY %I ON %I.%I', r.policyname, r.schemaname, r.tablename);
    EXECUTE format('CREATE POLICY %I ON %I.%I AS PERMISSIVE FOR ALL TO authenticated USING (private.is_ceo(auth.uid())) WITH CHECK (private.is_ceo(auth.uid()))',
                   r.policyname, r.schemaname, r.tablename);
  END LOOP;
END $$;

DROP POLICY IF EXISTS "ceo manage agencies" ON public.agencies;
CREATE POLICY "ceo manage agencies" ON public.agencies AS PERMISSIVE FOR ALL TO authenticated
  USING (private.is_ceo(auth.uid())) WITH CHECK (private.is_ceo(auth.uid()));

DROP POLICY IF EXISTS "users view own agency" ON public.agencies;
CREATE POLICY "users view own agency" ON public.agencies AS PERMISSIVE FOR SELECT TO authenticated
  USING (id = private.get_user_agency(auth.uid()));

DROP POLICY IF EXISTS "ceo manage roles" ON public.user_roles;
CREATE POLICY "ceo manage roles" ON public.user_roles AS PERMISSIVE FOR ALL TO authenticated
  USING (private.is_ceo(auth.uid())) WITH CHECK (private.is_ceo(auth.uid()));

-- 4) Drop public versions of helpers (no longer referenced by policies)
DROP FUNCTION IF EXISTS public.is_ceo(uuid);
DROP FUNCTION IF EXISTS public.has_role(uuid, public.app_role);
DROP FUNCTION IF EXISTS public.get_user_agency(uuid);

-- 5) Fix anon-scoped policies: re-scope to authenticated
DO $$
DECLARE
  recs record;
BEGIN
  FOR recs IN
    SELECT tablename, policyname FROM pg_policies
    WHERE schemaname='public' AND policyname IN (
      'own ceo msgs','own ceo convos','own ceo summaries','own market_analyses','own market_alerts'
    )
  LOOP
    EXECUTE format('DROP POLICY %I ON public.%I', recs.policyname, recs.tablename);
  END LOOP;
END $$;

CREATE POLICY "own ceo msgs" ON public.ceo_messages AS PERMISSIVE FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "own ceo convos" ON public.ceo_conversations AS PERMISSIVE FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "own ceo summaries" ON public.ceo_daily_summaries AS PERMISSIVE FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "own market_analyses" ON public.market_analyses AS PERMISSIVE FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "own market_alerts" ON public.market_alerts AS PERMISSIVE FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
