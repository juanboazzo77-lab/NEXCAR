
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view all profiles" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (user_id, display_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', NEW.email));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TABLE public.cars (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  patente TEXT NOT NULL,
  marca TEXT NOT NULL,
  modelo TEXT NOT NULL,
  version TEXT,
  anio INTEGER NOT NULL,
  color TEXT,
  estado TEXT NOT NULL DEFAULT 'Disponible',
  proveedor TEXT,
  precio_compra NUMERIC(12,2) DEFAULT 0,
  precio_venta NUMERIC(12,2) DEFAULT 0,
  publicado_ml BOOLEAN DEFAULT false,
  publicado_ig BOOLEAN DEFAULT false,
  publicado_fb BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.cars ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Auth users can view all cars" ON public.cars FOR SELECT TO authenticated USING (true);
CREATE POLICY "Auth users can insert cars" ON public.cars FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Auth users can update cars" ON public.cars FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Auth users can delete cars" ON public.cars FOR DELETE TO authenticated USING (true);
CREATE TRIGGER update_cars_updated_at BEFORE UPDATE ON public.cars FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.car_expenses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  car_id UUID REFERENCES public.cars(id) ON DELETE CASCADE,
  fecha DATE NOT NULL DEFAULT CURRENT_DATE,
  categoria TEXT NOT NULL,
  concepto TEXT,
  detalle TEXT,
  monto NUMERIC(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.car_expenses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Auth users can view all expenses" ON public.car_expenses FOR SELECT TO authenticated USING (true);
CREATE POLICY "Auth users can insert expenses" ON public.car_expenses FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Auth users can update expenses" ON public.car_expenses FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Auth users can delete expenses" ON public.car_expenses FOR DELETE TO authenticated USING (true);

CREATE TABLE public.cash_movements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  tipo TEXT NOT NULL CHECK (tipo IN ('ingreso', 'egreso')),
  fecha DATE NOT NULL DEFAULT CURRENT_DATE,
  categoria TEXT,
  concepto TEXT,
  detalle TEXT,
  monto NUMERIC(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.cash_movements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Auth users can view all cash" ON public.cash_movements FOR SELECT TO authenticated USING (true);
CREATE POLICY "Auth users can insert cash" ON public.cash_movements FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Auth users can update cash" ON public.cash_movements FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Auth users can delete cash" ON public.cash_movements FOR DELETE TO authenticated USING (true);

CREATE TABLE public.sales (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  car_id UUID REFERENCES public.cars(id) ON DELETE SET NULL,
  fecha DATE NOT NULL DEFAULT CURRENT_DATE,
  vendedor TEXT,
  patente TEXT,
  monto NUMERIC(12,2) NOT NULL DEFAULT 0,
  sena NUMERIC(12,2) DEFAULT 0,
  parte_pago TEXT,
  cuotas INTEGER DEFAULT 0,
  estado TEXT NOT NULL DEFAULT 'activa',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.sales ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Auth users can view all sales" ON public.sales FOR SELECT TO authenticated USING (true);
CREATE POLICY "Auth users can insert sales" ON public.sales FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Auth users can update sales" ON public.sales FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Auth users can delete sales" ON public.sales FOR DELETE TO authenticated USING (true);
CREATE TRIGGER update_sales_updated_at BEFORE UPDATE ON public.sales FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE public.sale_payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  sale_id UUID NOT NULL REFERENCES public.sales(id) ON DELETE CASCADE,
  fecha DATE NOT NULL DEFAULT CURRENT_DATE,
  monto NUMERIC(12,2) NOT NULL DEFAULT 0,
  nota TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.sale_payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Auth users can view all payments" ON public.sale_payments FOR SELECT TO authenticated USING (true);
CREATE POLICY "Auth users can insert payments" ON public.sale_payments FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Auth users can update payments" ON public.sale_payments FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Auth users can delete payments" ON public.sale_payments FOR DELETE TO authenticated USING (true);

CREATE TABLE public.car_documentation (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  car_id UUID NOT NULL UNIQUE REFERENCES public.cars(id) ON DELETE CASCADE,
  ubicacion TEXT,
  gnc TEXT,
  cat TEXT,
  cedula TEXT,
  verificacion TEXT,
  vtv TEXT,
  form_08 TEXT,
  form_04 TEXT,
  multas TEXT,
  dominio TEXT,
  segunda_llave TEXT,
  manual TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.car_documentation ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Auth users can view all docs" ON public.car_documentation FOR SELECT TO authenticated USING (true);
CREATE POLICY "Auth users can insert docs" ON public.car_documentation FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Auth users can update docs" ON public.car_documentation FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Auth users can delete docs" ON public.car_documentation FOR DELETE TO authenticated USING (true);
CREATE TRIGGER update_car_docs_updated_at BEFORE UPDATE ON public.car_documentation FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
