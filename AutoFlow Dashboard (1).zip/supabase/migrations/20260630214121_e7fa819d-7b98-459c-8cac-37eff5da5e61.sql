
-- 1) Ampliar public_settings con nuevos campos
ALTER TABLE public.public_settings
  ADD COLUMN IF NOT EXISTS financiacion_activa boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS financiacion_tasa numeric NOT NULL DEFAULT 75,
  ADD COLUMN IF NOT EXISTS financiacion_cuotas_max integer NOT NULL DEFAULT 60,
  ADD COLUMN IF NOT EXISTS financiacion_gastos_porcentaje numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS nosotros_historia text,
  ADD COLUMN IF NOT EXISTS nosotros_mision text,
  ADD COLUMN IF NOT EXISTS nosotros_valores text,
  ADD COLUMN IF NOT EXISTS nosotros_fotos jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS horarios text,
  ADD COLUMN IF NOT EXISTS direccion text,
  ADD COLUMN IF NOT EXISTS mapa_embed_url text,
  ADD COLUMN IF NOT EXISTS telefono text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS instagram_url text,
  ADD COLUMN IF NOT EXISTS facebook_url text,
  ADD COLUMN IF NOT EXISTS tiktok_url text,
  ADD COLUMN IF NOT EXISTS motivos jsonb NOT NULL DEFAULT '[]'::jsonb;

-- 2) trade_in_requests
CREATE TABLE IF NOT EXISTS public.trade_in_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  cliente_nombre text NOT NULL,
  cliente_telefono text,
  cliente_email text,
  marca text NOT NULL,
  modelo text NOT NULL,
  version text,
  anio integer,
  kilometros integer,
  combustible text,
  caja text,
  estado_general text,
  precio_pretendido numeric,
  observaciones text,
  fotos jsonb NOT NULL DEFAULT '[]'::jsonb,
  estado text NOT NULL DEFAULT 'Pendiente',
  notas_internas text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT INSERT ON public.trade_in_requests TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.trade_in_requests TO authenticated;
GRANT ALL ON public.trade_in_requests TO service_role;

ALTER TABLE public.trade_in_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can create trade in" ON public.trade_in_requests
  FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "Owner reads trade ins" ON public.trade_in_requests
  FOR SELECT TO authenticated
  USING (auth.uid() = owner_user_id OR owner_user_id IS NULL OR private.is_ceo(auth.uid()));

CREATE POLICY "Owner updates trade ins" ON public.trade_in_requests
  FOR UPDATE TO authenticated
  USING (auth.uid() = owner_user_id OR owner_user_id IS NULL OR private.is_ceo(auth.uid()))
  WITH CHECK (auth.uid() = owner_user_id OR owner_user_id IS NULL OR private.is_ceo(auth.uid()));

CREATE POLICY "Owner deletes trade ins" ON public.trade_in_requests
  FOR DELETE TO authenticated
  USING (auth.uid() = owner_user_id OR owner_user_id IS NULL OR private.is_ceo(auth.uid()));

CREATE TRIGGER trade_in_requests_updated_at BEFORE UPDATE ON public.trade_in_requests
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 3) vehicle_alerts
CREATE TABLE IF NOT EXISTS public.vehicle_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  cliente_nombre text NOT NULL,
  cliente_telefono text,
  cliente_whatsapp text,
  cliente_email text,
  marca text,
  modelo text,
  anio_aprox integer,
  presupuesto numeric,
  observaciones text,
  estado text NOT NULL DEFAULT 'Activa',
  notas_internas text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT INSERT ON public.vehicle_alerts TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vehicle_alerts TO authenticated;
GRANT ALL ON public.vehicle_alerts TO service_role;

ALTER TABLE public.vehicle_alerts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can create alert" ON public.vehicle_alerts
  FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "Owner reads alerts" ON public.vehicle_alerts
  FOR SELECT TO authenticated
  USING (auth.uid() = owner_user_id OR owner_user_id IS NULL OR private.is_ceo(auth.uid()));

CREATE POLICY "Owner updates alerts" ON public.vehicle_alerts
  FOR UPDATE TO authenticated
  USING (auth.uid() = owner_user_id OR owner_user_id IS NULL OR private.is_ceo(auth.uid()))
  WITH CHECK (auth.uid() = owner_user_id OR owner_user_id IS NULL OR private.is_ceo(auth.uid()));

CREATE POLICY "Owner deletes alerts" ON public.vehicle_alerts
  FOR DELETE TO authenticated
  USING (auth.uid() = owner_user_id OR owner_user_id IS NULL OR private.is_ceo(auth.uid()));

CREATE TRIGGER vehicle_alerts_updated_at BEFORE UPDATE ON public.vehicle_alerts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 4) public_faqs
CREATE TABLE IF NOT EXISTS public.public_faqs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  pregunta text NOT NULL,
  respuesta text NOT NULL,
  orden integer NOT NULL DEFAULT 0,
  activo boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.public_faqs TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.public_faqs TO authenticated;
GRANT ALL ON public.public_faqs TO service_role;

ALTER TABLE public.public_faqs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone reads active faqs" ON public.public_faqs
  FOR SELECT TO anon, authenticated USING (activo = true OR auth.uid() = owner_user_id OR private.is_ceo(auth.uid()));

CREATE POLICY "Owner manages faqs" ON public.public_faqs
  FOR ALL TO authenticated
  USING (auth.uid() = owner_user_id OR private.is_ceo(auth.uid()))
  WITH CHECK (auth.uid() = owner_user_id OR private.is_ceo(auth.uid()));

CREATE TRIGGER public_faqs_updated_at BEFORE UPDATE ON public.public_faqs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
