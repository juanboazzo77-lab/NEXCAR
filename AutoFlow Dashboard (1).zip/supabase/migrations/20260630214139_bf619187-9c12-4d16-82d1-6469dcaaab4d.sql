
DROP POLICY IF EXISTS "Anyone can create trade in" ON public.trade_in_requests;
CREATE POLICY "Anyone can create trade in" ON public.trade_in_requests
  FOR INSERT TO anon, authenticated
  WITH CHECK (owner_user_id IS NULL);

DROP POLICY IF EXISTS "Anyone can create alert" ON public.vehicle_alerts;
CREATE POLICY "Anyone can create alert" ON public.vehicle_alerts
  FOR INSERT TO anon, authenticated
  WITH CHECK (owner_user_id IS NULL);
