-- 1) Plans catalog
ALTER TABLE public.plans ADD COLUMN IF NOT EXISTS max_marketplace integer;
ALTER TABLE public.plans ADD COLUMN IF NOT EXISTS max_gold integer NOT NULL DEFAULT 0;

INSERT INTO public.plans (code, name, price_monthly, max_vehicles, max_marketplace, max_gold, marketplace_enabled, advanced_stats, features, active)
VALUES
  ('common','Común',0,NULL,15,0,true,false,
   '{"financiero":false,"cotizador":false,"pdfs":false,"turnos":false,"stats":false,"ia_ventas":false,"ia_documentos":false,"boleto":false,"vendedor":false,"duenio":false,"proveedor":false,"marketplace_priority":false}'::jsonb,true),
  ('advanced','Avanzado',0,NULL,35,10,true,true,
   '{"financiero":true,"cotizador":true,"pdfs":false,"turnos":false,"stats":true,"ia_ventas":true,"ia_documentos":true,"boleto":true,"vendedor":true,"duenio":true,"proveedor":true,"marketplace_priority":true}'::jsonb,true),
  ('pro','Pro',0,NULL,NULL,30,true,true,
   '{"financiero":true,"cotizador":true,"pdfs":true,"turnos":true,"stats":true,"ia_ventas":true,"ia_documentos":true,"boleto":true,"vendedor":true,"duenio":true,"proveedor":true,"marketplace_priority":true}'::jsonb,true)
ON CONFLICT (code) DO UPDATE SET
  name = EXCLUDED.name,
  max_marketplace = EXCLUDED.max_marketplace,
  max_gold = EXCLUDED.max_gold,
  marketplace_enabled = EXCLUDED.marketplace_enabled,
  advanced_stats = EXCLUDED.advanced_stats,
  features = EXCLUDED.features,
  active = true;

UPDATE public.plans SET active = false WHERE code IN ('trial','standard');

-- 2) Agencies map to new plan codes
UPDATE public.agencies SET plan = CASE
  WHEN slug = 'grupo-boazzo' THEN 'pro'
  WHEN plan IN ('premium','pro') THEN 'pro'
  WHEN plan IN ('common') THEN 'common'
  ELSE 'advanced' END;

-- 3) Cars marketplace tier
ALTER TABLE public.cars ADD COLUMN IF NOT EXISTS marketplace_tier text NOT NULL DEFAULT 'silver';

-- 4) Plan helper functions
CREATE OR REPLACE FUNCTION private.plan_code_of_agency(_agency_id uuid)
RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, private AS $$
  SELECT COALESCE((SELECT a.plan FROM public.agencies a WHERE a.id = _agency_id), 'pro')
$$;

CREATE OR REPLACE FUNCTION private.plan_feature(_agency_id uuid, _key text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, private AS $$
  SELECT COALESCE((SELECT (p.features ->> _key)::boolean FROM public.plans p
                   WHERE p.code = private.plan_code_of_agency(_agency_id)), true)
$$;

-- returns NULL when unlimited
CREATE OR REPLACE FUNCTION private.plan_limit(_agency_id uuid, _key text)
RETURNS integer LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, private AS $$
  SELECT CASE WHEN _key = 'max_gold' THEN (SELECT p.max_gold FROM public.plans p WHERE p.code = private.plan_code_of_agency(_agency_id))
              ELSE (SELECT p.max_marketplace FROM public.plans p WHERE p.code = private.plan_code_of_agency(_agency_id))
         END
$$;

CREATE OR REPLACE FUNCTION public.agency_plan_usage(_agency_id uuid)
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public, private AS $$
DECLARE
  used int; gold int; lim int; glim int; code text;
BEGIN
  IF _agency_id IS NULL THEN RETURN NULL; END IF;
  IF NOT (private.is_ceo(auth.uid()) OR private.get_user_agency(auth.uid()) = _agency_id) THEN
    RAISE EXCEPTION 'No autorizado';
  END IF;
  code := private.plan_code_of_agency(_agency_id);
  SELECT count(*), count(*) FILTER (WHERE marketplace_tier = 'gold')
    INTO used, gold
  FROM public.cars
  WHERE agency_id = _agency_id AND mostrar_publico = true AND estado IN ('Disponible','Reservado');
  lim := private.plan_limit(_agency_id, 'max_marketplace');
  glim := private.plan_limit(_agency_id, 'max_gold');
  RETURN jsonb_build_object(
    'plan', code,
    'marketplace_used', used,
    'gold_used', gold,
    'silver_used', used - gold,
    'max_marketplace', lim,
    'max_gold', glim,
    'max_silver', CASE WHEN lim IS NULL THEN NULL ELSE lim - COALESCE(glim,0) END
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.agency_plan_usage(uuid) TO authenticated;

-- Reconcile gold quota after a plan change (keeps newest, downgrades excess)
CREATE OR REPLACE FUNCTION public.reconcile_agency_gold(_agency_id uuid)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, private AS $$
DECLARE glim int; changed int := 0;
BEGIN
  IF NOT private.is_ceo(auth.uid()) THEN RAISE EXCEPTION 'Solo el CEO puede reconciliar planes'; END IF;
  glim := COALESCE(private.plan_limit(_agency_id, 'max_gold'), 0);
  WITH ranked AS (
    SELECT id, row_number() OVER (ORDER BY updated_at DESC, created_at DESC) rn
    FROM public.cars WHERE agency_id = _agency_id AND marketplace_tier = 'gold'
  )
  UPDATE public.cars c SET marketplace_tier = 'silver'
  FROM ranked r WHERE c.id = r.id AND r.rn > glim;
  GET DIAGNOSTICS changed = ROW_COUNT;
  RETURN changed;
END;
$$;

GRANT EXECUTE ON FUNCTION public.reconcile_agency_gold(uuid) TO authenticated, service_role;

-- 5) Enforcement triggers
CREATE OR REPLACE FUNCTION public.enforce_car_plan()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, private AS $$
DECLARE lim int; glim int; used int; gold int; ag uuid;
BEGIN
  ag := NEW.agency_id;
  IF ag IS NULL THEN RETURN NEW; END IF;

  IF NOT private.plan_feature(ag, 'duenio') THEN NEW.duenio := NULL; END IF;
  IF NOT private.plan_feature(ag, 'proveedor') THEN NEW.proveedor := NULL; END IF;

  IF NEW.marketplace_tier IS NULL OR NEW.marketplace_tier NOT IN ('gold','silver') THEN
    NEW.marketplace_tier := 'silver';
  END IF;

  IF NEW.marketplace_tier = 'gold' AND NOT private.plan_feature(ag, 'marketplace_priority') THEN
    NEW.marketplace_tier := 'silver';
  END IF;

  -- Marketplace publication limit (only when newly published/activated)
  IF NEW.mostrar_publico = true AND NEW.estado IN ('Disponible','Reservado')
     AND (TG_OP = 'INSERT' OR OLD.mostrar_publico IS DISTINCT FROM true
          OR OLD.estado NOT IN ('Disponible','Reservado')) THEN
    lim := private.plan_limit(ag, 'max_marketplace');
    IF lim IS NOT NULL THEN
      SELECT count(*) INTO used FROM public.cars
      WHERE agency_id = ag AND mostrar_publico = true AND estado IN ('Disponible','Reservado')
        AND id <> NEW.id;
      IF used >= lim THEN
        RAISE EXCEPTION 'PLAN_LIMIT_MARKETPLACE: Alcanzaste el límite de % publicaciones de tu plan. Actualizá tu plan para publicar más vehículos en el Marketplace.', lim;
      END IF;
    END IF;
  END IF;

  -- Gold quota (only when becoming gold)
  IF NEW.marketplace_tier = 'gold' AND (TG_OP = 'INSERT' OR OLD.marketplace_tier IS DISTINCT FROM 'gold') THEN
    glim := COALESCE(private.plan_limit(ag, 'max_gold'), 0);
    SELECT count(*) INTO gold FROM public.cars
    WHERE agency_id = ag AND marketplace_tier = 'gold' AND mostrar_publico = true
      AND estado IN ('Disponible','Reservado') AND id <> NEW.id;
    IF gold >= glim THEN
      RAISE EXCEPTION 'PLAN_LIMIT_GOLD: Ya utilizaste tus % publicaciones ORO. Quitá la categoría ORO de otro vehículo o actualizá tu plan.', glim;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_car_plan ON public.cars;
CREATE TRIGGER trg_enforce_car_plan BEFORE INSERT OR UPDATE ON public.cars
FOR EACH ROW EXECUTE FUNCTION public.enforce_car_plan();

CREATE OR REPLACE FUNCTION public.enforce_sale_plan()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, private AS $$
BEGIN
  IF NEW.agency_id IS NOT NULL AND NOT private.plan_feature(NEW.agency_id, 'vendedor') THEN
    NEW.vendedor := NULL;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_sale_plan ON public.sales;
CREATE TRIGGER trg_enforce_sale_plan BEFORE INSERT OR UPDATE ON public.sales
FOR EACH ROW EXECUTE FUNCTION public.enforce_sale_plan();

-- 6) Public view exposes tier (gold only if plan allows priority)
DROP VIEW IF EXISTS public.cars_public;
CREATE VIEW public.cars_public
WITH (security_invoker = false) AS
 SELECT c.id, c.marca, c.modelo, c.version, c.anio, c.color, c.kilometros, c.combustible,
    c.transmision, c.motor, c.carroceria, c.puertas, c.condicion, c.ubicacion, c.moneda,
    c.precio_venta, c.estado, c.slug, c.descripcion_publica, c.equipamiento, c.mostrar_publico,
    c.created_at, c.updated_at, c.provincia, c.ciudad, c.acepta_permuta,
    c.financiacion_disponible, c.garantia, c.agency_id,
    CASE WHEN c.marketplace_tier = 'gold'
              AND COALESCE((p.features ->> 'marketplace_priority')::boolean, false)
         THEN 'gold' ELSE 'silver' END AS marketplace_tier,
    a.name AS agency_name, a.slug AS agency_slug, a.logo_url AS agency_logo,
    a.ciudad AS agency_ciudad, a.provincia AS agency_provincia, a.whatsapp AS agency_whatsapp,
    a.lat AS agency_lat, a.lng AS agency_lng, a.marketplace_visible AS agency_marketplace_visible
   FROM public.cars c
     LEFT JOIN public.agencies a ON a.id = c.agency_id
     LEFT JOIN public.plans p ON p.code = a.plan
  WHERE c.mostrar_publico = true
    AND c.estado = ANY (ARRAY['Disponible'::text, 'Reservado'::text, 'Vendido'::text])
    AND (a.id IS NULL OR a.status = 'active'::text);

GRANT SELECT ON public.cars_public TO anon, authenticated;