CREATE TABLE public.ml_credentials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  app_id text NOT NULL,
  client_secret text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (user_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ml_credentials TO authenticated;
GRANT ALL ON public.ml_credentials TO service_role;

ALTER TABLE public.ml_credentials ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their own ML credentials"
  ON public.ml_credentials
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.update_ml_credentials_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = 'public'
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_ml_credentials_updated_at
  BEFORE UPDATE ON public.ml_credentials
  FOR EACH ROW
  EXECUTE FUNCTION public.update_ml_credentials_updated_at();