REVOKE EXECUTE ON FUNCTION public.set_agency_id() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.set_agency_id_from_car() FROM PUBLIC, anon, authenticated;