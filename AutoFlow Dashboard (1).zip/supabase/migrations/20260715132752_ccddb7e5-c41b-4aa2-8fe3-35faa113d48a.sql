ALTER TABLE public.sales
  ADD COLUMN IF NOT EXISTS vendedor_dni text,
  ADD COLUMN IF NOT EXISTS vendedor_domicilio text,
  ADD COLUMN IF NOT EXISTS vendedor_telefono text;