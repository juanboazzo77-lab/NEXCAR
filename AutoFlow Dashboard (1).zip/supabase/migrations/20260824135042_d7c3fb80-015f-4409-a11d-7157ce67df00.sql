-- 1) Ampliar la entidad agencia
ALTER TABLE public.agencies
  ADD COLUMN IF NOT EXISTS logo_url text,
  ADD COLUMN IF NOT EXISTS descripcion text,
  ADD COLUMN IF NOT EXISTS direccion text,
  ADD COLUMN IF NOT EXISTS ciudad text,
  ADD COLUMN IF NOT EXISTS provincia text,
  ADD COLUMN IF NOT EXISTS lat double precision,
  ADD COLUMN IF NOT EXISTS lng double precision,
  ADD COLUMN IF NOT EXISTS telefono text,
  ADD COLUMN IF NOT EXISTS whatsapp text,
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS instagram_url text,
  ADD COLUMN IF NOT EXISTS facebook_url text,
  ADD COLUMN IF NOT EXISTS tiktok_url text,
  ADD COLUMN IF NOT EXISTS website_url text,
  ADD COLUMN IF NOT EXISTS horarios text,
  ADD COLUMN IF NOT EXISTS marketplace_visible boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS fecha_alta timestamptz NOT NULL DEFAULT now();

UPDATE public.agencies SET slug = lower(regexp_replace(name, '[^a-zA-Z0-9]+', '-', 'g')) WHERE slug IS NULL OR slug = '';
CREATE UNIQUE INDEX IF NOT EXISTS agencies_slug_key ON public.agencies (slug);

-- 2) Nuevo rol de administrador de agencia (no se usa todavía en políticas)
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'agency_admin';

-- 3) Función de trigger genérica para completar agency_id
CREATE OR REPLACE FUNCTION public.set_agency_id()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.agency_id IS NULL THEN
    NEW.agency_id := private.get_user_agency(auth.uid());
  END IF;
  RETURN NEW;
END;
$$;

-- 4) Agregar agency_id + backfill + trigger + política por agencia en cada tabla
DO $do$
DECLARE
  t text;
  owner_col text;
  default_agency uuid;
  tables text[] := ARRAY[
    'cars','car_photos','car_expenses','cash_movements','sales','sale_payments',
    'leads','calendar_events','inbox_conversations','inbox_messages','channel_accounts',
    'message_templates','car_publications','vehicle_publications','market_analyses',
    'market_alerts','ai_generated_descriptions','conversation_analyses','notification_phones',
    'public_settings','public_faqs','trade_in_requests','vehicle_alerts','vehicles','publications'
  ];
BEGIN
  SELECT id INTO default_agency FROM public.agencies ORDER BY created_at ASC LIMIT 1;

  FOREACH t IN ARRAY tables LOOP
    IF to_regclass('public.' || t) IS NULL THEN CONTINUE; END IF;

    EXECUTE format('ALTER TABLE public.%I ADD COLUMN IF NOT EXISTS agency_id uuid REFERENCES public.agencies(id) ON DELETE SET NULL', t);
    EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON public.%I (agency_id)', t || '_agency_id_idx', t);

    SELECT column_name INTO owner_col
      FROM information_schema.columns
     WHERE table_schema='public' AND table_name=t AND column_name IN ('user_id','owner_user_id')
     ORDER BY column_name LIMIT 1;

    IF owner_col IS NOT NULL THEN
      EXECUTE format(
        'UPDATE public.%I x SET agency_id = COALESCE(
            (SELECT ur.agency_id FROM public.user_roles ur WHERE ur.user_id = x.%I AND ur.agency_id IS NOT NULL LIMIT 1),
            %L::uuid)
         WHERE x.agency_id IS NULL', t, owner_col, default_agency);
    ELSE
      EXECUTE format('UPDATE public.%I x SET agency_id = %L::uuid WHERE x.agency_id IS NULL', t, default_agency);
    END IF;

    EXECUTE format('DROP TRIGGER IF EXISTS trg_set_agency_id ON public.%I', t);
    EXECUTE format('CREATE TRIGGER trg_set_agency_id BEFORE INSERT ON public.%I FOR EACH ROW EXECUTE FUNCTION public.set_agency_id()', t);

    EXECUTE format('DROP POLICY IF EXISTS "agency members access" ON public.%I', t);
    EXECUTE format(
      'CREATE POLICY "agency members access" ON public.%I FOR ALL TO authenticated
         USING (agency_id IS NOT NULL AND agency_id = private.get_user_agency(auth.uid()))
         WITH CHECK (agency_id IS NOT NULL AND agency_id = private.get_user_agency(auth.uid()))', t);
  END LOOP;
END
$do$;

-- 5) car_documentation deriva su agencia del auto
ALTER TABLE public.car_documentation ADD COLUMN IF NOT EXISTS agency_id uuid REFERENCES public.agencies(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS car_documentation_agency_id_idx ON public.car_documentation (agency_id);
UPDATE public.car_documentation d SET agency_id = c.agency_id FROM public.cars c WHERE c.id = d.car_id AND d.agency_id IS NULL;

CREATE OR REPLACE FUNCTION public.set_agency_id_from_car()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.agency_id IS NULL THEN
    SELECT c.agency_id INTO NEW.agency_id FROM public.cars c WHERE c.id = NEW.car_id;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_set_agency_id ON public.car_documentation;
CREATE TRIGGER trg_set_agency_id BEFORE INSERT ON public.car_documentation FOR EACH ROW EXECUTE FUNCTION public.set_agency_id_from_car();

DROP POLICY IF EXISTS "agency members access" ON public.car_documentation;
CREATE POLICY "agency members access" ON public.car_documentation FOR ALL TO authenticated
  USING (agency_id IS NOT NULL AND agency_id = private.get_user_agency(auth.uid()))
  WITH CHECK (agency_id IS NOT NULL AND agency_id = private.get_user_agency(auth.uid()));

-- 6) Las agencias son visibles públicamente (datos comerciales para catálogo/marketplace)
DROP POLICY IF EXISTS "public can view active agencies" ON public.agencies;
CREATE POLICY "public can view active agencies" ON public.agencies FOR SELECT TO anon, authenticated
  USING (status = 'active');
GRANT SELECT ON public.agencies TO anon;
