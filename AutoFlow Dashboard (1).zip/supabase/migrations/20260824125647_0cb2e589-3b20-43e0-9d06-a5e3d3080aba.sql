ALTER TABLE public.sales
  ADD COLUMN IF NOT EXISTS fecha_sena date,
  ADD COLUMN IF NOT EXISTS fecha_entrega date,
  ADD COLUMN IF NOT EXISTS monto_entrega numeric,
  ADD COLUMN IF NOT EXISTS primera_cuota_fecha date;