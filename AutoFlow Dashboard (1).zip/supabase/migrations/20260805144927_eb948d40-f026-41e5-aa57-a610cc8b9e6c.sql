
-- 1. Campos extra en cars
ALTER TABLE public.cars
  ADD COLUMN IF NOT EXISTS internal_code text,
  ADD COLUMN IF NOT EXISTS vin text,
  ADD COLUMN IF NOT EXISTS traccion text,
  ADD COLUMN IF NOT EXISTS cilindrada text,
  ADD COLUMN IF NOT EXISTS potencia text,
  ADD COLUMN IF NOT EXISTS cilindros integer,
  ADD COLUMN IF NOT EXISTS direccion_asistida text,
  ADD COLUMN IF NOT EXISTS color_interior text,
  ADD COLUMN IF NOT EXISTS acepta_permuta boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS financiacion_disponible boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS anticipo_minimo numeric,
  ADD COLUMN IF NOT EXISTS cuotas_max integer,
  ADD COLUMN IF NOT EXISTS garantia text,
  ADD COLUMN IF NOT EXISTS provincia text,
  ADD COLUMN IF NOT EXISTS ciudad text,
  ADD COLUMN IF NOT EXISTS horario_atencion text,
  ADD COLUMN IF NOT EXISTS ml_text text,
  ADD COLUMN IF NOT EXISTS fb_text text,
  ADD COLUMN IF NOT EXISTS ig_text text;

-- 2. publication_batches
CREATE TABLE IF NOT EXISTS public.publication_batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  car_id uuid NOT NULL REFERENCES public.cars(id) ON DELETE CASCADE,
  selected_channels text[] NOT NULL DEFAULT '{}',
  overall_status text NOT NULL DEFAULT 'procesando',
  started_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.publication_batches TO authenticated;
GRANT ALL ON public.publication_batches TO service_role;
ALTER TABLE public.publication_batches ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own batches" ON public.publication_batches FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_pub_batches_upd BEFORE UPDATE ON public.publication_batches
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 3. publication_jobs
CREATE TABLE IF NOT EXISTS public.publication_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  batch_id uuid REFERENCES public.publication_batches(id) ON DELETE CASCADE,
  car_id uuid NOT NULL REFERENCES public.cars(id) ON DELETE CASCADE,
  channel text NOT NULL,
  action text NOT NULL DEFAULT 'create',
  status text NOT NULL DEFAULT 'en_cola',
  attempt_number integer NOT NULL DEFAULT 1,
  idempotency_key text,
  payload jsonb,
  response jsonb,
  error_code text,
  error_message text,
  technical_error text,
  started_at timestamptz,
  finished_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS publication_jobs_idem_idx ON public.publication_jobs(idempotency_key) WHERE idempotency_key IS NOT NULL;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.publication_jobs TO authenticated;
GRANT ALL ON public.publication_jobs TO service_role;
ALTER TABLE public.publication_jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own jobs" ON public.publication_jobs FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_pub_jobs_upd BEFORE UPDATE ON public.publication_jobs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 4. channel_publications
CREATE TABLE IF NOT EXISTS public.channel_publications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  car_id uuid NOT NULL REFERENCES public.cars(id) ON DELETE CASCADE,
  batch_id uuid REFERENCES public.publication_batches(id) ON DELETE SET NULL,
  channel text NOT NULL,
  external_publication_id text,
  external_url text,
  status text NOT NULL DEFAULT 'no_publicado',
  payload_hash text,
  last_successful_payload jsonb,
  last_response jsonb,
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (car_id, channel)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.channel_publications TO authenticated;
GRANT ALL ON public.channel_publications TO service_role;
ALTER TABLE public.channel_publications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own channel pubs" ON public.channel_publications FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_channel_pubs_upd BEFORE UPDATE ON public.channel_publications
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 5. publication_templates
CREATE TABLE IF NOT EXISTS public.publication_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  channel text NOT NULL,
  name text NOT NULL,
  template text NOT NULL,
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.publication_templates TO authenticated;
GRANT ALL ON public.publication_templates TO service_role;
ALTER TABLE public.publication_templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own templates" ON public.publication_templates FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER trg_pub_templates_upd BEFORE UPDATE ON public.publication_templates
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 6. vehicle_change_log
CREATE TABLE IF NOT EXISTS public.vehicle_change_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  car_id uuid NOT NULL REFERENCES public.cars(id) ON DELETE CASCADE,
  changed_fields text[] NOT NULL DEFAULT '{}',
  previous_values jsonb,
  new_values jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.vehicle_change_log TO authenticated;
GRANT ALL ON public.vehicle_change_log TO service_role;
ALTER TABLE public.vehicle_change_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own change log" ON public.vehicle_change_log FOR SELECT TO authenticated
  USING (auth.uid() = user_id);
CREATE POLICY "insert own change log" ON public.vehicle_change_log FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Realtime
ALTER TABLE public.publication_jobs REPLICA IDENTITY FULL;
ALTER TABLE public.publication_batches REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.publication_jobs;
ALTER PUBLICATION supabase_realtime ADD TABLE public.publication_batches;
