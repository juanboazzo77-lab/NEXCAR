
-- ============ ENUM + TABLAS ============
DO $$ BEGIN
  CREATE TYPE public.app_role AS ENUM ('ceo','owner','employee');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.agencies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','trial','cancelled')),
  plan TEXT DEFAULT 'standard',
  owner_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.agencies TO authenticated;
GRANT ALL ON public.agencies TO service_role;
ALTER TABLE public.agencies ENABLE ROW LEVEL SECURITY;
DROP TRIGGER IF EXISTS trg_agencies_updated ON public.agencies;
CREATE TRIGGER trg_agencies_updated BEFORE UPDATE ON public.agencies FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TABLE IF NOT EXISTS public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  agency_id UUID REFERENCES public.agencies(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, role, agency_id)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- ============ FUNCIONES SECURITY DEFINER ============
CREATE OR REPLACE FUNCTION public.is_ceo(_user_id UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = 'ceo') $$;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role) $$;

CREATE OR REPLACE FUNCTION public.get_user_agency(_user_id UUID)
RETURNS UUID LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT agency_id FROM public.user_roles WHERE user_id = _user_id AND agency_id IS NOT NULL LIMIT 1 $$;

-- ============ POLICIES de agencies y user_roles ============
DROP POLICY IF EXISTS "ceo manage agencies" ON public.agencies;
DROP POLICY IF EXISTS "users view own agency" ON public.agencies;
CREATE POLICY "ceo manage agencies" ON public.agencies FOR ALL
  USING (public.is_ceo(auth.uid())) WITH CHECK (public.is_ceo(auth.uid()));
CREATE POLICY "users view own agency" ON public.agencies FOR SELECT
  USING (id = public.get_user_agency(auth.uid()));

DROP POLICY IF EXISTS "ceo manage roles" ON public.user_roles;
DROP POLICY IF EXISTS "users view own roles" ON public.user_roles;
CREATE POLICY "ceo manage roles" ON public.user_roles FOR ALL
  USING (public.is_ceo(auth.uid())) WITH CHECK (public.is_ceo(auth.uid()));
CREATE POLICY "users view own roles" ON public.user_roles FOR SELECT
  USING (user_id = auth.uid());

-- ============ BOOTSTRAP: agencia Grupo Boazzo + roles ============
DO $$
DECLARE
  v_ceo UUID;
  v_emp UUID;
  v_agency UUID;
BEGIN
  SELECT id INTO v_ceo FROM auth.users WHERE email = 'juanboazzo77@gmail.com' LIMIT 1;
  SELECT id INTO v_emp FROM auth.users WHERE email = 'gastonboazzo@gmail.com' LIMIT 1;

  IF v_ceo IS NOT NULL THEN
    INSERT INTO public.agencies (name, slug, owner_user_id, status, plan, notes)
    VALUES ('Grupo Boazzo', 'grupo-boazzo', v_ceo, 'active', 'standard', 'Agencia inicial')
    ON CONFLICT (slug) DO UPDATE SET owner_user_id = EXCLUDED.owner_user_id
    RETURNING id INTO v_agency;

    IF v_agency IS NULL THEN
      SELECT id INTO v_agency FROM public.agencies WHERE slug = 'grupo-boazzo';
    END IF;

    INSERT INTO public.user_roles (user_id, role, agency_id) VALUES (v_ceo, 'ceo', NULL) ON CONFLICT DO NOTHING;
    INSERT INTO public.user_roles (user_id, role, agency_id) VALUES (v_ceo, 'owner', v_agency) ON CONFLICT DO NOTHING;

    IF v_emp IS NOT NULL THEN
      INSERT INTO public.user_roles (user_id, role, agency_id) VALUES (v_emp, 'employee', v_agency) ON CONFLICT DO NOTHING;
    END IF;
  END IF;
END $$;

-- ============ Ampliar RLS: CEO ve todo en TODAS las tablas de negocio ============
-- Genera una policy permisiva extra "ceo full access" en cada tabla relevante sin tocar las existentes.
DO $$
DECLARE
  t TEXT;
  tables TEXT[] := ARRAY[
    'cars','sales','leads','car_expenses','car_photos','car_publications',
    'cash_movements','sale_payments','vehicle_publications','calendar_events',
    'inbox_conversations','inbox_messages','channel_accounts','connected_accounts',
    'conversation_analyses','market_alerts','market_analyses','message_templates',
    'ml_listing_types','ai_generated_descriptions','car_documentation',
    'profiles','ceo_conversations','ceo_messages','ceo_daily_summaries'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name=t) THEN
      EXECUTE format('DROP POLICY IF EXISTS "ceo full access" ON public.%I', t);
      EXECUTE format('CREATE POLICY "ceo full access" ON public.%I FOR ALL USING (public.is_ceo(auth.uid())) WITH CHECK (public.is_ceo(auth.uid()))', t);
    END IF;
  END LOOP;
END $$;
