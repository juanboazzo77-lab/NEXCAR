
-- Cars: only see/edit/delete own
DROP POLICY "Auth users can view all cars" ON public.cars;
CREATE POLICY "Users can view own cars" ON public.cars FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY "Auth users can update cars" ON public.cars;
CREATE POLICY "Users can update own cars" ON public.cars FOR UPDATE TO authenticated USING (auth.uid() = user_id);

DROP POLICY "Auth users can delete cars" ON public.cars;
CREATE POLICY "Users can delete own cars" ON public.cars FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Car expenses: only see/edit/delete own
DROP POLICY "Auth users can view all expenses" ON public.car_expenses;
CREATE POLICY "Users can view own expenses" ON public.car_expenses FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY "Auth users can update expenses" ON public.car_expenses;
CREATE POLICY "Users can update own expenses" ON public.car_expenses FOR UPDATE TO authenticated USING (auth.uid() = user_id);

DROP POLICY "Auth users can delete expenses" ON public.car_expenses;
CREATE POLICY "Users can delete own expenses" ON public.car_expenses FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Cash movements: only see/edit/delete own
DROP POLICY "Auth users can view all cash" ON public.cash_movements;
CREATE POLICY "Users can view own cash" ON public.cash_movements FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY "Auth users can update cash" ON public.cash_movements;
CREATE POLICY "Users can update own cash" ON public.cash_movements FOR UPDATE TO authenticated USING (auth.uid() = user_id);

DROP POLICY "Auth users can delete cash" ON public.cash_movements;
CREATE POLICY "Users can delete own cash" ON public.cash_movements FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Sales: only see/edit/delete own
DROP POLICY "Auth users can view all sales" ON public.sales;
CREATE POLICY "Users can view own sales" ON public.sales FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY "Auth users can update sales" ON public.sales;
CREATE POLICY "Users can update own sales" ON public.sales FOR UPDATE TO authenticated USING (auth.uid() = user_id);

DROP POLICY "Auth users can delete sales" ON public.sales;
CREATE POLICY "Users can delete own sales" ON public.sales FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Sale payments: only see/edit/delete own
DROP POLICY "Auth users can view all payments" ON public.sale_payments;
CREATE POLICY "Users can view own payments" ON public.sale_payments FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY "Auth users can update payments" ON public.sale_payments;
CREATE POLICY "Users can update own payments" ON public.sale_payments FOR UPDATE TO authenticated USING (auth.uid() = user_id);

DROP POLICY "Auth users can delete payments" ON public.sale_payments;
CREATE POLICY "Users can delete own payments" ON public.sale_payments FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Car documentation: scope via car ownership
DROP POLICY "Auth users can view all docs" ON public.car_documentation;
CREATE POLICY "Users can view own car docs" ON public.car_documentation FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.cars WHERE cars.id = car_documentation.car_id AND cars.user_id = auth.uid()));

DROP POLICY "Auth users can insert docs" ON public.car_documentation;
CREATE POLICY "Users can insert own car docs" ON public.car_documentation FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.cars WHERE cars.id = car_documentation.car_id AND cars.user_id = auth.uid()));

DROP POLICY "Auth users can update docs" ON public.car_documentation;
CREATE POLICY "Users can update own car docs" ON public.car_documentation FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.cars WHERE cars.id = car_documentation.car_id AND cars.user_id = auth.uid()));

DROP POLICY "Auth users can delete docs" ON public.car_documentation;
CREATE POLICY "Users can delete own car docs" ON public.car_documentation FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.cars WHERE cars.id = car_documentation.car_id AND cars.user_id = auth.uid()));
