import { useEffect, useState } from "react";
import { Favoritos, Compare } from "@/lib/public-storage";

function useStored(getList: () => string[]) {
  const [ids, setIds] = useState<string[]>(() => getList());
  useEffect(() => {
    const refresh = () => setIds(getList());
    const onStorage = (e: StorageEvent) => { if (e.key) refresh(); };
    window.addEventListener("public-storage-change", refresh as any);
    window.addEventListener("storage", onStorage);
    return () => {
      window.removeEventListener("public-storage-change", refresh as any);
      window.removeEventListener("storage", onStorage);
    };
  }, [getList]);
  return ids;
}

export const useFavoritos = () => useStored(Favoritos.list);
export const useCompare = () => useStored(Compare.list);
