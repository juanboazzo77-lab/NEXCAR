import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import type { Car, CarInsert, CarExpense, CarExpenseInsert, CashMovement, CashMovementInsert, Sale, SaleInsert, SalePayment, SalePaymentInsert, CarDocumentation, CarDocInsert } from "@/lib/supabase-helpers";

// ---- Cars ----
export function useCars() {
  return useQuery({
    queryKey: ["cars"],
    queryFn: async () => {
      const { data, error } = await supabase.from("cars").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data as Car[];
    },
  });
}

export function useUpsertCar() {
  const qc = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (car: Partial<CarInsert> & { id?: string }) => {
      if (car.id) {
        const { id, ...rest } = car;
        const { error } = await supabase.from("cars").update(rest).eq("id", id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("cars").insert({ ...car, user_id: user!.id } as CarInsert);
        if (error) throw error;
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["cars"] }),
  });
}

export function useDeleteCar() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("cars").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["cars"] }),
  });
}

// ---- Expenses ----
export function useExpenses(carId?: string) {
  return useQuery({
    queryKey: ["expenses", carId],
    queryFn: async () => {
      let q = supabase.from("car_expenses").select("*").order("fecha", { ascending: false });
      if (carId) q = q.eq("car_id", carId);
      const { data, error } = await q;
      if (error) throw error;
      return data as CarExpense[];
    },
  });
}

export function useAddExpense() {
  const qc = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (exp: Omit<CarExpenseInsert, "user_id">) => {
      const { error } = await supabase.from("car_expenses").insert({ ...exp, user_id: user!.id });
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["expenses"] }),
  });
}

export function useUpdateExpense() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...rest }: Partial<CarExpenseInsert> & { id: string }) => {
      const { error } = await supabase.from("car_expenses").update(rest).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["expenses"] }),
  });
}

export function useDeleteExpense() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("car_expenses").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["expenses"] }),
  });
}

// ---- Cash Movements ----
export function useCashMovements() {
  return useQuery({
    queryKey: ["cash"],
    queryFn: async () => {
      const { data, error } = await supabase.from("cash_movements").select("*").order("fecha", { ascending: false });
      if (error) throw error;
      return data as CashMovement[];
    },
  });
}

export function useAddCashMovement() {
  const qc = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (mov: Omit<CashMovementInsert, "user_id">) => {
      const { error } = await supabase.from("cash_movements").insert({ ...mov, user_id: user!.id });
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["cash"] }),
  });
}

export function useDeleteCashMovement() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("cash_movements").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["cash"] }),
  });
}

// ---- Sales ----
export function useSales() {
  return useQuery({
    queryKey: ["sales"],
    queryFn: async () => {
      const { data, error } = await supabase.from("sales").select("*").order("fecha", { ascending: false });
      if (error) throw error;
      return data as Sale[];
    },
  });
}

export function useUpsertSale() {
  const qc = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (sale: Partial<SaleInsert> & { id?: string }) => {
      let resolvedCarId = sale.car_id ?? null;

      if (!resolvedCarId && sale.patente?.trim()) {
        const normalizedPatente = sale.patente.trim().toUpperCase();
        const { data: matchedCar, error: matchErr } = await supabase
          .from("cars")
          .select("id")
          .ilike("patente", normalizedPatente)
          .maybeSingle();

        if (matchErr) throw matchErr;
        resolvedCarId = matchedCar?.id ?? null;
      }

      const payload = {
        ...sale,
        car_id: resolvedCarId,
        patente: sale.patente?.trim().toUpperCase() ?? sale.patente,
      };

      if (sale.id) {
        const { id, ...rest } = payload;
        const { error } = await supabase.from("sales").update(rest).eq("id", id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("sales").insert({ ...payload, user_id: user!.id } as SaleInsert);
        if (error) throw error;
      }

      if (resolvedCarId) {
        const updates: any = { estado: "Vendido" };
        if (sale.monto != null && Number(sale.monto) > 0) updates.precio_venta = sale.monto;
        const { error: updErr } = await supabase.from("cars").update(updates).eq("id", resolvedCarId);
        if (updErr) throw updErr;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["sales"] });
      qc.invalidateQueries({ queryKey: ["cars"] });
    },
  });
}

export function useDeleteSale() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("sales").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["sales"] }),
  });
}

// ---- Sale Payments ----
export function useSalePayments(saleId?: string) {
  return useQuery({
    queryKey: ["sale_payments", saleId],
    queryFn: async () => {
      let q = supabase.from("sale_payments").select("*").order("fecha", { ascending: false });
      if (saleId) q = q.eq("sale_id", saleId);
      const { data, error } = await q;
      if (error) throw error;
      return data as SalePayment[];
    },
    enabled: !!saleId,
  });
}

export function useAddSalePayment() {
  const qc = useQueryClient();
  const { user } = useAuth();
  return useMutation({
    mutationFn: async (p: Omit<SalePaymentInsert, "user_id">) => {
      const { error } = await supabase.from("sale_payments").insert({ ...p, user_id: user!.id });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["sale_payments"] });
      qc.invalidateQueries({ queryKey: ["sales"] });
    },
  });
}

// ---- Car Documentation ----
export function useCarDocs() {
  return useQuery({
    queryKey: ["car_docs"],
    queryFn: async () => {
      const { data, error } = await supabase.from("car_documentation").select("*");
      if (error) throw error;
      return data as CarDocumentation[];
    },
  });
}

export function useUpsertCarDoc() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (doc: Partial<CarDocInsert> & { car_id: string; id?: string }) => {
      if (doc.id) {
        const { id, ...rest } = doc;
        const { error } = await supabase.from("car_documentation").update(rest).eq("id", id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("car_documentation").insert(doc as CarDocInsert);
        if (error) throw error;
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["car_docs"] }),
  });
}
