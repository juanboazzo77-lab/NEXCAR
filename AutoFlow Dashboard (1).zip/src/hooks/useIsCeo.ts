import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export function useIsCeo() {
  const { user } = useAuth();
  const [isCeo, setIsCeo] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { setIsCeo(false); setLoading(false); return; }
    let active = true;
    (async () => {
      const { data } = await (supabase as any).rpc("is_ceo", { _user_id: user.id });
      if (active) { setIsCeo(!!data); setLoading(false); }
    })();
    return () => { active = false; };
  }, [user?.id]);

  return { isCeo, loading };
}
