import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAgency } from "@/hooks/useAgency";

export type CarIntel = {
  id: string;
  marca: string;
  modelo: string;
  version: string | null;
  anio: number;
  patente: string | null;
  estado: string;
  precio_venta: number | null;
  precio_compra: number | null;
  moneda: string | null;
  mostrar_publico: boolean;
  marketplace_tier: string | null;
  created_at: string;
  dias: number;
  views: number;
  favoritos: number;
  consultas: number;
  reservas: number;
  /** consultas / visitas */
  conversion: number;
  sugerencias: string[];
};

export type RotationRow = {
  key: string;
  marca: string;
  modelo: string;
  vendidos: number;
  diasPromedio: number;
  margenPromedio: number;
  enStock: number;
};

const days = (iso: string) => Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 86400000));

function sugerir(c: Omit<CarIntel, "sugerencias">): string[] {
  const out: string[] = [];
  if (c.dias >= 90) out.push("Lleva más de 90 días en stock: revisá precio y considerá una acción comercial.");
  else if (c.dias >= 60) out.push("Más de 60 días publicado: podría necesitar un ajuste de precio.");
  if (c.views >= 100 && c.consultas === 0) out.push("Tiene muchas visitas pero ninguna consulta: revisá el precio y la descripción.");
  else if (c.views >= 50 && c.conversion < 0.02) out.push("Muchas visitas y pocas consultas: el precio puede estar alto para el mercado.");
  if (c.views < 20 && c.dias >= 21) out.push("Casi no recibe visitas: mejorá las fotos, el título y activá prioridad ORO.");
  if (c.favoritos >= 5 && c.consultas === 0) out.push("Varios clientes lo guardaron en favoritos: buen candidato para una promoción o financiación.");
  if (!c.mostrar_publico) out.push("No está visible en el catálogo público: activalo para generar consultas.");
  if (!c.precio_venta) out.push("Sin precio de venta cargado: los avisos sin precio reciben muchas menos consultas.");
  if (!out.length) out.push("Rendimiento saludable: mantené el aviso actualizado.");
  return out;
}

export function useStockIntelligence() {
  const { agency } = useAgency();
  const [cars, setCars] = useState<CarIntel[]>([]);
  const [rotation, setRotation] = useState<RotationRow[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [{ data: carRows }, { data: eventRows }, { data: saleRows }] = await Promise.all([
        supabase.from("cars").select("id, marca, modelo, version, anio, patente, estado, precio_venta, precio_compra, moneda, mostrar_publico, marketplace_tier, created_at, updated_at").order("created_at", { ascending: false }),
        (supabase as any).from("car_events").select("car_id, event_type"),
        supabase.from("sales").select("id, car_id, fecha, monto, created_at"),
      ]);

      const agg: Record<string, { view: number; favorite: number; unfavorite: number; inquiry: number; whatsapp: number; reserve: number }> = {};
      for (const e of (eventRows as any[]) || []) {
        const a = (agg[e.car_id] ||= { view: 0, favorite: 0, unfavorite: 0, inquiry: 0, whatsapp: 0, reserve: 0 });
        if (e.event_type in a) (a as any)[e.event_type]++;
      }

      const list: CarIntel[] = ((carRows as any[]) || []).map((c) => {
        const a = agg[c.id] || { view: 0, favorite: 0, unfavorite: 0, inquiry: 0, whatsapp: 0, reserve: 0 };
        const views = a.view;
        const consultas = a.inquiry + a.whatsapp;
        const favoritos = Math.max(0, a.favorite - a.unfavorite);
        const base = {
          id: c.id, marca: c.marca, modelo: c.modelo, version: c.version, anio: c.anio, patente: c.patente,
          estado: c.estado, precio_venta: c.precio_venta, precio_compra: c.precio_compra, moneda: c.moneda,
          mostrar_publico: !!c.mostrar_publico, marketplace_tier: c.marketplace_tier, created_at: c.created_at,
          dias: days(c.created_at), views, favoritos, consultas, reservas: a.reserve,
          conversion: views ? consultas / views : 0,
        };
        return { ...base, sugerencias: sugerir(base) };
      });
      setCars(list);

      // Ranking de rotación por marca + modelo
      const carById = new Map(((carRows as any[]) || []).map((c) => [c.id, c]));
      const rot: Record<string, { marca: string; modelo: string; dias: number[]; margen: number[]; enStock: number }> = {};
      for (const c of ((carRows as any[]) || [])) {
        const k = `${c.marca} ${c.modelo}`.toLowerCase();
        const r = (rot[k] ||= { marca: c.marca, modelo: c.modelo, dias: [], margen: [], enStock: 0 });
        if (c.estado !== "Vendido") r.enStock++;
      }
      for (const s of ((saleRows as any[]) || [])) {
        const c = s.car_id ? carById.get(s.car_id) : null;
        if (!c) continue;
        const k = `${c.marca} ${c.modelo}`.toLowerCase();
        const r = (rot[k] ||= { marca: c.marca, modelo: c.modelo, dias: [], margen: [], enStock: 0 });
        const d = Math.max(0, Math.floor((new Date(s.fecha || s.created_at).getTime() - new Date(c.created_at).getTime()) / 86400000));
        r.dias.push(d);
        if (c.precio_compra && s.monto) r.margen.push(Number(s.monto) - Number(c.precio_compra));
      }
      const avg = (arr: number[]) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0);
      setRotation(
        Object.entries(rot)
          .map(([key, r]) => ({
            key, marca: r.marca, modelo: r.modelo, vendidos: r.dias.length,
            diasPromedio: Math.round(avg(r.dias)), margenPromedio: Math.round(avg(r.margen)), enStock: r.enStock,
          }))
          .sort((a, b) => b.vendidos - a.vendidos || a.diasPromedio - b.diasPromedio)
      );
    } finally {
      setLoading(false);
    }
  }, [agency?.id]);

  useEffect(() => { load(); }, [load]);

  const totals = useMemo(() => {
    const activos = cars.filter((c) => c.estado !== "Vendido");
    return {
      vehiculos: activos.length,
      views: cars.reduce((a, c) => a + c.views, 0),
      favoritos: cars.reduce((a, c) => a + c.favoritos, 0),
      consultas: cars.reduce((a, c) => a + c.consultas, 0),
      diasPromedio: activos.length ? Math.round(activos.reduce((a, c) => a + c.dias, 0) / activos.length) : 0,
      clavados: activos.filter((c) => c.dias >= 60).length,
    };
  }, [cars]);

  return { cars, rotation, totals, loading, reload: load };
}
