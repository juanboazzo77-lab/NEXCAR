import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export function usePendingTasaciones() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let active = true;
    const load = async () => {
      const { count: c } = await supabase
        .from("trade_in_requests")
        .select("id", { count: "exact", head: true })
        .eq("estado", "Pendiente");
      if (active) setCount(c ?? 0);
    };
    load();
    const interval = setInterval(load, 60000);
    const onChange = () => load();
    window.addEventListener("tasaciones-change", onChange);
    return () => {
      active = false;
      clearInterval(interval);
      window.removeEventListener("tasaciones-change", onChange);
    };
  }, []);

  return count;
}
