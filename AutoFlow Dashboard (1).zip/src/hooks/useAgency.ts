import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export type Agency = {
  id: string;
  name: string;
  slug: string | null;
  status: string;
  plan: string | null;
  logo_url: string | null;
  descripcion: string | null;
  direccion: string | null;
  ciudad: string | null;
  provincia: string | null;
  lat: number | null;
  lng: number | null;
  telefono: string | null;
  whatsapp: string | null;
  email: string | null;
  instagram_url: string | null;
  facebook_url: string | null;
  tiktok_url: string | null;
  website_url: string | null;
  horarios: string | null;
  marketplace_visible: boolean;
};

export type Subscription = {
  id: string;
  status: string;
  started_at: string;
  current_period_end: string | null;
  plan?: { code: string; name: string; max_vehicles: number | null; max_users: number | null } | null;
};

/** Agencia a la que pertenece el usuario logueado. */
export function useAgency() {
  const { user } = useAuth();
  const [agency, setAgency] = useState<Agency | null>(null);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user) { setAgency(null); setLoading(false); return; }
    setLoading(true);
    const { data: role } = await supabase
      .from("user_roles").select("agency_id, role").eq("user_id", user.id)
      .not("agency_id", "is", null).maybeSingle();
    const agencyId = (role as any)?.agency_id as string | undefined;
    if (!agencyId) { setAgency(null); setSubscription(null); setLoading(false); return; }
    const { data: ag } = await supabase.from("agencies").select("*").eq("id", agencyId).maybeSingle();
    setAgency((ag as any) ?? null);
    const { data: sub } = await supabase
      .from("subscriptions")
      .select("id,status,started_at,current_period_end, plan:plans(code,name,max_vehicles,max_users)")
      .eq("agency_id", agencyId).maybeSingle();
    setSubscription((sub as any) ?? null);
    setLoading(false);
  }, [user?.id]);

  useEffect(() => { load(); }, [load]);

  return { agency, subscription, loading, reload: load };
}
