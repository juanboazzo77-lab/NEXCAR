import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAgency } from "@/hooks/useAgency";
import { useIsCeo } from "@/hooks/useIsCeo";
import { FeatureKey, PLANS, PlanCode, PlanUsage, normalizePlan } from "@/lib/plans";

/**
 * Plan efectivo de la agencia del usuario + uso de cupos del Marketplace.
 * Punto único de consulta de permisos en el frontend (la validación real vive en la base).
 */
export function usePlan() {
  const { agency, loading: agencyLoading } = useAgency();
  const { isCeo, loading: ceoLoading } = useIsCeo();
  const [usage, setUsage] = useState<PlanUsage | null>(null);
  const [usageLoading, setUsageLoading] = useState(false);

  const planCode: PlanCode = normalizePlan(agency?.plan);
  const plan = PLANS[planCode];
  const loading = agencyLoading || ceoLoading;

  const loadUsage = useCallback(async () => {
    if (!agency?.id) { setUsage(null); return; }
    setUsageLoading(true);
    const { data } = await (supabase as any).rpc("agency_plan_usage", { _agency_id: agency.id });
    setUsage((data as PlanUsage) ?? null);
    setUsageLoading(false);
  }, [agency?.id]);

  useEffect(() => { loadUsage(); }, [loadUsage]);

  /** CEO y usuarios sin agencia (sistema propio) tienen acceso total. */
  const can = useCallback(
    (feature: FeatureKey) => (isCeo || !agency ? true : !!plan.features[feature]),
    [isCeo, agency, plan]
  );

  return { plan, planCode, planName: plan.name, can, usage, loading, usageLoading, reloadUsage: loadUsage, isCeo, agency };
}
