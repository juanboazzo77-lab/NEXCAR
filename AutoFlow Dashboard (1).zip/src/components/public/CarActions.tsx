import { Heart, GitCompare } from "lucide-react";
import { Favoritos, Compare } from "@/lib/public-storage";
import { useFavoritos, useCompare } from "@/hooks/use-public-lists";
import { useToast } from "@/hooks/use-toast";
import { trackCarEvent } from "@/lib/car-tracking";

export function FavButton({ carId, className = "" }: { carId: string; className?: string }) {
  const favs = useFavoritos();
  const active = favs.includes(carId);
  return (
    <button
      onClick={(e) => { e.preventDefault(); e.stopPropagation(); const on = Favoritos.toggle(carId); trackCarEvent(carId, on ? "favorite" : "unfavorite"); }}
      className={`p-2 rounded-full bg-white/90 backdrop-blur shadow hover:bg-white transition ${className}`}
      title={active ? "Quitar de favoritos" : "Agregar a favoritos"}
      aria-label="Favorito"
    >
      <Heart className={`w-4 h-4 ${active ? "text-rose-500 fill-rose-500" : "text-slate-600"}`} />
    </button>
  );
}

export function CompareButton({ carId, label = true }: { carId: string; label?: boolean }) {
  const cmp = useCompare();
  const active = cmp.includes(carId);
  const { toast } = useToast();
  return (
    <button
      onClick={(e) => {
        e.preventDefault(); e.stopPropagation();
        const r = Compare.toggle(carId);
        if (r.reason) toast({ title: r.reason, variant: "destructive" });
      }}
      className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-medium border transition ${
        active ? "bg-slate-900 text-white border-slate-900" : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"
      }`}
    >
      <GitCompare className="w-3.5 h-3.5" />
      {label && (active ? "En comparador" : "Comparar")}
    </button>
  );
}
