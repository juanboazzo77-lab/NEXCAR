import { useEffect, useMemo, useState } from "react";

const OPTIONS = [9, 12, 24, 48, 96];

/** Paginación con cantidad por página editable (se recuerda en el navegador). */
export function usePagination<T>(items: T[], storageKey = "pageSize", defaultSize = 12) {
  const [perPage, setPerPage] = useState<number>(() => {
    const saved = typeof window !== "undefined" ? Number(localStorage.getItem(storageKey)) : 0;
    return saved && saved > 0 ? saved : defaultSize;
  });
  const [page, setPage] = useState(1);

  useEffect(() => {
    if (typeof window !== "undefined") localStorage.setItem(storageKey, String(perPage));
  }, [perPage, storageKey]);

  const totalPages = Math.max(1, Math.ceil(items.length / perPage));

  useEffect(() => { setPage(1); }, [items.length, perPage]);
  useEffect(() => { if (page > totalPages) setPage(totalPages); }, [page, totalPages]);

  const pageItems = useMemo(
    () => items.slice((page - 1) * perPage, page * perPage),
    [items, page, perPage]
  );

  return { page, setPage, perPage, setPerPage, totalPages, pageItems, total: items.length };
}

type Props = {
  page: number;
  totalPages: number;
  perPage: number;
  total: number;
  onPage: (p: number) => void;
  onPerPage: (n: number) => void;
};

export function PageSizeSelect({ perPage, onPerPage }: { perPage: number; onPerPage: (n: number) => void }) {
  return (
    <label className="flex items-center gap-2 text-sm text-slate-600">
      Ver
      <select
        value={perPage}
        onChange={(e) => onPerPage(Number(e.target.value))}
        className="px-2 py-1 rounded-lg border bg-white text-slate-900 text-sm outline-none"
      >
        {OPTIONS.map((n) => <option key={n} value={n}>{n}</option>)}
      </select>
      por página
    </label>
  );
}

export default function Pagination({ page, totalPages, perPage, total, onPage, onPerPage }: Props) {
  if (total === 0) return null;
  const from = (page - 1) * perPage + 1;
  const to = Math.min(total, page * perPage);

  const nums: (number | "…")[] = [];
  for (let i = 1; i <= totalPages; i++) {
    if (i === 1 || i === totalPages || Math.abs(i - page) <= 1) nums.push(i);
    else if (nums[nums.length - 1] !== "…") nums.push("…");
  }

  return (
    <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
      <div className="text-sm text-slate-500">Mostrando {from}–{to} de {total}</div>
      <div className="flex items-center gap-3">
        <PageSizeSelect perPage={perPage} onPerPage={onPerPage} />
        {totalPages > 1 && (
          <div className="flex items-center gap-1">
            <button
              onClick={() => onPage(page - 1)}
              disabled={page === 1}
              className="px-3 py-1.5 rounded-lg border bg-white text-sm disabled:opacity-40"
            >
              ←
            </button>
            {nums.map((n, i) =>
              n === "…" ? (
                <span key={`e${i}`} className="px-2 text-slate-400">…</span>
              ) : (
                <button
                  key={n}
                  onClick={() => onPage(n)}
                  className={`px-3 py-1.5 rounded-lg border text-sm ${n === page ? "bg-slate-900 text-white border-slate-900" : "bg-white text-slate-700 hover:bg-slate-100"}`}
                >
                  {n}
                </button>
              )
            )}
            <button
              onClick={() => onPage(page + 1)}
              disabled={page === totalPages}
              className="px-3 py-1.5 rounded-lg border bg-white text-sm disabled:opacity-40"
            >
              →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
