import { useMemo, useState } from "react";
import { usePublicSettings } from "@/pages/public/PublicLayout";

export default function FinanciacionSimulator({ precio, moneda }: { precio: number; moneda: string | null }) {
  const s = usePublicSettings();
  const [entrega, setEntrega] = useState(Math.round(precio * 0.4));
  const [cuotas, setCuotas] = useState(Math.min(24, s.financiacion_cuotas_max));
  const tasa = s.financiacion_tasa;
  const gastos = s.financiacion_gastos_porcentaje;

  if (!s.financiacion_activa) return null;

  const calc = useMemo(() => {
    const monto = Math.max(0, precio - entrega);
    const gastosMonto = (monto * gastos) / 100;
    const financiado = monto + gastosMonto;
    const tasaMensual = tasa / 100 / 12;
    let cuota = 0;
    if (cuotas > 0) {
      cuota = tasaMensual > 0
        ? (financiado * tasaMensual) / (1 - Math.pow(1 + tasaMensual, -cuotas))
        : financiado / cuotas;
    }
    const total = cuota * cuotas + entrega;
    return { monto, gastosMonto, financiado, cuota, total };
  }, [precio, entrega, cuotas, tasa, gastos]);

  const sym = moneda === "USD" ? "USD" : "$";
  const fmt = (n: number) => `${sym} ${Math.round(n).toLocaleString("es-AR")}`;

  return (
    <div className="bg-white rounded-2xl border p-5">
      <h3 className="font-semibold mb-3">💰 Simular financiación</h3>
      <div className="grid grid-cols-2 gap-3 text-sm">
        <label className="block">
          <div className="text-xs text-slate-600 mb-1">Entrega inicial</div>
          <input type="number" value={entrega} onChange={(e) => setEntrega(Number(e.target.value) || 0)}
            className="w-full px-3 py-2 rounded-lg border bg-slate-50" />
        </label>
        <label className="block">
          <div className="text-xs text-slate-600 mb-1">Cuotas (máx {s.financiacion_cuotas_max})</div>
          <input type="number" min={1} max={s.financiacion_cuotas_max} value={cuotas}
            onChange={(e) => setCuotas(Math.min(s.financiacion_cuotas_max, Math.max(1, Number(e.target.value) || 1)))}
            className="w-full px-3 py-2 rounded-lg border bg-slate-50" />
        </label>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2 text-center">
        <div className="bg-slate-50 rounded-xl p-3">
          <div className="text-[11px] text-slate-500">Cuota aprox</div>
          <div className="font-bold text-slate-900">{fmt(calc.cuota)}</div>
        </div>
        <div className="bg-slate-50 rounded-xl p-3">
          <div className="text-[11px] text-slate-500">A financiar</div>
          <div className="font-bold text-slate-900">{fmt(calc.financiado)}</div>
        </div>
        <div className="bg-slate-50 rounded-xl p-3">
          <div className="text-[11px] text-slate-500">Total a pagar</div>
          <div className="font-bold text-slate-900">{fmt(calc.total)}</div>
        </div>
      </div>
      <p className="text-[11px] text-slate-500 mt-3">
        Los valores son únicamente una simulación y pueden variar según la entidad financiera y las condiciones de aprobación.
      </p>
    </div>
  );
}
