import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

export default function RelatedCars({ car }: { car: any }) {
  const [items, setItems] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("cars_public")
        .select("id,slug,marca,modelo,version,anio,kilometros,precio_venta,moneda,carroceria,combustible,estado")
        .eq("mostrar_publico", true)
        .neq("id", car.id)
        .in("estado", ["Disponible", "Reservado"])
        .limit(40);
      const list = data || [];
      const precio = car.precio_venta || 0;
      const scored = list.map((c: any) => {
        let s = 0;
        if (c.marca === car.marca) s += 40;
        if (c.carroceria && c.carroceria === car.carroceria) s += 25;
        if (c.combustible && c.combustible === car.combustible) s += 15;
        if (precio && c.precio_venta) {
          const diff = Math.abs(c.precio_venta - precio) / precio;
          if (diff < 0.25) s += 25; else if (diff < 0.5) s += 10;
        }
        if (car.anio && c.anio && Math.abs(c.anio - car.anio) <= 2) s += 15;
        if (car.kilometros && c.kilometros) {
          const km = Math.abs(c.kilometros - car.kilometros) / Math.max(1, car.kilometros);
          if (km < 0.3) s += 10;
        }
        return { c, s };
      }).sort((a, b) => b.s - a.s).slice(0, 8).map((x) => x.c);

      const ids = scored.map((c) => c.id);
      const photos: Record<string, string> = {};
      if (ids.length) {
        const { data: ph } = await supabase.from("car_photos")
          .select("car_id,url,es_portada,orden").in("car_id", ids)
          .order("es_portada", { ascending: false }).order("orden", { ascending: true });
        (ph || []).forEach((p: any) => { if (!photos[p.car_id]) photos[p.car_id] = p.url; });
      }
      setItems(scored.map((c) => ({ ...c, cover: photos[c.id] })));
    })();
  }, [car?.id]);

  if (!items.length) return null;
  return (
    <div className="max-w-6xl mx-auto px-4 mt-12">
      <h2 className="text-xl font-bold mb-4">También te puede interesar</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {items.map((c) => (
          <Link key={c.id} to={`/catalogo/${c.slug || c.id}`}
            className="group bg-white rounded-2xl border overflow-hidden hover:shadow-lg transition">
            <div className="aspect-[4/3] bg-slate-100 overflow-hidden">
              {c.cover ? <img src={c.cover} className="w-full h-full object-cover group-hover:scale-105 transition" />
                : <div className="w-full h-full grid place-items-center text-slate-400 text-xs">Sin foto</div>}
            </div>
            <div className="p-3">
              <div className="text-xs text-slate-500">{c.marca}</div>
              <div className="font-semibold text-sm leading-tight">{c.modelo} {c.version || ""}</div>
              <div className="text-[11px] text-slate-500 mt-1">{c.anio} · {c.kilometros ? `${c.kilometros.toLocaleString("es-AR")} km` : "—"}</div>
              <div className="mt-2 flex items-end justify-between">
                <div className="font-bold text-sm">{c.precio_venta ? `${c.moneda === "USD" ? "USD" : "$"} ${Math.round(c.precio_venta).toLocaleString("es-AR")}` : "Consultar"}</div>
                <span className="text-[11px] text-slate-700 group-hover:text-slate-900 font-medium">Ver →</span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
