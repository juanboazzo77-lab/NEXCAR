import { Link } from "react-router-dom";
import { GitCompare, X } from "lucide-react";
import { Compare } from "@/lib/public-storage";
import { useCompare } from "@/hooks/use-public-lists";

export default function CompareBar() {
  const ids = useCompare();
  if (!ids.length) return null;
  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 bg-slate-900 text-white rounded-full shadow-2xl px-2 py-2 flex items-center gap-2 max-w-[95vw]">
      <div className="px-3 text-sm font-medium hidden sm:block">Comparador</div>
      <div className="flex items-center gap-1 bg-slate-800 rounded-full px-2 py-1">
        <GitCompare className="w-4 h-4" />
        <span className="text-sm font-semibold">{ids.length}/{Compare.MAX}</span>
      </div>
      <button onClick={() => Compare.clear()} className="text-xs text-slate-300 hover:text-white px-2" title="Vaciar">
        <X className="w-4 h-4" />
      </button>
      <Link to="/catalogo/comparar"
        className="px-4 py-2 rounded-full bg-emerald-500 hover:bg-emerald-600 text-sm font-semibold">
        Comparar vehículos →
      </Link>
    </div>
  );
}
