import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { MessageCircle, X, Send, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { usePublicSettings } from "@/pages/public/PublicLayout";

type Recommendation = { car_id: string; reason: string };
type Msg = { role: "user" | "assistant"; text: string; recs?: Recommendation[] };

export default function AdvisorWidget() {
  const s = usePublicSettings();
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([
    { role: "assistant", text: "Hola 👋 Soy tu asesor IA. Contame qué auto buscás (uso, presupuesto, preferencias) y te recomiendo opciones de nuestro stock." },
  ]);
  const [cars, setCars] = useState<Record<string, any>>({});
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [msgs, open]);

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;
    setInput("");
    setMsgs((m) => [...m, { role: "user", text }]);
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("public-ai-advisor", {
        body: { message: text, history: msgs.slice(-6).map((m) => ({ role: m.role, content: m.text })) },
      });
      if (error) throw error;
      const reply = (data?.reply as string) || "No tengo recomendaciones por ahora.";
      const recs = (data?.recommendations as Recommendation[]) || [];
      const carsData = (data?.cars as any[]) || [];
      const byId: Record<string, any> = {};
      carsData.forEach((c) => (byId[c.id] = c));
      setCars((prev) => ({ ...prev, ...byId }));
      setMsgs((m) => [...m, { role: "assistant", text: reply, recs }]);
    } catch (e: any) {
      setMsgs((m) => [...m, { role: "assistant", text: "Hubo un error consultando al asesor. Probá de nuevo en un momento." }]);
    } finally {
      setLoading(false);
    }
  };

  const waUrl = (car: any) => {
    const msg = encodeURIComponent(`Hola! Me interesa el ${car.marca} ${car.modelo} ${car.version || ""} ${car.anio}.`);
    return `https://wa.me/${s.whatsapp_number.replace(/\D/g, "")}?text=${msg}`;
  };

  return (
    <>
      {!open && (
        <button onClick={() => setOpen(true)}
          className="fixed bottom-20 right-4 sm:bottom-6 sm:right-6 z-40 inline-flex items-center gap-2 px-4 py-3 rounded-full bg-slate-900 text-white shadow-2xl hover:bg-slate-800 transition">
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span className="font-medium text-sm">Asesor IA</span>
        </button>
      )}
      {open && (
        <div className="fixed inset-x-3 bottom-3 sm:bottom-6 sm:right-6 sm:left-auto sm:w-[380px] z-50 bg-white rounded-2xl shadow-2xl border flex flex-col max-h-[80vh]">
          <div className="flex items-center justify-between px-4 py-3 border-b">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <div className="font-semibold text-sm">Asesor IA</div>
            </div>
            <button onClick={() => setOpen(false)} className="p-1 rounded hover:bg-slate-100"><X className="w-4 h-4" /></button>
          </div>
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-3 text-sm">
            {msgs.map((m, i) => (
              <div key={i} className={m.role === "user" ? "text-right" : ""}>
                <div className={`inline-block max-w-[85%] px-3 py-2 rounded-2xl whitespace-pre-wrap text-left ${m.role === "user" ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-800"}`}>
                  {m.text}
                </div>
                {m.recs && m.recs.length > 0 && (
                  <div className="mt-2 space-y-2">
                    {m.recs.map((r) => {
                      const c = cars[r.car_id];
                      if (!c) return null;
                      return (
                        <div key={r.car_id} className="text-left border rounded-xl p-2 bg-white">
                          <div className="font-semibold">{c.marca} {c.modelo} {c.version || ""}</div>
                          <div className="text-xs text-slate-500">{c.anio} · {c.kilometros?.toLocaleString("es-AR")} km · {c.moneda === "USD" ? "USD" : "$"} {Number(c.precio_venta || 0).toLocaleString("es-AR")}</div>
                          <div className="text-xs text-slate-600 mt-1">{r.reason}</div>
                          <div className="mt-2 flex gap-2">
                            <Link to={`/catalogo/${c.slug || c.id}`} onClick={() => setOpen(false)}
                              className="text-xs font-medium px-2 py-1 rounded bg-slate-900 text-white">Ver vehículo</Link>
                            <a href={waUrl(c)} target="_blank" rel="noreferrer" className="text-xs font-medium px-2 py-1 rounded bg-emerald-500 text-white">WhatsApp</a>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            ))}
            {loading && <div className="text-xs text-slate-500">Analizando stock…</div>}
          </div>
          <div className="border-t p-2 flex gap-2">
            <input value={input} onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") send(); }}
              placeholder="Ej: busco un auto familiar hasta 20 millones"
              className="flex-1 px-3 py-2 text-sm rounded-lg bg-slate-100 outline-none" />
            <button onClick={send} disabled={loading || !input.trim()}
              className="p-2 rounded-lg bg-slate-900 text-white disabled:opacity-40"><Send className="w-4 h-4" /></button>
          </div>
        </div>
      )}
    </>
  );
}
