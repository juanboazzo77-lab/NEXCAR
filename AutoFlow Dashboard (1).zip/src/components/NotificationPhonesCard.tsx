import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Trash2, Plus, Send, MessageCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function NotificationPhonesCard() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const { toast } = useToast();
  const [phone, setPhone] = useState("");
  const [label, setLabel] = useState("");
  const [sending, setSending] = useState(false);

  const { data: phones = [] } = useQuery({
    queryKey: ["notification_phones"],
    queryFn: async () => {
      const { data, error } = await supabase.from("notification_phones").select("*").order("created_at");
      if (error) throw error;
      return data as any[];
    },
    enabled: !!user,
  });

  const add = useMutation({
    mutationFn: async () => {
      const clean = phone.replace(/[^0-9]/g, "");
      if (clean.length < 8) throw new Error("Número inválido");
      const { error } = await supabase.from("notification_phones").insert({
        user_id: user!.id,
        phone: clean,
        label: label || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["notification_phones"] });
      setPhone(""); setLabel("");
      toast({ title: "Número agregado" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("notification_phones").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["notification_phones"] }),
  });

  const sendNow = async () => {
    setSending(true);
    try {
      const { data, error } = await supabase.functions.invoke("daily-summary-whatsapp", { body: {} });
      if (error) throw error;
      const sent = (data as any)?.sent ?? 0;
      const total = (data as any)?.total ?? 0;
      toast({ title: `Resumen enviado`, description: `${sent}/${total} mensajes` });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <MessageCircle className="w-4 h-4" /> Aviso diario por WhatsApp
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Todos los días a las 8:30 (hora Argentina) la IA manda un mensaje con lo que hay que hacer hoy (calendario + cuotas por cobrar) a los números de abajo. También podés mandar el resumen manualmente.
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap gap-2 items-end">
          <div className="flex-1 min-w-[160px]">
            <Label className="text-xs">Número (con código de país)</Label>
            <Input placeholder="Ej: 5491123456789" value={phone} onChange={e => setPhone(e.target.value)} />
          </div>
          <div className="flex-1 min-w-[120px]">
            <Label className="text-xs">Etiqueta</Label>
            <Input placeholder="Ej: Gastón" value={label} onChange={e => setLabel(e.target.value)} />
          </div>
          <Button onClick={() => add.mutate()} disabled={!phone || add.isPending}><Plus className="w-4 h-4 mr-1" />Agregar</Button>
        </div>

        {phones.length > 0 && (
          <div className="space-y-1">
            {phones.map((p: any) => (
              <div key={p.id} className="flex items-center justify-between border rounded px-3 py-1.5 text-sm">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">{p.phone}</Badge>
                  {p.label && <span className="text-muted-foreground text-xs">{p.label}</span>}
                </div>
                <Button size="icon" variant="ghost" onClick={() => del.mutate(p.id)}><Trash2 className="w-3 h-3" /></Button>
              </div>
            ))}
          </div>
        )}

        <Button onClick={sendNow} disabled={sending || phones.length === 0} className="w-full" variant="outline">
          <Send className="w-4 h-4 mr-1" /> {sending ? "Enviando..." : "Enviar resumen ahora"}
        </Button>
        <p className="text-[11px] text-muted-foreground">
          Requiere tener una cuenta de WhatsApp Business conectada en la sección <b>Canales</b>.
        </p>
      </CardContent>
    </Card>
  );
}
