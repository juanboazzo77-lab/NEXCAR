import { useCallback, useEffect, useRef, useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Loader2, RefreshCw } from "lucide-react";
import { callFn } from "@/lib/publisher";

type Attr = "BRAND" | "MODEL" | "VEHICLE_YEAR" | "TRIM";
type Option = { id: string | null; name: string };
type Known = { id: string; value_id?: string; value_name?: string };

function Picker({
  label, attributeId, known, categoryId, disabled, valueName, onPick,
}: {
  label: string;
  attributeId: Attr;
  known: Known[];
  categoryId?: string | null;
  disabled?: boolean;
  valueName: string;
  onPick: (option: Option | null, typed: string) => void;
}) {
  const [options, setOptions] = useState<Option[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [text, setText] = useState(valueName || "");
  const abort = useRef<AbortController | null>(null);
  const knownKey = JSON.stringify(known);

  useEffect(() => { setText(valueName || ""); }, [valueName]);

  const fetchOptions = useCallback(async (search: string) => {
    abort.current?.abort();
    const controller = new AbortController();
    abort.current = controller;
    setLoading(true);
    try {
      const data = await callFn("mercadolibre-vehicle-options", {
        attributeId, knownAttributes: known, categoryId: categoryId || undefined, search,
      });
      if (!controller.signal.aborted) {
        setOptions(data.options || []);
        setNotice(data.needsAuth ? (data.error as string) : null);
      }
    } catch {
      if (!controller.signal.aborted) { setOptions([]); setNotice(null); }
    }
    if (!controller.signal.aborted) setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [attributeId, knownKey, categoryId]);


  useEffect(() => {
    if (disabled) { setOptions([]); return; }
    const t = window.setTimeout(() => fetchOptions(text), 350);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [disabled, knownKey, text]);

  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <Label>{label}</Label>
        {loading && <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />}
      </div>
      <div className="relative">
        <Input
          value={text}
          disabled={disabled}
          placeholder={disabled ? "Elegí primero el paso anterior" : `Buscar ${label.toLowerCase()}…`}
          onChange={(e) => { setText(e.target.value); setOpen(true); onPick(null, e.target.value); }}
          onFocus={() => setOpen(true)}
          onBlur={() => window.setTimeout(() => setOpen(false), 150)}
        />
        {open && !disabled && (
          <div className="absolute z-30 mt-1 max-h-60 w-full overflow-auto rounded-md border bg-popover p-1 shadow-md">
            {options.map((o) => (
              <button
                key={`${o.id}-${o.name}`}
                type="button"
                className="block w-full rounded px-2 py-1.5 text-left text-sm hover:bg-accent"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => { setText(o.name); setOpen(false); onPick(o, o.name); }}
              >
                {o.name}
              </button>
            ))}
            {!options.length && (
              <p className="px-2 py-1.5 text-sm text-muted-foreground">
                {loading ? "Buscando…" : notice || "Sin resultados: podés escribir el valor a mano."}
              </p>
            )}

          </div>
        )}

      </div>
    </div>
  );
}

const SPEC_MAP: Record<string, string> = {
  FUEL_TYPE: "fuel_type",
  TRANSMISSION: "transmission",
  ENGINE: "engine",
  ENGINE_DISPLACEMENT: "engine",
  HORSEPOWER: "power",
  DOORS: "doors",
  VEHICLE_BODY_TYPE: "body_type",
  PASSENGER_CAPACITY: "passengers",
};

/** Selectores encadenados con el catálogo oficial de Mercado Libre. */
export default function VehicleCatalogPicker({
  vehicle, patch,
}: { vehicle: any; patch: (changes: Record<string, any>) => void }) {
  const known: Known[] = [];
  if (vehicle.brand) known.push({ id: "BRAND", value_id: vehicle.brand_value_id || undefined, value_name: vehicle.brand });
  const knownModel = [...known];
  if (vehicle.model) knownModel.push({ id: "MODEL", value_id: vehicle.model_value_id || undefined, value_name: vehicle.model });
  const knownYear = [...knownModel];
  if (vehicle.vehicle_year) knownYear.push({ id: "VEHICLE_YEAR", value_id: vehicle.year_value_id || undefined, value_name: String(vehicle.vehicle_year) });

  return (
    <div className="grid gap-4 md:col-span-2 md:grid-cols-4">
      <Picker
        label="Marca" attributeId="BRAND" known={[]} categoryId={vehicle.ml_category_id}
        valueName={vehicle.brand || ""}
        onPick={(o, typed) => patch({
          brand: o?.name ?? typed, brand_value_id: o?.id ?? null,
          model: "", model_value_id: null, vehicle_year: null, year_value_id: null, trim: "", trim_value_id: null,
        })}
      />
      <Picker
        label="Modelo" attributeId="MODEL" known={known} categoryId={vehicle.ml_category_id}
        disabled={!vehicle.brand} valueName={vehicle.model || ""}
        onPick={(o, typed) => patch({
          model: o?.name ?? typed, model_value_id: o?.id ?? null,
          vehicle_year: null, year_value_id: null, trim: "", trim_value_id: null,
        })}
      />
      <Picker
        label="Año" attributeId="VEHICLE_YEAR" known={knownModel} categoryId={vehicle.ml_category_id}
        disabled={!vehicle.model} valueName={vehicle.vehicle_year ? String(vehicle.vehicle_year) : ""}
        onPick={(o, typed) => {
          const name = o?.name ?? typed;
          const year = Number(String(name).replace(/\D/g, "")) || null;
          patch({ vehicle_year: year, year_value_id: o?.id ?? null, trim: "", trim_value_id: null });
        }}
      />
      <Picker
        label="Versión / TRIM" attributeId="TRIM" known={knownYear} categoryId={vehicle.ml_category_id}
        disabled={!vehicle.vehicle_year} valueName={vehicle.trim || ""}
        onPick={async (o, typed) => {
          const trim = o?.name ?? typed;
          patch({ trim, trim_value_id: o?.id ?? null });
          if (!o) return;
          try {
            const data = await callFn("mercadolibre-vehicle-options", {
              attributeId: "SPECS",
              categoryId: vehicle.ml_category_id || undefined,
              knownAttributes: [...knownYear, { id: "TRIM", value_id: o.id || undefined, value_name: trim }],
            });
            const specs: Record<string, string> = data?.specs || {};
            const changes: Record<string, any> = {};
            for (const [attr, value] of Object.entries(specs)) {
              const field = SPEC_MAP[attr];
              if (!field || vehicle[field]) continue;
              changes[field] = field === "doors" || field === "passengers"
                ? Number(String(value).replace(/\D/g, "")) || null
                : value;
            }
            if (Object.keys(changes).length) patch(changes);
          } catch { /* la ficha se completa a mano */ }
        }}
      />
      <p className="text-xs text-muted-foreground md:col-span-4">
        Los valores vienen del catálogo oficial de Mercado Libre: marca → modelo → año → versión.
        Si cambiás un paso, se limpian los siguientes.
        <Button variant="link" size="sm" className="h-auto px-1 py-0"
          onClick={() => patch({ brand: "", brand_value_id: null, model: "", model_value_id: null, vehicle_year: null, year_value_id: null, trim: "", trim_value_id: null })}>
          <RefreshCw className="mr-1 h-3 w-3" />Limpiar
        </Button>
      </p>
    </div>
  );
}
