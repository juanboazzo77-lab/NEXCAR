import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Loader2, Sparkles, Undo2 } from "lucide-react";
import { callFn } from "@/lib/publisher";

type Tone = "default" | "shorter" | "salesy" | "formal";

const TONES: { id: Tone; label: string }[] = [
  { id: "default", label: "Regenerar" },
  { id: "shorter", label: "Más corto" },
  { id: "salesy", label: "Más vendedor" },
  { id: "formal", label: "Más formal" },
];

/** Editor de textos para redes con generación por IA y verificación contra la ficha. */
export default function SocialCopyEditor({
  vehicle, patch,
}: { vehicle: any; patch: (changes: Record<string, any>) => void }) {
  const [loading, setLoading] = useState<Tone | null>(null);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [facts, setFacts] = useState<string[]>([]);
  const [history, setHistory] = useState<any[]>([]);

  const generate = async (tone: Tone) => {
    setLoading(tone);
    try {
      const data = await callFn("generate-social-copy", { vehicleId: vehicle.id, tone });
      setHistory((h) => [...h, {
        instagram_caption: vehicle.instagram_caption ?? "",
        facebook_message: vehicle.facebook_message ?? "",
        hashtags: vehicle.hashtags ?? [],
      }]);
      patch({
        instagram_caption: data.instagram.caption,
        hashtags: data.instagram.hashtags,
        facebook_message: data.facebook.message,
      });
      setWarnings(data.warnings || []);
      setFacts(data.factsUsed || []);
      if (data.warnings?.length) toast.warning("Revisá las advertencias antes de publicar");
      else toast.success("Textos generados");
    } catch (e) { toast.error((e as Error).message); }
    setLoading(null);
  };

  const undo = () => {
    const prev = history[history.length - 1];
    if (!prev) return;
    setHistory((h) => h.slice(0, -1));
    patch(prev);
    setWarnings([]);
  };

  const caption = vehicle.instagram_caption ?? "";
  const message = vehicle.facebook_message ?? "";

  return (
    <Card><CardContent className="grid gap-4 pt-6">
      <div className="flex flex-wrap gap-2">
        {TONES.map((t) => (
          <Button key={t.id} variant={t.id === "default" ? "default" : "outline"} size="sm"
            disabled={!!loading} onClick={() => generate(t.id)}>
            {loading === t.id ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
            {t.id === "default" && !vehicle.instagram_caption ? "Generar con IA" : t.label}
          </Button>
        ))}
        <Button variant="ghost" size="sm" disabled={!history.length} onClick={undo}>
          <Undo2 className="mr-2 h-4 w-4" />Deshacer
        </Button>
      </div>

      {!!warnings.length && (
        <div className="rounded-lg border border-amber-500/40 bg-amber-500/5 p-3 text-sm">
          <p className="font-medium text-amber-600">Verificación contra la ficha</p>
          {warnings.map((w) => <p key={w} className="text-amber-600">· {w}</p>)}
        </div>
      )}
      {!!facts.length && (
        <p className="text-xs text-muted-foreground">Datos usados: {facts.join(" · ")}</p>
      )}

      <div className="space-y-1">
        <div className="flex items-center justify-between">
          <Label>Texto para Instagram</Label>
          <span className={`text-xs ${caption.length > 2200 ? "text-destructive" : "text-muted-foreground"}`}>
            {caption.length}/2200
          </span>
        </div>
        <Textarea rows={8} value={caption} onChange={(e) => patch({ instagram_caption: e.target.value })} />
      </div>

      <div className="space-y-1">
        <Label>Hashtags (separados por espacio)</Label>
        <Input value={(vehicle.hashtags || []).join(" ")}
          onChange={(e) => patch({ hashtags: e.target.value.split(/\s+/).filter(Boolean) })} />
      </div>

      <div className="space-y-1">
        <div className="flex items-center justify-between">
          <Label>Texto para Facebook</Label>
          <span className={`text-xs ${message.length > 5000 ? "text-destructive" : "text-muted-foreground"}`}>
            {message.length}/5000
          </span>
        </div>
        <Textarea rows={8} value={message} onChange={(e) => patch({ facebook_message: e.target.value })} />
      </div>

      <p className="text-xs text-muted-foreground">
        La IA sólo usa los datos cargados en la ficha. Nunca se envían patente, VIN ni la dirección exacta.
        Los textos no se publican solos: revisalos y confirmá antes de publicar.
      </p>
    </CardContent></Card>
  );
}
