import { Link } from "react-router-dom";
import { Check, Lock, Sparkles } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { usePlan } from "@/hooks/usePlan";
import { FEATURE_LABELS, FeatureKey, fmtLimit } from "@/lib/plans";

const ROWS: FeatureKey[] = ["financiero", "cotizador", "stats", "pdfs", "turnos", "ia_ventas", "ia_documentos", "boleto", "vendedor", "duenio", "proveedor"];

export default function PlanUsageCard() {
  const { plan, planName, usage, can } = usePlan();
  const incluidas = ROWS.filter((f) => plan.features[f]);
  const bloqueadas = ROWS.filter((f) => !plan.features[f]);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-primary" /> Plan actual: <Badge>{planName.toUpperCase()}</Badge>
          </CardTitle>
          <Button size="sm" variant="outline" asChild><Link to="/planes">Mejorar plan</Link></Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-2 text-center">
          <Counter label="Marketplace" used={usage?.marketplace_used ?? 0} max={usage ? usage.max_marketplace : plan.max_marketplace} />
          <Counter label="ORO" used={usage?.gold_used ?? 0} max={usage ? usage.max_gold : plan.max_gold} />
          <Counter label="PLATA" used={usage?.silver_used ?? 0} max={usage ? usage.max_silver : (plan.max_marketplace == null ? null : plan.max_marketplace - plan.max_gold)} />
        </div>

        <div className="grid sm:grid-cols-2 gap-3 text-sm">
          <div>
            <div className="text-xs font-semibold text-muted-foreground mb-1">Funciones disponibles</div>
            <ul className="space-y-1">
              {incluidas.map((f) => (
                <li key={f} className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-600" />{FEATURE_LABELS[f]}</li>
              ))}
              {incluidas.length === 0 && <li className="text-muted-foreground">Gestión básica de stock, ventas y catálogo.</li>}
            </ul>
          </div>
          <div>
            <div className="text-xs font-semibold text-muted-foreground mb-1">Funciones bloqueadas</div>
            <ul className="space-y-1">
              {bloqueadas.map((f) => (
                <li key={f} className="flex items-center gap-2 text-muted-foreground"><Lock className="w-4 h-4" />{FEATURE_LABELS[f]}</li>
              ))}
              {bloqueadas.length === 0 && <li className="text-muted-foreground">Ninguna: tenés acceso completo.</li>}
            </ul>
          </div>
        </div>

        {!can("marketplace_priority") && (
          <p className="text-xs text-muted-foreground">
            Tu plan no incluye publicaciones ORO: tus vehículos aparecen normalmente en el Marketplace, sin prioridad.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function Counter({ label, used, max }: { label: string; used: number; max: number | null | undefined }) {
  const full = max != null && used >= max;
  return (
    <div className="rounded-md border p-3">
      <div className="text-[10px] uppercase text-muted-foreground">{label}</div>
      <div className={`text-lg font-bold ${full ? "text-destructive" : ""}`}>{used} / {fmtLimit(max)}</div>
    </div>
  );
}
