import { useEffect, useState, useMemo } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CAR_CATALOG, getModelos, getVersiones } from "@/lib/car-catalog";
import { MARCAS, ANIOS } from "@/lib/supabase-helpers";
import { Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Props {
  marca: string;
  modelo: string;
  version: string;
  anio: number;
  onChange: (patch: { marca?: string; modelo?: string; version?: string; anio?: number }) => void;
}

const ADD_NEW = "__add_new__";

export function CarSelector({ marca, modelo, version, anio, onChange }: Props) {
  const [addMarca, setAddMarca] = useState(false);
  const [addModelo, setAddModelo] = useState(false);
  const [addVersion, setAddVersion] = useState(false);
  const [apiBrands, setApiBrands] = useState<string[]>([]);
  const [apiModels, setApiModels] = useState<Record<string, string[]>>({});
  const [apiTrims, setApiTrims] = useState<Record<string, string[]>>({});
  const [apiYears, setApiYears] = useState<number[]>([]);

  const names = (list: unknown): string[] =>
    Array.isArray(list) ? (list as { name: string }[]).map(i => i.name).filter(Boolean) : [];

  // Marcas (una sola vez)
  useEffect(() => {
    let active = true;
    supabase.functions.invoke("ml-vehicle-catalog").then(({ data }) => {
      if (!active || !data) return;
      setApiBrands(names(data.brands));
      setApiYears(names(data.years).map(Number).filter(Number.isFinite));
    }).catch(() => undefined);
    return () => { active = false; };
  }, []);

  // Modelos de la marca elegida
  useEffect(() => {
    if (!marca || apiModels[marca]) return;
    let active = true;
    supabase.functions.invoke(`ml-vehicle-catalog?brand=${encodeURIComponent(marca)}`).then(({ data }) => {
      if (!active || !data) return;
      setApiModels(prev => ({ ...prev, [marca]: names(data.models) }));
    }).catch(() => undefined);
    return () => { active = false; };
  }, [marca, apiModels]);

  // Versiones del modelo elegido
  useEffect(() => {
    const key = `${marca}|${modelo}`;
    if (!marca || !modelo || apiTrims[key]) return;
    let active = true;
    supabase.functions.invoke(`ml-vehicle-catalog?brand=${encodeURIComponent(marca)}&model=${encodeURIComponent(modelo)}`).then(({ data }) => {
      if (!active || !data) return;
      setApiTrims(prev => ({ ...prev, [key]: names(data.trims) }));
    }).catch(() => undefined);
    return () => { active = false; };
  }, [marca, modelo, apiTrims]);

  const marcas = useMemo(() => {
    const fromCatalog = Object.keys(CAR_CATALOG);
    const merged = Array.from(new Set([...apiBrands, ...fromCatalog, ...MARCAS.filter(m => m !== "Otra")])).sort();
    return merged;
  }, [apiBrands]);

  const modelos = useMemo(
    () => Array.from(new Set([...(apiModels[marca] || []), ...getModelos(marca)])).sort(),
    [apiModels, marca],
  );
  const versiones = useMemo(
    () => Array.from(new Set([...(apiTrims[`${marca}|${modelo}`] || []), ...getVersiones(marca, modelo)])).sort(),
    [apiTrims, marca, modelo],
  );
  const years = useMemo(() => Array.from(new Set([...apiYears, ...ANIOS])).sort((a, b) => b - a), [apiYears]);

  const handleMarca = (v: string) => {
    if (v === ADD_NEW) { setAddMarca(true); onChange({ marca: "" }); return; }
    setAddMarca(false); setAddModelo(false); setAddVersion(false);
    onChange({ marca: v, modelo: "", version: "" });
  };
  const handleModelo = (v: string) => {
    if (v === ADD_NEW) { setAddModelo(true); onChange({ modelo: "" }); return; }
    setAddModelo(false); setAddVersion(false);
    onChange({ modelo: v, version: "" });
  };
  const handleVersion = (v: string) => {
    if (v === ADD_NEW) { setAddVersion(true); onChange({ version: "" }); return; }
    setAddVersion(false);
    onChange({ version: v });
  };

  return (
    <>
      <div>
        <Label>Marca</Label>
        {addMarca || (marca && !marcas.includes(marca)) ? (
          <div className="flex gap-1">
            <Input value={marca} onChange={e => onChange({ marca: e.target.value })} placeholder="Nueva marca" />
            <Button type="button" variant="ghost" size="sm" onClick={() => { setAddMarca(false); onChange({ marca: "" }); }}>×</Button>
          </div>
        ) : (
          <Select value={marca || ""} onValueChange={handleMarca}>
            <SelectTrigger><SelectValue placeholder="Elegí marca" /></SelectTrigger>
            <SelectContent>
              {marcas.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
              <SelectItem value={ADD_NEW}><span className="flex items-center gap-1"><Plus className="w-3 h-3" />Agregar marca</span></SelectItem>
            </SelectContent>
          </Select>
        )}
      </div>

      <div>
        <Label>Modelo</Label>
        {!marca ? (
          <Input disabled placeholder="Elegí marca primero" />
        ) : addModelo || (modelo && modelos.length > 0 && !modelos.includes(modelo)) ? (
          <div className="flex gap-1">
            <Input value={modelo} onChange={e => onChange({ modelo: e.target.value })} placeholder="Nuevo modelo" />
            <Button type="button" variant="ghost" size="sm" onClick={() => { setAddModelo(false); onChange({ modelo: "" }); }}>×</Button>
          </div>
        ) : modelos.length === 0 ? (
          <Input value={modelo} onChange={e => onChange({ modelo: e.target.value })} placeholder="Modelo" />
        ) : (
          <Select value={modelo || ""} onValueChange={handleModelo}>
            <SelectTrigger><SelectValue placeholder="Elegí modelo" /></SelectTrigger>
            <SelectContent>
              {modelos.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
              <SelectItem value={ADD_NEW}><span className="flex items-center gap-1"><Plus className="w-3 h-3" />Agregar modelo</span></SelectItem>
            </SelectContent>
          </Select>
        )}
      </div>

      <div>
        <Label>Año</Label>
        <Select value={String(anio || "")} onValueChange={v => onChange({ anio: Number(v) })}>
          <SelectTrigger><SelectValue placeholder="Año" /></SelectTrigger>
          <SelectContent>{years.map(a => <SelectItem key={a} value={String(a)}>{a}</SelectItem>)}</SelectContent>
        </Select>
      </div>

      <div>
        <Label>Versión</Label>
        {!modelo ? (
          <Input disabled placeholder="Elegí modelo primero" />
        ) : addVersion || (version && versiones.length > 0 && !versiones.includes(version)) ? (
          <div className="flex gap-1">
            <Input value={version} onChange={e => onChange({ version: e.target.value })} placeholder="Nueva versión" />
            <Button type="button" variant="ghost" size="sm" onClick={() => { setAddVersion(false); onChange({ version: "" }); }}>×</Button>
          </div>
        ) : versiones.length === 0 ? (
          <Input value={version} onChange={e => onChange({ version: e.target.value })} placeholder="Versión" />
        ) : (
          <Select value={version || ""} onValueChange={handleVersion}>
            <SelectTrigger><SelectValue placeholder="Elegí versión" /></SelectTrigger>
            <SelectContent>
              {versiones.map(v => <SelectItem key={v} value={v}>{v}</SelectItem>)}
              <SelectItem value={ADD_NEW}><span className="flex items-center gap-1"><Plus className="w-3 h-3" />Agregar versión</span></SelectItem>
            </SelectContent>
          </Select>
        )}
      </div>
    </>
  );
}
