import { Component, ReactNode } from "react";
import { Button } from "@/components/ui/button";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center gap-4 p-4">
          <p className="text-muted-foreground">Algo salió mal.</p>
          <Button onClick={() => { this.setState({ hasError: false }); window.location.reload(); }}>
            Recargar
          </Button>
        </div>
      );
    }
    return this.props.children;
  }
}
