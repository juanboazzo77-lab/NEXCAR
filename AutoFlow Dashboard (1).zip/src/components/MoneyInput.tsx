import { Input } from "@/components/ui/input";
import { forwardRef, useEffect, useState } from "react";

interface MoneyInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "value" | "onChange" | "type"> {
  value: number | string | null | undefined;
  onValueChange: (value: number) => void;
}

const formatNumber = (n: number) =>
  new Intl.NumberFormat("es-AR", { maximumFractionDigits: 0 }).format(n);

export const MoneyInput = forwardRef<HTMLInputElement, MoneyInputProps>(
  ({ value, onValueChange, ...props }, ref) => {
    const numeric = Number(value ?? 0) || 0;
    const [text, setText] = useState<string>(numeric ? formatNumber(numeric) : "");

    useEffect(() => {
      // Sync when external value changes and differs from current parsed text
      const parsed = Number(text.replace(/\D/g, "")) || 0;
      if (parsed !== numeric) {
        setText(numeric ? formatNumber(numeric) : "");
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [numeric]);

    return (
      <Input
        ref={ref}
        inputMode="numeric"
        {...props}
        value={text}
        onChange={(e) => {
          const raw = e.target.value.replace(/\D/g, "");
          if (raw === "") {
            setText("");
            onValueChange(0);
            return;
          }
          const n = Number(raw);
          setText(formatNumber(n));
          onValueChange(n);
        }}
        onFocus={(e) => {
          if (text === "0") setText("");
          props.onFocus?.(e);
        }}
      />
    );
  }
);
MoneyInput.displayName = "MoneyInput";
