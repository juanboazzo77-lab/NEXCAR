import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Crown, Globe, Image as ImageIcon, Star, Trash2, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { useQueryClient } from "@tanstack/react-query";
import { usePlan } from "@/hooks/usePlan";
import { planErrorMessage } from "@/lib/plan-errors";

export function StockCatalogoActions({ car }: { car: any }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [photos, setPhotos] = useState<any[]>([]);
  const [busy, setBusy] = useState(false);
  const { can, reloadUsage } = usePlan();
  const mostrar = !!car.mostrar_publico;
  const esOro = car.marketplace_tier === "gold";

  const loadPhotos = async () => {
    const { data } = await supabase.from("car_photos").select("*").eq("car_id", car.id)
      .order("es_portada", { ascending: false }).order("orden");
    setPhotos(data || []);
  };

  useEffect(() => { if (open) loadPhotos(); }, [open]);

  const toggleCatalogo = async () => {
    setBusy(true);
    const { error } = await supabase.from("cars").update({ mostrar_publico: !mostrar }).eq("id", car.id);
    setBusy(false);
    if (error) { toast({ title: "No se pudo publicar", description: planErrorMessage(error)!, variant: "destructive" }); return; }
    toast({ title: !mostrar ? "Publicado en catálogo" : "Quitado del catálogo" });
    qc.invalidateQueries({ queryKey: ["cars"] });
    reloadUsage();
  };

  const toggleOro = async () => {
    setBusy(true);
    const { error } = await supabase.from("cars")
      .update({ marketplace_tier: esOro ? "silver" : "gold" } as any).eq("id", car.id);
    setBusy(false);
    if (error) { toast({ title: "Publicación ORO", description: planErrorMessage(error)!, variant: "destructive" }); return; }
    toast({ title: esOro ? "Quitada la categoría ORO" : "Vehículo destacado como ORO" });
    qc.invalidateQueries({ queryKey: ["cars"] });
    reloadUsage();
  };

  const uploadPhotos = async (files: FileList) => {
    if (!user) return;
    setBusy(true);
    const ordenBase = photos.length;
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      if (f.size > 10 * 1024 * 1024) { toast({ title: "Foto muy grande", description: `${f.name} supera 10MB` }); continue; }
      const path = `${user.id}/${car.id}/${Date.now()}-${i}-${f.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`;
      const { error: upErr } = await supabase.storage.from("car-photos").upload(path, f);
      if (upErr) { toast({ title: "Error subiendo", description: upErr.message, variant: "destructive" }); continue; }
      const { data: pub } = supabase.storage.from("car-photos").getPublicUrl(path);
      await supabase.from("car_photos").insert({
        user_id: user.id, car_id: car.id, url: pub.publicUrl, storage_path: path,
        orden: ordenBase + i, es_portada: photos.length === 0 && i === 0,
      });
    }
    await loadPhotos();
    setBusy(false);
  };

  const setPortada = async (pid: string) => {
    await supabase.from("car_photos").update({ es_portada: false }).eq("car_id", car.id);
    await supabase.from("car_photos").update({ es_portada: true }).eq("id", pid);
    await loadPhotos();
  };

  const delPhoto = async (p: any) => {
    if (p.storage_path) await supabase.storage.from("car-photos").remove([p.storage_path]);
    await supabase.from("car_photos").delete().eq("id", p.id);
    await loadPhotos();
  };

  return (
    <>
      <Button
        variant={mostrar ? "default" : "outline"}
        size="sm"
        onClick={toggleCatalogo}
        disabled={busy}
        title={mostrar ? "Quitar del catálogo público" : "Publicar en catálogo público"}
      >
        <Globe className="w-3.5 h-3.5 mr-1" />
        {mostrar ? "En catálogo" : "Catálogo"}
      </Button>
      {can("marketplace_priority") && (
        <Button
          variant={esOro ? "default" : "outline"}
          size="sm"
          onClick={toggleOro}
          disabled={busy}
          className={esOro ? "bg-yellow-500 hover:bg-yellow-500/90 text-yellow-950" : undefined}
          title={esOro ? "Quitar prioridad ORO" : "Destacar como publicación ORO"}
        >
          <Crown className="w-3.5 h-3.5 mr-1" />
          {esOro ? "ORO" : "Destacar"}
        </Button>
      )}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button variant="ghost" size="sm" title="Fotos">
            <ImageIcon className="w-3.5 h-3.5" />
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Fotos · {car.marca} {car.modelo} {car.patente}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <label className="flex items-center justify-center gap-2 border-2 border-dashed rounded-lg p-6 cursor-pointer hover:bg-muted/50 text-sm">
              <Upload className="w-4 h-4" />
              <span>{busy ? "Subiendo..." : "Subir fotos (JPG/PNG, máx 10MB)"}</span>
              <input
                type="file" accept="image/*" multiple className="hidden"
                onChange={e => e.target.files && uploadPhotos(e.target.files)}
              />
            </label>
            {photos.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">Sin fotos cargadas.</p>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {photos.map(p => (
                  <div key={p.id} className="relative group rounded-lg overflow-hidden border">
                    <img src={p.url} alt="" className="w-full h-32 object-cover" />
                    {p.es_portada && (
                      <span className="absolute top-1 left-1 bg-yellow-500 text-white text-[10px] px-1.5 py-0.5 rounded">
                        Portada
                      </span>
                    )}
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center gap-1 transition">
                      {!p.es_portada && (
                        <Button size="sm" variant="secondary" onClick={() => setPortada(p.id)}>
                          <Star className="w-3.5 h-3.5" />
                        </Button>
                      )}
                      <Button size="sm" variant="destructive" onClick={() => delPhoto(p)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <p className="text-xs text-muted-foreground">
              Las fotos se usan tanto en stock como en el catálogo público.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
