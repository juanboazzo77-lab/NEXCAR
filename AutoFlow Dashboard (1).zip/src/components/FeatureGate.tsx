import { Link } from "react-router-dom";
import { Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { usePlan } from "@/hooks/usePlan";
import { FEATURE_LABELS, FeatureKey } from "@/lib/plans";

export function PlanLockedNotice({ feature }: { feature: FeatureKey }) {
  const { planName } = usePlan();
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center text-center gap-3 p-6">
      <div className="w-14 h-14 rounded-full bg-muted flex items-center justify-center">
        <Lock className="w-6 h-6 text-muted-foreground" />
      </div>
      <h2 className="text-xl font-bold">{FEATURE_LABELS[feature]} no disponible</h2>
      <p className="text-sm text-muted-foreground max-w-md">
        Esta función no está incluida en tu Plan {planName}. Actualizá tu plan para desbloquearla.
      </p>
      <Button asChild><Link to="/planes">Ver planes</Link></Button>
    </div>
  );
}

/** Envuelve un módulo existente: si el plan no lo incluye, muestra el aviso de upgrade. */
export default function FeatureGate({ feature, children }: { feature: FeatureKey; children: React.ReactNode }) {
  const { can, loading } = usePlan();
  if (loading) return <div className="p-6 text-muted-foreground">Cargando...</div>;
  if (!can(feature)) return <PlanLockedNotice feature={feature} />;
  return <>{children}</>;
}
