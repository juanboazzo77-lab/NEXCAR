import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronLeft, ChevronRight } from "lucide-react";

export { usePagination } from "@/components/public/Pagination";

const OPTIONS = [6, 9, 12, 24, 48, 96];

type Props = {
  page: number;
  totalPages: number;
  perPage: number;
  total: number;
  onPage: (p: number) => void;
  onPerPage: (n: number) => void;
};

export default function AdminPagination({ page, totalPages, perPage, total, onPage, onPerPage }: Props) {
  if (total === 0) return null;
  const from = (page - 1) * perPage + 1;
  const to = Math.min(total, page * perPage);

  const nums: (number | "…")[] = [];
  for (let i = 1; i <= totalPages; i++) {
    if (i === 1 || i === totalPages || Math.abs(i - page) <= 1) nums.push(i);
    else if (nums[nums.length - 1] !== "…") nums.push("…");
  }

  return (
    <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
      <div className="text-xs text-muted-foreground">Mostrando {from}–{to} de {total}</div>
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          Ver
          <Select value={String(perPage)} onValueChange={v => onPerPage(Number(v))}>
            <SelectTrigger className="h-8 w-[72px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              {OPTIONS.map(n => <SelectItem key={n} value={String(n)}>{n}</SelectItem>)}
            </SelectContent>
          </Select>
          por página
        </div>
        {totalPages > 1 && (
          <div className="flex items-center gap-1">
            <Button variant="outline" size="sm" disabled={page === 1} onClick={() => onPage(page - 1)}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            {nums.map((n, i) =>
              n === "…" ? (
                <span key={`e${i}`} className="px-1 text-muted-foreground text-xs">…</span>
              ) : (
                <Button
                  key={n}
                  variant={n === page ? "default" : "outline"}
                  size="sm"
                  className="min-w-9"
                  onClick={() => onPage(n)}
                >
                  {n}
                </Button>
              )
            )}
            <Button variant="outline" size="sm" disabled={page === totalPages} onClick={() => onPage(page + 1)}>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
