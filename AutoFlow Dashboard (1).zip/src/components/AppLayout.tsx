import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useIsCeo } from "@/hooks/useIsCeo";
import { usePendingTasaciones } from "@/hooks/usePendingTasaciones";
import { useAgency } from "@/hooks/useAgency";
import { usePlan } from "@/hooks/usePlan";
import type { FeatureKey } from "@/lib/plans";
import { Link, useLocation } from "react-router-dom";
import { Car, DollarSign, BarChart3, FileText, Receipt, Settings, LogOut, Menu, X, Wallet, CalendarClock, CheckCircle2, Users, Megaphone, FileSignature, Calculator, CalendarDays, PieChart, Inbox, Plug, BookText, TrendingUp, Sparkles, Crown, ChevronDown, Globe, RefreshCw, Bell, HelpCircle, Radio, CalendarCheck, Building2, PauseCircle, Lock, Handshake } from "lucide-react";
import { cn } from "@/lib/utils";
import { setCompanyBranding } from "@/lib/pdf-generator";

const PRIMARY = [
  { to: "/", label: "Stock", icon: Car },
  { to: "/vehiculos", label: "Vehículos", icon: Megaphone },
  { to: "/asistente-publicacion", label: "Asistente IA", icon: Sparkles },
  { to: "/publicador-pro", label: "Publicador", icon: Radio },
  { to: "/gastos", label: "Gastos", icon: Receipt },
  { to: "/ventas", label: "Ventas", icon: DollarSign },
  { to: "/cuotas", label: "Cuotas", icon: CalendarClock },
  { to: "/calendario", label: "Calendario", icon: CalendarDays },
  { to: "/financiero", label: "Financiero", icon: PieChart },
  { to: "/cotizador", label: "Cotizador", icon: Calculator },
  { to: "/pdfs", label: "PDFs", icon: FileSignature },
  { to: "/turnos", label: "Turnos", icon: CalendarCheck },
  { to: "/documentacion", label: "Docs", icon: FileText },
  { to: "/tasaciones", label: "Tasaciones", icon: RefreshCw },
  { to: "/canales", label: "Conexiones", icon: Plug },
];

const SECONDARY = [
  { to: "/stock-intelligence", label: "Inteligencia stock", icon: TrendingUp },
  { to: "/red-b2b", label: "Red B2B", icon: Handshake },
  { to: "/crm", label: "CRM", icon: Users },
  { to: "/caja", label: "Caja", icon: Wallet },
  { to: "/vendidos", label: "Vendidos", icon: CheckCircle2 },
  { to: "/estadisticas", label: "Stats", icon: BarChart3 },
  { to: "/sitio-publico", label: "Sitio público", icon: Globe },
  { to: "/mi-agencia", label: "Mi agencia", icon: Building2 },
  { to: "/planes", label: "Planes", icon: Sparkles },

  { to: "/alertas", label: "Alertas clientes", icon: Bell },

  { to: "/faq-admin", label: "FAQ", icon: HelpCircle },
  { to: "/herramientas", label: "Tools", icon: Settings },
];


const FEATURE_BY_ROUTE: Record<string, FeatureKey> = {
  "/financiero": "financiero",
  "/cotizador": "cotizador",
  "/pdfs": "pdfs",
  "/turnos": "turnos",
  "/estadisticas": "stats",
  "/stock-intelligence": "stock_intelligence",
  "/red-b2b": "b2b",
};

const MAIN_AGENCY_SLUG = "grupo-boazzo";
const MAIN_ONLY = ["/canales", "/crm", "/publicador-pro", "/vehiculos"];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const { signOut, user } = useAuth();
  const { isCeo } = useIsCeo();
  const { agency, loading: agencyLoading } = useAgency();

  // Cada agencia imprime sus PDFs con su propia marca y datos de contacto.
  useEffect(() => {
    if (!agency) return;
    setCompanyBranding({
      name: agency.name,
      address: [agency.direccion, agency.ciudad, agency.provincia].filter(Boolean).join(", "),
      phone: agency.telefono || agency.whatsapp || "",
      email: agency.email || "",
      web: agency.website_url || "",
      logo_url: agency.logo_url,
    });
  }, [agency?.id, agency?.name, agency?.logo_url]);
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const pendingTasaciones = usePendingTasaciones();
  const { can } = usePlan();
  const isMain = !agency || agency.slug === MAIN_AGENCY_SLUG || isCeo;
  const primary = isMain ? PRIMARY : PRIMARY.filter(n => !MAIN_ONLY.includes(n.to));
  const secondaryBase = isMain ? SECONDARY : SECONDARY.filter(n => !MAIN_ONLY.includes(n.to));
  const secondary = isCeo ? [...secondaryBase, { to: "/ceo", label: "Panel CEO", icon: Crown }] : secondaryBase;
  const [moreOpen, setMoreOpen] = useState(() => secondary.some(n => n.to === location.pathname));

  const renderLink = (n: { to: string; label: string; icon: any }) => (
    <Link
      key={n.to}
      to={n.to}
      onClick={() => setOpen(false)}
      className={cn(
        "flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors",
        location.pathname === n.to
          ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
          : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
      )}
    >
      <n.icon className="w-4 h-4" />
      <span className="flex-1">{n.label}</span>
      {FEATURE_BY_ROUTE[n.to] && !can(FEATURE_BY_ROUTE[n.to]) && (
        <Lock className="w-3.5 h-3.5 text-sidebar-muted" />
      )}
      {n.to === "/tasaciones" && pendingTasaciones > 0 && (
        <span className="min-w-5 h-5 px-1.5 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold flex items-center justify-center">
          {pendingTasaciones}
        </span>
      )}
    </Link>
  );


  const paused = !!agency && agency.status !== "active" && !isCeo;

  if (paused && !agencyLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-muted/30">
        <div className="max-w-md w-full bg-card border rounded-xl p-8 text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center mx-auto">
            <PauseCircle className="w-6 h-6 text-destructive" />
          </div>
          <h1 className="text-xl font-bold">Cuenta pausada</h1>
          <p className="text-sm text-muted-foreground">
            La cuenta de <strong>{agency?.name}</strong> está pausada por falta de pago. Toda tu información
            (stock, ventas, gastos y clientes) se conserva intacta y vuelve a estar disponible apenas se reactive.
          </p>
          <p className="text-sm text-muted-foreground">Comunicate con el administrador del sistema para reactivarla.</p>
          <button onClick={signOut} className="text-sm underline text-muted-foreground">Cerrar sesión</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex">
      {/* Mobile overlay */}
      {open && <div className="fixed inset-0 bg-foreground/20 z-40 lg:hidden" onClick={() => setOpen(false)} />}

      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 z-50 w-56 bg-sidebar flex flex-col transition-transform lg:translate-x-0 lg:static",
        open ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex items-center gap-2 p-4 border-b border-sidebar-border">
          <div className="w-8 h-8 rounded-md bg-sidebar-primary flex items-center justify-center">
            <Car className="w-4 h-4 text-sidebar-primary-foreground" />
          </div>
          <span className="font-semibold text-sidebar-accent-foreground">{agency?.name || "Mi agencia"}</span>
        </div>
        <nav className="flex-1 p-2 space-y-0.5 overflow-y-auto">
          {primary.map(renderLink)}
          <button
            type="button"
            onClick={() => setMoreOpen(o => !o)}
            className="mt-2 flex items-center justify-between w-full px-3 py-2 rounded-md text-xs uppercase tracking-wide text-sidebar-muted hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors"
          >
            <span>Todo lo demás</span>
            <ChevronDown className={cn("w-4 h-4 transition-transform", moreOpen && "rotate-180")} />
          </button>
          {moreOpen && (
            <div className="space-y-0.5 pt-1">
              {secondary.map(renderLink)}
            </div>
          )}
        </nav>
        <div className="p-2 border-t border-sidebar-border">
          <div className="px-3 py-1 text-xs text-sidebar-muted truncate">{user?.email}</div>
          <button
            onClick={signOut}
            className="flex items-center gap-3 px-3 py-2 rounded-md text-sm text-sidebar-foreground hover:bg-sidebar-accent w-full"
          >
            <LogOut className="w-4 h-4" />
            Cerrar sesión
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-14 border-b flex items-center px-4 gap-4 bg-card lg:hidden">
          <button onClick={() => setOpen(!open)}>
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <span className="font-semibold text-sm">{agency?.name || "Mi agencia"}</span>
        </header>
        <main className="flex-1 p-4 lg:p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
