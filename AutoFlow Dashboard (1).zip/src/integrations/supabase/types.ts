export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      agencies: {
        Row: {
          ciudad: string | null
          created_at: string
          descripcion: string | null
          direccion: string | null
          email: string | null
          facebook_url: string | null
          fecha_alta: string
          horarios: string | null
          id: string
          instagram_url: string | null
          lat: number | null
          lng: number | null
          logo_url: string | null
          marketplace_visible: boolean
          name: string
          notes: string | null
          owner_user_id: string | null
          plan: string | null
          provincia: string | null
          slug: string | null
          status: string
          telefono: string | null
          tiktok_url: string | null
          updated_at: string
          website_url: string | null
          whatsapp: string | null
        }
        Insert: {
          ciudad?: string | null
          created_at?: string
          descripcion?: string | null
          direccion?: string | null
          email?: string | null
          facebook_url?: string | null
          fecha_alta?: string
          horarios?: string | null
          id?: string
          instagram_url?: string | null
          lat?: number | null
          lng?: number | null
          logo_url?: string | null
          marketplace_visible?: boolean
          name: string
          notes?: string | null
          owner_user_id?: string | null
          plan?: string | null
          provincia?: string | null
          slug?: string | null
          status?: string
          telefono?: string | null
          tiktok_url?: string | null
          updated_at?: string
          website_url?: string | null
          whatsapp?: string | null
        }
        Update: {
          ciudad?: string | null
          created_at?: string
          descripcion?: string | null
          direccion?: string | null
          email?: string | null
          facebook_url?: string | null
          fecha_alta?: string
          horarios?: string | null
          id?: string
          instagram_url?: string | null
          lat?: number | null
          lng?: number | null
          logo_url?: string | null
          marketplace_visible?: boolean
          name?: string
          notes?: string | null
          owner_user_id?: string | null
          plan?: string | null
          provincia?: string | null
          slug?: string | null
          status?: string
          telefono?: string | null
          tiktok_url?: string | null
          updated_at?: string
          website_url?: string | null
          whatsapp?: string | null
        }
        Relationships: []
      }
      ai_generated_descriptions: {
        Row: {
          agency_id: string | null
          car_id: string
          created_at: string
          fb_caption: string | null
          hashtags: Json | null
          id: string
          ig_caption: string | null
          ml_desc: string | null
          titulo: string | null
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          car_id: string
          created_at?: string
          fb_caption?: string | null
          hashtags?: Json | null
          id?: string
          ig_caption?: string | null
          ml_desc?: string | null
          titulo?: string | null
          user_id: string
        }
        Update: {
          agency_id?: string | null
          car_id?: string
          created_at?: string
          fb_caption?: string | null
          hashtags?: Json | null
          id?: string
          ig_caption?: string | null
          ml_desc?: string | null
          titulo?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_generated_descriptions_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ai_generated_descriptions_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      b2b_offers: {
        Row: {
          agency_id: string
          car_id: string | null
          contacto_telefono: string | null
          created_at: string
          id: string
          mensaje: string | null
          moneda: string
          precio: number | null
          request_id: string
          user_id: string
        }
        Insert: {
          agency_id: string
          car_id?: string | null
          contacto_telefono?: string | null
          created_at?: string
          id?: string
          mensaje?: string | null
          moneda?: string
          precio?: number | null
          request_id: string
          user_id: string
        }
        Update: {
          agency_id?: string
          car_id?: string | null
          contacto_telefono?: string | null
          created_at?: string
          id?: string
          mensaje?: string | null
          moneda?: string
          precio?: number | null
          request_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "b2b_offers_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "b2b_offers_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "b2b_offers_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "b2b_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      b2b_requests: {
        Row: {
          agency_id: string
          anio_desde: number | null
          anio_hasta: number | null
          contacto_nombre: string | null
          contacto_telefono: string | null
          created_at: string
          detalle: string | null
          estado: string
          id: string
          km_max: number | null
          marca: string | null
          modelo: string | null
          moneda: string
          presupuesto_max: number | null
          updated_at: string
          user_id: string
          version: string | null
        }
        Insert: {
          agency_id: string
          anio_desde?: number | null
          anio_hasta?: number | null
          contacto_nombre?: string | null
          contacto_telefono?: string | null
          created_at?: string
          detalle?: string | null
          estado?: string
          id?: string
          km_max?: number | null
          marca?: string | null
          modelo?: string | null
          moneda?: string
          presupuesto_max?: number | null
          updated_at?: string
          user_id: string
          version?: string | null
        }
        Update: {
          agency_id?: string
          anio_desde?: number | null
          anio_hasta?: number | null
          contacto_nombre?: string | null
          contacto_telefono?: string | null
          created_at?: string
          detalle?: string | null
          estado?: string
          id?: string
          km_max?: number | null
          marca?: string | null
          modelo?: string | null
          moneda?: string
          presupuesto_max?: number | null
          updated_at?: string
          user_id?: string
          version?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "b2b_requests_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
        ]
      }
      calendar_events: {
        Row: {
          agency_id: string | null
          car_id: string | null
          created_at: string
          descripcion: string | null
          email_destino: string | null
          fecha: string
          hora: string | null
          id: string
          recordatorio_email: boolean
          recordatorio_enviado_at: string | null
          sale_id: string | null
          tipo: string
          titulo: string
          updated_at: string
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          car_id?: string | null
          created_at?: string
          descripcion?: string | null
          email_destino?: string | null
          fecha: string
          hora?: string | null
          id?: string
          recordatorio_email?: boolean
          recordatorio_enviado_at?: string | null
          sale_id?: string | null
          tipo?: string
          titulo: string
          updated_at?: string
          user_id: string
        }
        Update: {
          agency_id?: string | null
          car_id?: string | null
          created_at?: string
          descripcion?: string | null
          email_destino?: string | null
          fecha?: string
          hora?: string | null
          id?: string
          recordatorio_email?: boolean
          recordatorio_enviado_at?: string | null
          sale_id?: string | null
          tipo?: string
          titulo?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "calendar_events_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "calendar_events_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "calendar_events_sale_id_fkey"
            columns: ["sale_id"]
            isOneToOne: false
            referencedRelation: "sales"
            referencedColumns: ["id"]
          },
        ]
      }
      car_documentation: {
        Row: {
          agency_id: string | null
          car_id: string
          cat: string | null
          cedula: string | null
          created_at: string
          dominio: string | null
          form_04: string | null
          form_08: string | null
          gnc: string | null
          id: string
          manual: string | null
          multas: string | null
          segunda_llave: string | null
          ubicacion: string | null
          updated_at: string
          verificacion: string | null
          vtv: string | null
        }
        Insert: {
          agency_id?: string | null
          car_id: string
          cat?: string | null
          cedula?: string | null
          created_at?: string
          dominio?: string | null
          form_04?: string | null
          form_08?: string | null
          gnc?: string | null
          id?: string
          manual?: string | null
          multas?: string | null
          segunda_llave?: string | null
          ubicacion?: string | null
          updated_at?: string
          verificacion?: string | null
          vtv?: string | null
        }
        Update: {
          agency_id?: string | null
          car_id?: string
          cat?: string | null
          cedula?: string | null
          created_at?: string
          dominio?: string | null
          form_04?: string | null
          form_08?: string | null
          gnc?: string | null
          id?: string
          manual?: string | null
          multas?: string | null
          segunda_llave?: string | null
          ubicacion?: string | null
          updated_at?: string
          verificacion?: string | null
          vtv?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "car_documentation_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "car_documentation_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: true
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      car_events: {
        Row: {
          agency_id: string | null
          car_id: string
          created_at: string
          event_type: string
          id: string
          source: string | null
          visitor_id: string | null
        }
        Insert: {
          agency_id?: string | null
          car_id: string
          created_at?: string
          event_type: string
          id?: string
          source?: string | null
          visitor_id?: string | null
        }
        Update: {
          agency_id?: string | null
          car_id?: string
          created_at?: string
          event_type?: string
          id?: string
          source?: string | null
          visitor_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "car_events_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "car_events_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      car_expenses: {
        Row: {
          agency_id: string | null
          car_id: string | null
          categoria: string
          concepto: string | null
          created_at: string
          detalle: string | null
          fecha: string
          id: string
          monto: number
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          car_id?: string | null
          categoria: string
          concepto?: string | null
          created_at?: string
          detalle?: string | null
          fecha?: string
          id?: string
          monto?: number
          user_id: string
        }
        Update: {
          agency_id?: string | null
          car_id?: string | null
          categoria?: string
          concepto?: string | null
          created_at?: string
          detalle?: string | null
          fecha?: string
          id?: string
          monto?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "car_expenses_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "car_expenses_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      car_photos: {
        Row: {
          agency_id: string | null
          car_id: string
          created_at: string
          es_portada: boolean
          id: string
          orden: number
          storage_path: string | null
          url: string
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          car_id: string
          created_at?: string
          es_portada?: boolean
          id?: string
          orden?: number
          storage_path?: string | null
          url: string
          user_id: string
        }
        Update: {
          agency_id?: string | null
          car_id?: string
          created_at?: string
          es_portada?: boolean
          id?: string
          orden?: number
          storage_path?: string | null
          url?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "car_photos_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "car_photos_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      car_publications: {
        Row: {
          agency_id: string | null
          car_id: string
          created_at: string
          descripcion: string | null
          error_msg: string | null
          external_id: string | null
          external_url: string | null
          id: string
          platform: string
          published_at: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          car_id: string
          created_at?: string
          descripcion?: string | null
          error_msg?: string | null
          external_id?: string | null
          external_url?: string | null
          id?: string
          platform: string
          published_at?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          agency_id?: string | null
          car_id?: string
          created_at?: string
          descripcion?: string | null
          error_msg?: string | null
          external_id?: string | null
          external_url?: string | null
          id?: string
          platform?: string
          published_at?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "car_publications_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "car_publications_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      cars: {
        Row: {
          acepta_permuta: boolean
          agency_id: string | null
          anio: number
          anticipo_minimo: number | null
          b2b_disponible: boolean
          b2b_precio: number | null
          carroceria: string | null
          cilindrada: string | null
          cilindros: number | null
          ciudad: string | null
          color: string | null
          color_interior: string | null
          combustible: string | null
          comision: number | null
          condicion: string | null
          created_at: string
          cuotas_max: number | null
          descripcion_manual: string | null
          descripcion_publica: string | null
          direccion_asistida: string | null
          duenio: string | null
          equipamiento: Json | null
          estado: string
          estado_publicacion: string | null
          fb_text: string | null
          financiacion_disponible: boolean
          garantia: string | null
          horario_atencion: string | null
          id: string
          ig_text: string | null
          internal_code: string | null
          kilometros: number | null
          marca: string
          marketplace_tier: string
          ml_text: string | null
          modelo: string
          moneda: string | null
          mostrar_publico: boolean
          motor: string | null
          notas_internas: string | null
          patente: string
          potencia: string | null
          precio_compra: number | null
          precio_venta: number | null
          proveedor: string | null
          provincia: string | null
          publicado_fb: boolean | null
          publicado_ig: boolean | null
          publicado_ml: boolean | null
          puertas: number | null
          slug: string | null
          sucursal: string | null
          traccion: string | null
          transmision: string | null
          ubicacion: string | null
          updated_at: string
          user_id: string
          vendedor_nombre: string | null
          vendedor_telefono: string | null
          vendedor_whatsapp: string | null
          version: string | null
          vin: string | null
        }
        Insert: {
          acepta_permuta?: boolean
          agency_id?: string | null
          anio: number
          anticipo_minimo?: number | null
          b2b_disponible?: boolean
          b2b_precio?: number | null
          carroceria?: string | null
          cilindrada?: string | null
          cilindros?: number | null
          ciudad?: string | null
          color?: string | null
          color_interior?: string | null
          combustible?: string | null
          comision?: number | null
          condicion?: string | null
          created_at?: string
          cuotas_max?: number | null
          descripcion_manual?: string | null
          descripcion_publica?: string | null
          direccion_asistida?: string | null
          duenio?: string | null
          equipamiento?: Json | null
          estado?: string
          estado_publicacion?: string | null
          fb_text?: string | null
          financiacion_disponible?: boolean
          garantia?: string | null
          horario_atencion?: string | null
          id?: string
          ig_text?: string | null
          internal_code?: string | null
          kilometros?: number | null
          marca: string
          marketplace_tier?: string
          ml_text?: string | null
          modelo: string
          moneda?: string | null
          mostrar_publico?: boolean
          motor?: string | null
          notas_internas?: string | null
          patente: string
          potencia?: string | null
          precio_compra?: number | null
          precio_venta?: number | null
          proveedor?: string | null
          provincia?: string | null
          publicado_fb?: boolean | null
          publicado_ig?: boolean | null
          publicado_ml?: boolean | null
          puertas?: number | null
          slug?: string | null
          sucursal?: string | null
          traccion?: string | null
          transmision?: string | null
          ubicacion?: string | null
          updated_at?: string
          user_id: string
          vendedor_nombre?: string | null
          vendedor_telefono?: string | null
          vendedor_whatsapp?: string | null
          version?: string | null
          vin?: string | null
        }
        Update: {
          acepta_permuta?: boolean
          agency_id?: string | null
          anio?: number
          anticipo_minimo?: number | null
          b2b_disponible?: boolean
          b2b_precio?: number | null
          carroceria?: string | null
          cilindrada?: string | null
          cilindros?: number | null
          ciudad?: string | null
          color?: string | null
          color_interior?: string | null
          combustible?: string | null
          comision?: number | null
          condicion?: string | null
          created_at?: string
          cuotas_max?: number | null
          descripcion_manual?: string | null
          descripcion_publica?: string | null
          direccion_asistida?: string | null
          duenio?: string | null
          equipamiento?: Json | null
          estado?: string
          estado_publicacion?: string | null
          fb_text?: string | null
          financiacion_disponible?: boolean
          garantia?: string | null
          horario_atencion?: string | null
          id?: string
          ig_text?: string | null
          internal_code?: string | null
          kilometros?: number | null
          marca?: string
          marketplace_tier?: string
          ml_text?: string | null
          modelo?: string
          moneda?: string | null
          mostrar_publico?: boolean
          motor?: string | null
          notas_internas?: string | null
          patente?: string
          potencia?: string | null
          precio_compra?: number | null
          precio_venta?: number | null
          proveedor?: string | null
          provincia?: string | null
          publicado_fb?: boolean | null
          publicado_ig?: boolean | null
          publicado_ml?: boolean | null
          puertas?: number | null
          slug?: string | null
          sucursal?: string | null
          traccion?: string | null
          transmision?: string | null
          ubicacion?: string | null
          updated_at?: string
          user_id?: string
          vendedor_nombre?: string | null
          vendedor_telefono?: string | null
          vendedor_whatsapp?: string | null
          version?: string | null
          vin?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "cars_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
        ]
      }
      cash_movements: {
        Row: {
          agency_id: string | null
          categoria: string | null
          concepto: string | null
          created_at: string
          detalle: string | null
          fecha: string
          id: string
          monto: number
          tipo: string
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          categoria?: string | null
          concepto?: string | null
          created_at?: string
          detalle?: string | null
          fecha?: string
          id?: string
          monto?: number
          tipo: string
          user_id: string
        }
        Update: {
          agency_id?: string | null
          categoria?: string | null
          concepto?: string | null
          created_at?: string
          detalle?: string | null
          fecha?: string
          id?: string
          monto?: number
          tipo?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "cash_movements_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
        ]
      }
      ceo_conversations: {
        Row: {
          created_at: string
          id: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          title?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      ceo_daily_summaries: {
        Row: {
          created_at: string
          id: string
          metrics: Json | null
          summary: string
          summary_date: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          metrics?: Json | null
          summary: string
          summary_date: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          metrics?: Json | null
          summary?: string
          summary_date?: string
          user_id?: string
        }
        Relationships: []
      }
      ceo_messages: {
        Row: {
          content: string
          conversation_id: string
          created_at: string
          id: string
          metadata: Json | null
          role: string
          user_id: string
        }
        Insert: {
          content: string
          conversation_id: string
          created_at?: string
          id?: string
          metadata?: Json | null
          role: string
          user_id: string
        }
        Update: {
          content?: string
          conversation_id?: string
          created_at?: string
          id?: string
          metadata?: Json | null
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ceo_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "ceo_conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      channel_accounts: {
        Row: {
          access_token: string | null
          agency_id: string | null
          created_at: string
          estado: string
          external_id: string | null
          fecha_conexion: string | null
          id: string
          ig_username: string | null
          nombre_interno: string
          notas: string | null
          page_id: string | null
          phone_number: string | null
          platform: string
          responsable: string | null
          updated_at: string
          user_id: string
          waba_id: string | null
          webhook_verify_token: string | null
        }
        Insert: {
          access_token?: string | null
          agency_id?: string | null
          created_at?: string
          estado?: string
          external_id?: string | null
          fecha_conexion?: string | null
          id?: string
          ig_username?: string | null
          nombre_interno: string
          notas?: string | null
          page_id?: string | null
          phone_number?: string | null
          platform: string
          responsable?: string | null
          updated_at?: string
          user_id: string
          waba_id?: string | null
          webhook_verify_token?: string | null
        }
        Update: {
          access_token?: string | null
          agency_id?: string | null
          created_at?: string
          estado?: string
          external_id?: string | null
          fecha_conexion?: string | null
          id?: string
          ig_username?: string | null
          nombre_interno?: string
          notas?: string | null
          page_id?: string | null
          phone_number?: string | null
          platform?: string
          responsable?: string | null
          updated_at?: string
          user_id?: string
          waba_id?: string | null
          webhook_verify_token?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "channel_accounts_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
        ]
      }
      channel_connections: {
        Row: {
          access_token: string | null
          channel: Database["public"]["Enums"]["channel_name"]
          created_at: string
          expires_at: string | null
          external_account_id: string | null
          external_account_name: string | null
          id: string
          metadata: Json
          refresh_token: string | null
          secret_ref: string
          updated_at: string
          user_id: string
        }
        Insert: {
          access_token?: string | null
          channel: Database["public"]["Enums"]["channel_name"]
          created_at?: string
          expires_at?: string | null
          external_account_id?: string | null
          external_account_name?: string | null
          id?: string
          metadata?: Json
          refresh_token?: string | null
          secret_ref?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          access_token?: string | null
          channel?: Database["public"]["Enums"]["channel_name"]
          created_at?: string
          expires_at?: string | null
          external_account_id?: string | null
          external_account_name?: string | null
          id?: string
          metadata?: Json
          refresh_token?: string | null
          secret_ref?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      channel_publications: {
        Row: {
          batch_id: string | null
          car_id: string
          channel: string
          created_at: string
          external_publication_id: string | null
          external_url: string | null
          id: string
          last_response: Json | null
          last_successful_payload: Json | null
          payload_hash: string | null
          published_at: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          batch_id?: string | null
          car_id: string
          channel: string
          created_at?: string
          external_publication_id?: string | null
          external_url?: string | null
          id?: string
          last_response?: Json | null
          last_successful_payload?: Json | null
          payload_hash?: string | null
          published_at?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          batch_id?: string | null
          car_id?: string
          channel?: string
          created_at?: string
          external_publication_id?: string | null
          external_url?: string | null
          id?: string
          last_response?: Json | null
          last_successful_payload?: Json | null
          payload_hash?: string | null
          published_at?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "channel_publications_batch_id_fkey"
            columns: ["batch_id"]
            isOneToOne: false
            referencedRelation: "publication_batches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "channel_publications_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      connected_accounts: {
        Row: {
          access_token: string | null
          account_external_id: string | null
          account_name: string | null
          created_at: string
          expires_at: string | null
          id: string
          meta: Json | null
          platform: string
          refresh_token: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          access_token?: string | null
          account_external_id?: string | null
          account_name?: string | null
          created_at?: string
          expires_at?: string | null
          id?: string
          meta?: Json | null
          platform: string
          refresh_token?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          access_token?: string | null
          account_external_id?: string | null
          account_name?: string | null
          created_at?: string
          expires_at?: string | null
          id?: string
          meta?: Json | null
          platform?: string
          refresh_token?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      conversation_analyses: {
        Row: {
          agency_id: string | null
          clasificacion: string | null
          conversation_id: string
          created_at: string
          id: string
          intencion: string | null
          lead_score: number | null
          modelo: string | null
          nivel_interes: string | null
          nivel_urgencia: string | null
          objeciones: string | null
          presupuesto: string | null
          probabilidad_cierre: number | null
          problema: string | null
          proximos_pasos: string | null
          raw_response: Json | null
          resumen: string | null
          servicio_interes: string | null
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          clasificacion?: string | null
          conversation_id: string
          created_at?: string
          id?: string
          intencion?: string | null
          lead_score?: number | null
          modelo?: string | null
          nivel_interes?: string | null
          nivel_urgencia?: string | null
          objeciones?: string | null
          presupuesto?: string | null
          probabilidad_cierre?: number | null
          problema?: string | null
          proximos_pasos?: string | null
          raw_response?: Json | null
          resumen?: string | null
          servicio_interes?: string | null
          user_id: string
        }
        Update: {
          agency_id?: string | null
          clasificacion?: string | null
          conversation_id?: string
          created_at?: string
          id?: string
          intencion?: string | null
          lead_score?: number | null
          modelo?: string | null
          nivel_interes?: string | null
          nivel_urgencia?: string | null
          objeciones?: string | null
          presupuesto?: string | null
          probabilidad_cierre?: number | null
          problema?: string | null
          proximos_pasos?: string | null
          raw_response?: Json | null
          resumen?: string | null
          servicio_interes?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversation_analyses_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "conversation_analyses_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "inbox_conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      inbox_conversations: {
        Row: {
          agency_id: string | null
          archived: boolean
          channel_account_id: string | null
          contact_handle: string | null
          contact_name: string | null
          created_at: string
          estado: string
          external_contact_id: string | null
          id: string
          ignored: boolean
          last_message_at: string | null
          last_message_text: string | null
          lead_classification: string | null
          lead_id: string | null
          lead_score: number | null
          platform: string
          saved_to_crm: boolean
          tags: string[]
          unread_count: number
          updated_at: string
          user_id: string
          vendedor_asignado: string | null
        }
        Insert: {
          agency_id?: string | null
          archived?: boolean
          channel_account_id?: string | null
          contact_handle?: string | null
          contact_name?: string | null
          created_at?: string
          estado?: string
          external_contact_id?: string | null
          id?: string
          ignored?: boolean
          last_message_at?: string | null
          last_message_text?: string | null
          lead_classification?: string | null
          lead_id?: string | null
          lead_score?: number | null
          platform: string
          saved_to_crm?: boolean
          tags?: string[]
          unread_count?: number
          updated_at?: string
          user_id: string
          vendedor_asignado?: string | null
        }
        Update: {
          agency_id?: string | null
          archived?: boolean
          channel_account_id?: string | null
          contact_handle?: string | null
          contact_name?: string | null
          created_at?: string
          estado?: string
          external_contact_id?: string | null
          id?: string
          ignored?: boolean
          last_message_at?: string | null
          last_message_text?: string | null
          lead_classification?: string | null
          lead_id?: string | null
          lead_score?: number | null
          platform?: string
          saved_to_crm?: boolean
          tags?: string[]
          unread_count?: number
          updated_at?: string
          user_id?: string
          vendedor_asignado?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "inbox_conversations_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inbox_conversations_channel_account_id_fkey"
            columns: ["channel_account_id"]
            isOneToOne: false
            referencedRelation: "channel_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inbox_conversations_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      inbox_messages: {
        Row: {
          agency_id: string | null
          body: string | null
          conversation_id: string
          created_at: string
          direction: string
          external_message_id: string | null
          id: string
          message_type: string
          sent_at: string
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          body?: string | null
          conversation_id: string
          created_at?: string
          direction: string
          external_message_id?: string | null
          id?: string
          message_type?: string
          sent_at?: string
          user_id: string
        }
        Update: {
          agency_id?: string | null
          body?: string | null
          conversation_id?: string
          created_at?: string
          direction?: string
          external_message_id?: string | null
          id?: string
          message_type?: string
          sent_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "inbox_messages_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inbox_messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "inbox_conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      leads: {
        Row: {
          agency_id: string | null
          auto_interes: string | null
          canal: string | null
          created_at: string
          estado: string
          fecha_contacto: string
          id: string
          nombre: string
          notas: string | null
          presupuesto: number | null
          telefono: string | null
          tipo_auto: string | null
          ultimo_contacto: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          auto_interes?: string | null
          canal?: string | null
          created_at?: string
          estado?: string
          fecha_contacto?: string
          id?: string
          nombre: string
          notas?: string | null
          presupuesto?: number | null
          telefono?: string | null
          tipo_auto?: string | null
          ultimo_contacto?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          agency_id?: string | null
          auto_interes?: string | null
          canal?: string | null
          created_at?: string
          estado?: string
          fecha_contacto?: string
          id?: string
          nombre?: string
          notas?: string | null
          presupuesto?: number | null
          telefono?: string | null
          tipo_auto?: string | null
          ultimo_contacto?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "leads_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
        ]
      }
      market_alerts: {
        Row: {
          agency_id: string | null
          alert_type: string
          car_id: string | null
          created_at: string
          data: Json | null
          id: string
          message: string | null
          read: boolean
          severity: string
          title: string
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          alert_type: string
          car_id?: string | null
          created_at?: string
          data?: Json | null
          id?: string
          message?: string | null
          read?: boolean
          severity?: string
          title: string
          user_id: string
        }
        Update: {
          agency_id?: string | null
          alert_type?: string
          car_id?: string | null
          created_at?: string
          data?: Json | null
          id?: string
          message?: string | null
          read?: boolean
          severity?: string
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "market_alerts_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "market_alerts_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      market_analyses: {
        Row: {
          agency_id: string | null
          car_id: string
          competitiveness: string | null
          created_at: string
          diff_pct: number | null
          id: string
          items: Json | null
          my_position: number | null
          my_price: number | null
          price_avg: number | null
          price_max: number | null
          price_median: number | null
          price_min: number | null
          price_recommended: number | null
          query_used: string | null
          recommendation: string | null
          summary: Json | null
          total_results: number | null
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          car_id: string
          competitiveness?: string | null
          created_at?: string
          diff_pct?: number | null
          id?: string
          items?: Json | null
          my_position?: number | null
          my_price?: number | null
          price_avg?: number | null
          price_max?: number | null
          price_median?: number | null
          price_min?: number | null
          price_recommended?: number | null
          query_used?: string | null
          recommendation?: string | null
          summary?: Json | null
          total_results?: number | null
          user_id: string
        }
        Update: {
          agency_id?: string | null
          car_id?: string
          competitiveness?: string | null
          created_at?: string
          diff_pct?: number | null
          id?: string
          items?: Json | null
          my_position?: number | null
          my_price?: number | null
          price_avg?: number | null
          price_max?: number | null
          price_median?: number | null
          price_min?: number | null
          price_recommended?: number | null
          query_used?: string | null
          recommendation?: string | null
          summary?: Json | null
          total_results?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "market_analyses_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "market_analyses_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      message_templates: {
        Row: {
          agency_id: string | null
          categoria: string
          contenido: string
          created_at: string
          id: string
          shortcut: string | null
          titulo: string
          updated_at: string
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          categoria: string
          contenido: string
          created_at?: string
          id?: string
          shortcut?: string | null
          titulo: string
          updated_at?: string
          user_id: string
        }
        Update: {
          agency_id?: string | null
          categoria?: string
          contenido?: string
          created_at?: string
          id?: string
          shortcut?: string | null
          titulo?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "message_templates_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
        ]
      }
      ml_credentials: {
        Row: {
          app_id: string
          client_secret: string | null
          created_at: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          app_id: string
          client_secret?: string | null
          created_at?: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          app_id?: string
          client_secret?: string | null
          created_at?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      ml_listing_types: {
        Row: {
          active: boolean
          available_quantity: number | null
          currency: string | null
          id: string
          listing_type_id: string
          name: string | null
          publishing_account_id: string
          raw: Json | null
          updated_at: string
          used_quantity: number | null
          user_id: string
        }
        Insert: {
          active?: boolean
          available_quantity?: number | null
          currency?: string | null
          id?: string
          listing_type_id: string
          name?: string | null
          publishing_account_id: string
          raw?: Json | null
          updated_at?: string
          used_quantity?: number | null
          user_id: string
        }
        Update: {
          active?: boolean
          available_quantity?: number | null
          currency?: string | null
          id?: string
          listing_type_id?: string
          name?: string | null
          publishing_account_id?: string
          raw?: Json | null
          updated_at?: string
          used_quantity?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ml_listing_types_publishing_account_id_fkey"
            columns: ["publishing_account_id"]
            isOneToOne: false
            referencedRelation: "connected_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_phones: {
        Row: {
          agency_id: string | null
          created_at: string
          id: string
          label: string | null
          phone: string
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          created_at?: string
          id?: string
          label?: string | null
          phone: string
          user_id: string
        }
        Update: {
          agency_id?: string | null
          created_at?: string
          id?: string
          label?: string | null
          phone?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notification_phones_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
        ]
      }
      oauth_states: {
        Row: {
          code_verifier: string | null
          consumed_at: string | null
          created_at: string
          expires_at: string
          provider: string
          return_to: string
          state_hash: string
          user_id: string
        }
        Insert: {
          code_verifier?: string | null
          consumed_at?: string | null
          created_at?: string
          expires_at: string
          provider: string
          return_to?: string
          state_hash: string
          user_id: string
        }
        Update: {
          code_verifier?: string | null
          consumed_at?: string | null
          created_at?: string
          expires_at?: string
          provider?: string
          return_to?: string
          state_hash?: string
          user_id?: string
        }
        Relationships: []
      }
      plans: {
        Row: {
          active: boolean
          advanced_stats: boolean
          code: string
          created_at: string
          features: Json
          id: string
          marketplace_enabled: boolean
          max_gold: number
          max_marketplace: number | null
          max_users: number | null
          max_vehicles: number | null
          name: string
          price_monthly: number
          updated_at: string
        }
        Insert: {
          active?: boolean
          advanced_stats?: boolean
          code: string
          created_at?: string
          features?: Json
          id?: string
          marketplace_enabled?: boolean
          max_gold?: number
          max_marketplace?: number | null
          max_users?: number | null
          max_vehicles?: number | null
          name: string
          price_monthly?: number
          updated_at?: string
        }
        Update: {
          active?: boolean
          advanced_stats?: boolean
          code?: string
          created_at?: string
          features?: Json
          id?: string
          marketplace_enabled?: boolean
          max_gold?: number
          max_marketplace?: number | null
          max_users?: number | null
          max_vehicles?: number | null
          name?: string
          price_monthly?: number
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string | null
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          display_name?: string | null
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      public_faqs: {
        Row: {
          activo: boolean
          agency_id: string | null
          created_at: string
          id: string
          orden: number
          owner_user_id: string | null
          pregunta: string
          respuesta: string
          updated_at: string
        }
        Insert: {
          activo?: boolean
          agency_id?: string | null
          created_at?: string
          id?: string
          orden?: number
          owner_user_id?: string | null
          pregunta: string
          respuesta: string
          updated_at?: string
        }
        Update: {
          activo?: boolean
          agency_id?: string | null
          created_at?: string
          id?: string
          orden?: number
          owner_user_id?: string | null
          pregunta?: string
          respuesta?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "public_faqs_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
        ]
      }
      public_settings: {
        Row: {
          agency_id: string | null
          created_at: string
          direccion: string | null
          email: string | null
          facebook_url: string | null
          financiacion_activa: boolean
          financiacion_cuotas_max: number
          financiacion_gastos_porcentaje: number
          financiacion_tasa: number
          horarios: string | null
          id: string
          instagram_url: string | null
          is_default: boolean
          logo_url: string | null
          mapa_embed_url: string | null
          mostrar_vendidos: boolean
          motivos: Json
          nombre_agencia: string | null
          nosotros_fotos: Json
          nosotros_historia: string | null
          nosotros_mision: string | null
          nosotros_valores: string | null
          owner_user_id: string | null
          telefono: string | null
          tiktok_url: string | null
          transferencia_porcentaje: number
          updated_at: string
          whatsapp_number: string
        }
        Insert: {
          agency_id?: string | null
          created_at?: string
          direccion?: string | null
          email?: string | null
          facebook_url?: string | null
          financiacion_activa?: boolean
          financiacion_cuotas_max?: number
          financiacion_gastos_porcentaje?: number
          financiacion_tasa?: number
          horarios?: string | null
          id?: string
          instagram_url?: string | null
          is_default?: boolean
          logo_url?: string | null
          mapa_embed_url?: string | null
          mostrar_vendidos?: boolean
          motivos?: Json
          nombre_agencia?: string | null
          nosotros_fotos?: Json
          nosotros_historia?: string | null
          nosotros_mision?: string | null
          nosotros_valores?: string | null
          owner_user_id?: string | null
          telefono?: string | null
          tiktok_url?: string | null
          transferencia_porcentaje?: number
          updated_at?: string
          whatsapp_number?: string
        }
        Update: {
          agency_id?: string | null
          created_at?: string
          direccion?: string | null
          email?: string | null
          facebook_url?: string | null
          financiacion_activa?: boolean
          financiacion_cuotas_max?: number
          financiacion_gastos_porcentaje?: number
          financiacion_tasa?: number
          horarios?: string | null
          id?: string
          instagram_url?: string | null
          is_default?: boolean
          logo_url?: string | null
          mapa_embed_url?: string | null
          mostrar_vendidos?: boolean
          motivos?: Json
          nombre_agencia?: string | null
          nosotros_fotos?: Json
          nosotros_historia?: string | null
          nosotros_mision?: string | null
          nosotros_valores?: string | null
          owner_user_id?: string | null
          telefono?: string | null
          tiktok_url?: string | null
          transferencia_porcentaje?: number
          updated_at?: string
          whatsapp_number?: string
        }
        Relationships: [
          {
            foreignKeyName: "public_settings_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
        ]
      }
      publication_batches: {
        Row: {
          car_id: string
          completed_at: string | null
          created_at: string
          id: string
          overall_status: string
          selected_channels: string[]
          started_at: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          car_id: string
          completed_at?: string | null
          created_at?: string
          id?: string
          overall_status?: string
          selected_channels?: string[]
          started_at?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          car_id?: string
          completed_at?: string | null
          created_at?: string
          id?: string
          overall_status?: string
          selected_channels?: string[]
          started_at?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "publication_batches_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      publication_jobs: {
        Row: {
          action: string
          attempt_number: number
          batch_id: string | null
          car_id: string
          channel: string
          created_at: string
          error_code: string | null
          error_message: string | null
          finished_at: string | null
          id: string
          idempotency_key: string | null
          payload: Json | null
          response: Json | null
          started_at: string | null
          status: string
          technical_error: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          action?: string
          attempt_number?: number
          batch_id?: string | null
          car_id: string
          channel: string
          created_at?: string
          error_code?: string | null
          error_message?: string | null
          finished_at?: string | null
          id?: string
          idempotency_key?: string | null
          payload?: Json | null
          response?: Json | null
          started_at?: string | null
          status?: string
          technical_error?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          action?: string
          attempt_number?: number
          batch_id?: string | null
          car_id?: string
          channel?: string
          created_at?: string
          error_code?: string | null
          error_message?: string | null
          finished_at?: string | null
          id?: string
          idempotency_key?: string | null
          payload?: Json | null
          response?: Json | null
          started_at?: string | null
          status?: string
          technical_error?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "publication_jobs_batch_id_fkey"
            columns: ["batch_id"]
            isOneToOne: false
            referencedRelation: "publication_batches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "publication_jobs_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      publication_templates: {
        Row: {
          channel: string
          created_at: string
          id: string
          is_default: boolean
          name: string
          template: string
          updated_at: string
          user_id: string
        }
        Insert: {
          channel: string
          created_at?: string
          id?: string
          is_default?: boolean
          name: string
          template: string
          updated_at?: string
          user_id: string
        }
        Update: {
          channel?: string
          created_at?: string
          id?: string
          is_default?: boolean
          name?: string
          template?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      publications: {
        Row: {
          agency_id: string | null
          attempts: number
          channel: Database["public"]["Enums"]["channel_name"]
          created_at: string
          error_code: string | null
          error_message: string | null
          external_id: string | null
          external_url: string | null
          id: string
          idempotency_key: string
          published_at: string | null
          request_snapshot: Json | null
          response_snapshot: Json | null
          status: Database["public"]["Enums"]["publication_status"]
          updated_at: string
          user_id: string
          vehicle_id: string
        }
        Insert: {
          agency_id?: string | null
          attempts?: number
          channel: Database["public"]["Enums"]["channel_name"]
          created_at?: string
          error_code?: string | null
          error_message?: string | null
          external_id?: string | null
          external_url?: string | null
          id?: string
          idempotency_key: string
          published_at?: string | null
          request_snapshot?: Json | null
          response_snapshot?: Json | null
          status?: Database["public"]["Enums"]["publication_status"]
          updated_at?: string
          user_id: string
          vehicle_id: string
        }
        Update: {
          agency_id?: string | null
          attempts?: number
          channel?: Database["public"]["Enums"]["channel_name"]
          created_at?: string
          error_code?: string | null
          error_message?: string | null
          external_id?: string | null
          external_url?: string | null
          id?: string
          idempotency_key?: string
          published_at?: string | null
          request_snapshot?: Json | null
          response_snapshot?: Json | null
          status?: Database["public"]["Enums"]["publication_status"]
          updated_at?: string
          user_id?: string
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "publications_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "publications_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      publish_confirmations: {
        Row: {
          channels: string[]
          created_at: string
          expires_at: string
          id: string
          token: string
          used_at: string | null
          user_id: string
          vehicle_id: string
        }
        Insert: {
          channels?: string[]
          created_at?: string
          expires_at?: string
          id?: string
          token: string
          used_at?: string | null
          user_id: string
          vehicle_id: string
        }
        Update: {
          channels?: string[]
          created_at?: string
          expires_at?: string
          id?: string
          token?: string
          used_at?: string | null
          user_id?: string
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "publish_confirmations_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      sale_payments: {
        Row: {
          agency_id: string | null
          created_at: string
          fecha: string
          id: string
          metodo_pago: string | null
          monto: number
          nota: string | null
          sale_id: string
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          created_at?: string
          fecha?: string
          id?: string
          metodo_pago?: string | null
          monto?: number
          nota?: string | null
          sale_id: string
          user_id: string
        }
        Update: {
          agency_id?: string | null
          created_at?: string
          fecha?: string
          id?: string
          metodo_pago?: string | null
          monto?: number
          nota?: string | null
          sale_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "sale_payments_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sale_payments_sale_id_fkey"
            columns: ["sale_id"]
            isOneToOne: false
            referencedRelation: "sales"
            referencedColumns: ["id"]
          },
        ]
      }
      sales: {
        Row: {
          agency_id: string | null
          car_id: string | null
          comprador_dni: string | null
          comprador_domicilio: string | null
          comprador_nombre: string | null
          comprador_telefono: string | null
          cotizacion_usd: number | null
          created_at: string
          cuotas: number | null
          estado: string
          fecha: string
          fecha_entrega: string | null
          fecha_sena: string | null
          forma_pago: string | null
          id: string
          lugar: string | null
          marca_modelo: string | null
          margen_manual: number | null
          moneda: string
          monto: number
          monto_entrega: number | null
          monto_financiar: number | null
          parte_pago: string | null
          parte_pago_valor: number | null
          patente: string | null
          primera_cuota_fecha: string | null
          sena: number | null
          transferencia_incluida: boolean
          updated_at: string
          user_id: string
          valor_transferencia: number | null
          vendedor: string | null
          vendedor_dni: string | null
          vendedor_domicilio: string | null
          vendedor_telefono: string | null
        }
        Insert: {
          agency_id?: string | null
          car_id?: string | null
          comprador_dni?: string | null
          comprador_domicilio?: string | null
          comprador_nombre?: string | null
          comprador_telefono?: string | null
          cotizacion_usd?: number | null
          created_at?: string
          cuotas?: number | null
          estado?: string
          fecha?: string
          fecha_entrega?: string | null
          fecha_sena?: string | null
          forma_pago?: string | null
          id?: string
          lugar?: string | null
          marca_modelo?: string | null
          margen_manual?: number | null
          moneda?: string
          monto?: number
          monto_entrega?: number | null
          monto_financiar?: number | null
          parte_pago?: string | null
          parte_pago_valor?: number | null
          patente?: string | null
          primera_cuota_fecha?: string | null
          sena?: number | null
          transferencia_incluida?: boolean
          updated_at?: string
          user_id: string
          valor_transferencia?: number | null
          vendedor?: string | null
          vendedor_dni?: string | null
          vendedor_domicilio?: string | null
          vendedor_telefono?: string | null
        }
        Update: {
          agency_id?: string | null
          car_id?: string | null
          comprador_dni?: string | null
          comprador_domicilio?: string | null
          comprador_nombre?: string | null
          comprador_telefono?: string | null
          cotizacion_usd?: number | null
          created_at?: string
          cuotas?: number | null
          estado?: string
          fecha?: string
          fecha_entrega?: string | null
          fecha_sena?: string | null
          forma_pago?: string | null
          id?: string
          lugar?: string | null
          marca_modelo?: string | null
          margen_manual?: number | null
          moneda?: string
          monto?: number
          monto_entrega?: number | null
          monto_financiar?: number | null
          parte_pago?: string | null
          parte_pago_valor?: number | null
          patente?: string | null
          primera_cuota_fecha?: string | null
          sena?: number | null
          transferencia_incluida?: boolean
          updated_at?: string
          user_id?: string
          valor_transferencia?: number | null
          vendedor?: string | null
          vendedor_dni?: string | null
          vendedor_domicilio?: string | null
          vendedor_telefono?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "sales_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sales_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      subscriptions: {
        Row: {
          agency_id: string
          cancelled_at: string | null
          created_at: string
          current_period_end: string | null
          id: string
          notes: string | null
          plan_id: string | null
          started_at: string
          status: string
          updated_at: string
        }
        Insert: {
          agency_id: string
          cancelled_at?: string | null
          created_at?: string
          current_period_end?: string | null
          id?: string
          notes?: string | null
          plan_id?: string | null
          started_at?: string
          status?: string
          updated_at?: string
        }
        Update: {
          agency_id?: string
          cancelled_at?: string | null
          created_at?: string
          current_period_end?: string | null
          id?: string
          notes?: string | null
          plan_id?: string | null
          started_at?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscriptions_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "plans"
            referencedColumns: ["id"]
          },
        ]
      }
      trade_in_requests: {
        Row: {
          agency_id: string | null
          anio: number | null
          caja: string | null
          cliente_email: string | null
          cliente_nombre: string
          cliente_telefono: string | null
          combustible: string | null
          created_at: string
          estado: string
          estado_general: string | null
          fotos: Json
          id: string
          kilometros: number | null
          marca: string
          modelo: string
          notas_internas: string | null
          observaciones: string | null
          owner_user_id: string | null
          precio_pretendido: number | null
          updated_at: string
          version: string | null
        }
        Insert: {
          agency_id?: string | null
          anio?: number | null
          caja?: string | null
          cliente_email?: string | null
          cliente_nombre: string
          cliente_telefono?: string | null
          combustible?: string | null
          created_at?: string
          estado?: string
          estado_general?: string | null
          fotos?: Json
          id?: string
          kilometros?: number | null
          marca: string
          modelo: string
          notas_internas?: string | null
          observaciones?: string | null
          owner_user_id?: string | null
          precio_pretendido?: number | null
          updated_at?: string
          version?: string | null
        }
        Update: {
          agency_id?: string | null
          anio?: number | null
          caja?: string | null
          cliente_email?: string | null
          cliente_nombre?: string
          cliente_telefono?: string | null
          combustible?: string | null
          created_at?: string
          estado?: string
          estado_general?: string | null
          fotos?: Json
          id?: string
          kilometros?: number | null
          marca?: string
          modelo?: string
          notas_internas?: string | null
          observaciones?: string | null
          owner_user_id?: string | null
          precio_pretendido?: number | null
          updated_at?: string
          version?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "trade_in_requests_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          agency_id: string | null
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          agency_id?: string | null
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
        ]
      }
      vehicle_alerts: {
        Row: {
          agency_id: string | null
          anio_aprox: number | null
          cliente_email: string | null
          cliente_nombre: string
          cliente_telefono: string | null
          cliente_whatsapp: string | null
          created_at: string
          estado: string
          id: string
          marca: string | null
          modelo: string | null
          notas_internas: string | null
          observaciones: string | null
          owner_user_id: string | null
          presupuesto: number | null
          updated_at: string
        }
        Insert: {
          agency_id?: string | null
          anio_aprox?: number | null
          cliente_email?: string | null
          cliente_nombre: string
          cliente_telefono?: string | null
          cliente_whatsapp?: string | null
          created_at?: string
          estado?: string
          id?: string
          marca?: string | null
          modelo?: string | null
          notas_internas?: string | null
          observaciones?: string | null
          owner_user_id?: string | null
          presupuesto?: number | null
          updated_at?: string
        }
        Update: {
          agency_id?: string | null
          anio_aprox?: number | null
          cliente_email?: string | null
          cliente_nombre?: string
          cliente_telefono?: string | null
          cliente_whatsapp?: string | null
          created_at?: string
          estado?: string
          id?: string
          marca?: string | null
          modelo?: string | null
          notas_internas?: string | null
          observaciones?: string | null
          owner_user_id?: string | null
          presupuesto?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_alerts_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
        ]
      }
      vehicle_change_log: {
        Row: {
          car_id: string
          changed_fields: string[]
          created_at: string
          id: string
          new_values: Json | null
          previous_values: Json | null
          user_id: string
        }
        Insert: {
          car_id: string
          changed_fields?: string[]
          created_at?: string
          id?: string
          new_values?: Json | null
          previous_values?: Json | null
          user_id: string
        }
        Update: {
          car_id?: string
          changed_fields?: string[]
          created_at?: string
          id?: string
          new_values?: Json | null
          previous_values?: Json | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_change_log_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
        ]
      }
      vehicle_media: {
        Row: {
          alt_text: string | null
          created_at: string
          id: string
          is_cover: boolean
          public_url: string | null
          sort_order: number
          storage_path: string
          user_id: string
          vehicle_id: string
        }
        Insert: {
          alt_text?: string | null
          created_at?: string
          id?: string
          is_cover?: boolean
          public_url?: string | null
          sort_order?: number
          storage_path: string
          user_id: string
          vehicle_id: string
        }
        Update: {
          alt_text?: string | null
          created_at?: string
          id?: string
          is_cover?: boolean
          public_url?: string | null
          sort_order?: number
          storage_path?: string
          user_id?: string
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_media_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      vehicle_publications: {
        Row: {
          agency_id: string | null
          car_id: string
          created_at: string
          error_message: string | null
          external_id: string | null
          external_url: string | null
          id: string
          listing_type: string | null
          payload: Json | null
          platform: string
          published_at: string | null
          publishing_account_id: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          agency_id?: string | null
          car_id: string
          created_at?: string
          error_message?: string | null
          external_id?: string | null
          external_url?: string | null
          id?: string
          listing_type?: string | null
          payload?: Json | null
          platform: string
          published_at?: string | null
          publishing_account_id?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          agency_id?: string | null
          car_id?: string
          created_at?: string
          error_message?: string | null
          external_id?: string | null
          external_url?: string | null
          id?: string
          listing_type?: string | null
          payload?: Json | null
          platform?: string
          published_at?: string | null
          publishing_account_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_publications_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_publications_car_id_fkey"
            columns: ["car_id"]
            isOneToOne: false
            referencedRelation: "cars"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_publications_publishing_account_id_fkey"
            columns: ["publishing_account_id"]
            isOneToOne: false
            referencedRelation: "connected_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      vehicles: {
        Row: {
          accepts_trade: boolean
          agency_id: string | null
          body_type: string | null
          brand: string
          brand_value_id: string | null
          condition: string
          contact: Json
          created_at: string
          currency_id: string
          description: string
          doors: number | null
          engine: string | null
          equipment: Json
          exterior_color: string | null
          facebook_message: string | null
          financing: boolean
          fuel_type: string | null
          hashtags: string[]
          id: string
          initial_payment: number | null
          instagram_caption: string | null
          interior_color: string | null
          internal_title: string | null
          license_plate: string | null
          location: Json
          mileage_km: number | null
          ml_attributes: Json
          ml_category_id: string | null
          ml_domain_id: string | null
          ml_listing_type_id: string | null
          model: string
          model_value_id: string | null
          observations: string | null
          passengers: number | null
          power: string | null
          price: number | null
          safety: Json
          status: Database["public"]["Enums"]["vehicle_status"]
          title: string
          traction: string | null
          transmission: string | null
          trim: string
          trim_value_id: string | null
          updated_at: string
          user_id: string
          vehicle_year: number | null
          vin: string | null
          year_value_id: string | null
        }
        Insert: {
          accepts_trade?: boolean
          agency_id?: string | null
          body_type?: string | null
          brand?: string
          brand_value_id?: string | null
          condition?: string
          contact?: Json
          created_at?: string
          currency_id?: string
          description?: string
          doors?: number | null
          engine?: string | null
          equipment?: Json
          exterior_color?: string | null
          facebook_message?: string | null
          financing?: boolean
          fuel_type?: string | null
          hashtags?: string[]
          id?: string
          initial_payment?: number | null
          instagram_caption?: string | null
          interior_color?: string | null
          internal_title?: string | null
          license_plate?: string | null
          location?: Json
          mileage_km?: number | null
          ml_attributes?: Json
          ml_category_id?: string | null
          ml_domain_id?: string | null
          ml_listing_type_id?: string | null
          model?: string
          model_value_id?: string | null
          observations?: string | null
          passengers?: number | null
          power?: string | null
          price?: number | null
          safety?: Json
          status?: Database["public"]["Enums"]["vehicle_status"]
          title?: string
          traction?: string | null
          transmission?: string | null
          trim?: string
          trim_value_id?: string | null
          updated_at?: string
          user_id: string
          vehicle_year?: number | null
          vin?: string | null
          year_value_id?: string | null
        }
        Update: {
          accepts_trade?: boolean
          agency_id?: string | null
          body_type?: string | null
          brand?: string
          brand_value_id?: string | null
          condition?: string
          contact?: Json
          created_at?: string
          currency_id?: string
          description?: string
          doors?: number | null
          engine?: string | null
          equipment?: Json
          exterior_color?: string | null
          facebook_message?: string | null
          financing?: boolean
          fuel_type?: string | null
          hashtags?: string[]
          id?: string
          initial_payment?: number | null
          instagram_caption?: string | null
          interior_color?: string | null
          internal_title?: string | null
          license_plate?: string | null
          location?: Json
          mileage_km?: number | null
          ml_attributes?: Json
          ml_category_id?: string | null
          ml_domain_id?: string | null
          ml_listing_type_id?: string | null
          model?: string
          model_value_id?: string | null
          observations?: string | null
          passengers?: number | null
          power?: string | null
          price?: number | null
          safety?: Json
          status?: Database["public"]["Enums"]["vehicle_status"]
          title?: string
          traction?: string | null
          transmission?: string | null
          trim?: string
          trim_value_id?: string | null
          updated_at?: string
          user_id?: string
          vehicle_year?: number | null
          vin?: string | null
          year_value_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "vehicles_agency_id_fkey"
            columns: ["agency_id"]
            isOneToOne: false
            referencedRelation: "agencies"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      cars_public: {
        Row: {
          acepta_permuta: boolean | null
          agency_ciudad: string | null
          agency_id: string | null
          agency_lat: number | null
          agency_lng: number | null
          agency_logo: string | null
          agency_marketplace_visible: boolean | null
          agency_name: string | null
          agency_provincia: string | null
          agency_slug: string | null
          agency_whatsapp: string | null
          anio: number | null
          carroceria: string | null
          ciudad: string | null
          color: string | null
          combustible: string | null
          condicion: string | null
          created_at: string | null
          descripcion_publica: string | null
          equipamiento: Json | null
          estado: string | null
          financiacion_disponible: boolean | null
          garantia: string | null
          id: string | null
          kilometros: number | null
          marca: string | null
          marketplace_tier: string | null
          modelo: string | null
          moneda: string | null
          mostrar_publico: boolean | null
          motor: string | null
          precio_venta: number | null
          provincia: string | null
          puertas: number | null
          slug: string | null
          transmision: string | null
          ubicacion: string | null
          updated_at: string | null
          version: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      agency_plan_usage: { Args: { _agency_id: string }; Returns: Json }
      is_ceo: { Args: { _user_id: string }; Returns: boolean }
      reconcile_agency_gold: { Args: { _agency_id: string }; Returns: number }
    }
    Enums: {
      app_role: "ceo" | "owner" | "employee" | "agency_admin"
      channel_name: "mercadolibre" | "instagram" | "facebook"
      publication_status:
        | "draft"
        | "validating"
        | "queued"
        | "publishing"
        | "published"
        | "partial"
        | "failed"
        | "paused"
        | "closed"
      vehicle_status: "draft" | "available" | "reserved" | "sold"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["ceo", "owner", "employee", "agency_admin"],
      channel_name: ["mercadolibre", "instagram", "facebook"],
      publication_status: [
        "draft",
        "validating",
        "queued",
        "publishing",
        "published",
        "partial",
        "failed",
        "paused",
        "closed",
      ],
      vehicle_status: ["draft", "available", "reserved", "sold"],
    },
  },
} as const
