import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import AppLayout from "@/components/AppLayout";
import LoginPage from "@/pages/LoginPage";
import StockPage from "@/pages/StockPage";
import GastosPage from "@/pages/GastosPage";
import CajaPage from "@/pages/CajaPage";
import VentasPage from "@/pages/VentasPage";
import CuotasPage from "@/pages/CuotasPage";
import VendidosPage from "@/pages/VendidosPage";
import CrmPage from "@/pages/CrmPage";
import PublicadorPage from "@/pages/PublicadorPage";
import DocumentacionPage from "@/pages/DocumentacionPage";
import PdfsPage from "@/pages/PdfsPage";
import CotizadorPage from "@/pages/CotizadorPage";
import EstadisticasPage from "@/pages/EstadisticasPage";
import HerramientasPage from "@/pages/HerramientasPage";
import CalendarioPage from "@/pages/CalendarioPage";
import FinancieroPage from "@/pages/FinancieroPage";
import InboxPage from "@/pages/InboxPage";
import CanalesPage from "@/pages/CanalesPage";
import PlantillasPage from "@/pages/PlantillasPage";
import AutosPage from "@/pages/AutosPage";
import AutoFormPage from "@/pages/AutoFormPage";
import InteligenciaMercadoPage from "@/pages/InteligenciaMercadoPage";
import CeoIaPage from "@/pages/CeoIaPage";
import CeoPanelPage from "@/pages/CeoPanelPage";
import NotFound from "@/pages/NotFound";
import PublicCatalogPage from "@/pages/public/PublicCatalogPage";
import MarketplacePage from "@/pages/public/MarketplacePage";
import MiAgenciaPage from "@/pages/MiAgenciaPage";
import PublicCarPage from "@/pages/public/PublicCarPage";

import PublicFavoritosPage from "@/pages/public/PublicFavoritosPage";
import PublicComparePage from "@/pages/public/PublicComparePage";
import PublicTradeInPage from "@/pages/public/PublicTradeInPage";
import PublicAlertaPage from "@/pages/public/PublicAlertaPage";
import PublicNosotrosPage from "@/pages/public/PublicNosotrosPage";
import PublicFaqPage from "@/pages/public/PublicFaqPage";
import SitioPublicoPage from "@/pages/SitioPublicoPage";
import TasacionesPage from "@/pages/TasacionesPage";
import AlertasPage from "@/pages/AlertasPage";
import FaqAdminPage from "@/pages/FaqAdminPage";
import TurnosPage from "@/pages/TurnosPage";
import LandingPage from "@/pages/LandingPage";
import PlanesPage from "@/pages/PlanesPage";
import FeatureGate from "@/components/FeatureGate";
import VehiculosPage from "@/pages/VehiculosPage";
import VehiculoDetallePage from "@/pages/VehiculoDetallePage";
import PlantillasPublicacionPage from "@/pages/PlantillasPublicacionPage";
import PublicadorProPage from "@/pages/publisher/PublicadorProPage";
import StockIntelligencePage from "./pages/StockIntelligencePage";
import RedB2BPage from "./pages/RedB2BPage";
import AsistentePublicacionPage from "@/pages/AsistentePublicacionPage";
import PublisherVehiculoPage from "@/pages/publisher/PublisherVehiculoPage";
import PublisherPublicacionesPage from "@/pages/publisher/PublisherPublicacionesPage";
import PublisherConexionesPage from "@/pages/publisher/PublisherConexionesPage";
import OAuthResultPage from "@/pages/publisher/OAuthResultPage";
import { Navigate } from "react-router-dom";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 1000 * 30,
    },
  },
});

function ProtectedRoutes() {
  const { session, loading } = useAuth();
  if (loading) return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Cargando...</div>;
  if (!session) {
    return (
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    );
  }
  return (
    <AppLayout>
      <Routes>
        <Route path="/" element={<StockPage />} />
        <Route path="/login" element={<Navigate to="/" replace />} />
        <Route path="/gastos" element={<GastosPage />} />
        <Route path="/caja" element={<CajaPage />} />
        <Route path="/ventas" element={<VentasPage />} />
        <Route path="/cuotas" element={<CuotasPage />} />
        <Route path="/vendidos" element={<VendidosPage />} />
        <Route path="/crm" element={<CrmPage />} />
        <Route path="/publicador" element={<PublicadorPage />} />
        <Route path="/documentacion" element={<DocumentacionPage />} />
        <Route path="/pdfs" element={<FeatureGate feature="pdfs"><PdfsPage /></FeatureGate>} />
        <Route path="/cotizador" element={<FeatureGate feature="cotizador"><CotizadorPage /></FeatureGate>} />
        <Route path="/estadisticas" element={<FeatureGate feature="stats"><EstadisticasPage /></FeatureGate>} />
        <Route path="/herramientas" element={<HerramientasPage />} />
        <Route path="/calendario" element={<CalendarioPage />} />
        <Route path="/financiero" element={<FeatureGate feature="financiero"><FinancieroPage /></FeatureGate>} />
        <Route path="/inbox" element={<InboxPage />} />
        <Route path="/canales" element={<CanalesPage />} />
        <Route path="/plantillas" element={<PlantillasPage />} />
        <Route path="/autos" element={<AutosPage />} />
        <Route path="/autos/:id" element={<AutoFormPage />} />
        <Route path="/inteligencia-mercado" element={<InteligenciaMercadoPage />} />
        <Route path="/ceo-ia" element={<CeoIaPage />} />
        <Route path="/ceo" element={<CeoPanelPage />} />
        <Route path="/sitio-publico" element={<SitioPublicoPage />} />
        <Route path="/mi-agencia" element={<MiAgenciaPage />} />
        <Route path="/planes" element={<PlanesPage />} />

        <Route path="/tasaciones" element={<TasacionesPage />} />
        <Route path="/alertas" element={<AlertasPage />} />
        <Route path="/faq-admin" element={<FaqAdminPage />} />
        <Route path="/turnos" element={<FeatureGate feature="turnos"><TurnosPage /></FeatureGate>} />
        <Route path="/vehiculos" element={<VehiculosPage />} />
        <Route path="/vehiculos/:id" element={<VehiculoDetallePage />} />
        <Route path="/plantillas-publicacion" element={<PlantillasPublicacionPage />} />
        <Route path="/stock-intelligence" element={<FeatureGate feature="stock_intelligence"><StockIntelligencePage /></FeatureGate>} />
        <Route path="/red-b2b" element={<FeatureGate feature="b2b"><RedB2BPage /></FeatureGate>} />
        <Route path="/asistente-publicacion" element={<AsistentePublicacionPage />} />
        <Route path="/publicador-pro" element={<PublicadorProPage />} />
        <Route path="/publicador-pro/publicaciones" element={<PublisherPublicacionesPage />} />
        <Route path="/publicador-pro/conexiones" element={<PublisherConexionesPage />} />
        <Route path="/settings/connections" element={<PublisherConexionesPage />} />
        <Route path="/publicador-pro/:id" element={<PublisherVehiculoPage />} />
        <Route path="/oauth/result" element={<OAuthResultPage />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </AppLayout>
  );
}

const App = () => (
  <ErrorBoundary>
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/marketplace" element={<MarketplacePage />} />
              <Route path="/agencia/:agencySlug" element={<PublicCatalogPage />} />
              <Route path="/agencia/:agencySlug/auto/:slug" element={<PublicCarPage />} />
              <Route path="/agencia/:agencySlug/tasacion" element={<PublicTradeInPage />} />
              <Route path="/agencia/:agencySlug/nosotros" element={<PublicNosotrosPage />} />
              <Route path="/agencia/:agencySlug/faq" element={<PublicFaqPage />} />
              <Route path="/catalogo" element={<PublicCatalogPage />} />
              <Route path="/catalogo/favoritos" element={<PublicFavoritosPage />} />
              <Route path="/catalogo/comparar" element={<PublicComparePage />} />
              <Route path="/catalogo/tasacion" element={<PublicTradeInPage />} />
              <Route path="/catalogo/alerta" element={<PublicAlertaPage />} />
              <Route path="/catalogo/nosotros" element={<PublicNosotrosPage />} />
              <Route path="/catalogo/faq" element={<PublicFaqPage />} />
              <Route path="/catalogo/:slug" element={<PublicCarPage />} />

              <Route path="/*" element={<ProtectedRoutes />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  </ErrorBoundary>
);

export default App;
