import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Car = Database["public"]["Tables"]["cars"]["Row"];
export type CarInsert = Database["public"]["Tables"]["cars"]["Insert"];
export type CarExpense = Database["public"]["Tables"]["car_expenses"]["Row"];
export type CarExpenseInsert = Database["public"]["Tables"]["car_expenses"]["Insert"];
export type CashMovement = Database["public"]["Tables"]["cash_movements"]["Row"];
export type CashMovementInsert = Database["public"]["Tables"]["cash_movements"]["Insert"];
export type Sale = Database["public"]["Tables"]["sales"]["Row"];
export type SaleInsert = Database["public"]["Tables"]["sales"]["Insert"];
export type SalePayment = Database["public"]["Tables"]["sale_payments"]["Row"];
export type SalePaymentInsert = Database["public"]["Tables"]["sale_payments"]["Insert"];
export type CarDocumentation = Database["public"]["Tables"]["car_documentation"]["Row"];
export type CarDocInsert = Database["public"]["Tables"]["car_documentation"]["Insert"];
export type Profile = Database["public"]["Tables"]["profiles"]["Row"];

export const getSaleMargin = ({
  sale,
  car,
  expensesTotal,
}: {
  sale: Sale;
  car?: Car | null;
  expensesTotal: number;
}) => {
  if (sale.margen_manual != null && Number(sale.margen_manual) !== 0) return Number(sale.margen_manual);

  // Si la venta fue en dólares, se convierte a pesos con la cotización cargada
  const cotizacion = Number((sale as any).cotizacion_usd ?? 0);
  const esUsd = (sale as any).moneda === "USD";
  const montoArs = esUsd && cotizacion > 0 ? Number(sale.monto ?? 0) * cotizacion : Number(sale.monto ?? 0);

  const precioVenta = montoArs || Number(car?.precio_venta ?? 0);
  const precioCompra = Number(car?.precio_compra ?? 0);
  const valorTransferencia = Number((sale as any).valor_transferencia ?? 0);
  // Si la transferencia está incluida en el precio final, se descuenta del margen.
  // Si es aparte (la paga el comprador adicional), NO se descuenta.
  const transferenciaIncluida = (sale as any).transferencia_incluida ?? true;
  const transferenciaADescontar = transferenciaIncluida ? valorTransferencia : 0;

  if (!precioVenta && !precioCompra) return 0;

  return precioVenta - precioCompra - transferenciaADescontar - expensesTotal;
};

export const formatCurrency = (n: number) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 }).format(n);

export const formatMoney = (n: number, moneda?: string | null) =>
  moneda === "USD"
    ? `USD ${new Intl.NumberFormat("es-AR", { maximumFractionDigits: 0 }).format(n)}`
    : formatCurrency(n);


export const formatDate = (d: string) => {
  // Parse YYYY-MM-DD as local date to avoid UTC timezone shift
  const datePart = d.includes("T") ? d.split("T")[0] : d;
  const [y, m, day] = datePart.split("-").map(Number);
  if (!y || !m || !day) return new Date(d).toLocaleDateString("es-AR");
  return new Date(y, m - 1, day).toLocaleDateString("es-AR");
};

export const MARCAS = [
  "Chevrolet", "Fiat", "Ford", "Honda", "Hyundai", "Jeep", "Nissan", "Peugeot",
  "Renault", "Toyota", "Volkswagen", "Citroën", "Audi", "BMW", "Mercedes-Benz", "Otra"
];

export const ESTADOS = [
  "Disponible", "Reservado", "Vendido", "En chapista", "En mecánico"
];

export const CATEGORIAS_GASTO = [
  "Auto", "Local", "Escribanía", "Mecánica", "Chapista", "Gestora", "Publicidad", "Otro"
];

export const ANIOS = Array.from({ length: 37 }, (_, i) => 2026 - i);
