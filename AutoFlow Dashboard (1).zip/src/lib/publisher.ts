import { supabase } from "@/integrations/supabase/client";

export type Channel = "mercadolibre" | "instagram" | "facebook";

export const CHANNELS: { id: Channel; label: string }[] = [
  { id: "mercadolibre", label: "Mercado Libre" },
  { id: "instagram", label: "Instagram" },
  { id: "facebook", label: "Facebook" },
];

export const channelLabel = (c: Channel | string) =>
  CHANNELS.find((x) => x.id === c)?.label ?? c;

export const VEHICLE_STATUS: Record<string, string> = {
  draft: "Borrador",
  available: "Disponible",
  reserved: "Reservado",
  sold: "Vendido",
};

export const PUBLICATION_STATUS: Record<string, { label: string; tone: string }> = {
  draft: { label: "Sin publicar", tone: "bg-muted text-muted-foreground border-border" },
  validating: { label: "Validando", tone: "bg-blue-500/10 text-blue-600 border-blue-500/30" },
  queued: { label: "En cola", tone: "bg-blue-500/10 text-blue-600 border-blue-500/30" },
  publishing: { label: "Publicando", tone: "bg-blue-500/10 text-blue-600 border-blue-500/30" },
  published: { label: "Publicado", tone: "bg-emerald-500/10 text-emerald-600 border-emerald-500/30" },
  partial: { label: "Publicado con avisos", tone: "bg-amber-500/10 text-amber-600 border-amber-500/30" },
  failed: { label: "Falló", tone: "bg-destructive/10 text-destructive border-destructive/30" },
  paused: { label: "Pausado", tone: "bg-amber-500/10 text-amber-600 border-amber-500/30" },
  closed: { label: "Finalizado", tone: "bg-muted text-muted-foreground border-border" },
};

export const pubStatus = (s?: string | null) =>
  PUBLICATION_STATUS[s ?? "draft"] ?? PUBLICATION_STATUS.draft;

export type ValidationIssue = { channel: string; missing: string[]; warnings: string[] };

export async function callFn<T = any>(name: string, body: unknown): Promise<T> {
  const { data, error } = await supabase.functions.invoke(name, { body });
  if (error) {
    // El cuerpo del error trae el mensaje legible que devuelve la función.
    let message = error.message;
    try {
      const ctx = (error as any).context;
      const parsed = ctx && typeof ctx.json === "function" ? await ctx.json() : null;
      if (parsed?.error) message = parsed.error;
      if (parsed?.validation) throw Object.assign(new Error(parsed.error || "Faltan datos"), { validation: parsed.validation });
    } catch (e) {
      if ((e as any)?.validation) throw e;
    }
    throw new Error(message);
  }
  if ((data as any)?.error) throw new Error((data as any).error);
  return data as T;
}

export const money = (n: number | null | undefined, currency = "ARS") =>
  n == null ? "—" : `${currency === "USD" ? "USD " : "$"}${new Intl.NumberFormat("es-AR", { maximumFractionDigits: 0 }).format(n)}`;

/** Vista previa del texto por canal, tal cual se enviará. */
export function previewText(vehicle: any, channel: Channel) {
  if (channel === "mercadolibre")
    return (vehicle.description || "")
      .replace(/https?:\/\/\S+/g, "")
      .replace(/\b\d[\d\s.-]{6,}\b/g, "")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  if (channel === "facebook") return (vehicle.facebook_message || vehicle.description || "").trim();
  const tags = (vehicle.hashtags || []).map((h: string) => (h.startsWith("#") ? h : `#${h}`)).join(" ");
  return [(vehicle.instagram_caption || vehicle.description || "").trim(), tags].filter(Boolean).join("\n\n");
}
