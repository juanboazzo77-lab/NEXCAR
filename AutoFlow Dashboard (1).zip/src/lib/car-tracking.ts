// Registro de eventos de vehículos del sitio público (visitas, favoritos, consultas).
// Alimenta el módulo "Inteligencia de stock" del administrador.
import { supabase } from "@/integrations/supabase/client";

export type CarEventType = "view" | "favorite" | "unfavorite" | "inquiry" | "whatsapp" | "reserve";

const VISITOR_KEY = "public_visitor_id_v1";
const SEEN_KEY = "public_seen_views_v1";
const VIEW_TTL_MS = 30 * 60 * 1000; // una visita por auto cada 30 minutos

function visitorId(): string {
  if (typeof window === "undefined") return "server";
  let id = window.localStorage.getItem(VISITOR_KEY);
  if (!id) {
    id = (crypto?.randomUUID?.() ?? `v-${Date.now()}-${Math.random().toString(36).slice(2)}`);
    window.localStorage.setItem(VISITOR_KEY, id);
  }
  return id;
}

function alreadyViewed(carId: string): boolean {
  if (typeof window === "undefined") return true;
  try {
    const map = JSON.parse(window.localStorage.getItem(SEEN_KEY) || "{}");
    const now = Date.now();
    if (map[carId] && now - map[carId] < VIEW_TTL_MS) return true;
    map[carId] = now;
    window.localStorage.setItem(SEEN_KEY, JSON.stringify(map));
    return false;
  } catch {
    return false;
  }
}

/** Nunca rompe la UI pública: los errores se ignoran silenciosamente. */
export async function trackCarEvent(carId: string, type: CarEventType, source?: string) {
  if (!carId) return;
  if (type === "view" && alreadyViewed(carId)) return;
  try {
    await (supabase as any).from("car_events").insert({
      car_id: carId,
      event_type: type,
      visitor_id: visitorId(),
      source: source ?? null,
    });
  } catch {
    /* noop */
  }
}
