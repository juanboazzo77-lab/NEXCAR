import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import logoUrl from "@/assets/logo-boazzo.png";

const BRAND = {
  red: [220, 38, 38] as [number, number, number],
  black: [15, 15, 15] as [number, number, number],
  gray: [110, 110, 110] as [number, number, number],
  light: [245, 245, 245] as [number, number, number],
};

export const COMPANY = {
  name: "Grupo Boazzo Automotores",
  cuit: "",
  address: "",
  phone: "",
  email: "",
  web: "",
};

/** Marca los PDFs con los datos de la agencia logueada (cada agencia tiene los suyos). */
export function setCompanyBranding(b: Partial<typeof COMPANY> & { logo_url?: string | null }) {
  COMPANY.name = b.name || COMPANY.name;
  COMPANY.address = b.address ?? COMPANY.address;
  COMPANY.phone = b.phone ?? COMPANY.phone;
  COMPANY.email = b.email ?? COMPANY.email;
  COMPANY.web = b.web ?? COMPANY.web;
  if (b.logo_url !== undefined) { customLogo = b.logo_url || null; cachedLogo = null; }
}

let customLogo: string | null = null;
let cachedLogo: string | null = null;
async function getLogo(): Promise<string> {
  if (cachedLogo) return cachedLogo;
  const res = await fetch(customLogo || logoUrl);
  const blob = await res.blob();
  cachedLogo = await new Promise<string>((resolve) => {
    const r = new FileReader();
    r.onloadend = () => resolve(r.result as string);
    r.readAsDataURL(blob);
  });
  return cachedLogo;
}

const fmtCurrency = (n: number) =>
  new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 }).format(n || 0);

const fmtDate = (d?: string) => {
  if (!d) return new Date().toLocaleDateString("es-AR");
  const dt = d.includes("T") ? new Date(d) : new Date(d + "T00:00:00");
  return dt.toLocaleDateString("es-AR");
};

async function header(doc: jsPDF, title: string, subtitle?: string) {
  const logo = await getLogo();
  // Black header band
  doc.setFillColor(...BRAND.black);
  doc.rect(0, 0, 210, 32, "F");
  // Logo
  doc.addImage(logo, "PNG", 12, 5, 22, 22);
  // Company name
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(14);
  doc.text(COMPANY.name.toUpperCase(), 40, 14);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(200, 200, 200);
  const meta = [COMPANY.address, COMPANY.phone, COMPANY.email].filter(Boolean).join("  •  ");
  if (meta) doc.text(meta, 40, 20);
  // Red accent
  doc.setFillColor(...BRAND.red);
  doc.rect(0, 32, 210, 2, "F");

  // Title block
  doc.setTextColor(...BRAND.black);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.text(title.toUpperCase(), 12, 46);
  if (subtitle) {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(...BRAND.gray);
    doc.text(subtitle, 12, 52);
  }
  // Date right
  doc.setFontSize(9);
  doc.setTextColor(...BRAND.gray);
  doc.text(`Fecha: ${fmtDate()}`, 198, 46, { align: "right" });
}

function footer(doc: jsPDF) {
  const pageH = doc.internal.pageSize.getHeight();
  doc.setDrawColor(...BRAND.red);
  doc.setLineWidth(0.5);
  doc.line(12, pageH - 18, 198, pageH - 18);
  doc.setFontSize(8);
  doc.setTextColor(...BRAND.gray);
  doc.text(COMPANY.name, 12, pageH - 12);
  doc.text("Documento generado electrónicamente", 198, pageH - 12, { align: "right" });
}

function section(doc: jsPDF, title: string, y: number): number {
  doc.setFillColor(...BRAND.light);
  doc.rect(12, y, 186, 7, "F");
  doc.setFillColor(...BRAND.red);
  doc.rect(12, y, 2, 7, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(...BRAND.black);
  doc.text(title.toUpperCase(), 17, y + 5);
  return y + 12;
}

function kvGrid(doc: jsPDF, rows: [string, string][], y: number, cols = 2): number {
  doc.setFontSize(9);
  const colW = 186 / cols;
  let rowY = y;
  rows.forEach((r, i) => {
    const c = i % cols;
    if (c === 0 && i !== 0) rowY += 7;
    const x = 12 + c * colW;
    doc.setTextColor(...BRAND.gray);
    doc.setFont("helvetica", "normal");
    doc.text(r[0] + ":", x, rowY);
    doc.setTextColor(...BRAND.black);
    doc.setFont("helvetica", "bold");
    doc.text(r[1] || "—", x + 35, rowY);
  });
  return rowY + 10;
}

function signatures(doc: jsPDF, y: number, labels: [string, string]) {
  doc.setDrawColor(...BRAND.black);
  doc.setLineWidth(0.3);
  doc.line(25, y, 90, y);
  doc.line(120, y, 185, y);
  doc.setFontSize(9);
  doc.setTextColor(...BRAND.black);
  doc.setFont("helvetica", "bold");
  doc.text(labels[0], 57.5, y + 5, { align: "center" });
  doc.text(labels[1], 152.5, y + 5, { align: "center" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(...BRAND.gray);
  doc.text("Firma y aclaración", 57.5, y + 10, { align: "center" });
  doc.text("Firma y aclaración", 152.5, y + 10, { align: "center" });
}

// ============ Tipos ============
export interface CarInfo {
  marca: string; modelo: string; anio: number | string; version?: string;
  patente?: string; color?: string; kilometros?: number | string;
  motor?: string; chasis?: string; combustible?: string;
}
export interface PersonInfo {
  nombre: string; dni: string; domicilio?: string; telefono?: string;
  email?: string; cuit?: string;
}

// ============ Presupuesto ============
export async function generatePresupuesto(opts: {
  numero?: string; cliente: PersonInfo; auto: CarInfo;
  precio: number; transferencia: number; observaciones?: string;
}) {
  const doc = new jsPDF();
  await header(doc, "Presupuesto", opts.numero ? `N° ${opts.numero}` : undefined);
  let y = 62;
  y = section(doc, "Datos del cliente", y);
  y = kvGrid(doc, [
    ["Nombre", opts.cliente.nombre],
    ["DNI / CUIT", opts.cliente.dni || opts.cliente.cuit || ""],
    ["Teléfono", opts.cliente.telefono || ""],
    ["Email", opts.cliente.email || ""],
    ["Domicilio", opts.cliente.domicilio || ""],
  ], y);

  y = section(doc, "Vehículo", y);
  y = kvGrid(doc, [
    ["Marca", opts.auto.marca],
    ["Modelo", opts.auto.modelo],
    ["Año", String(opts.auto.anio)],
    ["Versión", opts.auto.version || ""],
    ["Kilómetros", String(opts.auto.kilometros ?? "")],
    ["Color", opts.auto.color || ""],
    ["Patente", opts.auto.patente || ""],
  ], y);

  y = section(doc, "Detalle económico", y);
  autoTable(doc, {
    startY: y,
    head: [["Concepto", "Importe"]],
    body: [
      ["Precio del vehículo", fmtCurrency(opts.precio)],
      ["Gastos de transferencia", fmtCurrency(opts.transferencia)],
      [{ content: "TOTAL", styles: { fontStyle: "bold", fillColor: BRAND.black, textColor: 255 } },
       { content: fmtCurrency(opts.precio + opts.transferencia), styles: { fontStyle: "bold", fillColor: BRAND.black, textColor: 255 } }],
    ],
    theme: "grid",
    headStyles: { fillColor: BRAND.red, textColor: 255 },
    margin: { left: 12, right: 12 },
  });
  y = (doc as any).lastAutoTable.finalY + 10;

  if (opts.observaciones) {
    y = section(doc, "Observaciones", y);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(...BRAND.black);
    doc.text(doc.splitTextToSize(opts.observaciones, 186), 12, y);
  }

  footer(doc);
  doc.save(`Presupuesto-${opts.auto.marca}-${opts.auto.modelo}.pdf`);
}

// ============ Boleto Compra/Venta ============
export async function generateBoleto(opts: {
  numero?: string; vendedor: PersonInfo; comprador: PersonInfo; auto: CarInfo;
  precio: number; sena?: number; saldo?: number; lugar?: string; fecha?: string;
  formaPago?: string;
}) {
  const doc = new jsPDF();
  await header(doc, "Boleto de Compra-Venta", opts.numero ? `N° ${opts.numero}` : undefined);
  let y = 60;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(...BRAND.black);
  const intro = `En ${opts.lugar || "_______________"}, a los ${fmtDate(opts.fecha)}, entre las partes que más abajo se identifican, se celebra el presente Boleto de Compra-Venta sujeto a las siguientes cláusulas:`;
  const introLines = doc.splitTextToSize(intro, 186);
  doc.text(introLines, 12, y);
  y += introLines.length * 3.5 + 4;

  y = section(doc, "Vendedor", y);
  y = kvGrid(doc, [
    ["Nombre", opts.vendedor.nombre], ["DNI / CUIT", opts.vendedor.dni || opts.vendedor.cuit || ""],
    ["Domicilio", opts.vendedor.domicilio || ""], ["Teléfono", opts.vendedor.telefono || ""],
  ], y);

  y = section(doc, "Comprador", y);
  y = kvGrid(doc, [
    ["Nombre", opts.comprador.nombre], ["DNI / CUIT", opts.comprador.dni || opts.comprador.cuit || ""],
    ["Domicilio", opts.comprador.domicilio || ""], ["Teléfono", opts.comprador.telefono || ""],
  ], y);

  y = section(doc, "Vehículo objeto", y);
  y = kvGrid(doc, [
    ["Marca", opts.auto.marca], ["Modelo", opts.auto.modelo],
    ["Año", String(opts.auto.anio)], ["Versión", opts.auto.version || ""],
    ["Patente", opts.auto.patente || ""], ["Color", opts.auto.color || ""],
    ["Motor", opts.auto.motor || ""], ["Chasis", opts.auto.chasis || ""],
    ["Kilómetros", String(opts.auto.kilometros ?? "")], ["Combustible", opts.auto.combustible || ""],
  ], y);

  y = section(doc, "Precio y forma de pago", y);
  const saldo = opts.saldo ?? (opts.precio - (opts.sena || 0));
  autoTable(doc, {
    startY: y,
    body: [
      ["Precio total", fmtCurrency(opts.precio)],
      ["Seña / Entrega", fmtCurrency(opts.sena || 0)],
      ["Saldo", fmtCurrency(saldo)],
      ["Forma de pago", opts.formaPago || "—"],
    ],
    theme: "grid",
    styles: { fontSize: 8, cellPadding: 1.5 },
    columnStyles: { 0: { fontStyle: "bold", fillColor: BRAND.light, cellWidth: 60 } },
    margin: { left: 12, right: 12 },
  });
  y = (doc as any).lastAutoTable.finalY + 4;

  doc.setFontSize(7);
  doc.setTextColor(...BRAND.gray);
  const clausulas = `El COMPRADOR declara conocer y aceptar el estado del vehículo. El VENDEDOR garantiza la libre disponibilidad del mismo. La transferencia se realizará en el Registro Automotor correspondiente, siendo los gastos de transferencia a cargo de ${opts.comprador.nombre || "EL COMPRADOR"}. En prueba de conformidad se firman dos ejemplares de un mismo tenor y a un solo efecto.`;
  const cLines = doc.splitTextToSize(clausulas, 186);
  doc.text(cLines, 12, y);
  y += cLines.length * 3 + 4;

  const pageH = doc.internal.pageSize.getHeight();
  const sigY = Math.min(Math.max(y + 8, 248), pageH - 28);
  signatures(doc, sigY, ["VENDEDOR", "COMPRADOR"]);

  footer(doc);
  doc.save(`Boleto-${opts.auto.marca}-${opts.auto.modelo}.pdf`);
}

// ============ Recibo ============
export async function generateRecibo(opts: {
  numero?: string; recibiDe: PersonInfo; monto: number; concepto: string;
  formaPago?: string; auto?: CarInfo;
}) {
  const doc = new jsPDF();
  await header(doc, "Recibo", opts.numero ? `N° ${opts.numero}` : undefined);
  let y = 62;

  doc.setFillColor(...BRAND.black);
  doc.rect(12, y, 186, 14, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(14);
  doc.text(`Importe: ${fmtCurrency(opts.monto)}`, 105, y + 9, { align: "center" });
  y += 22;

  y = section(doc, "Recibí de", y);
  y = kvGrid(doc, [
    ["Nombre", opts.recibiDe.nombre],
    ["DNI / CUIT", opts.recibiDe.dni || opts.recibiDe.cuit || ""],
    ["Domicilio", opts.recibiDe.domicilio || ""],
    ["Teléfono", opts.recibiDe.telefono || ""],
  ], y);

  y = section(doc, "Concepto", y);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(...BRAND.black);
  doc.text(doc.splitTextToSize(opts.concepto, 186), 12, y);
  y += 14;

  if (opts.auto) {
    y = section(doc, "Vehículo relacionado", y);
    y = kvGrid(doc, [
      ["Marca", opts.auto.marca], ["Modelo", opts.auto.modelo],
      ["Año", String(opts.auto.anio)], ["Patente", opts.auto.patente || ""],
    ], y);
  }

  y = kvGrid(doc, [["Forma de pago", opts.formaPago || "Efectivo"]], y);

  signatures(doc, Math.max(y + 30, 220), ["RECIBIDO POR", "ENTREGADO POR"]);
  footer(doc);
  doc.save(`Recibo-${opts.recibiDe.nombre.replace(/\s+/g, "_")}.pdf`);
}

// ============ Cuotas ============
export async function generateCuotas(opts: {
  cliente: PersonInfo; auto?: CarInfo; total: number;
  cuotas: { numero: number; fecha: string; monto: number; estado?: string }[];
  observaciones?: string;
}) {
  const doc = new jsPDF();
  await header(doc, "Plan de Cuotas");
  let y = 62;

  y = section(doc, "Cliente", y);
  y = kvGrid(doc, [
    ["Nombre", opts.cliente.nombre], ["DNI / CUIT", opts.cliente.dni || opts.cliente.cuit || ""],
    ["Teléfono", opts.cliente.telefono || ""], ["Email", opts.cliente.email || ""],
  ], y);

  if (opts.auto) {
    y = section(doc, "Vehículo", y);
    y = kvGrid(doc, [
      ["Marca", opts.auto.marca], ["Modelo", opts.auto.modelo],
      ["Año", String(opts.auto.anio)], ["Patente", opts.auto.patente || ""],
    ], y);
  }

  y = section(doc, "Detalle de cuotas", y);
  autoTable(doc, {
    startY: y,
    head: [["Cuota", "Vencimiento", "Monto", "Estado"]],
    body: opts.cuotas.map(c => [
      String(c.numero), fmtDate(c.fecha), fmtCurrency(c.monto), c.estado || "Pendiente"
    ]),
    foot: [[
      { content: "TOTAL", colSpan: 2, styles: { halign: "right", fontStyle: "bold" } },
      { content: fmtCurrency(opts.total), styles: { fontStyle: "bold" } }, ""
    ]],
    theme: "grid",
    headStyles: { fillColor: BRAND.red, textColor: 255 },
    footStyles: { fillColor: BRAND.black, textColor: 255 },
    margin: { left: 12, right: 12 },
  });
  y = (doc as any).lastAutoTable.finalY + 8;

  if (opts.observaciones) {
    y = section(doc, "Observaciones", y);
    doc.setFontSize(9);
    doc.setTextColor(...BRAND.black);
    doc.text(doc.splitTextToSize(opts.observaciones, 186), 12, y);
    y += 10;
  }

  signatures(doc, Math.max(y + 20, 240), ["CLIENTE", COMPANY.name.toUpperCase()]);
  footer(doc);
  doc.save(`Cuotas-${opts.cliente.nombre.replace(/\s+/g, "_")}.pdf`);
}


// ============ Simulación de financiación ============
export async function generateSimulacionFinanciacion(opts: {
  cliente?: PersonInfo;
  auto?: CarInfo;
  precio: number;
  entrega: number;
  planes: { cuotas: number; tasaAnual: number; gastosPorcentaje: number }[];
  primeraFecha?: string;
  observaciones?: string;
}) {
  const doc = new jsPDF();
  await header(doc, "Simulación de Financiación", "Valores estimados, sujetos a aprobación crediticia");
  let y = 62;

  if (opts.cliente?.nombre) {
    y = section(doc, "Cliente", y);
    y = kvGrid(doc, [
      ["Nombre", opts.cliente.nombre], ["DNI / CUIT", opts.cliente.dni || opts.cliente.cuit || ""],
      ["Teléfono", opts.cliente.telefono || ""], ["Email", opts.cliente.email || ""],
    ], y);
  }

  if (opts.auto?.marca) {
    y = section(doc, "Vehículo", y);
    y = kvGrid(doc, [
      ["Marca", opts.auto.marca], ["Modelo", opts.auto.modelo],
      ["Año", String(opts.auto.anio || "")], ["Versión", opts.auto.version || ""],
      ["Patente", opts.auto.patente || ""], ["Kilómetros", String(opts.auto.kilometros || "")],
    ], y);
  }

  const aFinanciarBase = Math.max(0, opts.precio - opts.entrega);
  y = section(doc, "Condiciones", y);
  y = kvGrid(doc, [
    ["Precio", fmtCurrency(opts.precio)], ["Entrega inicial", fmtCurrency(opts.entrega)],
    ["Saldo a financiar", fmtCurrency(aFinanciarBase)], ["Fecha", fmtDate(opts.primeraFecha)],
  ], y);

  const calc = (p: { cuotas: number; tasaAnual: number; gastosPorcentaje: number }) => {
    const gastos = (aFinanciarBase * (p.gastosPorcentaje || 0)) / 100;
    const financiado = aFinanciarBase + gastos;
    const i = (p.tasaAnual || 0) / 100 / 12;
    const cuota = p.cuotas > 0
      ? (i > 0 ? (financiado * i) / (1 - Math.pow(1 + i, -p.cuotas)) : financiado / p.cuotas)
      : 0;
    return { gastos, financiado, cuota, totalCuotas: cuota * p.cuotas, totalFinal: cuota * p.cuotas + opts.entrega };
  };

  y = section(doc, "Opciones de financiación", y);
  autoTable(doc, {
    startY: y,
    head: [["Plan", "Cuotas", "Valor cuota", "Tasa anual", "Total financiado", "Total a pagar"]],
    body: opts.planes.map((p, idx) => {
      const r = calc(p);
      return [
        `Opción ${idx + 1}`, `${p.cuotas}`, fmtCurrency(r.cuota), `${p.tasaAnual}%`,
        fmtCurrency(r.financiado), fmtCurrency(r.totalFinal),
      ];
    }),
    theme: "grid",
    headStyles: { fillColor: BRAND.red, textColor: 255 },
    margin: { left: 12, right: 12 },
    styles: { fontSize: 9 },
  });
  y = (doc as any).lastAutoTable.finalY + 8;

  // Cronograma de la primera opción
  const first = opts.planes[0];
  if (first && first.cuotas > 0 && first.cuotas <= 60) {
    const r = calc(first);
    const base = opts.primeraFecha ? new Date(opts.primeraFecha + "T00:00:00") : new Date();
    const rows: any[] = [];
    for (let n = 1; n <= first.cuotas; n++) {
      const d = new Date(base);
      d.setMonth(d.getMonth() + n);
      rows.push([String(n), d.toLocaleDateString("es-AR"), fmtCurrency(r.cuota)]);
    }
    if (y > 220) { doc.addPage(); y = 20; }
    y = section(doc, `Cronograma estimado - Opción 1 (${first.cuotas} cuotas)`, y);
    autoTable(doc, {
      startY: y,
      head: [["Cuota", "Vencimiento", "Monto"]],
      body: rows,
      foot: [[{ content: "TOTAL EN CUOTAS", colSpan: 2, styles: { halign: "right", fontStyle: "bold" } },
        { content: fmtCurrency(r.totalCuotas), styles: { fontStyle: "bold" } }]],
      theme: "grid",
      headStyles: { fillColor: BRAND.black, textColor: 255 },
      footStyles: { fillColor: BRAND.black, textColor: 255 },
      margin: { left: 12, right: 12 },
      styles: { fontSize: 8 },
    });
    y = (doc as any).lastAutoTable.finalY + 8;
  }

  if (y > 250) { doc.addPage(); y = 20; }
  if (opts.observaciones) {
    y = section(doc, "Observaciones", y);
    doc.setFontSize(9);
    doc.setTextColor(...BRAND.black);
    doc.text(doc.splitTextToSize(opts.observaciones, 186), 12, y);
    y += 12;
  }
  doc.setFontSize(8);
  doc.setTextColor(...BRAND.gray);
  doc.text(doc.splitTextToSize(
    "Los valores expresados son una simulación orientativa y pueden variar según la entidad financiera, la fecha de otorgamiento y las condiciones de aprobación crediticia. No constituye oferta ni compromiso de otorgamiento.",
    186), 12, y);

  footer(doc);
  const nom = opts.cliente?.nombre ? `-${opts.cliente.nombre.replace(/\s+/g, "_")}` : "";
  doc.save(`Financiacion${nom}.pdf`);
}

// ============ Contrato ============
export async function generateContrato(opts: {
  titulo?: string; vendedor: PersonInfo; comprador: PersonInfo;
  auto: CarInfo; precio: number; clausulas: string; lugar?: string; fecha?: string;
}) {
  const doc = new jsPDF();
  await header(doc, opts.titulo || "Contrato");
  let y = 62;

  doc.setFontSize(9);
  doc.setTextColor(...BRAND.black);
  doc.text(doc.splitTextToSize(
    `En ${opts.lugar || "_____________"}, a los ${fmtDate(opts.fecha)}, entre:`, 186), 12, y);
  y += 10;

  y = section(doc, "Parte vendedora", y);
  y = kvGrid(doc, [
    ["Nombre", opts.vendedor.nombre], ["DNI / CUIT", opts.vendedor.dni || opts.vendedor.cuit || ""],
    ["Domicilio", opts.vendedor.domicilio || ""], ["Teléfono", opts.vendedor.telefono || ""],
  ], y);

  y = section(doc, "Parte compradora", y);
  y = kvGrid(doc, [
    ["Nombre", opts.comprador.nombre], ["DNI / CUIT", opts.comprador.dni || opts.comprador.cuit || ""],
    ["Domicilio", opts.comprador.domicilio || ""], ["Teléfono", opts.comprador.telefono || ""],
  ], y);

  y = section(doc, "Objeto", y);
  y = kvGrid(doc, [
    ["Marca/Modelo", `${opts.auto.marca} ${opts.auto.modelo}`],
    ["Año", String(opts.auto.anio)], ["Patente", opts.auto.patente || ""],
    ["Motor", opts.auto.motor || ""], ["Chasis", opts.auto.chasis || ""],
    ["Precio", fmtCurrency(opts.precio)],
  ], y);

  y = section(doc, "Cláusulas", y);
  doc.setFontSize(9);
  doc.setTextColor(...BRAND.black);
  const lines = doc.splitTextToSize(opts.clausulas, 186);
  lines.forEach((line: string) => {
    if (y > 260) { doc.addPage(); y = 20; }
    doc.text(line, 12, y);
    y += 5;
  });
  y += 10;

  if (y > 240) { doc.addPage(); y = 30; }
  signatures(doc, y + 10, ["VENDEDOR", "COMPRADOR"]);
  footer(doc);
  doc.save(`Contrato-${opts.auto.marca}-${opts.auto.modelo}.pdf`);
}

// ============ Ficha técnica ============
export async function generateFichaTecnica(opts: { auto: CarInfo; precio?: number; observaciones?: string }) {
  const doc = new jsPDF();
  await header(doc, "Ficha Técnica", `${opts.auto.marca} ${opts.auto.modelo} ${opts.auto.anio}`);
  let y = 62;

  y = section(doc, "Identificación del vehículo", y);
  y = kvGrid(doc, [
    ["Marca", opts.auto.marca], ["Modelo", opts.auto.modelo],
    ["Año", String(opts.auto.anio)], ["Versión", opts.auto.version || ""],
    ["Patente", opts.auto.patente || ""], ["Color", opts.auto.color || ""],
  ], y);

  y = section(doc, "Datos técnicos", y);
  y = kvGrid(doc, [
    ["Motor", opts.auto.motor || ""], ["Chasis", opts.auto.chasis || ""],
    ["Combustible", opts.auto.combustible || ""], ["Kilómetros", String(opts.auto.kilometros ?? "")],
  ], y);

  if (opts.precio) {
    y = section(doc, "Precio", y);
    doc.setFillColor(...BRAND.red);
    doc.rect(12, y, 186, 14, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.text(fmtCurrency(opts.precio), 105, y + 9, { align: "center" });
    y += 22;
  }

  if (opts.observaciones) {
    y = section(doc, "Observaciones", y);
    doc.setFontSize(9);
    doc.setTextColor(...BRAND.black);
    doc.text(doc.splitTextToSize(opts.observaciones, 186), 12, y);
  }

  footer(doc);
  doc.save(`Ficha-${opts.auto.marca}-${opts.auto.modelo}.pdf`);
}

// ============ Carátula Documentación ============
export interface DocCaratulaField {
  label: string;
  value: string;
  status?: "ok" | "warn" | "danger" | "pending" | "none";
  hint?: string;
}
export async function generateCaratulaDocs(opts: {
  auto: CarInfo;
  ubicacion?: string;
  campos: DocCaratulaField[];
  observaciones?: string;
}) {
  const doc = new jsPDF();
  await header(doc, "Carátula de documentación", `${opts.auto.marca} ${opts.auto.modelo} — ${opts.auto.patente || "s/patente"}`);
  let y = 62;

  y = section(doc, "Datos del vehículo", y);
  y = kvGrid(doc, [
    ["Marca", String(opts.auto.marca || "—")],
    ["Modelo", String(opts.auto.modelo || "—")],
    ["Año", String(opts.auto.anio || "—")],
    ["Patente", String(opts.auto.patente || "—")],
    ["Color", String(opts.auto.color || "—")],
    ["Kilómetros", opts.auto.kilometros ? String(opts.auto.kilometros) : "—"],
    ["Motor", String(opts.auto.motor || "—")],
    ["Chasis", String(opts.auto.chasis || "—")],
    ["Combustible", String(opts.auto.combustible || "—")],
    ["Ubicación", String(opts.ubicacion || "—")],
  ], y, 2);

  y = section(doc, "Estado de documentación", y);

  const colorFor = (s?: string): [number, number, number] => {
    switch (s) {
      case "ok": return [22, 163, 74];
      case "warn": return [217, 119, 6];
      case "danger": return [220, 38, 38];
      case "pending": return [37, 99, 235];
      default: return [110, 110, 110];
    }
  };

  const colW = 93;
  const rowH = 14;
  doc.setFontSize(9);
  opts.campos.forEach((f, i) => {
    const c = i % 2;
    if (c === 0 && i !== 0) y += rowH;
    const x = 12 + c * colW;
    // Card background
    doc.setFillColor(250, 250, 250);
    doc.rect(x, y - 4, colW - 2, rowH - 2, "F");
    // Status stripe
    const [r, g, b] = colorFor(f.status);
    doc.setFillColor(r, g, b);
    doc.rect(x, y - 4, 1.5, rowH - 2, "F");
    // Label
    doc.setTextColor(...BRAND.gray);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.text(f.label.toUpperCase(), x + 4, y);
    // Value
    doc.setTextColor(...BRAND.black);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    const val = doc.splitTextToSize(f.value || "—", colW - 8)[0] || "—";
    doc.text(val, x + 4, y + 5);
    // Hint
    if (f.hint) {
      doc.setFont("helvetica", "normal");
      doc.setFontSize(7);
      doc.setTextColor(r, g, b);
      doc.text(f.hint, x + 4, y + 9);
    }
  });
  y += rowH + 4;

  if (opts.observaciones) {
    y = section(doc, "Observaciones", y);
    doc.setFontSize(9);
    doc.setTextColor(...BRAND.black);
    doc.text(doc.splitTextToSize(opts.observaciones, 186), 12, y);
    y += 20;
  }

  // Checklist / notas manuales
  y = section(doc, "Notas / pendientes", y);
  doc.setDrawColor(...BRAND.gray);
  doc.setLineWidth(0.2);
  for (let i = 0; i < 5; i++) {
    doc.line(12, y + i * 8, 198, y + i * 8);
  }

  footer(doc);
  doc.save(`Caratula-${opts.auto.marca}-${opts.auto.modelo}-${opts.auto.patente || ""}.pdf`);
}
