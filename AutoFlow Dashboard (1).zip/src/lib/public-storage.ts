// LocalStorage helpers para favoritos y comparador del sitio público.
// No requieren cuenta: viven solo en el navegador del cliente.

const FAV_KEY = "public_favoritos_v1";
const CMP_KEY = "public_compare_v1";

function read(key: string): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr.filter((x) => typeof x === "string") : [];
  } catch {
    return [];
  }
}

function write(key: string, ids: string[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(ids));
    window.dispatchEvent(new CustomEvent("public-storage-change", { detail: { key } }));
  } catch {}
}

export const Favoritos = {
  list: () => read(FAV_KEY),
  has: (id: string) => read(FAV_KEY).includes(id),
  toggle: (id: string) => {
    const cur = read(FAV_KEY);
    const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
    write(FAV_KEY, next);
    return next.includes(id);
  },
  remove: (id: string) => write(FAV_KEY, read(FAV_KEY).filter((x) => x !== id)),
  clear: () => write(FAV_KEY, []),
};

export const Compare = {
  MAX: 3,
  list: () => read(CMP_KEY),
  has: (id: string) => read(CMP_KEY).includes(id),
  toggle: (id: string): { active: boolean; reason?: string } => {
    const cur = read(CMP_KEY);
    if (cur.includes(id)) {
      write(CMP_KEY, cur.filter((x) => x !== id));
      return { active: false };
    }
    if (cur.length >= Compare.MAX) {
      return { active: false, reason: `Máximo ${Compare.MAX} vehículos para comparar.` };
    }
    write(CMP_KEY, [...cur, id]);
    return { active: true };
  },
  remove: (id: string) => write(CMP_KEY, read(CMP_KEY).filter((x) => x !== id)),
  clear: () => write(CMP_KEY, []),
};

export function usePublicListKey(key: "fav" | "cmp") {
  // simple hook utility consumers can build on top of
  return key === "fav" ? FAV_KEY : CMP_KEY;
}
