export type Channel = "website" | "mercadolibre" | "facebook" | "instagram";

export const CHANNELS: { id: Channel; label: string; short: string }[] = [
  { id: "website", label: "Página web", short: "Web" },
  { id: "mercadolibre", label: "Mercado Libre", short: "ML" },
  { id: "facebook", label: "Facebook", short: "FB" },
  { id: "instagram", label: "Instagram", short: "IG" },
];

type StatusMeta = { label: string; tone: "ok" | "warn" | "error" | "idle" | "busy"; icon: string };

export const STATUS_META: Record<string, StatusMeta> = {
  no_conectado: { label: "No conectado", tone: "idle", icon: "🔌" },
  no_publicado: { label: "No publicado", tone: "idle", icon: "⚪" },
  pendiente_validacion: { label: "Pendiente de validación", tone: "warn", icon: "⏳" },
  validando: { label: "Validando", tone: "busy", icon: "🔎" },
  listo: { label: "Listo para publicar", tone: "warn", icon: "✅" },
  en_cola: { label: "En cola", tone: "busy", icon: "⏱️" },
  publicando: { label: "Publicando", tone: "busy", icon: "🚀" },
  procesando: { label: "Procesando", tone: "busy", icon: "⚙️" },
  publicado: { label: "Publicado", tone: "ok", icon: "✔️" },
  publicado_advertencias: { label: "Publicado con advertencias", tone: "warn", icon: "⚠️" },
  sin_cambios: { label: "Sin cambios", tone: "ok", icon: "✔️" },
  error_validacion: { label: "Error de validación", tone: "error", icon: "✖️" },
  error_autorizacion: { label: "Error de autorización", tone: "error", icon: "🔑" },
  error_conexion: { label: "Error de conexión", tone: "error", icon: "📡" },
  error_plataforma: { label: "Error de la plataforma", tone: "error", icon: "✖️" },
  error: { label: "Error", tone: "error", icon: "✖️" },
  requiere_correccion: { label: "Requiere corrección", tone: "error", icon: "✏️" },
  actualizando: { label: "Actualizando", tone: "busy", icon: "🔄" },
  actualizado: { label: "Actualizado", tone: "ok", icon: "✔️" },
  pausado: { label: "Pausado", tone: "warn", icon: "⏸️" },
  finalizado: { label: "Finalizado", tone: "idle", icon: "🏁" },
};

export const statusMeta = (s?: string | null): StatusMeta =>
  STATUS_META[s ?? "no_publicado"] ?? { label: s ?? "—", tone: "idle", icon: "•" };

export const toneClass = (tone: StatusMeta["tone"]) =>
  ({
    ok: "bg-emerald-500/10 text-emerald-600 border-emerald-500/30",
    warn: "bg-amber-500/10 text-amber-600 border-amber-500/30",
    error: "bg-destructive/10 text-destructive border-destructive/30",
    idle: "bg-muted text-muted-foreground border-border",
    busy: "bg-blue-500/10 text-blue-600 border-blue-500/30",
  })[tone];

export const overallLabel = (s?: string | null) =>
  ({
    publicado_completo: "Publicado completamente",
    publicado_parcial: "Publicado parcialmente",
    error_total: "Error total",
    procesando: "Procesando",
  })[s ?? ""] ?? "Sin publicar";

export const TEMPLATE_VARS = [
  "marca", "modelo", "version", "anio", "kilometros", "precio", "moneda",
  "combustible", "transmision", "traccion", "descripcion", "financiacion",
  "permuta", "ubicacion", "telefono", "whatsapp", "url_vehiculo",
];

export const DEFAULT_TEMPLATES: Record<Exclude<Channel, "website">, string> = {
  mercadolibre: `{{marca}} {{modelo}} {{version}} {{anio}}

Año: {{anio}}
Kilómetros: {{kilometros}}
Combustible: {{combustible}}
Transmisión: {{transmision}}
Tracción: {{traccion}}

{{descripcion}}

{{financiacion}}
{{permuta}}

Ubicación: {{ubicacion}}
Consultas: {{telefono}}`,
  facebook: `🚗 {{marca}} {{modelo}} {{version}}

📅 Año: {{anio}}
📍 {{kilometros}} km
⚙️ {{transmision}}
⛽ {{combustible}}
💰 Precio: {{precio}}

{{financiacion}}
{{permuta}}

Conocé todos los detalles y fotografías:
{{url_vehiculo}}

📲 Consultanos por WhatsApp: {{whatsapp}}`,
  instagram: `🚘 {{marca}} {{modelo}} {{version}}

▫️ Año {{anio}}
▫️ {{kilometros}} km
▫️ {{transmision}}
▫️ {{combustible}}

💰 {{precio}}

{{financiacion}}
{{permuta}}

📲 Escribinos para conocer más.

#{{marca}} #{{modelo}} #AutosUsados #Vehículos #Agencia`,
};

const money = (n: number | null | undefined, moneda?: string | null) =>
  n == null ? "" : `${moneda === "USD" ? "USD " : "$"}${new Intl.NumberFormat("es-AR", { maximumFractionDigits: 0 }).format(n)}`;

export function buildVars(car: any, settings?: any) {
  const url = typeof window !== "undefined" ? `${window.location.origin}/catalogo/${car.slug ?? car.id}` : "";
  return {
    marca: car.marca ?? "",
    modelo: car.modelo ?? "",
    version: car.version ?? "",
    anio: car.anio ? String(car.anio) : "",
    kilometros: car.kilometros != null ? new Intl.NumberFormat("es-AR").format(car.kilometros) : "",
    precio: money(car.precio_venta, car.moneda),
    moneda: car.moneda ?? "ARS",
    combustible: car.combustible ?? "",
    transmision: car.transmision ?? "",
    traccion: car.traccion ?? "",
    descripcion: car.descripcion_publica ?? car.descripcion_manual ?? "",
    financiacion: car.financiacion_disponible ? "✅ Financiación disponible" : "",
    permuta: car.acepta_permuta ? "✅ Tomamos permutas" : "",
    ubicacion: [car.ciudad, car.provincia].filter(Boolean).join(", ") || car.ubicacion || "",
    telefono: car.vendedor_telefono ?? settings?.whatsapp_number ?? "",
    whatsapp: car.vendedor_whatsapp ?? settings?.whatsapp_number ?? "",
    url_vehiculo: url,
  } as Record<string, string>;
}

/** Reemplaza las variables y devuelve las que quedaron vacías. */
export function renderTemplate(template: string, vars: Record<string, string>) {
  const missing: string[] = [];
  const text = template.replace(/\{\{\s*(\w+)\s*\}\}/g, (_m, key: string) => {
    const v = vars[key];
    if (!v) { if (!missing.includes(key)) missing.push(key); return ""; }
    return v;
  });
  return { text: text.replace(/\n{3,}/g, "\n\n").trim(), missing };
}
