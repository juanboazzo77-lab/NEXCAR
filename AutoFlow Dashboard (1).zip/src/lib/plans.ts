/**
 * Catálogo centralizado de planes.
 * Fuente de verdad: tabla `plans` en la base (código, límites y features).
 * Este archivo es el espejo tipado + defaults para la UI.
 */

export type PlanCode = "common" | "advanced" | "pro";

export type FeatureKey =
  | "financiero"
  | "cotizador"
  | "pdfs"
  | "turnos"
  | "stats"
  | "ia_ventas"
  | "ia_documentos"
  | "boleto"
  | "vendedor"
  | "duenio"
  | "proveedor"
  | "marketplace_priority"
  | "stock_intelligence"
  | "b2b";

export type PlanDef = {
  code: PlanCode;
  name: string;
  /** null = ilimitado */
  max_marketplace: number | null;
  max_gold: number;
  features: Record<FeatureKey, boolean>;
};

const F = (on: FeatureKey[]): Record<FeatureKey, boolean> => {
  const all: FeatureKey[] = [
    "financiero", "cotizador", "pdfs", "turnos", "stats", "ia_ventas",
    "ia_documentos", "boleto", "vendedor", "duenio", "proveedor", "marketplace_priority",
    "stock_intelligence", "b2b",
  ];
  return Object.fromEntries(all.map(k => [k, on.includes(k)])) as Record<FeatureKey, boolean>;
};

export const PLANS: Record<PlanCode, PlanDef> = {
  common: {
    code: "common",
    name: "Común",
    max_marketplace: 15,
    max_gold: 0,
    features: F([]),
  },
  advanced: {
    code: "advanced",
    name: "Avanzado",
    max_marketplace: 35,
    max_gold: 10,
    features: F(["financiero", "cotizador", "stats", "ia_documentos", "boleto", "vendedor", "duenio", "proveedor", "marketplace_priority", "stock_intelligence"]),
  },
  pro: {
    code: "pro",
    name: "Pro",
    max_marketplace: null,
    max_gold: 30,
    features: F(["financiero", "cotizador", "pdfs", "turnos", "stats", "ia_ventas", "ia_documentos", "boleto", "vendedor", "duenio", "proveedor", "marketplace_priority", "stock_intelligence", "b2b"]),
  },
};

export const PLAN_ORDER: PlanCode[] = ["common", "advanced", "pro"];

export const normalizePlan = (code?: string | null): PlanCode =>
  (code && (PLAN_ORDER as string[]).includes(code) ? code : "pro") as PlanCode;

export const FEATURE_LABELS: Record<FeatureKey, string> = {
  financiero: "Financiero",
  cotizador: "Cotizador",
  pdfs: "PDFs",
  turnos: "Turnos",
  stats: "Estadísticas",
  ia_ventas: "IA en ventas",
  ia_documentos: "Lectura IA de documentos",
  boleto: "Boleto de compraventa",
  vendedor: "Guardar vendedor",
  duenio: "Dueño del vehículo",
  proveedor: "Proveedor",
  marketplace_priority: "Publicaciones ORO (prioridad)",
  stock_intelligence: "Inteligencia de stock",
  b2b: "Red B2B entre agencias",
};

export type PlanUsage = {
  plan: PlanCode;
  marketplace_used: number;
  gold_used: number;
  silver_used: number;
  max_marketplace: number | null;
  max_gold: number | null;
  max_silver: number | null;
};

export const fmtLimit = (v: number | null | undefined) => (v == null ? "∞" : String(v));
