/** Traduce los errores de límite de plan que devuelven los triggers de la base. */
export function planErrorMessage(error: { message?: string } | null | undefined): string | null {
  const m = error?.message || "";
  if (!m) return null;
  if (m.includes("PLAN_LIMIT_MARKETPLACE") || m.includes("PLAN_LIMIT_GOLD")) {
    const clean = m.split(/PLAN_LIMIT_(?:MARKETPLACE|GOLD):\s*/)[1] || m;
    return clean.trim();
  }
  return m;
}
