import { useState, useMemo } from "react";
import { useCashMovements, useAddCashMovement, useDeleteCashMovement, useExpenses } from "@/hooks/use-data";
import { formatCurrency, formatDate, CATEGORIAS_GASTO } from "@/lib/supabase-helpers";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Trash2, TrendingUp, TrendingDown, Wallet, BarChart3 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { MoneyInput } from "@/components/MoneyInput";

export default function CajaPage() {
  const { data: movements = [] } = useCashMovements();
  const { data: expenses = [] } = useExpenses();
  const addMov = useAddCashMovement();
  const deleteMov = useDeleteCashMovement();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ tipo: "ingreso" as "ingreso" | "egreso", fecha: new Date().toISOString().split("T")[0], categoria: "", concepto: "", detalle: "", monto: 0 });

  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const monthMovements = movements.filter(m => {
    const d = new Date(m.fecha);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  });
  const monthExpenses = expenses.filter(e => {
    const d = new Date(e.fecha);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  });

  const ingresos = monthMovements.filter(m => m.tipo === "ingreso").reduce((s, m) => s + Number(m.monto), 0);
  const egresos = monthMovements.filter(m => m.tipo === "egreso").reduce((s, m) => s + Number(m.monto), 0);
  const gastosAutos = monthExpenses.reduce((s, e) => s + Number(e.monto), 0);
  const totalGastos = egresos + gastosAutos;
  const resultado = ingresos - totalGastos;

  const set = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    try {
      await addMov.mutateAsync(form);
      setOpen(false);
      toast({ title: "Movimiento agregado" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const gastosPorCategoria = useMemo(() => {
    const map: Record<string, number> = {};
    monthExpenses.forEach(e => { map[e.categoria] = (map[e.categoria] || 0) + Number(e.monto); });
    monthMovements.filter(m => m.tipo === "egreso").forEach(m => { const cat = m.categoria || "Otros"; map[cat] = (map[cat] || 0) + Number(m.monto); });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  }, [monthExpenses, monthMovements]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="page-header">Caja Diaria</h1>
        <Button size="sm" onClick={() => setOpen(true)}><Plus className="w-4 h-4 mr-1" />Nuevo movimiento</Button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="stat-card"><CardContent className="p-0">
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1"><Wallet className="w-3.5 h-3.5" />Caja disponible</div>
          <div className={`text-xl font-bold ${resultado >= 0 ? "text-success" : "text-destructive"}`}>{formatCurrency(resultado)}</div>
        </CardContent></Card>
        <Card className="stat-card"><CardContent className="p-0">
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1"><TrendingUp className="w-3.5 h-3.5" />Ingresos del mes</div>
          <div className="text-xl font-bold text-success">{formatCurrency(ingresos)}</div>
        </CardContent></Card>
        <Card className="stat-card"><CardContent className="p-0">
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1"><TrendingDown className="w-3.5 h-3.5" />Gastos del mes</div>
          <div className="text-xl font-bold text-destructive">{formatCurrency(totalGastos)}</div>
        </CardContent></Card>
        <Card className="stat-card"><CardContent className="p-0">
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1"><BarChart3 className="w-3.5 h-3.5" />Resultado</div>
          <div className={`text-xl font-bold ${resultado >= 0 ? "text-success" : "text-destructive"}`}>{formatCurrency(resultado)}</div>
        </CardContent></Card>
      </div>

      {gastosPorCategoria.length > 0 && (
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm">Gastos por categoría</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {gastosPorCategoria.map(([cat, monto]) => (
              <div key={cat} className="flex items-center justify-between text-sm">
                <span>{cat}</span>
                <span className="font-medium">{formatCurrency(monto)}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <div className="rounded-lg border overflow-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Fecha</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Categoría</TableHead>
              <TableHead>Concepto</TableHead>
              <TableHead className="text-right">Monto</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {movements.map(m => (
              <TableRow key={m.id}>
                <TableCell className="text-sm">{formatDate(m.fecha)}</TableCell>
                <TableCell><span className={`text-xs font-medium ${m.tipo === "ingreso" ? "text-success" : "text-destructive"}`}>{m.tipo === "ingreso" ? "Ingreso" : "Egreso"}</span></TableCell>
                <TableCell className="text-sm">{m.categoria || "-"}</TableCell>
                <TableCell className="text-sm">{m.concepto}</TableCell>
                <TableCell className="text-right text-sm font-medium">{formatCurrency(Number(m.monto))}</TableCell>
                <TableCell><Button variant="ghost" size="sm" onClick={() => deleteMov.mutate(m.id)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button></TableCell>
              </TableRow>
            ))}
            {movements.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground text-sm">Sin movimientos</TableCell></TableRow>}
          </TableBody>
        </Table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Nuevo movimiento</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Tipo</Label>
              <Select value={form.tipo} onValueChange={v => set("tipo", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ingreso">Ingreso</SelectItem>
                  <SelectItem value="egreso">Egreso</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Fecha</Label><Input type="date" value={form.fecha} onChange={e => set("fecha", e.target.value)} /></div>
            <div><Label>Categoría</Label><Input value={form.categoria} onChange={e => set("categoria", e.target.value)} /></div>
            <div><Label>Concepto</Label><Input value={form.concepto} onChange={e => set("concepto", e.target.value)} /></div>
            <div><Label>Monto</Label><MoneyInput value={form.monto} onValueChange={v => set("monto", v)} /></div>
          </div>
          <Button onClick={handleSave} className="w-full" disabled={addMov.isPending}>Guardar</Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
