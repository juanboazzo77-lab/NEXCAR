import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { DEFAULT_TEMPLATES, TEMPLATE_VARS, CHANNELS } from "@/lib/publicaciones";
import { Trash2 } from "lucide-react";

const CANALES = ["mercadolibre", "facebook", "instagram"] as const;

export default function PlantillasPublicacionPage() {
  const qc = useQueryClient();
  const [draft, setDraft] = useState<Record<string, { name: string; template: string }>>({});

  const { data: plantillas = [] } = useQuery({
    queryKey: ["plantillas-publicacion"],
    queryFn: async () => {
      const { data, error } = await (supabase as any).from("publication_templates").select("*").order("created_at");
      if (error) throw error;
      return data ?? [];
    },
  });

  const crear = async (channel: string) => {
    const d = draft[channel] ?? { name: "", template: "" };
    if (!d.name.trim() || !d.template.trim()) return toast.error("Completá nombre y contenido");
    const { data: userRes } = await supabase.auth.getUser();
    const { error } = await (supabase as any).from("publication_templates").insert({
      user_id: userRes.user?.id, channel, name: d.name, template: d.template,
    });
    if (error) return toast.error(error.message);
    setDraft((s) => ({ ...s, [channel]: { name: "", template: "" } }));
    qc.invalidateQueries({ queryKey: ["plantillas-publicacion"] });
    toast.success("Plantilla guardada");
  };

  const borrar = async (id: string) => {
    await (supabase as any).from("publication_templates").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["plantillas-publicacion"] });
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-semibold">Plantillas de publicaciones</h1>
        <p className="text-sm text-muted-foreground">Textos reutilizables por canal, con variables del vehículo.</p>
      </div>

      <Card className="p-3 text-xs text-muted-foreground">
        Variables disponibles: {TEMPLATE_VARS.map((v) => `{{${v}}}`).join("  ")}
      </Card>

      <Tabs defaultValue="mercadolibre">
        <TabsList>
          {CANALES.map((c) => (
            <TabsTrigger key={c} value={c}>{CHANNELS.find((x) => x.id === c)!.label}</TabsTrigger>
          ))}
        </TabsList>
        {CANALES.map((c) => (
          <TabsContent key={c} value={c} className="space-y-4 pt-4">
            <Card className="p-4 space-y-3">
              <Input placeholder="Nombre de la plantilla" value={draft[c]?.name ?? ""}
                onChange={(e) => setDraft((s) => ({ ...s, [c]: { ...(s[c] ?? { template: "" }), name: e.target.value } as any }))} />
              <Textarea rows={10} placeholder="Contenido con variables" value={draft[c]?.template ?? ""}
                onChange={(e) => setDraft((s) => ({ ...s, [c]: { ...(s[c] ?? { name: "" }), template: e.target.value } as any }))} />
              <div className="flex gap-2">
                <Button variant="outline" onClick={() =>
                  setDraft((s) => ({ ...s, [c]: { name: s[c]?.name || `Plantilla ${c}`, template: DEFAULT_TEMPLATES[c] } }))}>
                  Usar plantilla sugerida
                </Button>
                <Button onClick={() => crear(c)}>Guardar plantilla</Button>
              </div>
            </Card>

            <div className="space-y-2">
              {(plantillas as any[]).filter((p) => p.channel === c).map((p) => (
                <Card key={p.id} className="p-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-medium text-sm">{p.name}</p>
                    <Button size="icon" variant="ghost" onClick={() => borrar(p.id)}><Trash2 className="w-4 h-4" /></Button>
                  </div>
                  <pre className="text-xs whitespace-pre-wrap text-muted-foreground mt-2">{p.template}</pre>
                </Card>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
