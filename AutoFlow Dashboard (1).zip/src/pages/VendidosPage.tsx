import { useState } from "react";
import { useCars, useUpsertCar, useDeleteCar, useExpenses, useSales } from "@/hooks/use-data";
import { MARCAS, formatCurrency, getSaleMargin } from "@/lib/supabase-helpers";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Search, Trash2, RotateCcw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { NotificationPhonesCard } from "@/components/NotificationPhonesCard";

export default function VendidosPage() {
  const { data: cars = [], isLoading } = useCars();
  const { data: allExpenses = [] } = useExpenses();
  const { data: sales = [] } = useSales();
  const upsert = useUpsertCar();
  const deleteCar = useDeleteCar();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [filterMarca, setFilterMarca] = useState("all");

  const soldIds = new Set(sales.map(s => s.car_id).filter(Boolean) as string[]);
  const vendidos = cars.filter(c => {
    if (c.estado !== "Vendido" && !soldIds.has(c.id)) return false;
    const matchSearch = `${c.patente} ${c.marca} ${c.modelo} ${c.version}`.toLowerCase().includes(search.toLowerCase());
    const matchMarca = filterMarca === "all" || c.marca === filterMarca;
    return matchSearch && matchMarca;
  });

  const getExpensesTotal = (carId: string) =>
    allExpenses.filter(e => e.car_id === carId).reduce((s, e) => s + Number(e.monto), 0);

  const handleDelete = async (id: string) => {
    if (!confirm("¿Eliminar este auto?")) return;
    await deleteCar.mutateAsync(id);
    toast({ title: "Auto eliminado" });
  };

  const handleRestore = async (car: any) => {
    if (!confirm("¿Devolver este auto al stock como Disponible?")) return;
    await upsert.mutateAsync({ ...car, estado: "Disponible" });
    toast({ title: "Auto devuelto al stock" });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <h1 className="page-header">Vendidos</h1>
      </div>

      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Buscar por patente, marca, modelo..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={filterMarca} onValueChange={setFilterMarca}>
          <SelectTrigger className="w-full sm:w-40"><SelectValue placeholder="Marca" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas</SelectItem>
            {MARCAS.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <p className="text-muted-foreground text-sm">Cargando...</p>
      ) : vendidos.length === 0 ? (
        <p className="text-muted-foreground text-sm">No hay autos vendidos.</p>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {vendidos.map(car => {
            const expenses = getExpensesTotal(car.id);
            const sale = sales.find(s => s.car_id === car.id);
            const precioVenta = Number(sale?.monto ?? 0) || Number(car.precio_venta ?? 0);
            const margen = sale ? getSaleMargin({ sale, car, expensesTotal: expenses }) : precioVenta - Number(car.precio_compra) - expenses;
            return (
              <Card key={car.id} className="animate-fade-in">
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-semibold text-sm uppercase">{car.marca} {car.modelo}</div>
                      <div className="text-xs text-muted-foreground">{car.version} · {car.anio} · {car.color}</div>
                      <div className="text-xs font-mono mt-1 uppercase">{car.patente}</div>
                    </div>
                    <Badge variant="outline" className="bg-muted text-muted-foreground border-border">Vendido</Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div><span className="text-muted-foreground">Compra</span><div className="font-medium">{formatCurrency(Number(car.precio_compra))}</div></div>
                    <div><span className="text-muted-foreground">Venta</span><div className="font-medium">{formatCurrency(precioVenta)}</div></div>
                    <div><span className="text-muted-foreground">Margen</span><div className={`font-medium ${margen >= 0 ? "text-success" : "text-destructive"}`}>{formatCurrency(margen)}</div></div>
                  </div>
                  {expenses > 0 && <div className="text-xs text-muted-foreground">Gastos: {formatCurrency(expenses)}</div>}
                  <div className="flex gap-2 pt-1">
                    <Button variant="ghost" size="sm" onClick={() => handleRestore(car)} title="Devolver a stock">
                      <RotateCcw className="w-3.5 h-3.5" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDelete(car.id)}>
                      <Trash2 className="w-3.5 h-3.5 text-destructive" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
      <NotificationPhonesCard />

    </div>
  );
}
