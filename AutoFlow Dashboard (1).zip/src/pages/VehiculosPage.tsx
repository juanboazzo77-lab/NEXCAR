import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { CHANNELS, statusMeta, toneClass } from "@/lib/publicaciones";
import { formatMoney } from "@/lib/supabase-helpers";
import { Search, Car as CarIcon, Settings2 } from "lucide-react";
import { cn } from "@/lib/utils";

const FILTROS = [
  { id: "todos", label: "Todos" },
  { id: "borrador", label: "Borrador" },
  { id: "Disponible", label: "Disponible" },
  { id: "Reservado", label: "Reservado" },
  { id: "Vendido", label: "Vendido" },
  { id: "publicado", label: "Publicado" },
  { id: "parcial", label: "Publicado parcialmente" },
  { id: "errores", label: "Con errores" },
  { id: "pausado", label: "Pausado" },
];

export default function VehiculosPage() {
  const [q, setQ] = useState("");
  const [filtro, setFiltro] = useState("todos");

  const { data: cars = [], isLoading } = useQuery({
    queryKey: ["vehiculos-list"],
    queryFn: async () => {
      const { data, error } = await supabase.from("cars").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: pubs = [] } = useQuery({
    queryKey: ["vehiculos-pubs"],
    queryFn: async () => {
      const { data, error } = await (supabase as any).from("channel_publications").select("*");
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: photos = [] } = useQuery({
    queryKey: ["vehiculos-portadas"],
    queryFn: async () => {
      const { data } = await supabase.from("car_photos").select("car_id, url, es_portada, orden");
      return data ?? [];
    },
  });

  const portada = (carId: string) => {
    const list = (photos as any[]).filter((p) => p.car_id === carId);
    return (list.find((p) => p.es_portada) ?? list.sort((a, b) => a.orden - b.orden)[0])?.url as string | undefined;
  };
  const pubsOf = (carId: string) => (pubs as any[]).filter((p) => p.car_id === carId);

  const rows = useMemo(() => {
    const term = q.trim().toLowerCase();
    return (cars as any[]).filter((c) => {
      if (term) {
        const hay = [c.marca, c.modelo, c.version, c.anio, c.patente, c.internal_code]
          .filter(Boolean).join(" ").toLowerCase();
        if (!hay.includes(term)) return false;
      }
      const cp = pubsOf(c.id);
      const ok = cp.filter((p) => p.status === "publicado").length;
      const err = cp.some((p) => p.status === "error");
      switch (filtro) {
        case "todos": return true;
        case "borrador": return cp.length === 0 && !c.mostrar_publico;
        case "publicado": return ok > 0 && !err;
        case "parcial": return ok > 0 && err;
        case "errores": return err;
        case "pausado": return cp.some((p) => p.status === "pausado");
        default: return c.estado === filtro;
      }
    });
  }, [cars, pubs, q, filtro]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold flex items-center gap-2"><CarIcon className="w-6 h-6" /> Vehículos</h1>
          <p className="text-sm text-muted-foreground">Cargá una vez y publicá en todos lados.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" asChild>
            <Link to="/canales"><Settings2 className="w-4 h-4 mr-2" />Conexiones</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link to="/plantillas-publicacion"><Settings2 className="w-4 h-4 mr-2" />Plantillas</Link>
          </Button>
        </div>

      </div>

      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-3 text-muted-foreground" />
        <Input className="pl-9" placeholder="Buscar por marca, modelo, versión, año, patente o código interno"
          value={q} onChange={(e) => setQ(e.target.value)} />
      </div>

      <div className="flex flex-wrap gap-2">
        {FILTROS.map((f) => (
          <button key={f.id} onClick={() => setFiltro(f.id)}
            className={cn("px-3 py-1.5 rounded-full text-xs border transition-colors",
              filtro === f.id ? "bg-primary text-primary-foreground border-primary" : "hover:bg-accent")}>
            {f.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">Cargando vehículos...</p>
      ) : rows.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground">No hay vehículos que coincidan.</Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {rows.map((c) => {
            const cp = pubsOf(c.id);
            return (
              <Link key={c.id} to={`/vehiculos/${c.id}`}>
                <Card className="overflow-hidden hover:border-primary transition-colors h-full">
                  <div className="aspect-video bg-muted flex items-center justify-center">
                    {portada(c.id)
                      ? <img src={portada(c.id)} alt={`${c.marca} ${c.modelo}`} className="w-full h-full object-cover" loading="lazy" />
                      : <CarIcon className="w-8 h-8 text-muted-foreground" />}
                  </div>
                  <div className="p-3 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="font-medium truncate">{c.marca} {c.modelo} {c.version ?? ""}</p>
                        <p className="text-xs text-muted-foreground">
                          {c.anio} · {c.kilometros != null ? `${new Intl.NumberFormat("es-AR").format(c.kilometros)} km` : "km s/d"} · {c.estado}
                        </p>
                      </div>
                      <span className="text-sm font-semibold whitespace-nowrap">
                        {c.precio_venta ? formatMoney(Number(c.precio_venta), c.moneda) : "s/precio"}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {CHANNELS.map((ch) => {
                        const st = cp.find((p) => p.channel === ch.id)?.status;
                        const m = statusMeta(st);
                        return (
                          <span key={ch.id} className={cn("text-[10px] px-1.5 py-0.5 rounded border", toneClass(m.tone))}>
                            {m.icon} {ch.short}
                          </span>
                        );
                      })}
                    </div>
                    <p className="text-[10px] text-muted-foreground">
                      Creado {new Date(c.created_at).toLocaleDateString("es-AR")} · Actualizado {new Date(c.updated_at).toLocaleDateString("es-AR")}
                    </p>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
