import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { useAgency } from "@/hooks/useAgency";
import { HelpCircle, Plus, Trash2 } from "lucide-react";

export default function FaqAdminPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const { agency } = useAgency();
  const [faqs, setFaqs] = useState<any[]>([]);

  const load = () => {
    let q = supabase.from("public_faqs").select("*").order("orden");
    if (agency?.id) q = q.eq("agency_id", agency.id);
    return q.then(({ data }) => setFaqs(data || []));
  };
  useEffect(() => { load(); }, [agency?.id]);

  const add = async () => {
    await supabase.from("public_faqs").insert({
      owner_user_id: user?.id,
      agency_id: agency?.id ?? null,
      pregunta: "Nueva pregunta", respuesta: "Escribí la respuesta acá.",
      orden: (faqs.at(-1)?.orden ?? 0) + 1,
    });
    load();
  };
  const save = async (f: any) => {
    await supabase.from("public_faqs").update({
      pregunta: f.pregunta, respuesta: f.respuesta, orden: f.orden, activo: f.activo,
    }).eq("id", f.id);
    toast({ title: "Guardado" });
  };
  const del = async (id: string) => { if (!confirm("Eliminar?")) return; await supabase.from("public_faqs").delete().eq("id", id); load(); };

  return (
    <div className="space-y-4 max-w-3xl">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold flex items-center gap-2"><HelpCircle className="w-5 h-5" /> Preguntas frecuentes</h1>
        <button onClick={add} className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-sm">
          <Plus className="w-4 h-4" /> Nueva
        </button>
      </div>

      <div className="space-y-3">
        {faqs.map((f, i) => (
          <div key={f.id} className="bg-card border rounded-lg p-4 space-y-2">
            <div className="flex gap-2 items-center">
              <input type="number" value={f.orden} onChange={(e) => setFaqs(faqs.map((x, j) => j === i ? { ...x, orden: Number(e.target.value) } : x))}
                className="w-16 px-2 py-1 rounded border bg-background text-sm" />
              <label className="text-xs flex items-center gap-1">
                <input type="checkbox" checked={f.activo} onChange={(e) => setFaqs(faqs.map((x, j) => j === i ? { ...x, activo: e.target.checked } : x))} />
                Activa
              </label>
              <button onClick={() => del(f.id)} className="ml-auto text-destructive text-xs inline-flex items-center gap-1"><Trash2 className="w-3 h-3" /> Eliminar</button>
            </div>
            <input value={f.pregunta} onChange={(e) => setFaqs(faqs.map((x, j) => j === i ? { ...x, pregunta: e.target.value } : x))}
              placeholder="Pregunta" className="w-full px-3 py-2 rounded border bg-background text-sm font-medium" />
            <textarea value={f.respuesta} onChange={(e) => setFaqs(faqs.map((x, j) => j === i ? { ...x, respuesta: e.target.value } : x))}
              rows={3} placeholder="Respuesta" className="w-full px-3 py-2 rounded border bg-background text-sm" />
            <button onClick={() => save(f)} className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-sm">Guardar</button>
          </div>
        ))}
        {faqs.length === 0 && <div className="text-sm text-muted-foreground text-center py-8">Sin preguntas. Agregá la primera para que aparezca en el sitio público.</div>}
      </div>
    </div>
  );
}
