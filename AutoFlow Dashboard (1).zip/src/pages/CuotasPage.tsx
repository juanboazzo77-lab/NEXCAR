import { useMemo, useState } from "react";
import { useSales, useCars, useAddSalePayment } from "@/hooks/use-data";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { formatCurrency, formatDate } from "@/lib/supabase-helpers";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, DollarSign, CheckCircle2, Plus, Pencil, Trash2 } from "lucide-react";
import { MoneyInput } from "@/components/MoneyInput";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { NotificationPhonesCard } from "@/components/NotificationPhonesCard";

const METODOS = ["Efectivo", "Transferencia", "Débito", "Crédito", "Cheque", "Otro"];

function useAllSalePayments() {
  return useQuery({
    queryKey: ["sale_payments", "all"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("sale_payments")
        .select("*")
        .order("fecha", { ascending: false });
      if (error) throw error;
      return data as any[];
    },
  });
}

export default function CuotasPage() {
  const { data: sales = [] } = useSales();
  const { data: cars = [] } = useCars();
  const { data: payments = [] } = useAllSalePayments();
  const addPayment = useAddSalePayment();
  const qc = useQueryClient();
  const { toast } = useToast();
  const { user } = useAuth();

  const [open, setOpen] = useState(false);
  const [activeSaleId, setActiveSaleId] = useState<string | null>(null);
  const [editingPaymentId, setEditingPaymentId] = useState<string | null>(null);
  const [form, setForm] = useState({
    fecha: new Date().toISOString().split("T")[0],
    monto: 0,
    metodo_pago: "Efectivo",
    nota: "",
  });

  const [oldOpen, setOldOpen] = useState(false);
  const [oldForm, setOldForm] = useState({
    fecha: new Date().toISOString().split("T")[0],
    marca_modelo: "",
    patente: "",
    vendedor: "",
    monto: 0,
    sena: 0,
    cuotas: 12,
    monto_financiar: 0,
  });

  const handleSaveOld = async () => {
    if (!user) return;
    try {
      const { error } = await supabase.from("sales").insert({
        user_id: user.id,
        fecha: oldForm.fecha,
        marca_modelo: oldForm.marca_modelo,
        patente: oldForm.patente.toUpperCase(),
        vendedor: oldForm.vendedor,
        monto: oldForm.monto,
        sena: oldForm.sena,
        cuotas: oldForm.cuotas,
        monto_financiar: oldForm.monto_financiar || (oldForm.monto - oldForm.sena),
        estado: "activa",
      } as any);
      if (error) throw error;
      qc.invalidateQueries({ queryKey: ["sales"] });
      setOldOpen(false);
      setOldForm({ fecha: new Date().toISOString().split("T")[0], marca_modelo: "", patente: "", vendedor: "", monto: 0, sena: 0, cuotas: 12, monto_financiar: 0 });
      toast({ title: "Venta antigua agregada" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  // Solo ventas con cuotas
  const ventasConCuotas = useMemo(
    () => sales.filter(s => (s.cuotas ?? 0) > 0),
    [sales]
  );

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const startEditPayment = (p: any) => {
    setEditingPaymentId(p.id);
    setActiveSaleId(p.sale_id);
    setForm({
      fecha: p.fecha,
      monto: Number(p.monto),
      metodo_pago: p.metodo_pago || "Efectivo",
      nota: p.nota || "",
    });
    setOpen(true);
  };

  const handleDeletePayment = async (id: string) => {
    if (!confirm("¿Eliminar este pago de cuota?")) return;
    try {
      const { error } = await supabase.from("sale_payments").delete().eq("id", id);
      if (error) throw error;
      qc.invalidateQueries({ queryKey: ["sale_payments", "all"] });
      qc.invalidateQueries({ queryKey: ["sale_payments"] });
      toast({ title: "Pago eliminado" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleAdd = async () => {
    if (!activeSaleId) return;
    try {
      if (editingPaymentId) {
        const { error } = await supabase
          .from("sale_payments")
          .update({ monto: form.monto, fecha: form.fecha, nota: form.nota, metodo_pago: form.metodo_pago } as any)
          .eq("id", editingPaymentId);
        if (error) throw error;
        toast({ title: "Pago actualizado" });
      } else {
        await addPayment.mutateAsync({
          sale_id: activeSaleId,
          monto: form.monto,
          fecha: form.fecha,
          nota: form.nota,
          metodo_pago: form.metodo_pago,
        } as any);
        toast({ title: "Cuota registrada" });
      }
      qc.invalidateQueries({ queryKey: ["sale_payments", "all"] });
      qc.invalidateQueries({ queryKey: ["sale_payments"] });
      setOpen(false);
      setEditingPaymentId(null);
      setForm({ fecha: new Date().toISOString().split("T")[0], monto: 0, metodo_pago: "Efectivo", nota: "" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="page-header">Cuotas</h1>
        <Button size="sm" onClick={() => setOldOpen(true)}><Plus className="w-4 h-4 mr-1" />Agregar venta antigua</Button>
      </div>

      {ventasConCuotas.length === 0 && (
        <p className="text-muted-foreground text-sm">No hay ventas en cuotas.</p>
      )}

      <div className="space-y-2">
        {ventasConCuotas.map(sale => {
          const car = cars.find(c => c.id === sale.car_id);
          const salePays = payments.filter(p => p.sale_id === sale.id);
          const totalCuotas = sale.cuotas ?? 0;
          const cuotasPagadas = salePays.length;
          const cuotasRestantes = Math.max(0, totalCuotas - cuotasPagadas);
          const montoFinanciar = Number((sale as any).monto_financiar) || Number(sale.monto);
          const montoCuota = totalCuotas > 0 ? montoFinanciar / totalCuotas : 0;

          const finalizada = cuotasRestantes === 0;

          // Próxima cuota: desde el vencimiento de la 1ª cuota si está cargado, si no desde la fecha de venta
          const primera = (sale as any).primera_cuota_fecha as string | null;
          const [sy, sm, sd] = (primera || sale.fecha).split("-").map(Number);
          const proxima = new Date(sy, (sm - 1) + (primera ? cuotasPagadas : cuotasPagadas + 1), sd);
          const vencida = !finalizada && proxima < today;

          const labelAuto = car ? `${car.marca} ${car.modelo}` : ((sale as any).marca_modelo ?? "");
          const titulo = `${labelAuto} ${(sale.patente || car?.patente || "").toUpperCase()}`.toUpperCase().trim();

          return (
            <Collapsible key={sale.id}>
              <Card className={cn(
                finalizada && "border-success/60 bg-success/5",
                vencida && !finalizada && "border-destructive/60 bg-destructive/5",
              )}>
                <CollapsibleTrigger className="w-full">
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="text-left">
                      <div className="text-sm font-bold uppercase">{titulo}</div>
                      <div className="text-xs text-muted-foreground">
                        {cuotasPagadas} / {totalCuotas} cuotas pagadas
                      </div>
                      {!finalizada && (
                        <div className={cn(
                          "text-xs mt-0.5",
                          vencida ? "text-destructive font-semibold" : "text-muted-foreground"
                        )}>
                          Próx. vencimiento: {proxima.toLocaleDateString("es-AR")}
                          {vencida && " · VENCIDA"}
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="text-right">
                        <div className="text-sm font-semibold">{formatCurrency(montoCuota)}</div>
                        {finalizada ? (
                          <Badge className="bg-success text-success-foreground text-xs">
                            <CheckCircle2 className="w-3 h-3 mr-1" />Pagada
                          </Badge>
                        ) : (
                          <Badge variant={vencida ? "destructive" : "secondary"} className="text-xs">
                            Debe {cuotasRestantes}
                          </Badge>
                        )}
                      </div>
                      <ChevronDown className="w-4 h-4 text-muted-foreground" />
                    </div>
                  </CardContent>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <CardContent className="px-4 pb-4 pt-0 space-y-3">
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div><span className="text-muted-foreground">Total a financiar:</span> <span className="font-medium">{formatCurrency(montoFinanciar)}</span></div>
                      <div><span className="text-muted-foreground">Monto por cuota:</span> <span className="font-medium">{formatCurrency(montoCuota)}</span></div>
                      <div><span className="text-muted-foreground">Pagadas:</span> <span className="font-medium text-success">{cuotasPagadas}</span></div>
                      <div><span className="text-muted-foreground">Restantes:</span> <span className={cn("font-medium", cuotasRestantes === 0 ? "text-success" : "text-warning")}>{cuotasRestantes}</span></div>
                    </div>

                    {salePays.length > 0 && (
                      <div className="space-y-1 border-t pt-2">
                        <div className="text-xs font-semibold text-muted-foreground">Historial</div>
                        {salePays
                          .slice()
                          .sort((a, b) => a.fecha.localeCompare(b.fecha))
                          .map((p, idx) => (
                            <div key={p.id} className="flex justify-between items-center gap-2 text-xs">
                              <span>
                                Cuota {idx + 1} · {formatDate(p.fecha)}
                                {p.metodo_pago && <span className="text-muted-foreground"> · {p.metodo_pago}</span>}
                                {p.nota && <span className="text-muted-foreground"> · {p.nota}</span>}
                              </span>
                              <span className="flex items-center gap-1">
                                <span className="font-medium">{formatCurrency(Number(p.monto))}</span>
                                <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => startEditPayment(p)}>
                                  <Pencil className="w-3 h-3" />
                                </Button>
                                <Button size="icon" variant="ghost" className="h-6 w-6 text-destructive" onClick={() => handleDeletePayment(p.id)}>
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </span>
                            </div>
                          ))}
                      </div>
                    )}

                    {!finalizada && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-xs"
                        onClick={() => {
                          setEditingPaymentId(null);
                          setActiveSaleId(sale.id);
                          setForm({
                            fecha: new Date().toISOString().split("T")[0],
                            monto: Math.round(montoCuota),
                            metodo_pago: "Efectivo",
                            nota: `Cuota ${cuotasPagadas + 1}/${totalCuotas}`,
                          });
                          setOpen(true);
                        }}
                      >
                        <DollarSign className="w-3 h-3 mr-1" />Registrar pago de cuota
                      </Button>
                    )}
                  </CardContent>
                </CollapsibleContent>
              </Card>
            </Collapsible>
          );
        })}
      </div>

      <NotificationPhonesCard />

      <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setEditingPaymentId(null); }}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editingPaymentId ? "Editar pago de cuota" : "Registrar pago de cuota"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Fecha</Label><Input type="date" value={form.fecha} onChange={e => setForm(f => ({ ...f, fecha: e.target.value }))} /></div>
            <div><Label>Monto</Label><MoneyInput value={form.monto} onValueChange={v => setForm(f => ({ ...f, monto: v }))} /></div>
            <div>
              <Label>Forma de pago</Label>
              <Select value={form.metodo_pago} onValueChange={v => setForm(f => ({ ...f, metodo_pago: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {METODOS.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div><Label>Nota</Label><Input value={form.nota} onChange={e => setForm(f => ({ ...f, nota: e.target.value }))} /></div>
          </div>
          <Button onClick={handleAdd} className="w-full" disabled={!form.monto}>Guardar</Button>
        </DialogContent>
      </Dialog>

      <Dialog open={oldOpen} onOpenChange={setOldOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Agregar venta antigua (solo cuotas)</DialogTitle></DialogHeader>
          <p className="text-xs text-muted-foreground">Para autos vendidos hace tiempo. No se agrega al stock, solo se controlan las cuotas.</p>
          <div className="space-y-3 mt-2">
            <div><Label>Fecha de venta</Label><Input type="date" value={oldForm.fecha} onChange={e => setOldForm(f => ({ ...f, fecha: e.target.value }))} /></div>
            <div><Label>Marca y modelo</Label><Input value={oldForm.marca_modelo} onChange={e => setOldForm(f => ({ ...f, marca_modelo: e.target.value }))} placeholder="Ej: Toyota Corolla" /></div>
            <div><Label>Patente</Label><Input value={oldForm.patente} onChange={e => setOldForm(f => ({ ...f, patente: e.target.value.toUpperCase() }))} /></div>
            <div><Label>Comprador / Vendedor</Label><Input value={oldForm.vendedor} onChange={e => setOldForm(f => ({ ...f, vendedor: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-2">
              <div><Label>Monto total</Label><MoneyInput value={oldForm.monto} onValueChange={v => setOldForm(f => ({ ...f, monto: v }))} /></div>
              <div><Label>Seña</Label><MoneyInput value={oldForm.sena} onValueChange={v => setOldForm(f => ({ ...f, sena: v }))} /></div>
              <div><Label>Monto a financiar</Label><MoneyInput value={oldForm.monto_financiar} onValueChange={v => setOldForm(f => ({ ...f, monto_financiar: v }))} placeholder="Automático si vacío" /></div>
              <div><Label>Cantidad de cuotas</Label><Input type="number" value={oldForm.cuotas} onChange={e => setOldForm(f => ({ ...f, cuotas: Number(e.target.value) }))} /></div>
            </div>
          </div>
          <Button onClick={handleSaveOld} className="w-full mt-2" disabled={!oldForm.marca_modelo || !oldForm.cuotas}>Guardar</Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
