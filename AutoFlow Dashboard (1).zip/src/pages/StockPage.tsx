import { useState } from "react";
import { Link } from "react-router-dom";
import { useCars, useUpsertCar, useDeleteCar, useExpenses, useSales } from "@/hooks/use-data";
import { MARCAS, ESTADOS, ANIOS, formatCurrency } from "@/lib/supabase-helpers";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Pencil, Trash2, AlertTriangle, Facebook, Instagram, ShoppingCart } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Car, CarInsert } from "@/lib/supabase-helpers";
import { CarSelector } from "@/components/CarSelector";
import { MoneyInput } from "@/components/MoneyInput";
import { StockCatalogoActions } from "@/components/StockCatalogoActions";
import { NotificationPhonesCard } from "@/components/NotificationPhonesCard";
import AdminPagination, { usePagination } from "@/components/AdminPagination";
import { usePlan } from "@/hooks/usePlan";

const EMPTY_CAR: Partial<CarInsert> & any = {
  patente: "", marca: "", modelo: "", version: "", anio: 2024, color: "",
  estado: "Disponible", duenio: "", proveedor: "", precio_compra: 0, precio_venta: 0,
  kilometros: 0, moneda: "ARS",
  combustible: "", transmision: "", motor: "", carroceria: "", puertas: 4,
  condicion: "Usado", ubicacion: "", sucursal: "",
  vendedor_nombre: "", vendedor_telefono: "", vendedor_whatsapp: "",
  descripcion_manual: "", notas_internas: "", equipamiento: [],
  publicado_ml: false, publicado_ig: false, publicado_fb: false,
};

const COMBUSTIBLES = ["Nafta", "Diésel", "GNC", "Híbrido", "Eléctrico"];
const TRANSMISIONES = ["Manual", "Automática", "Automática Secuencial", "CVT"];
const CARROCERIAS = ["Sedán", "Hatchback", "SUV", "Pickup", "Coupé", "Familiar", "Monovolumen", "Van"];
const CONDICIONES = ["Nuevo", "Usado", "0km"];
const EQUIPAMIENTO_OPCIONES = [
  "Aire acondicionado", "Dirección hidráulica", "Dirección asistida", "Levantavidrios eléctricos",
  "Cierre centralizado", "Alarma", "ABS", "Airbags", "Airbags laterales", "Control de estabilidad",
  "Control de tracción", "Bluetooth", "GPS", "Cámara de retroceso", "Sensor de estacionamiento",
  "Tapizado de cuero", "Llantas de aleación", "Techo solar", "Faros antiniebla", "Computadora de a bordo",
  "Asientos eléctricos", "Asientos calefaccionados", "Volante multifunción", "Pantalla táctil", "CarPlay/Android Auto",
];

function estadoBadgeClass(estado: string) {
  switch (estado) {
    case "Disponible": return "bg-success/15 text-success border-success/30";
    case "Reservado": return "bg-warning/15 text-warning border-warning/30";
    case "Vendido": return "bg-muted text-muted-foreground border-border";
    default: return "bg-primary/15 text-primary border-primary/30";
  }
}

export default function StockPage() {
  const { can } = usePlan();
  const canDuenio = can("duenio") || can("proveedor");
  const { data: cars = [], isLoading } = useCars();
  const { data: allExpenses = [] } = useExpenses();
  const { data: sales = [] } = useSales();
  const pendingPartePago = sales.filter(s => s.parte_pago && !s.parte_pago.includes("✓ en stock"));
  const upsert = useUpsertCar();
  const deleteCar = useDeleteCar();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [filterMarca, setFilterMarca] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState<Partial<CarInsert> & { id?: string }>(EMPTY_CAR);
  const [customEstado, setCustomEstado] = useState("");

  const soldCarIds = new Set(sales.map(s => s.car_id).filter(Boolean) as string[]);
  const filtered = cars.filter(c => {
    if (c.estado === "Vendido") return false;
    if (soldCarIds.has(c.id)) return false;
    const matchSearch = `${c.patente} ${c.marca} ${c.modelo} ${c.version}`.toLowerCase().includes(search.toLowerCase());
    const matchMarca = filterMarca === "all" || c.marca === filterMarca;
    return matchSearch && matchMarca;
  });

  const pag = usePagination(filtered, "stockPageSize", 12);

  const getExpensesTotal = (carId: string) =>
    allExpenses.filter(e => e.car_id === carId).reduce((s, e) => s + Number(e.monto), 0);

  const openEdit = (car: Car) => {
    setForm(car);
    setCustomEstado("");
    setDialogOpen(true);
  };

  const openNew = () => {
    setForm({ ...EMPTY_CAR });
    setCustomEstado("");
    setDialogOpen(true);
  };

  const handleSave = async () => {
    const estado = customEstado || form.estado;
    try {
      await upsert.mutateAsync({ ...form, estado });
      setDialogOpen(false);
      toast({ title: form.id ? "Auto actualizado" : "Auto agregado" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("¿Eliminar este auto?")) return;
    await deleteCar.mutateAsync(id);
    toast({ title: "Auto eliminado" });
  };

  const set = (key: string, val: any) => setForm(f => ({ ...f, [key]: val }));

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <h1 className="page-header">Stock</h1>
        <Button onClick={openNew} size="sm"><Plus className="w-4 h-4 mr-1" />Agregar auto</Button>
      </div>

      {pendingPartePago.length > 0 && (
        <Alert className="border-warning/40 bg-warning/10">
          <AlertTriangle className="h-4 w-4 text-warning" />
          <AlertTitle className="text-warning">
            {pendingPartePago.length === 1
              ? "Tenés 1 auto recibido como parte de pago para sumar al stock"
              : `Tenés ${pendingPartePago.length} autos recibidos como parte de pago para sumar al stock`}
          </AlertTitle>
          <AlertDescription>
            <ul className="mt-1 space-y-1 text-xs">
              {pendingPartePago.map(s => (
                <li key={s.id}>• {s.parte_pago}</li>
              ))}
            </ul>
            <Link to="/ventas" className="text-xs underline mt-2 inline-block">
              Ir a Ventas para agregarlos
            </Link>
          </AlertDescription>
        </Alert>
      )}

      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Buscar por patente, marca, modelo..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={filterMarca} onValueChange={setFilterMarca}>
          <SelectTrigger className="w-full sm:w-40"><SelectValue placeholder="Marca" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas</SelectItem>
            {MARCAS.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <p className="text-muted-foreground text-sm">Cargando...</p>
      ) : filtered.length === 0 ? (
        <p className="text-muted-foreground text-sm">No hay autos.</p>
      ) : (
        <>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {pag.pageItems.map(car => {
            const expenses = getExpensesTotal(car.id);
            const margen = Number(car.precio_venta) - Number(car.precio_compra) - expenses;
            return (
              <Card key={car.id} className="animate-fade-in">
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-semibold text-sm">{car.marca} {car.modelo}</div>
                      <div className="text-xs text-muted-foreground">{car.version} · {car.anio} · {car.color}</div>
                      <div className="text-xs font-mono mt-1">{car.patente}{(car as any).kilometros ? ` · ${Number((car as any).kilometros).toLocaleString("es-AR")} km` : ""}</div>
                      {canDuenio && (car as any).duenio && <div className="text-xs text-muted-foreground mt-1">Dueño: <span className="text-foreground font-medium">{(car as any).duenio}</span></div>}
                      {canDuenio && car.proveedor && <div className="text-xs text-muted-foreground mt-1">Proveedor: <span className="text-foreground font-medium">{car.proveedor}</span></div>}
                    </div>
                    <Badge variant="outline" className={estadoBadgeClass(car.estado)}>{car.estado}</Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div><span className="text-muted-foreground">Compra</span><div className="font-medium">{(car as any).moneda === "USD" ? "U$S " : ""}{formatCurrency(Number(car.precio_compra))}</div></div>
                    <div><span className="text-muted-foreground">Venta</span><div className="font-medium">{(car as any).moneda === "USD" ? "U$S " : ""}{formatCurrency(Number(car.precio_venta))}</div></div>
                    <div><span className="text-muted-foreground">Margen</span><div className={`font-medium ${margen >= 0 ? "text-success" : "text-destructive"}`}>{formatCurrency(margen)}</div></div>
                  </div>
                  {expenses > 0 && <div className="text-xs text-muted-foreground">Gastos: {formatCurrency(expenses)}</div>}
                  <div className="flex items-center gap-3 pt-1">
                    <span title="Mercado Libre"><ShoppingCart className={`w-4 h-4 ${car.publicado_ml ? "text-yellow-500" : "text-muted-foreground"}`} /></span>
                    <span title="Instagram"><Instagram className={`w-4 h-4 ${car.publicado_ig ? "text-pink-500" : "text-muted-foreground"}`} /></span>
                    <span title="Facebook"><Facebook className={`w-4 h-4 ${car.publicado_fb ? "text-blue-600" : "text-muted-foreground"}`} /></span>
                  </div>
                  <div className="flex gap-1 pt-1 flex-wrap items-center">
                    <StockCatalogoActions car={car} />
                    <Button variant="ghost" size="sm" onClick={() => openEdit(car)}><Pencil className="w-3.5 h-3.5" /></Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDelete(car.id)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
        <AdminPagination
          page={pag.page}
          totalPages={pag.totalPages}
          perPage={pag.perPage}
          total={pag.total}
          onPage={pag.setPage}
          onPerPage={pag.setPerPage}
        />
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{form.id ? "Editar auto" : "Nuevo auto"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2"><Label>Patente</Label><Input value={form.patente ?? ""} onChange={e => set("patente", e.target.value.toUpperCase())} /></div>
            <div className="col-span-2 grid grid-cols-2 gap-3">
              <CarSelector
                marca={form.marca ?? ""}
                modelo={form.modelo ?? ""}
                version={form.version ?? ""}
                anio={Number(form.anio ?? 2024)}
                onChange={(patch) => setForm(f => ({ ...f, ...patch }))}
              />
            </div>
            <div><Label>Color</Label><Input value={form.color ?? ""} onChange={e => set("color", e.target.value)} /></div>
            <div><Label>Estado</Label>
              <Select value={form.estado ?? "Disponible"} onValueChange={v => { set("estado", v); setCustomEstado(""); }}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ESTADOS.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}
                  <SelectItem value="__custom">Personalizado...</SelectItem>
                </SelectContent>
              </Select>
              {form.estado === "__custom" && <Input className="mt-1" placeholder="Estado personalizado" value={customEstado} onChange={e => setCustomEstado(e.target.value)} />}
            </div>
            <div>
              <Label>Moneda</Label>
              <Select value={(form as any).moneda ?? "ARS"} onValueChange={v => set("moneda", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ARS">Pesos (ARS $)</SelectItem>
                  <SelectItem value="USD">Dólares (USD U$S)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Precio compra ({(form as any).moneda === "USD" ? "U$S" : "$"})</Label><MoneyInput value={form.precio_compra ?? 0} onValueChange={v => set("precio_compra", v)} /></div>
            <div><Label>Precio venta ({(form as any).moneda === "USD" ? "U$S" : "$"})</Label><MoneyInput value={form.precio_venta ?? 0} onValueChange={v => set("precio_venta", v)} /></div>
            <div><Label>Kilómetros</Label><MoneyInput value={(form as any).kilometros ?? 0} onValueChange={v => set("kilometros", v)} /></div>
            <div><Label>Condición</Label>
              <Select value={(form as any).condicion ?? "Usado"} onValueChange={v => set("condicion", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CONDICIONES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>

            {canDuenio && (
              <>
                <div className="col-span-2 pt-2 border-t">
                  <h3 className="text-sm font-semibold mb-2">Dueño y Proveedor del auto</h3>
                </div>
                <div><Label>Dueño</Label><Input placeholder="De quién es el auto" value={(form as any).duenio ?? ""} onChange={e => set("duenio", e.target.value)} /></div>
                <div><Label>Proveedor</Label><Input placeholder="Quién lo trajo / proveedor" value={form.proveedor ?? ""} onChange={e => set("proveedor", e.target.value)} /></div>
              </>
            )}

            <div className="col-span-2 pt-2 border-t">
              <h3 className="text-sm font-semibold mb-2">Ficha técnica</h3>
            </div>
            <div><Label>Combustible</Label>
              <Select value={(form as any).combustible ?? ""} onValueChange={v => set("combustible", v)}>
                <SelectTrigger><SelectValue placeholder="Elegir..." /></SelectTrigger>
                <SelectContent>{COMBUSTIBLES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Transmisión</Label>
              <Select value={(form as any).transmision ?? ""} onValueChange={v => set("transmision", v)}>
                <SelectTrigger><SelectValue placeholder="Elegir..." /></SelectTrigger>
                <SelectContent>{TRANSMISIONES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Motor</Label><Input placeholder="Ej: 1.6 16v" value={(form as any).motor ?? ""} onChange={e => set("motor", e.target.value)} /></div>
            <div><Label>Carrocería</Label>
              <Select value={(form as any).carroceria ?? ""} onValueChange={v => set("carroceria", v)}>
                <SelectTrigger><SelectValue placeholder="Elegir..." /></SelectTrigger>
                <SelectContent>{CARROCERIAS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Puertas</Label>
              <Select value={String((form as any).puertas ?? 4)} onValueChange={v => set("puertas", Number(v))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{[2,3,4,5].map(p => <SelectItem key={p} value={String(p)}>{p}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Ubicación</Label><Input value={(form as any).ubicacion ?? ""} onChange={e => set("ubicacion", e.target.value)} /></div>
            <div className="col-span-2"><Label>Sucursal</Label><Input value={(form as any).sucursal ?? ""} onChange={e => set("sucursal", e.target.value)} /></div>

            <div className="col-span-2">
              <Label>Equipamiento</Label>
              <div className="grid grid-cols-2 gap-1 mt-1 max-h-48 overflow-y-auto border rounded p-2">
                {EQUIPAMIENTO_OPCIONES.map(opt => {
                  const arr: string[] = Array.isArray((form as any).equipamiento) ? (form as any).equipamiento : [];
                  const checked = arr.includes(opt);
                  return (
                    <label key={opt} className="flex items-center gap-2 text-xs">
                      <input type="checkbox" checked={checked} onChange={e => {
                        const next = e.target.checked ? [...arr, opt] : arr.filter(x => x !== opt);
                        set("equipamiento", next);
                      }} />{opt}
                    </label>
                  );
                })}
              </div>
            </div>

            <div className="col-span-2"><Label>Descripción pública</Label>
              <textarea className="w-full border rounded p-2 text-sm bg-background" rows={3} value={(form as any).descripcion_manual ?? ""} onChange={e => set("descripcion_manual", e.target.value)} />
            </div>
            <div className="col-span-2"><Label>Notas internas</Label>
              <textarea className="w-full border rounded p-2 text-sm bg-background" rows={2} value={(form as any).notas_internas ?? ""} onChange={e => set("notas_internas", e.target.value)} />
            </div>

            <div className="col-span-2 pt-2 border-t">
              <h3 className="text-sm font-semibold mb-2">Vendedor / Publicaciones</h3>
            </div>
            <div><Label>Vendedor</Label><Input value={(form as any).vendedor_nombre ?? ""} onChange={e => set("vendedor_nombre", e.target.value)} /></div>
            <div><Label>Teléfono</Label><Input value={(form as any).vendedor_telefono ?? ""} onChange={e => set("vendedor_telefono", e.target.value)} /></div>
            <div className="col-span-2"><Label>WhatsApp</Label><Input value={(form as any).vendedor_whatsapp ?? ""} onChange={e => set("vendedor_whatsapp", e.target.value)} /></div>

            <div className="col-span-2 flex gap-4 flex-wrap">
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.publicado_ml ?? false} onChange={e => set("publicado_ml", e.target.checked)} />MercadoLibre</label>
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.publicado_ig ?? false} onChange={e => set("publicado_ig", e.target.checked)} />Instagram</label>
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.publicado_fb ?? false} onChange={e => set("publicado_fb", e.target.checked)} />Facebook</label>
            </div>
          </div>
          <Button onClick={handleSave} className="w-full mt-2" disabled={upsert.isPending}>
            {upsert.isPending ? "Guardando..." : "Guardar"}
          </Button>
        </DialogContent>
      </Dialog>
      <NotificationPhonesCard />

    </div>
  );
}
