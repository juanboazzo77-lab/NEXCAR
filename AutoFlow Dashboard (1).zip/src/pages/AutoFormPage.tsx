import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Trash2, Star, Upload, Sparkles, Send, Loader2, CheckCircle2, XCircle, ExternalLink, TrendingUp } from "lucide-react";

type Acc = { id: string; platform: string; account_name: string; meta: any; account_external_id: string | null };
type LT = { listing_type_id: string; name: string; available_quantity: number; used_quantity: number };

export default function AutoFormPage() {
  const { id } = useParams();
  const isNew = !id || id === "nuevo";
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const [carId, setCarId] = useState<string | null>(isNew ? null : id!);
  const [form, setForm] = useState<any>({
    marca: "", modelo: "", version: "", anio: new Date().getFullYear(), kilometros: 0,
    precio_venta: 0, moneda: "ARS", patente: "", color: "", combustible: "", transmision: "",
    motor: "", carroceria: "", puertas: 4, condicion: "usado", ubicacion: "",
    estado: "Disponible", vendedor_nombre: "", vendedor_telefono: "", vendedor_whatsapp: "",
    sucursal: "", comision: 0, descripcion_manual: "", notas_internas: "", equipamiento: [],
    mostrar_publico: false, descripcion_publica: "",
  });
  const [photos, setPhotos] = useState<any[]>([]);
  const [aiDesc, setAiDesc] = useState<any>({ titulo: "", ml_desc: "", ig_caption: "", fb_caption: "", hashtags: [] });
  const [accounts, setAccounts] = useState<Acc[]>([]);
  const [listingTypes, setListingTypes] = useState<Record<string, LT[]>>({});
  const [publishOpen, setPublishOpen] = useState(false);
  const [genLoading, setGenLoading] = useState(false);
  const [pubLoading, setPubLoading] = useState(false);
  const [results, setResults] = useState<any[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [marketOpen, setMarketOpen] = useState(false);
  const [marketLoading, setMarketLoading] = useState(false);
  const [market, setMarket] = useState<any>(null);

  // Publish modal selections
  const [selML, setSelML] = useState(false);
  const [selIG, setSelIG] = useState(false);
  const [selFB, setSelFB] = useState(false);
  const [mlAcc, setMlAcc] = useState<string>("");
  const [mlLT, setMlLT] = useState<string>("");
  const [igAcc, setIgAcc] = useState<string>("");
  const [igCarousel, setIgCarousel] = useState(true);
  const [fbAcc, setFbAcc] = useState<string>("");

  useEffect(() => {
    (async () => {
      if (!isNew && id) {
        const { data: c } = await supabase.from("cars").select("*").eq("id", id).maybeSingle();
        if (c) setForm({ ...form, ...c });
        const { data: ph } = await supabase.from("car_photos").select("*").eq("car_id", id).order("es_portada", { ascending: false }).order("orden");
        setPhotos(ph || []);
        const { data: ai } = await supabase.from("ai_generated_descriptions").select("*").eq("car_id", id).order("created_at", { ascending: false }).limit(1);
        if (ai?.[0]) setAiDesc(ai[0]);
        const { data: h } = await supabase.from("vehicle_publications").select("*").eq("car_id", id).order("created_at", { ascending: false });
        setHistory(h || []);
      }
      const { data: accs } = await supabase.from("connected_accounts").select("id, platform, account_name, meta, account_external_id").in("platform", ["mercadolibre", "instagram", "facebook"]);
      setAccounts((accs as any) || []);
      const mlAccs = (accs || []).filter((a: any) => a.platform === "mercadolibre");
      for (const a of mlAccs) {
        const { data: lt } = await supabase.from("ml_listing_types").select("*").eq("publishing_account_id", a.id);
        setListingTypes(prev => ({ ...prev, [a.id]: lt as LT[] || [] }));
      }
    })();
  }, [id]);

  const set = (k: string, v: any) => setForm((f: any) => ({ ...f, [k]: v }));

  const save = async (): Promise<string | null> => {
    if (!form.marca || !form.modelo || !form.anio) {
      toast({ title: "Faltan datos", description: "Marca, modelo y año son obligatorios", variant: "destructive" });
      return null;
    }
    const payload: any = { ...form, user_id: user!.id };
    delete payload.id; delete payload.created_at; delete payload.updated_at;
    if (!payload.patente) payload.patente = `SIN-${Date.now()}`;
    if (carId) {
      const { error } = await supabase.from("cars").update(payload).eq("id", carId);
      if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); return null; }
      return carId;
    } else {
      const { data, error } = await supabase.from("cars").insert(payload).select().single();
      if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); return null; }
      setCarId(data.id);
      navigate(`/autos/${data.id}`, { replace: true });
      return data.id;
    }
  };

  const uploadPhotos = async (files: FileList) => {
    const cid = carId || await save();
    if (!cid) return;
    const ordenBase = photos.length;
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      if (f.size > 10 * 1024 * 1024) { toast({ title: "Foto muy grande", description: `${f.name} supera 10MB` }); continue; }
      const path = `${user!.id}/${cid}/${Date.now()}-${i}-${f.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`;
      const { error: upErr } = await supabase.storage.from("car-photos").upload(path, f);
      if (upErr) { toast({ title: "Error subiendo", description: upErr.message, variant: "destructive" }); continue; }
      const { data: pub } = supabase.storage.from("car-photos").getPublicUrl(path);
      await supabase.from("car_photos").insert({ user_id: user!.id, car_id: cid, url: pub.publicUrl, storage_path: path, orden: ordenBase + i, es_portada: photos.length === 0 && i === 0 });
    }
    const { data: ph } = await supabase.from("car_photos").select("*").eq("car_id", cid).order("es_portada", { ascending: false }).order("orden");
    setPhotos(ph || []);
  };

  const setPortada = async (pid: string) => {
    if (!carId) return;
    await supabase.from("car_photos").update({ es_portada: false }).eq("car_id", carId);
    await supabase.from("car_photos").update({ es_portada: true }).eq("id", pid);
    const { data: ph } = await supabase.from("car_photos").select("*").eq("car_id", carId).order("es_portada", { ascending: false }).order("orden");
    setPhotos(ph || []);
  };
  const delPhoto = async (p: any) => {
    if (p.storage_path) await supabase.storage.from("car-photos").remove([p.storage_path]);
    await supabase.from("car_photos").delete().eq("id", p.id);
    setPhotos(photos.filter(x => x.id !== p.id));
  };

  const generarIA = async () => {
    const cid = carId || await save();
    if (!cid) return;
    setGenLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("generate-description-rich", { body: { car_id: cid } });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      setAiDesc(data);
      toast({ title: "Descripción generada" });
    } catch (e: any) {
      toast({ title: "Error IA", description: e.message, variant: "destructive" });
    } finally { setGenLoading(false); }
  };

  const refreshListingTypes = async (accId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke("ml-listing-types", { body: { account_id: accId } });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      const { data: lt } = await supabase.from("ml_listing_types").select("*").eq("publishing_account_id", accId);
      setListingTypes(prev => ({ ...prev, [accId]: lt as LT[] || [] }));
      toast({ title: "Cupos actualizados" });
    } catch (e: any) { toast({ title: "Error", description: e.message, variant: "destructive" }); }
  };

  const openPublish = async () => {
    const cid = carId || await save();
    if (!cid) return;
    if (photos.length === 0) { toast({ title: "Subí al menos 1 foto", variant: "destructive" }); return; }
    if (!form.precio_venta) { toast({ title: "Falta el precio", variant: "destructive" }); return; }
    setResults([]);
    setPublishOpen(true);
  };

  const doPublish = async () => {
    const targets: any[] = [];
    if (selML) {
      if (!mlAcc || !mlLT) { toast({ title: "Elegí cuenta y tipo de publicación de ML", variant: "destructive" }); return; }
      targets.push({ platform: "mercadolibre", account_id: mlAcc, listing_type_id: mlLT, descripcion: aiDesc.ml_desc || form.descripcion_manual || `${form.marca} ${form.modelo} ${form.anio}`, titulo: aiDesc.titulo });
    }
    if (selIG) {
      if (!igAcc) { toast({ title: "Elegí cuenta de Instagram", variant: "destructive" }); return; }
      targets.push({ platform: "instagram", account_id: igAcc, carousel: igCarousel, descripcion: aiDesc.ig_caption || form.descripcion_manual || `${form.marca} ${form.modelo} ${form.anio}` });
    }
    if (selFB) {
      if (!fbAcc) { toast({ title: "Elegí página de Facebook", variant: "destructive" }); return; }
      targets.push({ platform: "facebook", account_id: fbAcc, descripcion: aiDesc.fb_caption || form.descripcion_manual || `${form.marca} ${form.modelo} ${form.anio}` });
    }
    if (targets.length === 0) { toast({ title: "Elegí al menos 1 plataforma", variant: "destructive" }); return; }
    setPubLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("vehicle-publish-all", { body: { car_id: carId, targets } });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      setResults(data.results || []);
      const { data: h } = await supabase.from("vehicle_publications").select("*").eq("car_id", carId!).order("created_at", { ascending: false });
      setHistory(h || []);
    } catch (e: any) { toast({ title: "Error publicando", description: e.message, variant: "destructive" }); }
    finally { setPubLoading(false); }
  };

  const analizarMercado = async () => {
    const cid = carId || await save();
    if (!cid) return;
    setMarketOpen(true);
    setMarketLoading(true);
    setMarket(null);
    try {
      const { data, error } = await supabase.functions.invoke("ml-market-analyze", { body: { car_id: cid } });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      setMarket(data.analysis);
      toast({ title: "Análisis listo", description: `${data.analysis?.total_results || 0} publicaciones analizadas` });
    } catch (e: any) {
      toast({ title: "Error analizando mercado", description: e.message, variant: "destructive" });
    } finally { setMarketLoading(false); }
  };

  // Cargar último análisis al abrir
  useEffect(() => {
    if (carId) {
      supabase.from("market_analyses").select("*").eq("car_id", carId).order("created_at", { ascending: false }).limit(1)
        .then(({ data }) => { if (data?.[0]) setMarket(data[0]); });
    }
  }, [carId]);

  const mlAccs = accounts.filter(a => a.platform === "mercadolibre");
  const igAccs = accounts.filter(a => a.platform === "instagram");
  const fbAccs = accounts.filter(a => a.platform === "facebook");

  const lastByPlatform = (plat: string) => history.find(h => h.platform === plat && h.status === 'publicado') || history.find(h => h.platform === plat);
  const hasAnyPublished = history.some(h => h.status === 'publicado');

  const LastInfo = ({ plat }: { plat: string }) => {
    const last = lastByPlatform(plat);
    if (!last) return null;
    return (
      <div className="text-xs text-muted-foreground mt-1 flex items-center gap-2">
        <span>Última: {new Date(last.created_at).toLocaleDateString()}</span>
        <Badge variant={last.status === 'publicado' ? 'default' : last.status === 'error' ? 'destructive' : 'secondary'} className="text-[10px] py-0">{last.status}</Badge>
        {last.external_url && <a href={last.external_url} target="_blank" rel="noreferrer" className="text-primary inline-flex items-center gap-1">ver <ExternalLink className="w-3 h-3" /></a>}
        <span className="text-amber-600">Se creará una nueva publicación</span>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => navigate("/autos")}><ArrowLeft className="w-4 h-4" /></Button>
          <h1 className="text-xl font-bold">{isNew ? "Nuevo auto" : `${form.marca} ${form.modelo}`}</h1>
          {hasAnyPublished && <Badge variant="secondary">Publicado</Badge>}
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" onClick={analizarMercado} disabled={marketLoading}>
            {marketLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <TrendingUp className="w-4 h-4" />} Analizar mercado
          </Button>
          <Button variant="outline" onClick={save}>Guardar cambios</Button>
          <Button onClick={openPublish}><Send className="w-4 h-4" /> {hasAnyPublished ? "Republicar" : "Publicar en plataformas"}</Button>
        </div>
      </div>

      {market && (
        <Card className="p-3 border-primary/30 bg-primary/5">
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 text-sm font-medium">
                <TrendingUp className="w-4 h-4" /> Mercado · {market.total_results} similares
                <Badge variant={market.diff_pct >= 10 ? "destructive" : market.diff_pct <= -5 ? "default" : "secondary"}>
                  {market.diff_pct > 0 ? '+' : ''}{market.diff_pct}% vs promedio
                </Badge>
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Min {market.summary?.currency || 'ARS'} {Math.round(market.price_min).toLocaleString()} · Prom {Math.round(market.price_avg).toLocaleString()} · Max {Math.round(market.price_max).toLocaleString()} · Sugerido <b>{Math.round(market.price_recommended).toLocaleString()}</b>
              </div>
              <div className="text-xs mt-1">{market.recommendation}</div>
            </div>
            <Button variant="outline" size="sm" onClick={() => setMarketOpen(true)}>Ver detalle</Button>
          </div>
        </Card>
      )}

      <Tabs defaultValue="datos">
        <TabsList>
          <TabsTrigger value="datos">Datos</TabsTrigger>
          <TabsTrigger value="fotos">Fotos {photos.length > 0 && `(${photos.length})`}</TabsTrigger>
          <TabsTrigger value="comercial">Comercial</TabsTrigger>
          <TabsTrigger value="ia">IA & Publicar</TabsTrigger>
          <TabsTrigger value="historial">Historial</TabsTrigger>
        </TabsList>

        <TabsContent value="datos">
          <Card className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <Field label="Marca *"><Input value={form.marca} onChange={e => set("marca", e.target.value)} /></Field>
            <Field label="Modelo *"><Input value={form.modelo} onChange={e => set("modelo", e.target.value)} /></Field>
            <Field label="Versión"><Input value={form.version || ""} onChange={e => set("version", e.target.value)} /></Field>
            <Field label="Año *"><Input type="number" value={form.anio} onChange={e => set("anio", Number(e.target.value))} /></Field>
            <Field label="Kilómetros"><Input type="number" value={form.kilometros || 0} onChange={e => set("kilometros", Number(e.target.value))} /></Field>
            <Field label="Precio"><Input type="number" value={form.precio_venta || 0} onChange={e => set("precio_venta", Number(e.target.value))} /></Field>
            <Field label="Moneda">
              <Select value={form.moneda || "ARS"} onValueChange={v => set("moneda", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="ARS">ARS</SelectItem><SelectItem value="USD">USD</SelectItem></SelectContent>
              </Select>
            </Field>
            <Field label="Ubicación"><Input value={form.ubicacion || ""} onChange={e => set("ubicacion", e.target.value)} /></Field>
            <Field label="Color"><Input value={form.color || ""} onChange={e => set("color", e.target.value)} /></Field>
            <Field label="Combustible">
              <Select value={form.combustible || ""} onValueChange={v => set("combustible", v)}>
                <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                <SelectContent>{["Nafta", "Diésel", "GNC", "Híbrido", "Eléctrico"].map(x => <SelectItem key={x} value={x}>{x}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Transmisión">
              <Select value={form.transmision || ""} onValueChange={v => set("transmision", v)}>
                <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                <SelectContent>{["Manual", "Automática", "CVT", "Tiptronic"].map(x => <SelectItem key={x} value={x}>{x}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Motor"><Input value={form.motor || ""} onChange={e => set("motor", e.target.value)} placeholder="ej: 1.6 16v" /></Field>
            <Field label="Carrocería">
              <Select value={form.carroceria || ""} onValueChange={v => set("carroceria", v)}>
                <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                <SelectContent>{["Sedán", "Hatchback", "SUV", "Pick-up", "Coupé", "Familiar"].map(x => <SelectItem key={x} value={x}>{x}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <Field label="Puertas"><Input type="number" value={form.puertas || 4} onChange={e => set("puertas", Number(e.target.value))} /></Field>
            <Field label="Condición">
              <Select value={form.condicion || "usado"} onValueChange={v => set("condicion", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="usado">Usado</SelectItem><SelectItem value="nuevo">Nuevo</SelectItem></SelectContent>
              </Select>
            </Field>
            <Field label="Patente"><Input value={form.patente || ""} onChange={e => set("patente", e.target.value)} /></Field>
            <Field label="Estado">
              <Select value={form.estado} onValueChange={v => set("estado", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{["Disponible", "Reservado", "Vendido", "Pausado"].map(x => <SelectItem key={x} value={x}>{x}</SelectItem>)}</SelectContent>
              </Select>
            </Field>
            <div className="sm:col-span-2 lg:col-span-3">
              <Field label="Descripción manual / observaciones"><Textarea value={form.descripcion_manual || ""} onChange={e => set("descripcion_manual", e.target.value)} rows={3} /></Field>
            </div>
            <div className="sm:col-span-2 lg:col-span-3">
              <Field label="Descripción para sitio público (opcional)"><Textarea value={form.descripcion_publica || ""} onChange={e => set("descripcion_publica", e.target.value)} rows={3} placeholder="Si está vacía, se usa la descripción manual." /></Field>
            </div>
            <div className="sm:col-span-2 lg:col-span-3">
              <Field label="Notas internas (no se publica)"><Textarea value={form.notas_internas || ""} onChange={e => set("notas_internas", e.target.value)} rows={2} /></Field>
            </div>
            <div className="sm:col-span-2 lg:col-span-3 flex items-center justify-between rounded-md border p-3 bg-muted/30">
              <div>
                <div className="font-medium text-sm">Mostrar en sitio web público</div>
                <div className="text-xs text-muted-foreground">Si está activo, el auto aparece en /catalogo automáticamente.</div>
              </div>
              <Checkbox checked={!!form.mostrar_publico} onCheckedChange={v => set("mostrar_publico", !!v)} />
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="fotos">
          <Card className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">Mínimo recomendado: 6 fotos. Máx 10MB c/u.</div>
              <label className="inline-flex">
                <input type="file" accept="image/*" multiple className="hidden" onChange={e => e.target.files && uploadPhotos(e.target.files)} />
                <Button asChild variant="outline"><span><Upload className="w-4 h-4" /> Subir fotos</span></Button>
              </label>
            </div>
            {photos.length === 0 ? <div className="text-center py-10 text-muted-foreground text-sm">Todavía no hay fotos</div> : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                {photos.map(p => (
                  <div key={p.id} className="relative group">
                    <img src={p.url} className="w-full aspect-square object-cover rounded-md border" alt="" />
                    {p.es_portada && <Badge className="absolute top-2 left-2 bg-amber-500 text-white">Portada</Badge>}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition rounded-md flex items-center justify-center gap-2">
                      {!p.es_portada && <Button size="icon" variant="secondary" onClick={() => setPortada(p.id)}><Star className="w-4 h-4" /></Button>}
                      <Button size="icon" variant="destructive" onClick={() => delPhoto(p)}><Trash2 className="w-4 h-4" /></Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </TabsContent>

        <TabsContent value="comercial">
          <Card className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Field label="Vendedor"><Input value={form.vendedor_nombre || ""} onChange={e => set("vendedor_nombre", e.target.value)} /></Field>
            <Field label="Sucursal"><Input value={form.sucursal || ""} onChange={e => set("sucursal", e.target.value)} /></Field>
            <Field label="Teléfono"><Input value={form.vendedor_telefono || ""} onChange={e => set("vendedor_telefono", e.target.value)} /></Field>
            <Field label="WhatsApp"><Input value={form.vendedor_whatsapp || ""} onChange={e => set("vendedor_whatsapp", e.target.value)} placeholder="ej: 5491155556666" /></Field>
            <Field label="Comisión"><Input type="number" value={form.comision || 0} onChange={e => set("comision", Number(e.target.value))} /></Field>
            <Field label="Proveedor"><Input value={form.proveedor || ""} onChange={e => set("proveedor", e.target.value)} /></Field>
          </Card>
        </TabsContent>

        <TabsContent value="ia">
          <Card className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">Descripciones para publicar</h3>
                <p className="text-xs text-muted-foreground">La IA genera título + texto optimizado para ML, IG y FB usando solo los datos cargados.</p>
              </div>
              <Button onClick={generarIA} disabled={genLoading}>{genLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />} Generar con IA</Button>
            </div>
            <Field label="Título"><Input value={aiDesc.titulo || ""} onChange={e => setAiDesc({ ...aiDesc, titulo: e.target.value })} /></Field>
            <Field label="Mercado Libre"><Textarea value={aiDesc.ml_desc || ""} onChange={e => setAiDesc({ ...aiDesc, ml_desc: e.target.value })} rows={6} /></Field>
            <Field label="Instagram"><Textarea value={aiDesc.ig_caption || ""} onChange={e => setAiDesc({ ...aiDesc, ig_caption: e.target.value })} rows={4} /></Field>
            <Field label="Facebook"><Textarea value={aiDesc.fb_caption || ""} onChange={e => setAiDesc({ ...aiDesc, fb_caption: e.target.value })} rows={4} /></Field>
            <Button onClick={openPublish} className="w-full"><Send className="w-4 h-4" /> Publicar en plataformas</Button>
          </Card>
        </TabsContent>

        <TabsContent value="historial">
          <Card className="p-4 space-y-2">
            {history.length === 0 ? <div className="text-sm text-muted-foreground">Sin publicaciones todavía</div> : history.map(h => (
              <div key={h.id} className="flex items-center justify-between border-b py-2 text-sm">
                <div>
                  <div className="font-medium capitalize">{h.platform} · {h.listing_type || '-'}</div>
                  <div className="text-xs text-muted-foreground">{new Date(h.created_at).toLocaleString()}</div>
                  {h.error_message && <div className="text-xs text-red-600">{h.error_message}</div>}
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={h.status === 'publicado' ? 'default' : h.status === 'error' ? 'destructive' : 'secondary'}>{h.status}</Badge>
                  {h.external_url && <a href={h.external_url} target="_blank" rel="noreferrer" className="text-primary"><ExternalLink className="w-4 h-4" /></a>}
                </div>
              </div>
            ))}
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={publishOpen} onOpenChange={setPublishOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Publicar en plataformas</DialogTitle></DialogHeader>
          <div className="space-y-4">
            {/* ML */}
            <Card className="p-3">
              <label className="flex items-start gap-2 cursor-pointer">
                <Checkbox checked={selML} onCheckedChange={v => setSelML(!!v)} />
                <div className="flex-1">
                  <div className="font-medium">Mercado Libre</div>
                  {mlAccs.length === 0 ? <div className="text-xs text-amber-600">Conectá una cuenta de ML en /canales</div> : (
                    <div className="space-y-2 mt-2">
                      <Select value={mlAcc} onValueChange={v => { setMlAcc(v); setMlLT(""); }}>
                        <SelectTrigger><SelectValue placeholder="Elegí cuenta" /></SelectTrigger>
                        <SelectContent>{mlAccs.map(a => <SelectItem key={a.id} value={a.id}>{a.account_name}</SelectItem>)}</SelectContent>
                      </Select>
                      {mlAcc && (
                        <div className="flex gap-2">
                          <Select value={mlLT} onValueChange={setMlLT}>
                            <SelectTrigger><SelectValue placeholder="Tipo de publicación" /></SelectTrigger>
                            <SelectContent>
                              {(listingTypes[mlAcc] || []).map(lt => (
                                <SelectItem key={lt.listing_type_id} value={lt.listing_type_id} disabled={lt.available_quantity === 0}>
                                  {lt.name} · {lt.available_quantity === null ? 'cupos s/d' : `${lt.available_quantity} disp.`}
                                </SelectItem>
                              ))}
                              {(listingTypes[mlAcc] || []).length === 0 && <div className="px-2 py-1.5 text-xs text-muted-foreground">Sin tipos cargados</div>}
                            </SelectContent>
                          </Select>
                          <Button size="sm" variant="outline" onClick={() => refreshListingTypes(mlAcc)}>Refrescar</Button>
                        </div>
                      )}
                    </div>
                  )}
                  <LastInfo plat="mercadolibre" />
                </div>
              </label>
            </Card>



            {/* IG */}
            <Card className="p-3">
              <label className="flex items-start gap-2 cursor-pointer">
                <Checkbox checked={selIG} onCheckedChange={v => setSelIG(!!v)} />
                <div className="flex-1">
                  <div className="font-medium">Instagram</div>
                  {igAccs.length === 0 ? <div className="text-xs text-amber-600">Conectá Instagram Business en /canales</div> : (
                    <div className="space-y-2 mt-2">
                      <Select value={igAcc} onValueChange={setIgAcc}>
                        <SelectTrigger><SelectValue placeholder="Elegí cuenta" /></SelectTrigger>
                        <SelectContent>{igAccs.map(a => <SelectItem key={a.id} value={a.id}>{a.account_name}</SelectItem>)}</SelectContent>
                      </Select>
                      <label className="flex items-center gap-2 text-sm"><Checkbox checked={igCarousel} onCheckedChange={v => setIgCarousel(!!v)} /> Publicar como carrusel (hasta 10 fotos)</label>
                    </div>
                  )}
                  <LastInfo plat="instagram" />
                </div>
              </label>
            </Card>

            {/* FB */}
            <Card className="p-3">
              <label className="flex items-start gap-2 cursor-pointer">
                <Checkbox checked={selFB} onCheckedChange={v => setSelFB(!!v)} />
                <div className="flex-1">
                  <div className="font-medium">Facebook</div>
                  <div className="text-xs text-muted-foreground">Publica como post en la página. Marketplace de autos no está habilitado por la API de Meta para terceros.</div>
                  {fbAccs.length === 0 ? <div className="text-xs text-amber-600 mt-1">Conectá una página de Facebook en /canales</div> : (
                    <Select value={fbAcc} onValueChange={setFbAcc}>
                      <SelectTrigger className="mt-2"><SelectValue placeholder="Elegí página" /></SelectTrigger>
                      <SelectContent>{fbAccs.map(a => <SelectItem key={a.id} value={a.id}>{a.account_name}</SelectItem>)}</SelectContent>
                    </Select>
                  )}
                  <LastInfo plat="facebook" />
                </div>
              </label>
            </Card>

            {results.length > 0 && (
              <Card className="p-3 space-y-2">
                <div className="font-medium">Resultados</div>
                {results.map((r, i) => (
                  <div key={i} className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      {r.ok ? <CheckCircle2 className="w-4 h-4 text-green-600" /> : <XCircle className="w-4 h-4 text-red-600" />}
                      <span className="capitalize">{r.platform}</span>
                    </div>
                    {r.ok ? <a href={r.url} target="_blank" rel="noreferrer" className="text-primary text-xs flex items-center gap-1">Ver publicación <ExternalLink className="w-3 h-3" /></a> : <span className="text-xs text-red-600">{r.error}</span>}
                  </div>
                ))}
              </Card>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPublishOpen(false)}>Cerrar</Button>
            <Button onClick={doPublish} disabled={pubLoading}>{pubLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />} {hasAnyPublished ? "Republicar ahora" : "Publicar ahora"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={marketOpen} onOpenChange={setMarketOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><TrendingUp className="w-5 h-5" /> Análisis de mercado</DialogTitle></DialogHeader>
          {marketLoading ? (
            <div className="py-10 text-center text-muted-foreground"><Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" /> Buscando vehículos similares en Mercado Libre…</div>
          ) : !market ? (
            <div className="py-10 text-center text-muted-foreground">Sin datos todavía.</div>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {[
                  ["Mínimo", market.price_min],
                  ["Promedio", market.price_avg],
                  ["Mediana", market.price_median],
                  ["Máximo", market.price_max],
                  ["Sugerido", market.price_recommended],
                ].map(([label, val]) => (
                  <Card key={label as string} className="p-3 text-center">
                    <div className="text-[10px] text-muted-foreground uppercase">{label}</div>
                    <div className="font-bold">{market.summary?.currency || 'ARS'} {Math.round(Number(val)).toLocaleString()}</div>
                  </Card>
                ))}
              </div>
              <Card className="p-3 bg-muted/50">
                <div className="text-sm"><b>Tu precio:</b> {market.summary?.currency || 'ARS'} {Math.round(market.my_price).toLocaleString()} · Posición {market.my_position}/{market.total_results} · <b>{market.competitiveness}</b></div>
                <div className="text-sm mt-1"><b>Diferencia vs promedio:</b> {market.diff_pct > 0 ? '+' : ''}{market.diff_pct}%</div>
                <div className="text-sm mt-2"><Sparkles className="w-3 h-3 inline" /> {market.recommendation}</div>
              </Card>
              <div>
                <div className="text-sm font-medium mb-2">Top similares por precio</div>
                <div className="space-y-1 max-h-96 overflow-y-auto">
                  {(market.items || []).sort((a: any, b: any) => a.price - b.price).map((it: any) => {
                    const diff = market.price_avg ? Math.round(((it.price - market.price_avg) / market.price_avg) * 100) : 0;
                    return (
                      <a key={it.id} href={it.permalink} target="_blank" rel="noreferrer" className="flex items-center gap-2 p-2 rounded border hover:bg-muted text-xs">
                        {it.thumbnail && <img src={it.thumbnail} className="w-10 h-10 object-cover rounded" alt="" />}
                        <div className="flex-1 min-w-0">
                          <div className="font-medium truncate">{it.title}</div>
                          <div className="text-muted-foreground">{it.year || '?'} · {it.km ? `${it.km.toLocaleString()} km` : 'km s/d'} · {it.location || '—'}</div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="font-bold">{it.currency} {Number(it.price).toLocaleString()}</div>
                          <div className={diff < 0 ? "text-green-600" : diff > 10 ? "text-red-600" : "text-muted-foreground"}>{diff > 0 ? '+' : ''}{diff}%</div>
                        </div>
                        <ExternalLink className="w-3 h-3 text-muted-foreground" />
                      </a>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setMarketOpen(false)}>Cerrar</Button>
            <Button onClick={analizarMercado} disabled={marketLoading}>{marketLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <TrendingUp className="w-4 h-4" />} Reanalizar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="space-y-1"><Label className="text-xs">{label}</Label>{children}</div>;
}
