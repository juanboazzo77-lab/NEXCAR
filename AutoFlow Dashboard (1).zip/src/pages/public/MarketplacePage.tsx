import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { supabase } from "@/integrations/supabase/client";
import PublicLayout from "./PublicLayout";
import { FavButton, CompareButton } from "@/components/public/CarActions";
import { MapPin, Navigation } from "lucide-react";
import Pagination, { usePagination } from "@/components/public/Pagination";

type Row = any;

const formatPrice = (v: number | null, moneda: string | null) => {
  if (!v) return "Consultar";
  return `${moneda === "USD" ? "USD" : "$"} ${Math.round(v).toLocaleString("es-AR")}`;
};

const haversineKm = (lat1: number, lng1: number, lat2: number, lng2: number) => {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
};

export default function MarketplacePage() {
  const [cars, setCars] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [marca, setMarca] = useState("");
  const [provincia, setProvincia] = useState("");
  const [agencia, setAgencia] = useState("");
  const [precioMax, setPrecioMax] = useState("");
  const [anioMin, setAnioMin] = useState("");
  const [orden, setOrden] = useState("recientes");
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);
  const [radio, setRadio] = useState("100");

  useEffect(() => {
    (async () => {
      setLoading(true);
      const { data: list } = await supabase
        .from("cars_public")
        .select("*")
        .eq("mostrar_publico", true)
        .eq("agency_marketplace_visible", true)
        .in("estado", ["Disponible", "Reservado"])
        .order("created_at", { ascending: false })
        .limit(500);
      const ids = (list || []).map((c: any) => c.id);
      const coverByCar: Record<string, string> = {};
      if (ids.length) {
        const { data: photos } = await supabase
          .from("car_photos").select("car_id,url,es_portada,orden").in("car_id", ids)
          .order("es_portada", { ascending: false }).order("orden", { ascending: true });
        (photos || []).forEach((p: any) => { if (!coverByCar[p.car_id]) coverByCar[p.car_id] = p.url; });
      }
      setCars((list || []).map((c: any) => ({ ...c, cover: coverByCar[c.id] || null })));
      setLoading(false);
    })();
  }, []);

  const marcas = useMemo(() => Array.from(new Set(cars.map((c) => c.marca).filter(Boolean))).sort(), [cars]);
  const provincias = useMemo(
    () => Array.from(new Set(cars.map((c) => c.agency_provincia || c.provincia).filter(Boolean))).sort(),
    [cars]
  );
  const agencias = useMemo(
    () => Array.from(new Map(cars.filter((c) => c.agency_id).map((c) => [c.agency_id, c.agency_name])).entries()),
    [cars]
  );

  const withDistance = useMemo(
    () =>
      cars.map((c) => ({
        ...c,
        _dist:
          pos && c.agency_lat != null && c.agency_lng != null
            ? haversineKm(pos.lat, pos.lng, c.agency_lat, c.agency_lng)
            : null,
      })),
    [cars, pos]
  );

  const filtered = useMemo(() => {
    let r = withDistance.filter((c) => {
      if (marca && c.marca !== marca) return false;
      if (provincia && (c.agency_provincia || c.provincia) !== provincia) return false;
      if (agencia && c.agency_id !== agencia) return false;
      if (precioMax && (c.precio_venta || 0) > Number(precioMax)) return false;
      if (anioMin && c.anio < Number(anioMin)) return false;
      if (pos && radio && c._dist != null && c._dist > Number(radio)) return false;
      if (q) {
        const t = `${c.marca} ${c.modelo} ${c.version || ""} ${c.anio} ${c.agency_name || ""}`.toLowerCase();
        if (!t.includes(q.toLowerCase())) return false;
      }
      return true;
    });
    switch (orden) {
      case "precio-asc": r = [...r].sort((a, b) => (a.precio_venta || 0) - (b.precio_venta || 0)); break;
      case "precio-desc": r = [...r].sort((a, b) => (b.precio_venta || 0) - (a.precio_venta || 0)); break;
      case "km-asc": r = [...r].sort((a, b) => (a.kilometros || 0) - (b.kilometros || 0)); break;
      case "nuevos": r = [...r].sort((a, b) => b.anio - a.anio); break;
      case "cerca": r = [...r].sort((a, b) => (a._dist ?? 1e9) - (b._dist ?? 1e9)); break;
    }
    // Prioridad ORO: dentro de los resultados ya relevantes y ordenados,
    // los destacados suben sin romper filtros, búsqueda ni radio.
    r = [...r].sort((a, b) => (b.marketplace_tier === "gold" ? 1 : 0) - (a.marketplace_tier === "gold" ? 1 : 0));
    return r;
  }, [withDistance, q, marca, provincia, agencia, precioMax, anioMin, orden, pos, radio]);

  const pg = usePagination(filtered, "mk_page_size", 12);

  const pedirUbicacion = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (p) => { setPos({ lat: p.coords.latitude, lng: p.coords.longitude }); setOrden("cerca"); },
      () => setPos(null)
    );
  };

  return (
    <PublicLayout>
      <Helmet>
        <title>Marketplace de vehículos · Todas las agencias</title>
        <meta name="description" content="Buscá vehículos usados y 0km de todas las agencias adheridas. Filtrá por marca, precio, provincia y cercanía." />
      </Helmet>

      <section className="bg-gradient-to-br from-slate-900 to-slate-700 text-white">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight">Marketplace de agencias</h1>
          <p className="mt-2 text-slate-200">Todo el stock publicado por las agencias de la red, en un solo buscador.</p>
          <div className="mt-6 bg-white rounded-2xl p-3 shadow-lg flex flex-col sm:flex-row gap-2">
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar marca, modelo o agencia..."
              className="flex-1 px-4 py-3 rounded-xl bg-slate-100 text-slate-900 outline-none" />
            <select value={orden} onChange={(e) => setOrden(e.target.value)} className="px-4 py-3 rounded-xl bg-slate-100 text-slate-900 outline-none">
              <option value="recientes">Más recientes</option>
              <option value="nuevos">Más nuevos</option>
              <option value="precio-asc">Menor precio</option>
              <option value="precio-desc">Mayor precio</option>
              <option value="km-asc">Menor kilometraje</option>
              <option value="cerca">Más cercanos</option>
            </select>
          </div>
          <button onClick={pedirUbicacion} className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 text-sm font-medium">
            <Navigation className="w-4 h-4" /> {pos ? "Ubicación activada" : "Buscar cerca mío"}
          </button>
        </div>
      </section>

      {/* Directorio de agencias: tocá una para ver su stock */}
      <section className="max-w-7xl mx-auto px-4 pt-8">
        <h2 className="font-semibold text-lg">Agencias de la red</h2>
        <p className="text-sm text-slate-500">Tocá el nombre de una agencia para ver solo su stock.</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            onClick={() => setAgencia("")}
            className={`px-4 py-2 rounded-full text-sm font-medium border transition ${!agencia ? "bg-slate-900 text-white border-slate-900" : "bg-white text-slate-700 hover:bg-slate-100"}`}>
            Todas
          </button>
          {agencias.map(([id, name]) => {
            const count = cars.filter((c) => c.agency_id === id).length;
            const active = agencia === id;
            return (
              <button key={id as string} onClick={() => setAgencia(active ? "" : (id as string))}
                className={`px-4 py-2 rounded-full text-sm font-medium border transition ${active ? "bg-slate-900 text-white border-slate-900" : "bg-white text-slate-700 hover:bg-slate-100"}`}>
                {(name as string) || "Agencia"} <span className={active ? "text-slate-300" : "text-slate-400"}>({count})</span>
              </button>
            );
          })}
        </div>
        {agencia && (
          <div className="mt-3 text-sm">
            <Link to={`/agencia/${cars.find((c) => c.agency_id === agencia)?.agency_slug || ""}`}
              className="text-emerald-600 hover:underline font-medium">
              Ver el catálogo completo de {agencias.find(([id]) => id === agencia)?.[1] as string} →
            </Link>
          </div>
        )}
      </section>

      <section className="max-w-7xl mx-auto px-4 py-8 grid lg:grid-cols-[260px_1fr] gap-6">
        <aside className="bg-white rounded-2xl p-4 h-fit border space-y-4 lg:sticky lg:top-20">

          <h3 className="font-semibold">Filtros</h3>
          <Field label="Marca">
            <select value={marca} onChange={(e) => setMarca(e.target.value)} className="w-full mk-input">
              <option value="">Todas</option>
              {marcas.map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
          </Field>
          <Field label="Provincia">
            <select value={provincia} onChange={(e) => setProvincia(e.target.value)} className="w-full mk-input">
              <option value="">Todas</option>
              {provincias.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </Field>
          <Field label="Agencia">
            <select value={agencia} onChange={(e) => setAgencia(e.target.value)} className="w-full mk-input">
              <option value="">Todas</option>
              {agencias.map(([id, name]) => <option key={id} value={id as string}>{name as string}</option>)}
            </select>
          </Field>
          {pos && (
            <Field label={`Radio (${radio} km)`}>
              <input type="range" min={10} max={500} step={10} value={radio} onChange={(e) => setRadio(e.target.value)} className="w-full" />
            </Field>
          )}
          <Field label="Precio máximo">
            <input type="number" value={precioMax} onChange={(e) => setPrecioMax(e.target.value)} className="w-full mk-input" placeholder="$" />
          </Field>
          <Field label="Año desde">
            <input type="number" value={anioMin} onChange={(e) => setAnioMin(e.target.value)} className="w-full mk-input" placeholder="2015" />
          </Field>
          <button onClick={() => { setMarca(""); setProvincia(""); setAgencia(""); setPrecioMax(""); setAnioMin(""); setQ(""); }}
            className="w-full text-sm text-slate-600 hover:text-slate-900 underline">Limpiar filtros</button>
          <style>{`.mk-input{padding:.55rem .75rem;border:1px solid #e2e8f0;border-radius:.625rem;background:#f8fafc;outline:none;font-size:.875rem}`}</style>
        </aside>

        <div>
          <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
            <div className="text-sm text-slate-600">{filtered.length} vehículos publicados</div>
          </div>
          {loading ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="bg-white rounded-2xl border overflow-hidden animate-pulse">
                  <div className="aspect-[4/3] bg-slate-200" /><div className="p-4 h-16" />
                </div>
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="bg-white rounded-2xl border p-12 text-center text-slate-500">No encontramos vehículos con esos filtros.</div>
          ) : (
            <>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {pg.pageItems.map((c: any) => (
                <div key={c.id} className="group bg-white rounded-2xl border overflow-hidden hover:shadow-xl transition relative">
                  <FavButton carId={c.id} className="absolute top-3 right-3 z-10" />
                  {c.marketplace_tier === "gold" && (
                    <span className="absolute top-3 left-3 z-10 rounded-full bg-yellow-400 text-yellow-950 text-[10px] font-bold px-2 py-1 shadow">
                      DESTACADO
                    </span>
                  )}
                  <Link to={c.agency_slug ? `/agencia/${c.agency_slug}/auto/${c.slug || c.id}` : `/catalogo/${c.slug || c.id}`} className="block">
                    <div className="aspect-[4/3] bg-slate-100 overflow-hidden">
                      {c.cover ? (
                        <img src={c.cover} alt={`${c.marca} ${c.modelo}`} className="w-full h-full object-cover group-hover:scale-105 transition" />
                      ) : (
                        <div className="w-full h-full grid place-items-center text-slate-400 text-sm">Sin foto</div>
                      )}
                    </div>
                    <div className="p-4">
                      <div className="text-sm text-slate-500">{c.marca}</div>
                      <div className="font-semibold leading-tight">{c.modelo} {c.version || ""}</div>
                      <div className="text-xs text-slate-500 mt-1">
                        {c.anio} · {c.kilometros ? `${c.kilometros.toLocaleString("es-AR")} km` : "—"}
                      </div>
                      <div className="mt-2 text-xs text-slate-600 flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5" />
                        {c.agency_name || "Agencia"}
                        {c.agency_ciudad ? ` · ${c.agency_ciudad}` : ""}
                        {c._dist != null ? ` · ${Math.round(c._dist)} km` : ""}
                      </div>
                      <div className="mt-3 text-lg font-bold">{formatPrice(c.precio_venta, c.moneda)}</div>
                    </div>
                  </Link>
                  <div className="px-4 pb-4"><CompareButton carId={c.id} /></div>
                </div>
              ))}
            </div>
            <Pagination page={pg.page} totalPages={pg.totalPages} perPage={pg.perPage} total={pg.total}
              onPage={(p) => { pg.setPage(p); window.scrollTo({ top: 0, behavior: "smooth" }); }}
              onPerPage={pg.setPerPage} />
            </>
          )}
        </div>
      </section>
    </PublicLayout>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="text-xs font-medium text-slate-600 mb-1">{label}</div>
      {children}
    </label>
  );
}
