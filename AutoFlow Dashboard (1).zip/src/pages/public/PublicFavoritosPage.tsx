import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import PublicLayout, { usePublicSettings } from "./PublicLayout";
import { FavButton, CompareButton } from "@/components/public/CarActions";
import { useFavoritos } from "@/hooks/use-public-lists";
import { Favoritos } from "@/lib/public-storage";
import { Heart, Trash2 } from "lucide-react";

const fmt = (v: number | null, m: string | null) => !v ? "Consultar" : `${m === "USD" ? "USD" : "$"} ${Math.round(v).toLocaleString("es-AR")}`;

export default function PublicFavoritosPage() {
  const s = usePublicSettings();
  const ids = useFavoritos();
  const [cars, setCars] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      if (!ids.length) { setCars([]); setLoading(false); return; }
      const { data } = await supabase.from("cars_public")
        .select("id,slug,marca,modelo,version,anio,kilometros,precio_venta,moneda,combustible,estado")
        .in("id", ids).eq("mostrar_publico", true);
      const { data: ph } = await supabase.from("car_photos").select("car_id,url,es_portada,orden")
        .in("car_id", ids).order("es_portada", { ascending: false }).order("orden", { ascending: true });
      const covers: Record<string, string> = {};
      (ph || []).forEach((p: any) => { if (!covers[p.car_id]) covers[p.car_id] = p.url; });
      setCars((data || []).map((c: any) => ({ ...c, cover: covers[c.id] })));
      setLoading(false);
    })();
  }, [ids.join(",")]);

  const wa = (c: any) => {
    const m = encodeURIComponent(`Hola! Me interesa el ${c.marca} ${c.modelo} ${c.version || ""} ${c.anio}.`);
    return `https://wa.me/${s.whatsapp_number.replace(/\D/g, "")}?text=${m}`;
  };

  return (
    <PublicLayout>
      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-2"><Heart className="text-rose-500 fill-rose-500" /> Mis Favoritos</h1>
            <p className="text-slate-500 text-sm mt-1">{ids.length} vehículo{ids.length !== 1 ? "s" : ""} guardado{ids.length !== 1 ? "s" : ""} en este navegador.</p>
          </div>
          {ids.length > 0 && (
            <button onClick={() => Favoritos.clear()} className="text-sm text-slate-500 hover:text-rose-600 inline-flex items-center gap-1.5">
              <Trash2 className="w-4 h-4" /> Vaciar
            </button>
          )}
        </div>

        {loading ? <div className="mt-8 text-slate-500">Cargando...</div> :
          cars.length === 0 ? (
            <div className="mt-8 bg-white rounded-2xl border p-12 text-center text-slate-500">
              Todavía no agregaste favoritos. Volvé al <Link to="/catalogo" className="underline">catálogo</Link> y marcá con ❤️ los autos que te interesen.
            </div>
          ) : (
            <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {cars.map((c) => (
                <div key={c.id} className="bg-white rounded-2xl border overflow-hidden relative group">
                  <FavButton carId={c.id} className="absolute top-3 right-3 z-10" />
                  <Link to={`/catalogo/${c.slug || c.id}`}>
                    <div className="aspect-[4/3] bg-slate-100">
                      {c.cover ? <img src={c.cover} className="w-full h-full object-cover" /> : <div className="grid place-items-center h-full text-slate-400 text-sm">Sin foto</div>}
                    </div>
                    <div className="p-4">
                      <div className="text-sm text-slate-500">{c.marca}</div>
                      <div className="font-semibold">{c.modelo} {c.version || ""}</div>
                      <div className="text-xs text-slate-500 mt-1">{c.anio} · {c.kilometros ? `${c.kilometros.toLocaleString("es-AR")} km` : "—"}</div>
                      <div className="mt-2 font-bold">{fmt(c.precio_venta, c.moneda)}</div>
                    </div>
                  </Link>
                  <div className="px-4 pb-4 flex gap-2">
                    <CompareButton carId={c.id} label={false} />
                    <a href={wa(c)} target="_blank" rel="noreferrer" className="ml-auto text-xs font-medium px-3 py-1.5 rounded-full bg-emerald-500 text-white">WhatsApp</a>
                  </div>
                </div>
              ))}
            </div>
          )}
      </div>
    </PublicLayout>
  );
}
