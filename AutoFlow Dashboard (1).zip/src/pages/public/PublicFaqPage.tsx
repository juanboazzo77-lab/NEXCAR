import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import PublicLayout, { usePublicSettings } from "./PublicLayout";
import { ChevronDown } from "lucide-react";

export default function PublicFaqPage() {
  const [faqs, setFaqs] = useState<any[]>([]);
  const [open, setOpen] = useState<string | null>(null);
  const settings: any = usePublicSettings();
  const agencyId = settings?.agency_id ?? null;

  useEffect(() => {
    let q = supabase.from("public_faqs").select("*").eq("activo", true).order("orden");
    if (agencyId) q = q.eq("agency_id", agencyId);
    q.then(({ data }) => setFaqs(data || []));
  }, [agencyId]);

  return (
    <PublicLayout>
      <div className="max-w-3xl mx-auto px-4 py-12">
        <h1 className="text-3xl sm:text-4xl font-bold">Preguntas frecuentes</h1>
        <p className="text-slate-500 text-sm mt-2">Resolvé las dudas más comunes antes de comunicarte.</p>

        <div className="mt-8 space-y-2">
          {faqs.length === 0 && <div className="text-slate-500 text-sm">Todavía no hay preguntas cargadas.</div>}
          {faqs.map((f) => (
            <div key={f.id} className="bg-white rounded-xl border overflow-hidden">
              <button onClick={() => setOpen(open === f.id ? null : f.id)}
                className="w-full text-left px-4 py-3 flex items-center justify-between gap-2 hover:bg-slate-50">
                <span className="font-medium text-sm">{f.pregunta}</span>
                <ChevronDown className={`w-4 h-4 transition ${open === f.id ? "rotate-180" : ""}`} />
              </button>
              {open === f.id && <div className="px-4 pb-4 text-sm text-slate-700 whitespace-pre-line">{f.respuesta}</div>}
            </div>
          ))}
        </div>
      </div>
    </PublicLayout>
  );
}
