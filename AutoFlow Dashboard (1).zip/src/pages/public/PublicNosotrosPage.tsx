import PublicLayout, { usePublicSettings } from "./PublicLayout";
import { Check } from "lucide-react";

export default function PublicNosotrosPage() {
  const s = usePublicSettings();
  return (
    <PublicLayout>
      <section className="bg-gradient-to-br from-slate-900 to-slate-700 text-white">
        <div className="max-w-6xl mx-auto px-4 py-16">
          <h1 className="text-3xl sm:text-5xl font-bold tracking-tight">Sobre {s.nombre_agencia}</h1>
          {s.nosotros_historia && <p className="mt-4 text-slate-200 max-w-3xl whitespace-pre-line">{s.nosotros_historia}</p>}
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 py-12 space-y-12">
        {(s.nosotros_mision || s.nosotros_valores) && (
          <div className="grid md:grid-cols-2 gap-6">
            {s.nosotros_mision && (
              <div className="bg-white rounded-2xl border p-6">
                <h2 className="font-semibold mb-2">Nuestra misión</h2>
                <p className="text-sm text-slate-700 whitespace-pre-line">{s.nosotros_mision}</p>
              </div>
            )}
            {s.nosotros_valores && (
              <div className="bg-white rounded-2xl border p-6">
                <h2 className="font-semibold mb-2">Nuestros valores</h2>
                <p className="text-sm text-slate-700 whitespace-pre-line">{s.nosotros_valores}</p>
              </div>
            )}
          </div>
        )}

        {s.motivos.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold">¿Por qué elegirnos?</h2>
            <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {s.motivos.map((m, i) => (
                <div key={i} className="bg-white rounded-xl border p-4 flex items-start gap-2 text-sm">
                  <Check className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" /> <span>{m}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {s.nosotros_fotos.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold">Nuestro local y equipo</h2>
            <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {s.nosotros_fotos.map((url, i) => (
                <div key={i} className="aspect-[4/3] bg-slate-100 rounded-xl overflow-hidden">
                  <img src={url} alt="" className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl border p-6 space-y-2 text-sm">
            <h2 className="font-semibold text-base">Contacto</h2>
            {s.direccion && <div>📍 {s.direccion}</div>}
            {s.horarios && <div>🕐 {s.horarios}</div>}
            {s.telefono && <div>📞 {s.telefono}</div>}
            {s.email && <div>✉️ {s.email}</div>}
            <div className="pt-2 flex gap-2 flex-wrap">
              <a href={`https://wa.me/${s.whatsapp_number.replace(/\D/g, "")}`} target="_blank" rel="noreferrer"
                className="px-3 py-1.5 rounded-full bg-emerald-500 text-white text-xs font-medium">WhatsApp</a>
              {s.instagram_url && <a href={s.instagram_url} target="_blank" rel="noreferrer" className="px-3 py-1.5 rounded-full bg-slate-100 text-xs">Instagram</a>}
              {s.facebook_url && <a href={s.facebook_url} target="_blank" rel="noreferrer" className="px-3 py-1.5 rounded-full bg-slate-100 text-xs">Facebook</a>}
              {s.tiktok_url && <a href={s.tiktok_url} target="_blank" rel="noreferrer" className="px-3 py-1.5 rounded-full bg-slate-100 text-xs">TikTok</a>}
            </div>
          </div>
          {s.mapa_embed_url && (
            <div className="bg-white rounded-2xl border overflow-hidden aspect-video">
              <iframe src={s.mapa_embed_url} className="w-full h-full" loading="lazy" allowFullScreen />
            </div>
          )}
        </div>
      </div>
    </PublicLayout>
  );
}
