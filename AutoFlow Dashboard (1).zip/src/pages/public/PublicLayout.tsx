import { ReactNode, useEffect, useState } from "react";
import { Link, useLocation, useParams } from "react-router-dom";

import { supabase } from "@/integrations/supabase/client";
import { Heart, Menu, X } from "lucide-react";
import CompareBar from "@/components/public/CompareBar";
import AdvisorWidget from "@/components/public/AdvisorWidget";
import { useFavoritos } from "@/hooks/use-public-lists";

export type PublicSettings = {
  id?: string;
  whatsapp_number: string;
  transferencia_porcentaje: number;
  mostrar_vendidos: boolean;
  nombre_agencia: string;
  logo_url: string | null;
  financiacion_activa: boolean;
  financiacion_tasa: number;
  financiacion_cuotas_max: number;
  financiacion_gastos_porcentaje: number;
  nosotros_historia: string | null;
  nosotros_mision: string | null;
  nosotros_valores: string | null;
  nosotros_fotos: string[];
  horarios: string | null;
  direccion: string | null;
  mapa_embed_url: string | null;
  telefono: string | null;
  email: string | null;
  instagram_url: string | null;
  facebook_url: string | null;
  tiktok_url: string | null;
  motivos: string[];
};

const DEFAULTS: PublicSettings = {
  whatsapp_number: "+5491165361978",
  transferencia_porcentaje: 4,
  mostrar_vendidos: false,
  nombre_agencia: "Grupo Boazzo",
  logo_url: null,
  financiacion_activa: true,
  financiacion_tasa: 75,
  financiacion_cuotas_max: 60,
  financiacion_gastos_porcentaje: 0,
  nosotros_historia: null,
  nosotros_mision: null,
  nosotros_valores: null,
  nosotros_fotos: [],
  horarios: "Lun a Vie 9 a 17hs · Sáb 10 a 13hs",
  direccion: "Calle 42 Nro 883 e/ 12 y 13 — La Plata",
  mapa_embed_url: null,
  telefono: null,
  email: null,
  instagram_url: null,
  facebook_url: null,
  tiktok_url: null,
  motivos: [
    "Vehículos seleccionados",
    "Atención personalizada",
    "Transparencia en cada operación",
    "Asesoramiento profesional",
    "Gestión integral de transferencia",
    "Posibilidad de financiación",
    "Recepción de vehículos en parte de pago",
  ],
};

/** Alcance público: catálogo global (/catalogo) o catálogo de una agencia (/agencia/:agencySlug). */
export function usePublicScope() {
  const { agencySlug } = useParams();
  const base = agencySlug ? `/agencia/${agencySlug}` : "/catalogo";
  return {
    agencySlug: agencySlug || null,
    base,
    carHref: (idOrSlug: string) => (agencySlug ? `${base}/auto/${idOrSlug}` : `/catalogo/${idOrSlug}`),
  };
}

export function usePublicSettings() {
  const { agencySlug } = usePublicScope();
  const [settings, setSettings] = useState<PublicSettings>(DEFAULTS);
  useEffect(() => {
    let active = true;
    (async () => {
      let agencyRow: any = null;
      if (agencySlug) {
        const { data: ag } = await supabase
          .from("agencies").select("*").eq("slug", agencySlug).eq("status", "active").maybeSingle();
        agencyRow = ag;
      }

      // Config del sitio público: la de la agencia si estamos en su catálogo
      let query = supabase.from("public_settings").select("*");
      query = agencyRow?.id
        ? query.eq("agency_id", agencyRow.id)
        : query.order("is_default", { ascending: false });
      const { data } = await query.limit(1).maybeSingle();

      let next: PublicSettings = DEFAULTS;
      if (data) {
        const d: any = data;
        next = {
          ...DEFAULTS,
          ...d,
          nosotros_fotos: Array.isArray(d.nosotros_fotos) ? d.nosotros_fotos : [],
          motivos: Array.isArray(d.motivos) && d.motivos.length ? d.motivos : DEFAULTS.motivos,
        };
      }
      if (agencyRow) {
        const a: any = agencyRow;
        next = {
          ...next,
          nombre_agencia: a.name || next.nombre_agencia,
          logo_url: a.logo_url ?? next.logo_url,
          whatsapp_number: a.whatsapp || next.whatsapp_number,
          direccion: a.direccion ?? next.direccion,
          horarios: a.horarios ?? next.horarios,
          telefono: a.telefono ?? next.telefono,
          email: a.email ?? next.email,
          instagram_url: a.instagram_url ?? next.instagram_url,
          facebook_url: a.facebook_url ?? next.facebook_url,
          tiktok_url: a.tiktok_url ?? next.tiktok_url,
        };
      }

      if (active) setSettings(next);
    })();
    return () => { active = false; };
  }, [agencySlug]);
  return settings;
}

export default function PublicLayout({ children }: { children: ReactNode }) {
  const s = usePublicSettings();
  const { base, agencySlug } = usePublicScope();
  const favs = useFavoritos();
  const loc = useLocation();
  const [open, setOpen] = useState(false);
  const isMarketplace = loc.pathname.startsWith("/marketplace");

  const NAV = isMarketplace
    ? [{ to: "/marketplace", label: "Marketplace" }]
    : [
        { to: base, label: "Catálogo" },
        // La tasación se envía a la agencia dueña del catálogo
        { to: `${base}/tasacion`, label: "Tasar mi auto" },
        { to: agencySlug ? `${base}/nosotros` : "/catalogo/nosotros", label: "Nosotros" },
        { to: agencySlug ? `${base}/faq` : "/catalogo/faq", label: "FAQ" },
      ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
          <Link to={isMarketplace ? "/marketplace" : base} className="flex items-center gap-2 shrink-0">
            {s.logo_url ? (
              <img src={s.logo_url} alt={s.nombre_agencia} className="h-9 w-auto" />
            ) : (
              <div className="h-9 w-9 rounded-lg bg-slate-900 text-white grid place-items-center font-bold">
                {s.nombre_agencia?.[0] || "A"}
              </div>
            )}
            <div className="font-semibold tracking-tight truncate">{isMarketplace ? "Marketplace" : s.nombre_agencia}</div>
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {NAV.map((n) => {
              const active = loc.pathname === n.to;
              return (
                <Link key={n.to} to={n.to}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition ${active ? "bg-slate-900 text-white" : "text-slate-700 hover:bg-slate-100"}`}>
                  {n.label}
                </Link>
              );
            })}
          </nav>


          <div className="flex items-center gap-2">
            <Link to="/catalogo/favoritos"
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-full text-sm font-medium bg-rose-50 text-rose-600 hover:bg-rose-100 transition">
              <Heart className="w-4 h-4" fill={favs.length ? "currentColor" : "none"} />
              <span>{favs.length}</span>
            </Link>
            <a href={`https://wa.me/${s.whatsapp_number.replace(/\D/g, "")}`} target="_blank" rel="noreferrer"
              className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-600 transition">
              WhatsApp
            </a>
            <button onClick={() => setOpen((v) => !v)} className="md:hidden p-2 rounded-lg hover:bg-slate-100">
              {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
        {open && (
          <div className="md:hidden border-t bg-white">
            <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col gap-1">
              {NAV.map((n) => (
                <Link key={n.to} to={n.to} onClick={() => setOpen(false)}
                  className="px-3 py-2 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100">
                  {n.label}
                </Link>
              ))}
            </div>
          </div>
        )}
      </header>

      <main>{children}</main>

      <CompareBar />
      <AdvisorWidget />

      <footer className="border-t mt-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 py-8 text-sm text-slate-500 grid sm:grid-cols-3 gap-4">
          <div>
            <div className="font-semibold text-slate-900">{s.nombre_agencia}</div>
            <div>© {new Date().getFullYear()} · Stock sujeto a disponibilidad</div>
          </div>
          <div className="space-y-1">
            {s.direccion && <div>📍 {s.direccion}</div>}
            {s.horarios && <div>🕐 {s.horarios}</div>}
            {s.telefono && <div>📞 {s.telefono}</div>}
            {s.email && <div>✉️ {s.email}</div>}
          </div>
          <div className="flex gap-3 flex-wrap">
            {s.instagram_url && <a className="hover:text-slate-900" href={s.instagram_url} target="_blank" rel="noreferrer">Instagram</a>}
            {s.facebook_url && <a className="hover:text-slate-900" href={s.facebook_url} target="_blank" rel="noreferrer">Facebook</a>}
            {s.tiktok_url && <a className="hover:text-slate-900" href={s.tiktok_url} target="_blank" rel="noreferrer">TikTok</a>}
          </div>
        </div>
      </footer>
    </div>
  );
}
