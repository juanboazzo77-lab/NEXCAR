import { useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import PublicLayout, { usePublicSettings } from "./PublicLayout";
import { useToast } from "@/hooks/use-toast";
import { Bell, CheckCircle2 } from "lucide-react";

export default function PublicAlertaPage() {
  const { toast } = useToast();
  const s = usePublicSettings();
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);
  const [f, setF] = useState({
    cliente_nombre: "", cliente_telefono: "", cliente_whatsapp: "", cliente_email: "",
    marca: "", modelo: "", anio_aprox: "", presupuesto: "", observaciones: "",
  });
  const set = (k: string, v: string) => setF({ ...f, [k]: v });

  const submit = async () => {
    if (!f.cliente_nombre || (!f.cliente_telefono && !f.cliente_whatsapp && !f.cliente_email)) {
      toast({ title: "Indicanos tu nombre y al menos un dato de contacto", variant: "destructive" });
      return;
    }
    setLoading(true);
    const { error } = await supabase.from("vehicle_alerts").insert({
      agency_id: (s as any)?.agency_id ?? null,
      cliente_nombre: f.cliente_nombre,
      cliente_telefono: f.cliente_telefono || null,
      cliente_whatsapp: f.cliente_whatsapp || null,
      cliente_email: f.cliente_email || null,
      marca: f.marca || null, modelo: f.modelo || null,
      anio_aprox: f.anio_aprox ? Number(f.anio_aprox) : null,
      presupuesto: f.presupuesto ? Number(f.presupuesto) : null,
      observaciones: f.observaciones || null,
    });
    setLoading(false);
    if (error) return toast({ title: "Error", description: error.message, variant: "destructive" });
    setDone(true);
  };

  if (done) return (
    <PublicLayout>
      <div className="max-w-xl mx-auto px-4 py-20 text-center">
        <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto" />
        <h1 className="text-2xl font-bold mt-4">¡Aviso registrado!</h1>
        <p className="text-slate-500 mt-2">Cuando ingrese un vehículo que coincida con tu búsqueda, te contactamos.</p>
        <Link to="/catalogo" className="inline-block mt-8 px-5 py-2.5 rounded-full bg-slate-900 text-white">Volver al catálogo</Link>
      </div>
    </PublicLayout>
  );

  return (
    <PublicLayout>
      <div className="max-w-xl mx-auto px-4 py-10">
        <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-2"><Bell /> Avisame cuando ingrese</h1>
        <p className="text-slate-500 text-sm mt-1">Decinos qué buscás y te contactamos apenas tengamos un vehículo que encaje.</p>

        <div className="bg-white rounded-2xl border p-6 mt-6 space-y-3">
          <F label="Nombre *"><I v={f.cliente_nombre} on={(v) => set("cliente_nombre", v)} /></F>
          <div className="grid sm:grid-cols-2 gap-3">
            <F label="Teléfono"><I v={f.cliente_telefono} on={(v) => set("cliente_telefono", v)} /></F>
            <F label="WhatsApp"><I v={f.cliente_whatsapp} on={(v) => set("cliente_whatsapp", v)} /></F>
          </div>
          <F label="Email (opcional)"><I v={f.cliente_email} on={(v) => set("cliente_email", v)} type="email" /></F>
          <div className="grid sm:grid-cols-2 gap-3">
            <F label="Marca"><I v={f.marca} on={(v) => set("marca", v)} /></F>
            <F label="Modelo"><I v={f.modelo} on={(v) => set("modelo", v)} /></F>
            <F label="Año aproximado"><I v={f.anio_aprox} on={(v) => set("anio_aprox", v)} type="number" /></F>
            <F label="Presupuesto $"><I v={f.presupuesto} on={(v) => set("presupuesto", v)} type="number" /></F>
          </div>
          <F label="Observaciones">
            <textarea value={f.observaciones} onChange={(e) => set("observaciones", e.target.value)} rows={3}
              className="w-full px-3 py-2 rounded-lg border bg-slate-50 text-sm" />
          </F>
          <button onClick={submit} disabled={loading}
            className="w-full py-3 rounded-xl bg-slate-900 text-white font-semibold hover:bg-slate-800 disabled:opacity-50">
            {loading ? "Enviando..." : "Enviar aviso"}
          </button>
        </div>
      </div>
    </PublicLayout>
  );
}
function F({ label, children }: any) { return <label className="block"><div className="text-xs text-slate-600 mb-1">{label}</div>{children}</label>; }
function I({ v, on, type = "text" }: any) {
  return <input type={type} value={v} onChange={(e) => on(e.target.value)} className="w-full px-3 py-2 rounded-lg border bg-slate-50 text-sm" />;
}
