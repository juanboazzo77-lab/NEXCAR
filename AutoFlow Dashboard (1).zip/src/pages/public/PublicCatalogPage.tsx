import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { supabase } from "@/integrations/supabase/client";
import PublicLayout, { usePublicSettings, usePublicScope } from "./PublicLayout";
import { FavButton, CompareButton } from "@/components/public/CarActions";
import { Bell, RefreshCw, MessageCircle } from "lucide-react";
import Pagination, { usePagination } from "@/components/public/Pagination";

type Car = {
  id: string;
  slug: string | null;
  marca: string;
  modelo: string;
  version: string | null;
  anio: number;
  kilometros: number | null;
  precio_venta: number | null;
  moneda: string | null;
  combustible: string | null;
  transmision: string | null;
  carroceria: string | null;
  estado: string;
  ubicacion: string | null;
  cover?: string | null;
};

const formatPrice = (v: number | null, moneda: string | null) => {
  if (!v) return "Consultar";
  const sym = moneda === "USD" ? "USD" : "$";
  return `${sym} ${Math.round(v).toLocaleString("es-AR")}`;
};

export default function PublicCatalogPage() {
  const s = usePublicSettings();
  const { agencySlug, carHref } = usePublicScope();
  const [cars, setCars] = useState<Car[]>([]);
  const [loading, setLoading] = useState(true);
  const [agencyOk, setAgencyOk] = useState<boolean | null>(null);
  const [q, setQ] = useState("");
  const [marca, setMarca] = useState("");
  const [combustible, setCombustible] = useState("");
  const [transmision, setTransmision] = useState("");
  const [precioMax, setPrecioMax] = useState<string>("");
  const [anioMin, setAnioMin] = useState<string>("");
  const [orden, setOrden] = useState("recientes");

  useEffect(() => {
    (async () => {
      setLoading(true);
      if (agencySlug) {
        const { data: ag } = await supabase
          .from("agencies").select("id").eq("slug", agencySlug).eq("status", "active").maybeSingle();
        if (!ag) { setAgencyOk(false); setCars([]); setLoading(false); return; }
        setAgencyOk(true);
      } else {
        setAgencyOk(true);
      }
      const estados = s.mostrar_vendidos ? ["Disponible", "Reservado", "Vendido"] : ["Disponible", "Reservado"];
      let query = supabase
        .from("cars_public")
        .select("id,slug,marca,modelo,version,anio,kilometros,precio_venta,moneda,combustible,transmision,carroceria,estado,ubicacion,agency_slug")
        .eq("mostrar_publico", true)
        .in("estado", estados);
      if (agencySlug) query = query.eq("agency_slug", agencySlug);
      const { data: list } = await query.order("created_at", { ascending: false });
      const ids = (list || []).map((c) => c.id);
      let coverByCar: Record<string, string> = {};
      if (ids.length) {
        const { data: photos } = await supabase
          .from("car_photos").select("car_id,url,es_portada,orden").in("car_id", ids)
          .order("es_portada", { ascending: false }).order("orden", { ascending: true });
        (photos || []).forEach((p: any) => { if (!coverByCar[p.car_id]) coverByCar[p.car_id] = p.url; });
      }
      setCars((list || []).map((c: any) => ({ ...c, cover: coverByCar[c.id] || null })));
      setLoading(false);
    })();
  }, [s.mostrar_vendidos, agencySlug]);


  const marcas = useMemo(() => Array.from(new Set(cars.map((c) => c.marca).filter(Boolean))).sort(), [cars]);

  const filtered = useMemo(() => {
    let r = cars.filter((c) => {
      if (marca && c.marca !== marca) return false;
      if (combustible && c.combustible !== combustible) return false;
      if (transmision && c.transmision !== transmision) return false;
      if (precioMax && (c.precio_venta || 0) > Number(precioMax)) return false;
      if (anioMin && c.anio < Number(anioMin)) return false;
      if (q) {
        const t = `${c.marca} ${c.modelo} ${c.version || ""} ${c.anio}`.toLowerCase();
        if (!t.includes(q.toLowerCase())) return false;
      }
      return true;
    });
    switch (orden) {
      case "precio-asc": r = [...r].sort((a, b) => (a.precio_venta || 0) - (b.precio_venta || 0)); break;
      case "precio-desc": r = [...r].sort((a, b) => (b.precio_venta || 0) - (a.precio_venta || 0)); break;
      case "km-asc": r = [...r].sort((a, b) => (a.kilometros || 0) - (b.kilometros || 0)); break;
      case "km-desc": r = [...r].sort((a, b) => (b.kilometros || 0) - (a.kilometros || 0)); break;
      case "nuevos": r = [...r].sort((a, b) => b.anio - a.anio); break;
    }
    return r;
  }, [cars, q, marca, combustible, transmision, precioMax, anioMin, orden]);

  const disponibles = useMemo(() => filtered.filter((c) => c.estado !== "Vendido"), [filtered]);
  const vendidos = useMemo(() => filtered.filter((c) => c.estado === "Vendido"), [filtered]);
  const pgDisp = usePagination(disponibles, "cat_page_size", 12);
  const pgVend = usePagination(vendidos, "cat_page_size_vend", 12);

  if (agencyOk === false) {
    return (
      <PublicLayout>
        <Helmet>
          <title>Catálogo no disponible</title>
          <meta name="robots" content="noindex" />
        </Helmet>
        <section className="max-w-2xl mx-auto px-4 py-24 text-center">
          <h1 className="text-2xl sm:text-3xl font-bold">Catálogo temporalmente no disponible</h1>
          <p className="mt-3 text-muted-foreground">
            Esta agencia pausó su publicación online. Volvé a intentar más tarde o explorá el resto de las agencias.
          </p>
          <Link to="/marketplace" className="inline-block mt-6 rounded-md bg-slate-900 text-white px-5 py-2.5 text-sm font-medium">
            Ir al Marketplace
          </Link>
        </section>
      </PublicLayout>
    );
  }

  return (
    <PublicLayout>
      <Helmet>
        <title>{s.nombre_agencia} · Catálogo de vehículos</title>
        <meta name="description" content={`Stock de vehículos usados y 0km en ${s.nombre_agencia}. Consultá precios, fotos y financiación.`} />
        <meta property="og:title" content={`${s.nombre_agencia} · Catálogo`} />
        <meta property="og:type" content="website" />
      </Helmet>

      <section className="bg-gradient-to-br from-slate-900 to-slate-700 text-white">
        <div className="max-w-7xl mx-auto px-4 py-14">
          <h1 className="text-3xl sm:text-5xl font-bold tracking-tight">Encontrá tu próximo auto</h1>
          <p className="mt-3 text-slate-200 max-w-2xl whitespace-pre-line">
            🚗 Stock actualizado, fotos reales y atención inmediata por WhatsApp.{"\n"}
            📍 Ubicados en La Plata calle 42 Nro 883 E/ 12 y 13{"\n"}
            🕐 Horario: Lun a Vie de 9 a 17hs y Sab de 10 a 13hs
          </p>
          <div className="mt-6 bg-white rounded-2xl p-3 shadow-lg flex flex-col sm:flex-row gap-2">
            <input value={q} onChange={(e) => setQ(e.target.value)}
              placeholder="Buscar marca, modelo, versión..."
              className="flex-1 px-4 py-3 rounded-xl bg-slate-100 text-slate-900 placeholder:text-slate-500 outline-none" />
            <select value={orden} onChange={(e) => setOrden(e.target.value)} className="px-4 py-3 rounded-xl bg-slate-100 text-slate-900 outline-none">
              <option value="recientes">Más recientes</option>
              <option value="nuevos">Más nuevos</option>
              <option value="precio-asc">Menor precio</option>
              <option value="precio-desc">Mayor precio</option>
              <option value="km-asc">Menor kilometraje</option>
              <option value="km-desc">Mayor kilometraje</option>
            </select>
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <Link to="/catalogo/tasacion" className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 text-sm font-medium">
              <RefreshCw className="w-4 h-4" /> Quiero entregar mi vehículo en parte de pago
            </Link>
            <Link to="/catalogo/alerta" className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 text-sm font-medium">
              <Bell className="w-4 h-4" /> No encontré el vehículo que buscaba
            </Link>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 py-8 grid lg:grid-cols-[260px_1fr] gap-6">
        <aside className="bg-white rounded-2xl p-4 h-fit border space-y-4 lg:sticky lg:top-20">
          <h3 className="font-semibold">Filtros</h3>
          <Filter label="Marca">
            <select value={marca} onChange={(e) => setMarca(e.target.value)} className="w-full input">
              <option value="">Todas</option>
              {marcas.map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
          </Filter>
          <Filter label="Combustible">
            <select value={combustible} onChange={(e) => setCombustible(e.target.value)} className="w-full input">
              <option value="">Todos</option>
              {["Nafta", "Diésel", "GNC", "Híbrido", "Eléctrico"].map((x) => <option key={x} value={x}>{x}</option>)}
            </select>
          </Filter>
          <Filter label="Transmisión">
            <select value={transmision} onChange={(e) => setTransmision(e.target.value)} className="w-full input">
              <option value="">Todas</option>
              {["Manual", "Automática", "CVT", "Tiptronic"].map((x) => <option key={x} value={x}>{x}</option>)}
            </select>
          </Filter>
          <Filter label="Precio máximo">
            <input type="number" value={precioMax} onChange={(e) => setPrecioMax(e.target.value)} className="w-full input" placeholder="$" />
          </Filter>
          <Filter label="Año desde">
            <input type="number" value={anioMin} onChange={(e) => setAnioMin(e.target.value)} className="w-full input" placeholder="2015" />
          </Filter>
          <button onClick={() => { setMarca(""); setCombustible(""); setTransmision(""); setPrecioMax(""); setAnioMin(""); setQ(""); }}
            className="w-full text-sm text-slate-600 hover:text-slate-900 underline">Limpiar filtros</button>
          <style>{`.input{padding:.55rem .75rem;border:1px solid #e2e8f0;border-radius:.625rem;background:#f8fafc;outline:none;font-size:.875rem}`}</style>
        </aside>

        <div className="space-y-10">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="text-sm text-slate-600">{disponibles.length} vehículos disponibles</div>
            </div>
            {loading ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="bg-white rounded-2xl border overflow-hidden animate-pulse">
                    <div className="aspect-[4/3] bg-slate-200" />
                    <div className="p-4 space-y-2"><div className="h-4 bg-slate-200 rounded w-2/3" /><div className="h-3 bg-slate-100 rounded w-1/2" /></div>
                  </div>
                ))}
              </div>
            ) : disponibles.length === 0 ? (
              <div className="bg-white rounded-2xl border p-12 text-center text-slate-500">
                No encontramos vehículos con esos filtros.
              </div>
            ) : (
              <>
                <CarGrid cars={pgDisp.pageItems} carHref={carHref} />
                <Pagination page={pgDisp.page} totalPages={pgDisp.totalPages} perPage={pgDisp.perPage} total={pgDisp.total}
                  onPage={(p) => { pgDisp.setPage(p); window.scrollTo({ top: 0, behavior: "smooth" }); }}
                  onPerPage={pgDisp.setPerPage} />
              </>
            )}
          </div>

          {!loading && vendidos.length > 0 && (
            <div>
              <div className="flex items-center gap-3 mb-4">
                <h2 className="text-lg font-semibold text-slate-900">Vendidos</h2>
                <span className="text-xs text-slate-500">{vendidos.length} vehículos ya entregados</span>
              </div>
              <div className="opacity-80">
                <CarGrid cars={pgVend.pageItems} whatsapp={s.whatsapp_number} carHref={carHref} />
                <Pagination page={pgVend.page} totalPages={pgVend.totalPages} perPage={pgVend.perPage} total={pgVend.total}
                  onPage={(p) => pgVend.setPage(p)} onPerPage={pgVend.setPerPage} />
              </div>
            </div>
          )}
        </div>
      </section>
    </PublicLayout>
  );
}

function CarGrid({ cars, whatsapp, carHref }: { cars: any[]; whatsapp?: string | null; carHref?: (s: string) => string }) {
  const href = carHref || ((s: string) => `/catalogo/${s}`);
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
      {cars.map((c) => (
        <div key={c.id} className="group bg-white rounded-2xl border overflow-hidden hover:shadow-xl transition relative">
          <FavButton carId={c.id} className="absolute top-3 right-3 z-10" />
          <Link to={href(c.slug || c.id)} className="block">

            <div className="aspect-[4/3] bg-slate-100 overflow-hidden relative">
              {c.cover ? (
                <img src={c.cover} alt={`${c.marca} ${c.modelo}`} className="w-full h-full object-cover group-hover:scale-105 transition" />
              ) : (
                <div className="w-full h-full grid place-items-center text-slate-400 text-sm">Sin foto</div>
              )}
              {c.estado === "Reservado" && <span className="absolute top-3 left-3 bg-amber-500 text-white text-xs font-semibold px-2 py-1 rounded-full">Reservado</span>}
              {c.estado === "Vendido" && <span className="absolute top-3 left-3 bg-slate-900 text-white text-xs font-semibold px-2 py-1 rounded-full">Vendido</span>}
            </div>
            <div className="p-4">
              <div className="text-sm text-slate-500">{c.marca}</div>
              <div className="font-semibold leading-tight">{c.modelo} {c.version || ""}</div>
              <div className="text-xs text-slate-500 mt-1">
                {c.anio} · {c.kilometros ? `${c.kilometros.toLocaleString("es-AR")} km` : "—"} {c.combustible ? `· ${c.combustible}` : ""}
              </div>
              <div className="mt-3 flex items-end justify-between">
                <div className="text-lg font-bold">{formatPrice(c.precio_venta, c.moneda)}</div>
                <span className="text-xs text-slate-700 group-hover:text-slate-900 font-medium">Ver →</span>
              </div>
            </div>
          </Link>
          <div className="px-4 pb-4 space-y-2">
            <CompareButton carId={c.id} />
            {whatsapp && (
              <a
                href={`https://wa.me/${String(whatsapp).replace(/\D/g, "")}?text=${encodeURIComponent(
                  `Hola! Vi que el ${c.marca} ${c.modelo} ${c.version || ""} ${c.anio} ya está vendido. ¿Va a entrar alguno similar?`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium transition"
              >
                <MessageCircle className="w-4 h-4" /> ¿Entra alguno similar?
              </a>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

function Filter({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="text-xs font-medium text-slate-600 mb-1">{label}</div>
      {children}
    </label>
  );
}
