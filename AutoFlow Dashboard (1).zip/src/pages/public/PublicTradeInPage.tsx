import { useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import PublicLayout, { usePublicSettings, usePublicScope } from "./PublicLayout";
import { useToast } from "@/hooks/use-toast";
import { Upload, CheckCircle2, X, MessageCircle } from "lucide-react";

export default function PublicTradeInPage() {
  const { toast } = useToast();
  const s = usePublicSettings();
  const { agencySlug } = usePublicScope();
  const [waUrl, setWaUrl] = useState("");
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [f, setF] = useState({
    cliente_nombre: "", cliente_telefono: "", cliente_email: "",
    marca: "", modelo: "", version: "", anio: "", kilometros: "",
    combustible: "", caja: "", estado_general: "", precio_pretendido: "", observaciones: "",
  });
  const set = (k: string, v: string) => setF({ ...f, [k]: v });

  const submit = async () => {
    if (!f.cliente_nombre || !f.marca || !f.modelo) {
      toast({ title: "Completá al menos nombre, marca y modelo", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const fotos: string[] = [];
      for (const file of files.slice(0, 8)) {
        const path = `trade-ins/${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9.]/g, "_")}`;
        const up = await supabase.storage.from("car-photos").upload(path, file, { upsert: false });
        if (!up.error) {
          const { data: pub } = supabase.storage.from("car-photos").getPublicUrl(path);
          if (pub?.publicUrl) fotos.push(pub.publicUrl);
        }
      }
      let agencyId: string | null = null;
      if (agencySlug) {
        const { data: ag } = await supabase
          .from("agencies").select("id").eq("slug", agencySlug).maybeSingle();
        agencyId = (ag as any)?.id ?? null;
      }
      if (!agencyId) agencyId = (s as any)?.agency_id ?? null;
      const { data: inserted, error } = await supabase.from("trade_in_requests").insert({
        agency_id: agencyId,
        cliente_nombre: f.cliente_nombre,
        cliente_telefono: f.cliente_telefono || null,
        cliente_email: f.cliente_email || null,
        marca: f.marca, modelo: f.modelo, version: f.version || null,
        anio: f.anio ? Number(f.anio) : null,
        kilometros: f.kilometros ? Number(f.kilometros) : null,
        combustible: f.combustible || null, caja: f.caja || null,
        estado_general: f.estado_general || null,
        precio_pretendido: f.precio_pretendido ? Number(f.precio_pretendido) : null,
        observaciones: f.observaciones || null,
        fotos,
      }).select("id").single();
      if (error) throw error;
      if (inserted?.id) {
        // Esperamos el aviso por WhatsApp para que no se corte al desmontar la página
        await supabase.functions
          .invoke("notify-tasacion", { body: { request_id: inserted.id } })
          .catch(() => {});
      }

      // Mensaje de WhatsApp al número de la agencia, con toda la info + links de las fotos
      const msg = [
        "Hola! Quiero tasar mi auto para entregarlo en parte de pago 🚙",
        "",
        `👤 ${f.cliente_nombre}`,
        f.cliente_telefono ? `📞 ${f.cliente_telefono}` : null,
        f.cliente_email ? `✉️ ${f.cliente_email}` : null,
        "",
        `🚗 ${[f.marca, f.modelo, f.version].filter(Boolean).join(" ")}${f.anio ? ` (${f.anio})` : ""}`,
        f.kilometros ? `📏 ${Number(f.kilometros).toLocaleString("es-AR")} km` : null,
        [f.combustible, f.caja].filter(Boolean).join(" · ") || null,
        f.estado_general ? `🔧 Estado: ${f.estado_general}` : null,
        f.precio_pretendido ? `💰 Pretendo: $${Number(f.precio_pretendido).toLocaleString("es-AR")}` : null,
        f.observaciones ? `📝 ${f.observaciones}` : null,
        fotos.length ? `\n📷 Fotos:\n${fotos.join("\n")}` : null,
      ].filter(Boolean).join("\n");

      const numero = (s.whatsapp_number || "").replace(/\D/g, "");
      const url = `https://wa.me/${numero}?text=${encodeURIComponent(msg)}`;
      setWaUrl(url);
      setDone(true);
      if (numero) window.open(url, "_blank");
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  if (done) return (
    <PublicLayout>
      <div className="max-w-xl mx-auto px-4 py-20 text-center">
        <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto" />
        <h1 className="text-2xl font-bold mt-4">¡Solicitud enviada!</h1>
        <p className="text-slate-500 mt-2">Te abrimos WhatsApp con todos los datos y las fotos para que nos lo envíes. Si no se abrió, tocá el botón:</p>
        {waUrl && (
          <a href={waUrl} target="_blank" rel="noreferrer"
            className="inline-flex items-center gap-2 mt-6 px-5 py-3 rounded-full bg-emerald-500 text-white font-semibold hover:bg-emerald-600">
            <MessageCircle className="w-4 h-4" /> Enviar por WhatsApp
          </a>
        )}
        <div><Link to="/catalogo" className="inline-block mt-6 px-5 py-2.5 rounded-full bg-slate-900 text-white">Volver al catálogo</Link></div>
      </div>
    </PublicLayout>
  );

  return (
    <PublicLayout>
      <div className="max-w-2xl mx-auto px-4 py-10">
        <h1 className="text-2xl sm:text-3xl font-bold">Entregá tu vehículo en parte de pago</h1>
        <p className="text-slate-500 text-sm mt-1">Completá los datos y te enviamos una valoración aproximada.</p>

        <div className="bg-white rounded-2xl border p-6 mt-6 space-y-4">
          <Section title="Tus datos">
            <Field label="Nombre completo *"><Input value={f.cliente_nombre} onChange={(v) => set("cliente_nombre", v)} /></Field>
            <div className="grid sm:grid-cols-2 gap-3">
              <Field label="Teléfono"><Input value={f.cliente_telefono} onChange={(v) => set("cliente_telefono", v)} /></Field>
              <Field label="Email"><Input value={f.cliente_email} onChange={(v) => set("cliente_email", v)} type="email" /></Field>
            </div>
          </Section>
          <Section title="Tu vehículo">
            <div className="grid sm:grid-cols-2 gap-3">
              <Field label="Marca *"><Input value={f.marca} onChange={(v) => set("marca", v)} /></Field>
              <Field label="Modelo *"><Input value={f.modelo} onChange={(v) => set("modelo", v)} /></Field>
              <Field label="Versión"><Input value={f.version} onChange={(v) => set("version", v)} /></Field>
              <Field label="Año"><Input value={f.anio} onChange={(v) => set("anio", v)} type="number" /></Field>
              <Field label="Kilómetros"><Input value={f.kilometros} onChange={(v) => set("kilometros", v)} type="number" /></Field>
              <Field label="Combustible">
                <Select value={f.combustible} onChange={(v) => set("combustible", v)} options={["", "Nafta", "Diésel", "GNC", "Híbrido", "Eléctrico"]} />
              </Field>
              <Field label="Caja">
                <Select value={f.caja} onChange={(v) => set("caja", v)} options={["", "Manual", "Automática", "CVT", "Tiptronic"]} />
              </Field>
              <Field label="Estado general">
                <Select value={f.estado_general} onChange={(v) => set("estado_general", v)} options={["", "Excelente", "Muy bueno", "Bueno", "Regular"]} />
              </Field>
            </div>
            <Field label="Precio que pretendés"><Input value={f.precio_pretendido} onChange={(v) => set("precio_pretendido", v)} type="number" /></Field>
            <Field label="Observaciones">
              <textarea value={f.observaciones} onChange={(e) => set("observaciones", e.target.value)}
                rows={3} className="w-full px-3 py-2 rounded-lg border bg-slate-50 text-sm" />
            </Field>
          </Section>
          <Section title="Fotos (opcional)">
            <label className="block border-2 border-dashed rounded-xl p-6 text-center cursor-pointer hover:bg-slate-50">
              <Upload className="w-6 h-6 mx-auto text-slate-400" />
              <div className="text-sm mt-2">Subí fotos del vehículo</div>
              <input type="file" multiple accept="image/*" className="hidden"
                onChange={(e) => setFiles(Array.from(e.target.files || []))} />
            </label>
            {files.length > 0 && (
              <div className="text-xs text-slate-600 flex flex-wrap gap-2 mt-2">
                {files.map((file, i) => (
                  <span key={i} className="inline-flex items-center gap-1 bg-slate-100 rounded-full px-2 py-0.5">
                    {file.name}
                    <button onClick={() => setFiles(files.filter((_, j) => j !== i))}><X className="w-3 h-3" /></button>
                  </span>
                ))}
              </div>
            )}
          </Section>
          <button onClick={submit} disabled={loading}
            className="w-full py-3 rounded-xl bg-slate-900 text-white font-semibold hover:bg-slate-800 disabled:opacity-50">
            {loading ? "Enviando..." : "Enviar solicitud"}
          </button>
        </div>
      </div>
    </PublicLayout>
  );
}

function Section({ title, children }: any) { return <div className="space-y-3"><h3 className="font-semibold text-sm">{title}</h3>{children}</div>; }
function Field({ label, children }: any) { return <label className="block"><div className="text-xs text-slate-600 mb-1">{label}</div>{children}</label>; }
function Input({ value, onChange, type = "text" }: any) {
  return <input type={type} value={value} onChange={(e) => onChange(e.target.value)} className="w-full px-3 py-2 rounded-lg border bg-slate-50 text-sm" />;
}
function Select({ value, onChange, options }: any) {
  return <select value={value} onChange={(e) => onChange(e.target.value)} className="w-full px-3 py-2 rounded-lg border bg-slate-50 text-sm">
    {options.map((o: string) => <option key={o} value={o}>{o || "—"}</option>)}
  </select>;
}
