import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import PublicLayout, { usePublicSettings } from "./PublicLayout";
import { useCompare } from "@/hooks/use-public-lists";
import { Compare } from "@/lib/public-storage";
import { X } from "lucide-react";

const fmt = (v: number | null, m: string | null) => !v ? "—" : `${m === "USD" ? "USD" : "$"} ${Math.round(v).toLocaleString("es-AR")}`;

const ROWS: { key: string; label: string; format?: (v: any, c: any) => string }[] = [
  { key: "marca", label: "Marca" },
  { key: "modelo", label: "Modelo" },
  { key: "version", label: "Versión" },
  { key: "anio", label: "Año" },
  { key: "kilometros", label: "Kilómetros", format: (v) => v ? `${v.toLocaleString("es-AR")} km` : "—" },
  { key: "precio_venta", label: "Precio", format: (v, c) => fmt(v, c.moneda) },
  { key: "combustible", label: "Combustible" },
  { key: "motor", label: "Motor" },
  { key: "transmision", label: "Transmisión" },
  { key: "carroceria", label: "Carrocería" },
  { key: "puertas", label: "Puertas" },
  { key: "color", label: "Color" },
  { key: "condicion", label: "Condición" },
  { key: "ubicacion", label: "Ubicación" },
  { key: "estado", label: "Estado" },
];

export default function PublicComparePage() {
  const ids = useCompare();
  const s = usePublicSettings();
  const [cars, setCars] = useState<any[]>([]);
  const [covers, setCovers] = useState<Record<string, string>>({});

  useEffect(() => {
    (async () => {
      if (!ids.length) { setCars([]); return; }
      const { data } = await supabase.from("cars_public").select("*").in("id", ids);
      setCars((data || []).sort((a, b) => ids.indexOf(a.id) - ids.indexOf(b.id)));
      const { data: ph } = await supabase.from("car_photos").select("car_id,url,es_portada,orden")
        .in("car_id", ids).order("es_portada", { ascending: false }).order("orden", { ascending: true });
      const cv: Record<string, string> = {};
      (ph || []).forEach((p: any) => { if (!cv[p.car_id]) cv[p.car_id] = p.url; });
      setCovers(cv);
    })();
  }, [ids.join(",")]);

  const diffs = useMemo(() => {
    const out: Record<string, boolean> = {};
    ROWS.forEach((r) => {
      const vals = cars.map((c) => c[r.key] ?? "");
      out[r.key] = new Set(vals.map((v) => String(v))).size > 1;
    });
    return out;
  }, [cars]);

  const transferencia = (c: any) => c.precio_venta && c.moneda !== "USD"
    ? Math.round((c.precio_venta * (s.transferencia_porcentaje || 0)) / 100) : 0;

  const wa = (c: any) => {
    const m = encodeURIComponent(`Hola! Me interesa el ${c.marca} ${c.modelo} ${c.version || ""} ${c.anio}.`);
    return `https://wa.me/${s.whatsapp_number.replace(/\D/g, "")}?text=${m}`;
  };

  if (!cars.length) {
    return (
      <PublicLayout>
        <div className="max-w-3xl mx-auto p-10 text-center">
          <h1 className="text-2xl font-bold">Comparador vacío</h1>
          <p className="text-slate-500 mt-2">Volvé al catálogo y agregá hasta 3 vehículos para comparar lado a lado.</p>
          <Link to="/catalogo" className="inline-block mt-6 px-5 py-2.5 rounded-full bg-slate-900 text-white">Ir al catálogo</Link>
        </div>
      </PublicLayout>
    );
  }

  return (
    <PublicLayout>
      <div className="max-w-7xl mx-auto px-4 py-10">
        <h1 className="text-2xl sm:text-3xl font-bold">Comparar vehículos</h1>
        <p className="text-slate-500 text-sm mt-1">Las diferencias entre filas se resaltan en amarillo.</p>

        <div className="mt-6 overflow-x-auto">
          <table className="min-w-full bg-white rounded-2xl border overflow-hidden">
            <thead>
              <tr>
                <th className="sticky left-0 bg-white p-3 text-left text-xs font-medium text-slate-500 border-b">Característica</th>
                {cars.map((c) => (
                  <th key={c.id} className="p-3 border-b min-w-[220px] align-top">
                    <div className="relative">
                      <button onClick={() => Compare.remove(c.id)} className="absolute -top-1 -right-1 p-1 rounded-full bg-slate-100 hover:bg-slate-200"><X className="w-3 h-3" /></button>
                      <div className="aspect-[4/3] bg-slate-100 rounded-lg overflow-hidden mb-2">
                        {covers[c.id] ? <img src={covers[c.id]} className="w-full h-full object-cover" /> :
                          <div className="grid place-items-center h-full text-slate-400 text-xs">Sin foto</div>}
                      </div>
                      <Link to={`/catalogo/${c.slug || c.id}`} className="block text-left">
                        <div className="font-semibold text-sm">{c.marca} {c.modelo}</div>
                        <div className="text-xs text-slate-500">{c.version || ""}</div>
                      </Link>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ROWS.map((r) => (
                <tr key={r.key} className={diffs[r.key] ? "bg-amber-50" : ""}>
                  <td className="sticky left-0 bg-inherit p-3 text-xs font-medium text-slate-600 border-b">{r.label}</td>
                  {cars.map((c) => (
                    <td key={c.id} className="p-3 text-sm border-b">
                      {r.format ? r.format(c[r.key], c) : (c[r.key] || "—")}
                    </td>
                  ))}
                </tr>
              ))}
              <tr className="bg-slate-50">
                <td className="sticky left-0 bg-slate-50 p-3 text-xs font-medium text-slate-600 border-b">Transferencia aprox.</td>
                {cars.map((c) => (
                  <td key={c.id} className="p-3 text-sm border-b">
                    {transferencia(c) ? `$ ${transferencia(c).toLocaleString("es-AR")}` : "—"}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="sticky left-0 bg-white p-3 text-xs font-medium text-slate-600">Equipamiento</td>
                {cars.map((c) => (
                  <td key={c.id} className="p-3 text-xs align-top">
                    {Array.isArray(c.equipamiento) && c.equipamiento.length
                      ? <ul className="space-y-0.5">{c.equipamiento.slice(0, 12).map((e: string) => <li key={e}>• {e}</li>)}</ul>
                      : "—"}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="sticky left-0 bg-white p-3"></td>
                {cars.map((c) => (
                  <td key={c.id} className="p-3">
                    <a href={wa(c)} target="_blank" rel="noreferrer" className="block text-center px-3 py-2 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold">
                      Consultar este auto
                    </a>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </PublicLayout>
  );
}
