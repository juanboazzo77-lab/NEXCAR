import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { supabase } from "@/integrations/supabase/client";
import PublicLayout, { usePublicSettings } from "./PublicLayout";
import { FavButton, CompareButton } from "@/components/public/CarActions";
import FinanciacionSimulator from "@/components/public/FinanciacionSimulator";
import RelatedCars from "@/components/public/RelatedCars";
import { trackCarEvent } from "@/lib/car-tracking";

const fmt = (v: number | null | undefined, moneda?: string | null) =>
  !v ? "Consultar" : `${moneda === "USD" ? "USD" : "$"} ${Math.round(v).toLocaleString("es-AR")}`;

export default function PublicCarPage() {
  const { slug } = useParams();
  const s = usePublicSettings();
  const [car, setCar] = useState<any>(null);
  const [photos, setPhotos] = useState<any[]>([]);
  const [active, setActive] = useState(0);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    (async () => {
      setLoading(true);
      let { data } = await supabase.from("cars_public").select("*").eq("slug", slug!).eq("mostrar_publico", true).maybeSingle();
      if (!data) {
        const r = await supabase.from("cars_public").select("*").eq("id", slug!).eq("mostrar_publico", true).maybeSingle();
        data = r.data;
      }
      if (!data) { setNotFound(true); setLoading(false); return; }
      setCar(data);
      const { data: ph } = await supabase
        .from("car_photos").select("*").eq("car_id", data.id)
        .order("es_portada", { ascending: false }).order("orden", { ascending: true });
      setPhotos(ph || []);
      setLoading(false);
      trackCarEvent(data.id, "view", "detalle");
    })();
  }, [slug]);

  if (loading) return <PublicLayout><div className="max-w-6xl mx-auto p-10 text-slate-500">Cargando...</div></PublicLayout>;
  if (notFound || !car) return (
    <PublicLayout>
      <div className="max-w-6xl mx-auto p-10 text-center">
        <h1 className="text-2xl font-bold">Vehículo no disponible</h1>
        <p className="text-slate-500 mt-2">Puede haber sido vendido o despublicado.</p>
        <Link to="/catalogo" className="inline-block mt-6 px-5 py-2.5 rounded-full bg-slate-900 text-white">Volver al catálogo</Link>
      </div>
    </PublicLayout>
  );

  const title = `${car.marca} ${car.modelo} ${car.version || ""} ${car.anio}`.trim();
  const transferencia = car.precio_venta && car.moneda !== "USD"
    ? Math.round((car.precio_venta * (s.transferencia_porcentaje || 0)) / 100)
    : 0;

  const waMsg = encodeURIComponent(
    `Hola, ¿cómo están? Me interesa este vehículo que vi en su página:\n\n` +
    `🚗 ${car.marca} ${car.modelo} ${car.version || ""}\n` +
    `📅 Año: ${car.anio}\n` +
    `🛣 Kilómetros: ${car.kilometros ? car.kilometros.toLocaleString("es-AR") + " km" : "—"}\n` +
    `💲 Precio: ${fmt(car.precio_venta, car.moneda)}\n\n` +
    `Me gustaría recibir más información sobre esta unidad.\n\n¡Muchas gracias!`
  );
  const waUrl = `https://wa.me/${s.whatsapp_number.replace(/\D/g, "")}?text=${waMsg}`;
  const shareUrl = typeof window !== "undefined" ? window.location.href : "";

  const cover = photos[active]?.url || photos[0]?.url;

  return (
    <PublicLayout>
      <Helmet>
        <title>{title} · {s.nombre_agencia}</title>
        <meta name="description" content={`${title} con ${car.kilometros || 0} km. ${fmt(car.precio_venta, car.moneda)}. Consultá ahora.`} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={`${fmt(car.precio_venta, car.moneda)} · ${car.anio} · ${car.kilometros || 0} km`} />
        {cover && <meta property="og:image" content={cover} />}
      </Helmet>

      <div className="max-w-6xl mx-auto px-4 py-6">
        <Link to="/catalogo" className="text-sm text-slate-500 hover:text-slate-900">← Volver al catálogo</Link>
      </div>

      <div className="max-w-6xl mx-auto px-4 grid lg:grid-cols-[1.4fr_1fr] gap-8">
        <div>
          <div className="aspect-[4/3] bg-slate-100 rounded-2xl overflow-hidden relative">
            {cover ? <img src={cover} alt={title} className="w-full h-full object-cover" /> :
              <div className="w-full h-full grid place-items-center text-slate-400">Sin foto</div>}
            <FavButton carId={car.id} className="absolute top-3 right-3" />
          </div>
          {photos.length > 1 && (
            <div className="mt-3 grid grid-cols-5 sm:grid-cols-6 gap-2">
              {photos.map((p, i) => (
                <button key={p.id} onClick={() => setActive(i)} className={`aspect-square rounded-lg overflow-hidden border-2 ${i === active ? "border-slate-900" : "border-transparent"}`}>
                  <img src={p.url} className="w-full h-full object-cover" alt="" />
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-5">
          <div>
            <div className="text-sm text-slate-500">{car.marca} · {car.anio}</div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">{car.modelo} {car.version || ""}</h1>
            <div className="mt-2 flex items-center gap-2">
              {car.estado !== "Disponible" && (
                <span className={`inline-block text-xs font-semibold px-2.5 py-1 rounded-full ${car.estado === "Reservado" ? "bg-amber-100 text-amber-700" : "bg-slate-900 text-white"}`}>{car.estado}</span>
              )}
              <CompareButton carId={car.id} />
            </div>
          </div>

          <div className="bg-white rounded-2xl border p-5">
            <div className="text-3xl font-bold">{fmt(car.precio_venta, car.moneda)}</div>
            {transferencia > 0 && (
              <div className="mt-2 text-sm text-slate-600">
                Transferencia estimada: <b>${transferencia.toLocaleString("es-AR")}</b>
                <div className="text-xs text-slate-400">Valor aproximado. Puede variar según la provincia y la normativa vigente.</div>
              </div>
            )}
            <a href={waUrl} target="_blank" rel="noreferrer" onClick={() => trackCarEvent(car.id, "whatsapp", "detalle")}
              className="mt-4 w-full inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold transition">
              Consultar por WhatsApp
            </a>
            <div className="mt-3 flex gap-2">
              <a href={`https://wa.me/?text=${encodeURIComponent(shareUrl)}`} target="_blank" rel="noreferrer" className="flex-1 text-center text-sm px-3 py-2 rounded-lg border hover:bg-slate-50">Compartir WA</a>
              <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`} target="_blank" rel="noreferrer" className="flex-1 text-center text-sm px-3 py-2 rounded-lg border hover:bg-slate-50">Facebook</a>
              <button onClick={() => navigator.clipboard?.writeText(shareUrl)} className="flex-1 text-center text-sm px-3 py-2 rounded-lg border hover:bg-slate-50">Copiar link</button>
            </div>
          </div>

          <div className="bg-white rounded-2xl border p-5">
            <h3 className="font-semibold mb-3">Ficha técnica</h3>
            <dl className="grid grid-cols-2 gap-y-3 text-sm">
              <Spec k="Año" v={car.anio} />
              <Spec k="Kilómetros" v={car.kilometros ? `${car.kilometros.toLocaleString("es-AR")} km` : "—"} />
              <Spec k="Combustible" v={car.combustible} />
              <Spec k="Transmisión" v={car.transmision} />
              <Spec k="Motor" v={car.motor} />
              <Spec k="Carrocería" v={car.carroceria} />
              <Spec k="Puertas" v={car.puertas} />
              <Spec k="Color" v={car.color} />
              <Spec k="Ubicación" v={car.ubicacion} />
              <Spec k="Condición" v={car.condicion} />
            </dl>
          </div>

          {car.precio_venta && <FinanciacionSimulator precio={car.precio_venta} moneda={car.moneda} />}
        </div>
      </div>

      {(car.descripcion_publica || car.descripcion_manual || car.equipamiento?.length) && (
        <div className="max-w-6xl mx-auto px-4 mt-8 grid lg:grid-cols-[1.4fr_1fr] gap-8">
          <div className="bg-white rounded-2xl border p-6">
            <h3 className="font-semibold mb-3">Descripción</h3>
            <p className="text-sm text-slate-700 whitespace-pre-wrap">{car.descripcion_publica || car.descripcion_manual || ""}</p>
          </div>
          {car.equipamiento?.length > 0 && (
            <div className="bg-white rounded-2xl border p-6">
              <h3 className="font-semibold mb-3">Equipamiento</h3>
              <ul className="text-sm grid grid-cols-1 sm:grid-cols-2 gap-y-1">
                {car.equipamiento.map((e: string) => <li key={e} className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />{e}</li>)}
              </ul>
            </div>
          )}
        </div>
      )}

      <RelatedCars car={car} />
      <div className="h-16" />
    </PublicLayout>
  );
}

function Spec({ k, v }: { k: string; v: any }) {
  return (
    <>
      <dt className="text-slate-500">{k}</dt>
      <dd className="font-medium">{v || "—"}</dd>
    </>
  );
}
