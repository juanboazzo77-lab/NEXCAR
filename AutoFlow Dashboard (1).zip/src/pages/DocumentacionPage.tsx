import { useState } from "react";
import { useCars, useCarDocs, useUpsertCarDoc } from "@/hooks/use-data";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, Save, Calculator, CalendarIcon, Printer } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format, differenceInCalendarDays, parseISO } from "date-fns";
import { es } from "date-fns/locale";
import type { CarDocumentation } from "@/lib/supabase-helpers";
import { NotificationPhonesCard } from "@/components/NotificationPhonesCard";
import { generateCaratulaDocs, type DocCaratulaField } from "@/lib/pdf-generator";

const DOC_FIELDS: { key: keyof CarDocumentation; label: string; type?: "date" }[] = [
  { key: "ubicacion", label: "Ubicación" },
  { key: "gnc", label: "GNC" },
  { key: "cat", label: "CAT" },
  { key: "cedula", label: "Cédula" },
  { key: "verificacion", label: "Verificación", type: "date" },
  { key: "vtv", label: "VTV", type: "date" },
  { key: "form_08", label: "08" },
  { key: "form_04", label: "04" },
  { key: "multas", label: "Multas" },
  { key: "dominio", label: "Dominio" },
  { key: "segunda_llave", label: "Segunda llave" },
  { key: "manual", label: "Manual" },
];

// Try parse ISO yyyy-mm-dd; if fails, return null
function tryParseDate(value: string): Date | null {
  if (!value) return null;
  const m = value.match(/^\d{4}-\d{2}-\d{2}$/);
  if (!m) return null;
  const d = parseISO(value);
  return isNaN(d.getTime()) ? null : d;
}

function ExpiryBadge({ value }: { value: string }) {
  const d = tryParseDate(value);
  if (!d) return null;
  const days = differenceInCalendarDays(d, new Date());
  let cls = "bg-success/15 text-success border-success/30";
  if (days < 0) cls = "bg-destructive/15 text-destructive border-destructive/30";
  else if (days <= 7) cls = "bg-destructive/15 text-destructive border-destructive/30";
  else if (days <= 30) cls = "bg-warning/15 text-warning border-warning/30";
  return <span className={cn("inline-block text-[10px] px-1.5 py-0.5 rounded border mt-1", cls)}>{format(d, "dd/MM/yyyy")}</span>;
}

function DateField({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const date = tryParseDate(value);
  return (
    <div className="space-y-1">
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className={cn("w-full justify-start text-left font-normal text-sm h-9", !date && "text-muted-foreground")}
          >
            <CalendarIcon className="mr-2 h-3.5 w-3.5" />
            {date ? format(date, "dd/MM/yyyy") : <span>Elegir fecha</span>}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0 z-50 bg-popover" align="start">
          <Calendar
            mode="single"
            selected={date ?? undefined}
            onSelect={(d) => onChange(d ? format(d, "yyyy-MM-dd") : "")}
            initialFocus
            locale={es}
            className={cn("p-3 pointer-events-auto")}
          />
        </PopoverContent>
      </Popover>
      <ExpiryBadge value={value} />
    </div>
  );
}

// Feriados nacionales de Argentina (inamovibles + trasladables principales)
const FERIADOS_AR = new Set([
  // 2026
  "2026-01-01","2026-02-16","2026-02-17","2026-03-24","2026-04-02","2026-04-03",
  "2026-05-01","2026-05-25","2026-06-15","2026-06-20","2026-07-09","2026-08-17",
  "2026-10-12","2026-11-23","2026-12-08","2026-12-25",
  // 2027
  "2027-01-01","2027-02-08","2027-02-09","2027-03-24","2027-03-25","2027-03-26",
  "2027-05-01","2027-05-25","2027-06-21","2027-07-09","2027-08-16",
  "2027-10-11","2027-11-22","2027-12-08","2027-12-25",
]);

const toISO = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

const esHabil = (d: Date) => d.getDay() !== 0 && d.getDay() !== 6 && !FERIADOS_AR.has(toISO(d));

// Suma N días hábiles a una fecha (no cuenta el día de inicio)
function addBusinessDays(startISO: string, n: number): Date {
  const [y, m, day] = startISO.split("-").map(Number);
  const cur = new Date(y, m - 1, day);
  let added = 0;
  while (added < n) {
    cur.setDate(cur.getDate() + 1);
    if (esHabil(cur)) added++;
  }
  return cur;
}

function BusinessDaysCalc() {
  const [from, setFrom] = useState("");
  const [cant, setCant] = useState("150");
  const n = Number(cant);
  const result = from && n > 0 ? addBusinessDays(from, n) : null;

  return (
    <Card>
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center gap-2 text-sm font-medium"><Calculator className="w-4 h-4" />Días hábiles</div>
        <div className="grid grid-cols-2 gap-2">
          <div><Label className="text-xs">Desde</Label><Input type="date" value={from} onChange={e => setFrom(e.target.value)} /></div>
          <div><Label className="text-xs">Días hábiles</Label><Input type="number" min={1} value={cant} onChange={e => setCant(e.target.value)} /></div>
        </div>
        {result && (
          <div>
            <div className="text-lg font-bold text-primary">{format(result, "dd/MM/yyyy", { locale: es })}</div>
            <div className="text-xs text-muted-foreground">
              {format(result, "EEEE d 'de' MMMM 'de' yyyy", { locale: es })} — {n} días hábiles (excluye fines de semana y feriados nacionales)
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}


export default function DocumentacionPage() {
  const { data: cars = [] } = useCars();
  const { data: docs = [] } = useCarDocs();
  const upsertDoc = useUpsertCarDoc();
  const { toast } = useToast();
  const [edits, setEdits] = useState<Record<string, Record<string, string>>>({});

  const getDoc = (carId: string) => docs.find(d => d.car_id === carId);

  const setField = (carId: string, field: string, value: string) => {
    setEdits(prev => ({ ...prev, [carId]: { ...prev[carId], [field]: value } }));
  };

  const saveDoc = async (carId: string) => {
    const existing = getDoc(carId);
    const changes = edits[carId] || {};
    try {
      await upsertDoc.mutateAsync({ car_id: carId, id: existing?.id, ...changes });
      setEdits(prev => { const n = { ...prev }; delete n[carId]; return n; });
      toast({ title: "Documentación guardada" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const getValue = (carId: string, field: string) => {
    if (edits[carId]?.[field] !== undefined) return edits[carId][field];
    const doc = getDoc(carId);
    return (doc as any)?.[field] ?? "";
  };

  const printCaratula = async (car: any) => {
    try {
      const campos: DocCaratulaField[] = DOC_FIELDS.filter(f => f.key !== "ubicacion").map(({ key, label, type }) => {
        const raw = getValue(car.id, key as string);
        let status: DocCaratulaField["status"] = raw ? "ok" : "pending";
        let hint: string | undefined;
        if (type === "date") {
          const d = tryParseDate(raw);
          if (!d) { status = "pending"; hint = "Sin fecha cargada"; }
          else {
            const days = differenceInCalendarDays(d, new Date());
            if (days < 0) status = "danger";
            else if (days <= 7) status = "danger";
            else if (days <= 30) status = "warn";
            else status = "ok";
          }
        } else if (raw?.toUpperCase?.() === "PEDIR") {
          status = "warn"; hint = "Pendiente de gestión";
        } else if (!raw) {
          status = "pending"; hint = "Sin completar";
        }
        const value = type === "date" && tryParseDate(raw)
          ? format(tryParseDate(raw)!, "dd/MM/yyyy")
          : (raw || "—");
        return { label, value, status, hint };
      });
      await generateCaratulaDocs({
        auto: {
          marca: car.marca, modelo: car.modelo, anio: car.anio,
          patente: car.patente, color: car.color, kilometros: car.kilometros,
          motor: car.motor, chasis: car.chasis, combustible: car.combustible,
        },
        ubicacion: getValue(car.id, "ubicacion"),
        campos,
      });
    } catch (err: any) {
      toast({ title: "Error al generar PDF", description: err.message, variant: "destructive" });
    }
  };

  return (
    <div className="space-y-4">
      <h1 className="page-header">Documentación</h1>
      <BusinessDaysCalc />
      <div className="space-y-2">
        {cars.map(car => (
          <Collapsible key={car.id}>
            <Card>
              <CollapsibleTrigger className="w-full">
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="text-left">
                    <div className="text-sm font-medium">{car.marca} {car.modelo}</div>
                    <div className="text-xs text-muted-foreground">{car.patente} · {car.anio}</div>
                  </div>
                  <ChevronDown className="w-4 h-4 text-muted-foreground" />
                </CardContent>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <CardContent className="px-4 pb-4 pt-0 space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    {DOC_FIELDS.map(({ key, label, type }) => (
                      <div key={key}>
                        <Label className="text-xs">{label}</Label>
                        {type === "date" ? (
                          <DateField
                            value={getValue(car.id, key)}
                            onChange={(v) => setField(car.id, key, v)}
                          />
                        ) : key === "form_08" ? (
                          <div className="flex gap-1">
                            <Input className="text-sm" value={getValue(car.id, key)} onChange={e => setField(car.id, key, e.target.value)} />
                            <Button variant="outline" size="sm" className="text-xs shrink-0" onClick={() => setField(car.id, key, "PEDIR")}>PEDIR</Button>
                          </div>
                        ) : (
                          <Input className="text-sm" value={getValue(car.id, key)} onChange={e => setField(car.id, key, e.target.value)} />
                        )}
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => saveDoc(car.id)} disabled={!edits[car.id]}>
                      <Save className="w-3.5 h-3.5 mr-1" />Guardar
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => printCaratula(car)}>
                      <Printer className="w-3.5 h-3.5 mr-1" />Imprimir carátula
                    </Button>
                  </div>
                </CardContent>
              </CollapsibleContent>
            </Card>
          </Collapsible>
        ))}
        {cars.length === 0 && <p className="text-muted-foreground text-sm">No hay autos registrados.</p>}
      </div>
      <NotificationPhonesCard />

    </div>
  );
}
