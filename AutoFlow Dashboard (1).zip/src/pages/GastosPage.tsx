import { useState, useMemo } from "react";
import { useExpenses, useAddExpense, useUpdateExpense, useDeleteExpense, useCars } from "@/hooks/use-data";
import { CATEGORIAS_GASTO, formatCurrency, formatDate } from "@/lib/supabase-helpers";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Plus, Trash2, Check, ChevronsUpDown, X, Search, Pencil } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { MoneyInput } from "@/components/MoneyInput";
import { NotificationPhonesCard } from "@/components/NotificationPhonesCard";

export default function GastosPage() {
  const { data: expenses = [] } = useExpenses();
  const { data: cars = [] } = useCars();
  const addExpense = useAddExpense();
  const updateExpense = useUpdateExpense();
  const deleteExpense = useDeleteExpense();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const emptyForm = { car_id: "", fecha: new Date().toISOString().split("T")[0], categoria: "Auto", concepto: "", detalle: "", monto: 0 };
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [carPickerOpen, setCarPickerOpen] = useState(false);
  const [filterCarId, setFilterCarId] = useState<string>("all");
  const [filterPickerOpen, setFilterPickerOpen] = useState(false);
  const [tab, setTab] = useState<"activos" | "vendidos">("activos");

  const soldCarIds = useMemo(() => new Set(cars.filter(c => c.estado === "Vendido").map(c => c.id)), [cars]);

  const set = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  const openNew = () => {
    setEditingId(null);
    // Preselect car from current filter when applicable
    const presetCar = filterCarId === "all" ? "" : filterCarId === "none" ? "none" : filterCarId;
    setForm({ ...emptyForm, car_id: presetCar });
    setOpen(true);
  };

  const openEdit = (e: any) => {
    setEditingId(e.id);
    setForm({
      car_id: e.car_id ?? "none",
      fecha: e.fecha,
      categoria: e.categoria ?? "Auto",
      concepto: e.concepto ?? "",
      detalle: e.detalle ?? "",
      monto: Number(e.monto) || 0,
    });
    setOpen(true);
  };

  const handleSave = async () => {
    try {
      const payload = { ...form, car_id: form.car_id === "none" || !form.car_id ? null : form.car_id };
      if (editingId) {
        await updateExpense.mutateAsync({ id: editingId, ...payload });
        toast({ title: "Gasto actualizado" });
      } else {
        await addExpense.mutateAsync(payload);
        toast({ title: "Gasto agregado" });
      }
      setOpen(false);
      setEditingId(null);
      setForm(emptyForm);
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const filteredExpenses = useMemo(() => {
    let list = expenses;
    if (tab === "activos") list = list.filter(e => !e.car_id || !soldCarIds.has(e.car_id));
    else list = list.filter(e => e.car_id && soldCarIds.has(e.car_id));
    if (filterCarId === "all") return list;
    if (filterCarId === "none") return list.filter(e => !e.car_id);
    return list.filter(e => e.car_id === filterCarId);
  }, [expenses, filterCarId, tab, soldCarIds]);

  const total = filteredExpenses.reduce((s, e) => s + Number(e.monto), 0);

  const carLabel = (id?: string | null) => {
    if (!id) return "Sin auto";
    const c = cars.find(x => x.id === id);
    return c ? `${c.marca} ${c.modelo} (${c.patente})` : "Sin auto";
  };

  const selectedFormCar = form.car_id && form.car_id !== "none" ? cars.find(c => c.id === form.car_id) : null;
  const selectedFilterCar = filterCarId !== "all" && filterCarId !== "none" ? cars.find(c => c.id === filterCarId) : null;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="page-header">Gastos</h1>
        <Button size="sm" onClick={openNew}><Plus className="w-4 h-4 mr-1" />Nuevo gasto</Button>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as "activos" | "vendidos")}>
        <TabsList>
          <TabsTrigger value="activos">En stock / Sin auto</TabsTrigger>
          <TabsTrigger value="vendidos">Autos vendidos</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="flex flex-col sm:flex-row gap-3">
        <Card className="flex-1">
          <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">{filterCarId === "all" ? "Total gastos" : "Total filtrado"}</CardTitle></CardHeader>
          <CardContent><div className="text-2xl font-bold text-destructive">{formatCurrency(total)}</div></CardContent>
        </Card>

        <Card className="flex-1">
          <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Filtrar por auto</CardTitle></CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Popover open={filterPickerOpen} onOpenChange={setFilterPickerOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" role="combobox" className="flex-1 justify-between font-normal">
                    <span className="flex items-center gap-2 truncate">
                      <Search className="w-3.5 h-3.5 opacity-50 shrink-0" />
                      <span className="truncate">
                        {filterCarId === "all" ? "Todos los autos" : filterCarId === "none" ? "Sin auto asignado" : selectedFilterCar ? `${selectedFilterCar.marca} ${selectedFilterCar.modelo} (${selectedFilterCar.patente})` : "Seleccionar..."}
                      </span>
                    </span>
                    <ChevronsUpDown className="w-3.5 h-3.5 opacity-50 shrink-0" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
                  <Command>
                    <CommandInput placeholder="Buscar patente o modelo..." />
                    <CommandList>
                      <CommandEmpty>Sin resultados.</CommandEmpty>
                      <CommandGroup>
                        <CommandItem value="todos" onSelect={() => { setFilterCarId("all"); setFilterPickerOpen(false); }}>
                          <Check className={cn("mr-2 h-4 w-4", filterCarId === "all" ? "opacity-100" : "opacity-0")} />
                          Todos los autos
                        </CommandItem>
                        <CommandItem value="sin auto" onSelect={() => { setFilterCarId("none"); setFilterPickerOpen(false); }}>
                          <Check className={cn("mr-2 h-4 w-4", filterCarId === "none" ? "opacity-100" : "opacity-0")} />
                          Sin auto asignado
                        </CommandItem>
                        {cars.map(c => (
                          <CommandItem key={c.id} value={`${c.marca} ${c.modelo} ${c.patente} ${c.version ?? ""}`} onSelect={() => { setFilterCarId(c.id); setFilterPickerOpen(false); }}>
                            <Check className={cn("mr-2 h-4 w-4", filterCarId === c.id ? "opacity-100" : "opacity-0")} />
                            <span className="truncate">{c.marca} {c.modelo} <span className="text-muted-foreground">({c.patente})</span></span>
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
              {filterCarId !== "all" && (
                <Button variant="ghost" size="icon" onClick={() => setFilterCarId("all")} title="Limpiar filtro">
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="rounded-lg border overflow-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Fecha</TableHead>
              <TableHead>Auto</TableHead>
              <TableHead>Categoría</TableHead>
              <TableHead>Concepto</TableHead>
              <TableHead className="text-right">Monto</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredExpenses.map(e => (
              <TableRow key={e.id}>
                <TableCell className="text-sm">{formatDate(e.fecha)}</TableCell>
                <TableCell className="text-sm">{carLabel(e.car_id) === "Sin auto" ? <span className="text-muted-foreground">-</span> : carLabel(e.car_id)}</TableCell>
                <TableCell className="text-sm">{e.categoria}</TableCell>
                <TableCell className="text-sm">{e.concepto}</TableCell>
                <TableCell className="text-right text-sm font-medium">{formatCurrency(Number(e.monto))}</TableCell>
                <TableCell className="text-right whitespace-nowrap">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(e)}><Pencil className="w-3.5 h-3.5" /></Button>
                  <Button variant="ghost" size="sm" onClick={() => deleteExpense.mutate(e.id)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                </TableCell>
              </TableRow>
            ))}
            {filteredExpenses.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground text-sm">{filterCarId === "all" ? "Sin gastos registrados" : "Sin gastos para este filtro"}</TableCell></TableRow>}
          </TableBody>
        </Table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editingId ? "Editar gasto" : "Nuevo gasto"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Auto (opcional)</Label>
              <Popover open={carPickerOpen} onOpenChange={setCarPickerOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" role="combobox" className="w-full justify-between font-normal">
                    <span className="truncate">
                      {selectedFormCar ? `${selectedFormCar.marca} ${selectedFormCar.modelo} (${selectedFormCar.patente})` : "Sin auto"}
                    </span>
                    <ChevronsUpDown className="w-3.5 h-3.5 opacity-50 shrink-0" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
                  <Command>
                    <CommandInput placeholder="Buscar patente o modelo..." />
                    <CommandList>
                      <CommandEmpty>Sin resultados.</CommandEmpty>
                      <CommandGroup>
                        <CommandItem value="sin auto" onSelect={() => { set("car_id", "none"); setCarPickerOpen(false); }}>
                          <Check className={cn("mr-2 h-4 w-4", form.car_id === "none" || !form.car_id ? "opacity-100" : "opacity-0")} />
                          Sin auto
                        </CommandItem>
                        {cars.map(c => (
                          <CommandItem key={c.id} value={`${c.marca} ${c.modelo} ${c.patente} ${c.version ?? ""}`} onSelect={() => { set("car_id", c.id); setCarPickerOpen(false); }}>
                            <Check className={cn("mr-2 h-4 w-4", form.car_id === c.id ? "opacity-100" : "opacity-0")} />
                            <span className="truncate">{c.marca} {c.modelo} <span className="text-muted-foreground">({c.patente})</span></span>
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>
            <div><Label>Fecha</Label><Input type="date" value={form.fecha} onChange={e => set("fecha", e.target.value)} /></div>
            <div><Label>Categoría</Label>
              <Select value={form.categoria} onValueChange={v => set("categoria", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CATEGORIAS_GASTO.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Concepto</Label><Input value={form.concepto} onChange={e => set("concepto", e.target.value)} /></div>
            <div><Label>Detalle</Label><Input value={form.detalle} onChange={e => set("detalle", e.target.value)} /></div>
            <div><Label>Monto</Label><MoneyInput value={form.monto} onValueChange={v => set("monto", v)} /></div>
          </div>
          <Button onClick={handleSave} className="w-full" disabled={addExpense.isPending || updateExpense.isPending}>{editingId ? "Actualizar" : "Guardar"}</Button>
        </DialogContent>
      </Dialog>
      <NotificationPhonesCard />

    </div>
  );
}
