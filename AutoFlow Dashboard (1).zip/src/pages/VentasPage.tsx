import { useState } from "react";
import { useSales, useUpsertSale, useDeleteSale, useSalePayments, useAddSalePayment, useCars, useUpsertCar, useExpenses } from "@/hooks/use-data";
import { formatCurrency, formatMoney, formatDate, MARCAS, ANIOS, ESTADOS, getSaleMargin } from "@/lib/supabase-helpers";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Plus, ChevronDown, DollarSign, PackagePlus, Trash2, Check, ChevronsUpDown, FileText, Camera, Loader2, Save, Sparkles } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";

import { MoneyInput } from "@/components/MoneyInput";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { generateBoleto } from "@/lib/pdf-generator";
import { usePlan } from "@/hooks/usePlan";
import { useAgency } from "@/hooks/useAgency";
import { supabase } from "@/integrations/supabase/client";
import type { Sale, SaleInsert } from "@/lib/supabase-helpers";
import { NotificationPhonesCard } from "@/components/NotificationPhonesCard";

// Los datos del vendedor son propios de cada agencia: la clave incluye el id de la agencia.
const vendedorKey = (agencyId?: string | null) => `boazzo:vendedor_default:${agencyId || "sin-agencia"}`;
type VendedorDefault = { vendedor: string; vendedor_dni: string; vendedor_domicilio: string; vendedor_telefono: string };
const VENDEDOR_FALLBACK: VendedorDefault = {
  vendedor: "",
  vendedor_dni: "",
  vendedor_domicilio: "",
  vendedor_telefono: "",
};
const loadVendedorDefault = (agencyId?: string | null): VendedorDefault => {
  try {
    const saved = JSON.parse(localStorage.getItem(vendedorKey(agencyId)) || "{}") as Partial<VendedorDefault>;
    return {
      vendedor: saved.vendedor || VENDEDOR_FALLBACK.vendedor,
      vendedor_dni: saved.vendedor_dni || VENDEDOR_FALLBACK.vendedor_dni,
      vendedor_domicilio: saved.vendedor_domicilio || VENDEDOR_FALLBACK.vendedor_domicilio,
      vendedor_telefono: saved.vendedor_telefono || VENDEDOR_FALLBACK.vendedor_telefono,
    };
  } catch { return { ...VENDEDOR_FALLBACK }; }
};

function AddPartePagoToStock({ sale }: { sale: Sale }) {
  const upsertCar = useUpsertCar();
  const updateSale = useUpsertSale();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    marca: "", modelo: "", version: "", anio: new Date().getFullYear(),
    patente: "", color: "", precio_compra: 0, precio_venta: 0, estado: "Disponible",
  });
  const set = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    try {
      await upsertCar.mutateAsync(form as any);
      // Marcar en la venta que ya se ingresó al stock
      await updateSale.mutateAsync({ id: sale.id, parte_pago: `${sale.parte_pago} ✓ en stock` });
      setOpen(false);
      toast({ title: "Auto agregado al stock" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  if (sale.parte_pago?.includes("✓ en stock")) {
    return <Badge variant="outline" className="text-xs">✓ Ya en stock</Badge>;
  }

  return (
    <>
      <Button variant="outline" size="sm" className="text-xs" onClick={() => setOpen(true)}>
        <PackagePlus className="w-3 h-3 mr-1" />Agregar al stock
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Agregar auto al stock</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Marca</Label>
              <Select value={form.marca} onValueChange={v => set("marca", v)}>
                <SelectTrigger><SelectValue placeholder="Seleccionar" /></SelectTrigger>
                <SelectContent>{MARCAS.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Modelo</Label><Input value={form.modelo} onChange={e => set("modelo", e.target.value)} /></div>
            <div><Label>Versión</Label><Input value={form.version} onChange={e => set("version", e.target.value)} /></div>
            <div><Label>Año</Label>
              <Select value={String(form.anio)} onValueChange={v => set("anio", Number(v))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{ANIOS.map(a => <SelectItem key={a} value={String(a)}>{a}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Patente</Label><Input value={form.patente} onChange={e => set("patente", e.target.value.toUpperCase())} /></div>
            <div><Label>Color</Label><Input value={form.color} onChange={e => set("color", e.target.value)} /></div>
            <div><Label>Precio toma (compra)</Label><MoneyInput value={form.precio_compra} onValueChange={v => set("precio_compra", v)} /></div>
            <div><Label>Precio de venta</Label><MoneyInput value={form.precio_venta} onValueChange={v => set("precio_venta", v)} /></div>
            <div><Label>Estado</Label>
              <Select value={form.estado} onValueChange={v => set("estado", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{ESTADOS.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <Button onClick={handleSave} className="w-full" disabled={!form.marca || !form.modelo || !form.patente}>Guardar en stock</Button>
        </DialogContent>
      </Dialog>
    </>
  );
}

function SalePayments({ sale }: { sale: Sale }) {
  const { data: payments = [] } = useSalePayments(sale.id);
  const addPayment = useAddSalePayment();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [monto, setMonto] = useState(0);
  const [fecha, setFecha] = useState(new Date().toISOString().split("T")[0]);
  const [nota, setNota] = useState("");

  const totalPagado = Number(sale.sena) + payments.reduce((s, p) => s + Number(p.monto), 0);
  const deuda = Number(sale.monto) - totalPagado;

  const handleAdd = async () => {
    try {
      await addPayment.mutateAsync({ sale_id: sale.id, monto, fecha, nota });
      setOpen(false);
      toast({ title: "Pago registrado" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  return (
    <div className="space-y-2 pt-2 border-t mt-2">
      <div className="grid grid-cols-3 gap-2 text-xs">
        <div><span className="text-muted-foreground">Total</span><div className="font-medium">{formatCurrency(Number(sale.monto))}</div></div>
        <div><span className="text-muted-foreground">Pagado</span><div className="font-medium text-success">{formatCurrency(totalPagado)}</div></div>
        <div><span className="text-muted-foreground">Debe</span><div className={`font-medium ${deuda > 0 ? "text-warning" : "text-success"}`}>{formatCurrency(deuda)}</div></div>
      </div>
      {payments.length > 0 && (
        <div className="space-y-1">
          {payments.map(p => (
            <div key={p.id} className="flex justify-between text-xs">
              <span>{formatDate(p.fecha)} {p.nota && `- ${p.nota}`}</span>
              <span className="font-medium">{formatCurrency(Number(p.monto))}</span>
            </div>
          ))}
        </div>
      )}
      {deuda > 0 && (
        <>
          <Button variant="outline" size="sm" className="text-xs" onClick={() => setOpen(true)}>
            <DollarSign className="w-3 h-3 mr-1" />Registrar pago
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogContent>
              <DialogHeader><DialogTitle>Registrar pago</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Fecha</Label><Input type="date" value={fecha} onChange={e => setFecha(e.target.value)} /></div>
                <div><Label>Monto</Label><MoneyInput value={monto} onValueChange={setMonto} /></div>
                <div><Label>Nota</Label><Input value={nota} onChange={e => setNota(e.target.value)} /></div>
              </div>
              <Button onClick={handleAdd} className="w-full">Guardar</Button>
            </DialogContent>
          </Dialog>
        </>
      )}
    </div>
  );
}

export default function VentasPage() {
  const { data: sales = [] } = useSales();
  const { data: cars = [] } = useCars();
  const { data: expenses = [] } = useExpenses();
  const upsert = useUpsertSale();
  const deleteSale = useDeleteSale();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [carPickerOpen, setCarPickerOpen] = useState(false);
  const { agency } = useAgency();
  const agencyId = agency?.id ?? null;
  const defaultLugar = agency?.ciudad || "";
  const [form, setForm] = useState<Partial<SaleInsert> & { id?: string }>(() => {
    const v = loadVendedorDefault(null);
    return { fecha: new Date().toISOString().split("T")[0], vendedor: v.vendedor || "", car_id: "", patente: "", moneda: "ARS", cotizacion_usd: null, monto: 0, sena: 0, monto_financiar: 0, parte_pago: "", parte_pago_valor: 0, cuotas: 0, estado: "activa",
      comprador_nombre: "", comprador_dni: "", comprador_domicilio: "", comprador_telefono: "", forma_pago: "", lugar: "",
      vendedor_dni: v.vendedor_dni || "", vendedor_domicilio: v.vendedor_domicilio || "", vendedor_telefono: v.vendedor_telefono || "" } as any;
  });
  const [dniLoading, setDniLoading] = useState(false);
  const [aiText, setAiText] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiFaltantes, setAiFaltantes] = useState("");
  const [confirmOpen, setConfirmOpen] = useState(false);
  const { can } = usePlan();
  const [pendingBoleto, setPendingBoleto] = useState<{ sale: any; car: any } | null>(null);
  const selectedFormCar = form.car_id ? cars.find(c => c.id === form.car_id) : null;


  const set = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  const openEdit = (sale: Sale) => { setForm(sale); setAiText(""); setAiFaltantes(""); setOpen(true); };
  const openNew = () => {
    const v = loadVendedorDefault(agencyId);
    setAiText(""); setAiFaltantes("");
    setForm({ fecha: new Date().toISOString().split("T")[0], vendedor: v.vendedor || "", car_id: "", patente: "", moneda: "ARS", cotizacion_usd: null, monto: 0, sena: 0, monto_financiar: 0, parte_pago: "", parte_pago_valor: 0, cuotas: 0, estado: "activa",
      comprador_nombre: "", comprador_dni: "", comprador_domicilio: "", comprador_telefono: "", forma_pago: "", lugar: defaultLugar,
      vendedor_dni: v.vendedor_dni || "", vendedor_domicilio: v.vendedor_domicilio || "", vendedor_telefono: v.vendedor_telefono || "" } as any);
    setOpen(true);
  };

  const handleParseVenta = async () => {
    if (!aiText.trim()) return;
    setAiLoading(true);
    setAiFaltantes("");
    try {
      const { data, error } = await supabase.functions.invoke("parse-venta", {
        body: {
          text: aiText,
          cars: cars.map(c => ({ id: c.id, label: `${c.marca} ${c.modelo} ${(c as any).version ?? ""} ${c.anio} ${c.patente}`.trim() })),
        },
      });
      if (error) throw error;
      setForm(f => {
        const next: any = { ...f };
        const put = (k: string, v: any) => { if (v !== "" && v !== 0 && v !== null && v !== undefined) next[k] = v; };
        put("comprador_nombre", data.comprador_nombre);
        put("comprador_dni", data.comprador_dni);
        put("comprador_domicilio", data.comprador_domicilio);
        put("comprador_telefono", data.comprador_telefono);
        put("forma_pago", data.forma_pago);
        put("lugar", data.lugar);
        put("monto", data.monto);
        put("moneda", data.moneda);
        put("cotizacion_usd", data.cotizacion_usd);
        put("sena", data.sena);
        put("monto_financiar", data.monto_financiar);
        put("cuotas", data.cuotas);
        put("parte_pago", data.parte_pago);
        put("parte_pago_valor", data.parte_pago_valor);
        put("valor_transferencia", data.valor_transferencia);
        put("fecha", data.fecha);
        if (typeof data.transferencia_incluida === "boolean") next.transferencia_incluida = data.transferencia_incluida;
        if (data.car_id) {
          next.car_id = data.car_id;
          const c = cars.find(x => x.id === data.car_id);
          if (c) next.patente = c.patente;
        } else put("patente", data.patente);
        return next;
      });
      setAiFaltantes(data.notas_faltantes || "");
      toast({ title: "Datos completados con IA", description: "Revisá todo antes de confirmar el boleto." });
    } catch (err: any) {
      toast({ title: "No se pudo interpretar el texto", description: err.message, variant: "destructive" });
    } finally {
      setAiLoading(false);
    }
  };

  const saveVendedorDefault = () => {
    const v: VendedorDefault = {
      vendedor: form.vendedor || "",
      vendedor_dni: (form as any).vendedor_dni || "",

      vendedor_domicilio: (form as any).vendedor_domicilio || "",
      vendedor_telefono: (form as any).vendedor_telefono || "",
    };
    localStorage.setItem(vendedorKey(agencyId), JSON.stringify(v));
    toast({ title: "Datos del vendedor guardados", description: "Quedan guardados sólo para esta agencia." });
  };

  const handleDniPhotos = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setDniLoading(true);
    try {
      const images: string[] = await Promise.all(Array.from(files).slice(0, 2).map(f => new Promise<string>((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(r.result as string);
        r.onerror = () => reject(r.error);
        r.readAsDataURL(f);
      })));
      const { data, error } = await supabase.functions.invoke("extract-dni", { body: { images } });
      if (error) throw error;
      if (data?.nombre) set("comprador_nombre", data.nombre);
      if (data?.dni) set("comprador_dni", data.dni);
      if (data?.domicilio) set("comprador_domicilio", data.domicilio);
      if (data?.telefono) set("comprador_telefono", data.telefono);
      toast({ title: "Datos extraídos del DNI", description: "Revisá los campos antes de guardar." });
    } catch (err: any) {
      toast({ title: "No se pudo leer el DNI", description: err.message, variant: "destructive" });
    } finally {
      setDniLoading(false);
    }
  };

  const buildBoletoOpts = (sale: any, car: any) => ({
    vendedor: {
      nombre: sale.vendedor || "",
      dni: sale.vendedor_dni || "",
      domicilio: sale.vendedor_domicilio || "",
      telefono: sale.vendedor_telefono || "",
    },
    comprador: {
      nombre: sale.comprador_nombre || "",
      dni: sale.comprador_dni || "",
      domicilio: sale.comprador_domicilio || "",
      telefono: sale.comprador_telefono || "",
    },
    auto: {
      marca: car?.marca || "", modelo: car?.modelo || "", anio: car?.anio || new Date().getFullYear(),
      version: car?.version || "", patente: sale.patente || car?.patente || "",
      color: car?.color || "", motor: car?.motor_num || car?.motor || "", chasis: car?.chasis_num || car?.chasis || "",
      kilometros: car?.kilometros ?? "", combustible: car?.combustible || "",
    },
    precio: Number(sale.monto || 0),
    sena: Number(sale.sena || 0),
    lugar: sale.lugar || "",
    fecha: sale.fecha,
    formaPago: sale.forma_pago || "",
  });

  const handleSave = async () => {
    try {
      await upsert.mutateAsync({ ...(form as any), car_id: form.car_id || null });
      const car = form.car_id ? cars.find(c => c.id === form.car_id) : null;
      if (car && car.estado !== "Vendido") {
        const { supabase } = await import("@/integrations/supabase/client");
        await supabase.from("cars").update({ estado: "Vendido" }).eq("id", form.car_id!);
      }
      setOpen(false);
      toast({ title: "Venta guardada" });
      if (can("boleto")) {
        setPendingBoleto({ sale: { ...(form as any) }, car });
        setConfirmOpen(true);
      }
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const confirmBoleto = async () => {
    if (!pendingBoleto) return;
    try {
      await generateBoleto(buildBoletoOpts(pendingBoleto.sale, pendingBoleto.car));
      setConfirmOpen(false);
      setPendingBoleto(null);
    } catch (e: any) {
      toast({ title: "No se pudo generar el boleto", description: e.message, variant: "destructive" });
    }
  };


  // Ganancia = monto de venta - precio de compra - gastos del auto
  const getMargen = (sale: Sale) => {
    const car = cars.find(c => c.id === sale.car_id);
    const gastosAuto = sale.car_id
      ? expenses.filter((e: any) => e.car_id === sale.car_id).reduce((sum: number, e: any) => sum + Number(e.monto ?? 0), 0)
      : 0;
    return getSaleMargin({ sale, car, expensesTotal: gastosAuto });
  };

  // Group by month
  const grouped = sales.reduce((acc, s) => {
    const key = ((s as any).fecha_entrega || s.fecha).substring(0, 7);
    (acc[key] = acc[key] || []).push(s);
    return acc;
  }, {} as Record<string, Sale[]>);

  const gananciaTotal = sales.reduce((s, sale) => s + getMargen(sale), 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="page-header">Ventas</h1>
        <Button size="sm" onClick={openNew}><Plus className="w-4 h-4 mr-1" />Nueva venta</Button>
      </div>

      {sales.length > 0 && (
        <Card>
          <CardContent className="p-3 flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Ganancia total acumulada</span>
            <span className={`text-base font-bold ${gananciaTotal >= 0 ? "text-success" : "text-destructive"}`}>{formatCurrency(gananciaTotal)}</span>
          </CardContent>
        </Card>
      )}

      {Object.entries(grouped).sort((a, b) => b[0].localeCompare(a[0])).map(([month, salesInMonth]) => {
        const gananciaMes = salesInMonth.reduce((s, sale) => s + getMargen(sale), 0);
        return (
        <div key={month} className="space-y-2">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-muted-foreground capitalize">{(() => { const [y, m] = month.split("-").map(Number); return new Date(y, m - 1, 1).toLocaleDateString("es-AR", { month: "long", year: "numeric" }); })()}</h2>
            <span className="text-xs">
              <span className="text-muted-foreground">Ganancia: </span>
              <span className={`font-semibold ${gananciaMes >= 0 ? "text-success" : "text-destructive"}`}>{formatCurrency(gananciaMes)}</span>
            </span>
          </div>
          <div className="space-y-2">
            {salesInMonth.map(sale => {
              const car = cars.find(c => c.id === sale.car_id);
              return (
                <Collapsible key={sale.id}>
                  <Card>
                    <CollapsibleTrigger className="w-full">
                      <CardContent className="p-4 flex items-center justify-between">
                        <div className="text-left">
                          <div className="text-sm font-bold uppercase">
                            {car ? `${car.marca} ${car.modelo}` : (sale as any).marca_modelo || ""} {(sale.patente || car?.patente || "").toUpperCase()}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {(sale as any).fecha_entrega
                              ? <>Entrega: {formatDate((sale as any).fecha_entrega)}</>
                              : formatDate(sale.fecha)} · {sale.vendedor}
                          </div>
                          {sale.parte_pago && (
                            <div className="text-xs text-accent-foreground mt-0.5">🔄 Entró: {sale.parte_pago}</div>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="text-right">
                            <div className="text-sm font-semibold">{formatMoney(Number(sale.monto), (sale as any).moneda)}</div>
                            <Badge variant={sale.estado === "pagada" ? "default" : "secondary"} className="text-xs">
                              {sale.estado}
                            </Badge>
                          </div>
                          <ChevronDown className="w-4 h-4 text-muted-foreground" />
                        </div>
                      </CardContent>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <CardContent className="px-4 pb-4 pt-0">
                        <div className="grid grid-cols-2 gap-2 text-xs mb-2">
                          <div><span className="text-muted-foreground">Seña:</span> {formatCurrency(Number(sale.sena))}</div>
                          <div><span className="text-muted-foreground">Cuotas:</span> {sale.cuotas || 0}</div>
                          {(sale as any).fecha_sena && (
                            <div><span className="text-muted-foreground">Fecha seña:</span> {formatDate((sale as any).fecha_sena)}</div>
                          )}
                          {(sale as any).fecha_entrega && (
                            <div><span className="text-muted-foreground">Entrega del auto:</span> {formatDate((sale as any).fecha_entrega)}</div>
                          )}
                          {Number((sale as any).monto_entrega) > 0 && (
                            <div className="col-span-2">
                              <span className="text-muted-foreground">Entrega al retirar:</span>{" "}
                              <span className="font-semibold">{formatCurrency(Number((sale as any).monto_entrega))}</span>
                            </div>
                          )}
                          {(sale as any).primera_cuota_fecha && (
                            <div className="col-span-2">
                              <span className="text-muted-foreground">1ª cuota vence:</span>{" "}
                              <span className="font-semibold">{formatDate((sale as any).primera_cuota_fecha)}</span>
                            </div>
                          )}
                          {Number((sale as any).monto_financiar) > 0 && (
                            <div className="col-span-2">
                              <span className="text-muted-foreground">Monto a financiar:</span>{" "}
                              <span className="font-semibold">{formatCurrency(Number((sale as any).monto_financiar))}</span>
                            </div>
                          )}
                          {Number((sale as any).valor_transferencia) > 0 && (
                            <div className="col-span-2">
                              <span className="text-muted-foreground">Valor transferencia:</span>{" "}
                              <span className="font-semibold">{formatCurrency(Number((sale as any).valor_transferencia))}</span>
                              <span className="ml-1 text-muted-foreground">
                                ({((sale as any).transferencia_incluida ?? true) ? "incluida en precio" : "aparte"})
                              </span>
                            </div>
                          )}
                          {sale.cuotas && sale.cuotas > 0 && (
                            <div className="col-span-2">
                              <span className="text-muted-foreground">Monto por cuota:</span>{" "}
                              <span className="font-semibold">{formatCurrency(Number((sale as any).monto_financiar || sale.monto) / sale.cuotas)}</span>
                            </div>
                          )}
                          {sale.parte_pago && (
                            <div className="col-span-2 space-y-1">
                              <div>
                                <span className="text-muted-foreground">Auto parte de pago:</span>{" "}
                                {sale.parte_pago}
                              </div>
                              {Number((sale as any).parte_pago_valor) > 0 && (
                                <>
                                  <div>
                                    <span className="text-muted-foreground">Valor toma:</span>{" "}
                                    <span className="font-semibold">{formatCurrency(Number((sale as any).parte_pago_valor))}</span>
                                  </div>
                                  <div>
                                    <span className="text-muted-foreground">Diferencia a favor:</span>{" "}
                                    <span className="font-semibold text-success">{formatCurrency(Number(sale.monto) - Number((sale as any).parte_pago_valor))}</span>
                                  </div>
                                </>
                              )}
                              <AddPartePagoToStock sale={sale} />
                            </div>
                          )}
                        </div>
                        {(() => {
                          const compra = Number(car?.precio_compra ?? 0);
                          const gastosAuto = sale.car_id ? expenses.filter((e: any) => e.car_id === sale.car_id) : [];
                          const totalGastos = gastosAuto.reduce((s: number, e: any) => s + Number(e.monto ?? 0), 0);
                          const margen = getMargen(sale);
                          return (
                            <>
                              <div className="rounded-md border bg-muted/40 p-2 text-xs grid grid-cols-4 gap-2 mb-2">
                                <div><span className="text-muted-foreground block">Compra</span><span className="font-medium">{formatCurrency(compra)}</span></div>
                                <div><span className="text-muted-foreground block">Gastos</span><span className="font-medium text-destructive">{formatCurrency(totalGastos)}</span></div>
                                <div><span className="text-muted-foreground block">Venta</span><span className="font-medium">{formatMoney(Number(sale.monto), (sale as any).moneda)}</span>{(sale as any).moneda === "USD" && Number((sale as any).cotizacion_usd) > 0 && <span className="block text-[10px] text-muted-foreground">≈ {formatCurrency(Number(sale.monto) * Number((sale as any).cotizacion_usd))} (dólar {formatCurrency(Number((sale as any).cotizacion_usd))})</span>}</div>
                                <div><span className="text-muted-foreground block">Margen</span><span className={`font-bold ${margen >= 0 ? "text-success" : "text-destructive"}`}>{formatCurrency(margen)}</span></div>
                              </div>
                              {gastosAuto.length > 0 && (
                                <div className="rounded-md border bg-card p-2 text-xs mb-2 space-y-1">
                                  <div className="font-semibold text-muted-foreground mb-1">Gastos del auto ({gastosAuto.length})</div>
                                  {gastosAuto
                                    .slice()
                                    .sort((a: any, b: any) => a.fecha.localeCompare(b.fecha))
                                    .map((g: any) => (
                                      <div key={g.id} className="flex justify-between gap-2">
                                        <span className="truncate">
                                          {formatDate(g.fecha)} · {g.categoria}
                                          {g.concepto && <span className="text-muted-foreground"> · {g.concepto}</span>}
                                        </span>
                                        <span className="font-medium shrink-0">{formatCurrency(Number(g.monto))}</span>
                                      </div>
                                    ))}
                                  <div className="flex justify-between border-t pt-1 mt-1 font-semibold">
                                    <span>Total gastos</span>
                                    <span className="text-destructive">{formatCurrency(totalGastos)}</span>
                                  </div>
                                </div>
                              )}
                            </>
                          );
                        })()}
                        <SalePayments sale={sale} />
                        <div className="flex gap-2 mt-2 flex-wrap">
                          <Button variant="ghost" size="sm" className="text-xs" onClick={() => openEdit(sale)}>Editar venta</Button>
                          {can("boleto") && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-xs"
                            onClick={async () => {
                              try {
                                await generateBoleto(buildBoletoOpts(sale, cars.find(c => c.id === sale.car_id)));
                              } catch (e: any) {
                                toast({ title: "Error", description: e.message, variant: "destructive" });
                              }
                            }}
                          >
                            <FileText className="w-3 h-3 mr-1" />Boleto C/V
                          </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-xs text-destructive hover:text-destructive"
                            onClick={async () => {
                              if (!confirm("¿Eliminar esta venta? Esta acción no se puede deshacer.")) return;
                              try {
                                await deleteSale.mutateAsync(sale.id);
                                toast({ title: "Venta eliminada" });
                              } catch (err: any) {
                                toast({ title: "Error", description: err.message, variant: "destructive" });
                              }
                            }}
                          >
                            <Trash2 className="w-3 h-3 mr-1" />Eliminar
                          </Button>
                        </div>
                      </CardContent>
                    </CollapsibleContent>
                  </Card>
                </Collapsible>
              );
            })}
          </div>
        </div>
      );})}

      {sales.length === 0 && <p className="text-muted-foreground text-sm">No hay ventas registradas.</p>}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{form.id ? "Editar venta" : "Nueva venta"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            {can("ia_ventas") && (
            <div className="rounded-md border border-dashed p-3 space-y-2 bg-muted/30">
              <div className="flex items-center gap-2 text-xs font-semibold text-muted-foreground">
                <Sparkles className="w-3.5 h-3.5" /> COMPLETAR CON IA (opcional)
              </div>
              <p className="text-[11px] text-muted-foreground">Escribí todo de corrido (comprador, auto, precio, seña, forma de pago...) y la IA completa los campos. Después revisás y confirmás.</p>
              <Textarea
                rows={4}
                placeholder="Ej: Le vendí el Gol Trend patente ABC123 a Juan Pérez, DNI 30123456, vive en Calle 7 nro 500 La Plata, tel 2214567890. Precio 15.000.000, seña 2.000.000 en efectivo y el resto por transferencia."
                value={aiText}
                onChange={e => setAiText(e.target.value)}
              />
              <Button type="button" size="sm" variant="secondary" disabled={aiLoading || !aiText.trim()} onClick={handleParseVenta}>
                {aiLoading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Interpretando...</> : <><Sparkles className="w-4 h-4 mr-2" />Completar campos con IA</>}
              </Button>
              {aiFaltantes && <p className="text-[11px] text-warning-foreground bg-warning/20 rounded p-2">Faltan: {aiFaltantes}</p>}
            </div>
            )}
            <div><Label>Fecha de la venta</Label><Input type="date" value={form.fecha ?? ""} onChange={e => set("fecha", e.target.value)} /></div>
            <div className="grid grid-cols-2 gap-2">
              <div><Label>Fecha de la seña</Label><Input type="date" value={(form as any).fecha_sena ?? ""} onChange={e => set("fecha_sena", e.target.value || null)} /></div>
              <div><Label>Fecha de entrega del auto</Label><Input type="date" value={(form as any).fecha_entrega ?? ""} onChange={e => set("fecha_entrega", e.target.value || null)} /></div>
            </div>
            <p className="text-[10px] text-muted-foreground -mt-2">La venta se agrupa y se muestra por la fecha de entrega cuando la cargás.</p>

            {can("vendedor") && (
            <div className="border-t pt-3 mt-2">
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-semibold text-muted-foreground">DATOS DEL VENDEDOR (para el boleto)</div>
                <Button type="button" variant="ghost" size="sm" className="text-xs h-7" onClick={saveVendedorDefault}>
                  <Save className="w-3 h-3 mr-1" />Guardar como predeterminado
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="col-span-2"><Label>Nombre completo</Label><Input value={form.vendedor ?? ""} onChange={e => set("vendedor", e.target.value)} /></div>
                <div><Label>DNI / CUIT</Label><Input value={(form as any).vendedor_dni ?? ""} onChange={e => set("vendedor_dni", e.target.value)} /></div>
                <div><Label>Teléfono</Label><Input value={(form as any).vendedor_telefono ?? ""} onChange={e => set("vendedor_telefono", e.target.value)} /></div>
                <div className="col-span-2"><Label>Domicilio</Label><Input value={(form as any).vendedor_domicilio ?? ""} onChange={e => set("vendedor_domicilio", e.target.value)} /></div>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">Estos datos se guardan localmente y se cargan solos en cada nueva venta.</p>
            </div>
            )}
            <div><Label>Auto</Label>
              <Popover open={carPickerOpen} onOpenChange={setCarPickerOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" role="combobox" className="w-full justify-between font-normal">
                    <span className="truncate">
                      {selectedFormCar ? `${selectedFormCar.marca} ${selectedFormCar.modelo} (${selectedFormCar.patente})` : "Seleccionar"}
                    </span>
                    <ChevronsUpDown className="w-3.5 h-3.5 opacity-50 shrink-0" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
                  <Command>
                    <CommandInput placeholder="Buscar patente o modelo..." />
                    <CommandList>
                      <CommandEmpty>Sin resultados.</CommandEmpty>
                      <CommandGroup>
                        {cars.map(c => (
                          <CommandItem key={c.id} value={`${c.marca} ${c.modelo} ${c.patente} ${c.version ?? ""}`} onSelect={() => { set("car_id", c.id); set("patente", c.patente); setCarPickerOpen(false); }}>
                            <Check className={cn("mr-2 h-4 w-4", form.car_id === c.id ? "opacity-100" : "opacity-0")} />
                            <span className="truncate">{c.marca} {c.modelo} <span className="text-muted-foreground">({c.patente})</span></span>
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>
            <div><Label>Patente</Label><Input value={form.patente ?? ""} onChange={e => set("patente", e.target.value)} /></div>

            <div className="border-t pt-3 mt-2">
              <div className="text-xs font-semibold text-muted-foreground mb-2">DATOS DEL COMPRADOR (para el boleto)</div>
              {can("ia_documentos") && (
              <label className="block mb-3">
                <div className="border-2 border-dashed rounded-md p-3 text-center cursor-pointer hover:bg-muted/50 transition">
                  {dniLoading ? (
                    <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                      <Loader2 className="w-4 h-4 animate-spin" /> Leyendo DNI con IA...
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2 text-sm">
                      <Camera className="w-4 h-4" />
                      <span>Subir foto/s del DNI (frente y dorso) — la IA completa los datos</span>
                    </div>
                  )}
                </div>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  capture="environment"
                  className="hidden"
                  disabled={dniLoading}
                  onChange={e => { handleDniPhotos(e.target.files); e.target.value = ""; }}
                />
              </label>
              )}
              <div className="grid grid-cols-2 gap-2">
                <div><Label>Nombre completo</Label><Input value={(form as any).comprador_nombre ?? ""} onChange={e => set("comprador_nombre", e.target.value)} /></div>
                <div><Label>DNI / CUIT</Label><Input value={(form as any).comprador_dni ?? ""} onChange={e => set("comprador_dni", e.target.value)} /></div>
                <div className="col-span-2"><Label>Domicilio</Label><Input value={(form as any).comprador_domicilio ?? ""} onChange={e => set("comprador_domicilio", e.target.value)} /></div>
                <div><Label>Teléfono</Label><Input value={(form as any).comprador_telefono ?? ""} onChange={e => set("comprador_telefono", e.target.value)} /></div>
                <div><Label>Lugar</Label><Input value={(form as any).lugar ?? defaultLugar} onChange={e => set("lugar", e.target.value)} /></div>
                <div className="col-span-2"><Label>Forma de pago</Label><Input placeholder="Ej: efectivo + transferencia" value={(form as any).forma_pago ?? ""} onChange={e => set("forma_pago", e.target.value)} /></div>
              </div>
            </div>

            <div>
              <Label>Moneda de la venta</Label>
              <Select
                value={(form as any).moneda ?? "ARS"}
                onValueChange={v => set("moneda", v)}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ARS">Pesos (ARS)</SelectItem>
                  <SelectItem value="USD">Dólares (USD)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Monto {(form as any).moneda === "USD" ? "(en USD)" : "(en $)"}</Label><MoneyInput value={form.monto ?? 0} onValueChange={v => set("monto", v)} /></div>
            {(form as any).moneda === "USD" && (
              <div>
                <Label>Cotización del dólar (para calcular la ganancia en pesos)</Label>
                <MoneyInput value={(form as any).cotizacion_usd ?? 0} onValueChange={v => set("cotizacion_usd", v || null)} />
                {Number(form.monto) > 0 && Number((form as any).cotizacion_usd) > 0 && (
                  <div className="text-xs bg-muted/50 rounded-md p-2 mt-2">
                    <span className="text-muted-foreground">Equivale a:</span>{" "}
                    <span className="font-semibold">{formatCurrency(Number(form.monto) * Number((form as any).cotizacion_usd))}</span>
                  </div>
                )}
              </div>
            )}
            <div><Label>Margen manual</Label><MoneyInput value={(form as any).margen_manual ?? 0} onValueChange={v => set("margen_manual", v || null)} /></div>
            <div><Label>Seña</Label><MoneyInput value={form.sena ?? 0} onValueChange={v => set("sena", v)} /></div>
            <div><Label>Entrega el día que retira el vehículo</Label><MoneyInput value={(form as any).monto_entrega ?? 0} onValueChange={v => set("monto_entrega", v || null)} /></div>
            <div><Label>Parte de pago (auto recibido)</Label>
              <Input
                placeholder="Ej: VW Gol Trend 2018 gris ABC123"
                value={form.parte_pago ?? ""}
                onChange={e => set("parte_pago", e.target.value)}
              />
            </div>
            {form.parte_pago && (
              <>
                <div><Label>Valor toma del auto recibido</Label>
                  <MoneyInput
                    value={(form as any).parte_pago_valor ?? 0}
                    onValueChange={v => set("parte_pago_valor", v)}
                  />
                </div>
                {Number((form as any).parte_pago_valor) > 0 && Number(form.monto) > 0 && (
                  <div className="text-xs bg-muted/50 rounded-md p-2">
                    <span className="text-muted-foreground">Diferencia a favor:</span>{" "}
                    <span className="font-semibold text-success">
                      {new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 }).format(Number(form.monto) - Number((form as any).parte_pago_valor))}
                    </span>
                  </div>
                )}
              </>
            )}
            <div><Label>Monto a financiar</Label><MoneyInput value={(form as any).monto_financiar ?? 0} onValueChange={v => set("monto_financiar", v)} /></div>
            <div><Label>Valor de transferencia</Label><MoneyInput value={(form as any).valor_transferencia ?? 0} onValueChange={v => set("valor_transferencia", v)} /></div>
            <div>
              <Label>¿La transferencia está incluida en el precio?</Label>
              <Select
                value={String((form as any).transferencia_incluida ?? true)}
                onValueChange={v => set("transferencia_incluida", v === "true")}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="true">Sí, incluida (se descuenta del margen)</SelectItem>
                  <SelectItem value="false">No, aparte (la paga el comprador)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Cuotas</Label><Input type="number" value={form.cuotas ?? 0} onChange={e => set("cuotas", Number(e.target.value))} /></div>
            {Number(form.cuotas) > 0 && (
              <div>
                <Label>Vencimiento de la primera cuota</Label>
                <Input type="date" value={(form as any).primera_cuota_fecha ?? ""} onChange={e => set("primera_cuota_fecha", e.target.value || null)} />
                <p className="text-[10px] text-muted-foreground mt-1">Las cuotas siguientes se calculan mes a mes desde esta fecha.</p>
              </div>
            )}
            <div><Label>Estado</Label>
              <Select value={form.estado ?? "activa"} onValueChange={v => set("estado", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="activa">Activa</SelectItem>
                  <SelectItem value="pagada">Pagada</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button onClick={handleSave} className="w-full">Guardar</Button>
        </DialogContent>
      </Dialog>

      <Dialog open={confirmOpen} onOpenChange={(o) => { setConfirmOpen(o); if (!o) setPendingBoleto(null); }}>
        <DialogContent className="max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Confirmar datos del boleto</DialogTitle></DialogHeader>
          {pendingBoleto && (() => {
            const s = pendingBoleto.sale; const c = pendingBoleto.car;
            const rows: [string, string][] = [
              ["Vendedor", `${s.vendedor || "-"} ${s.vendedor_dni ? `(DNI ${s.vendedor_dni})` : ""}`],
              ["Domicilio vendedor", s.vendedor_domicilio || "-"],
              ["Comprador", `${s.comprador_nombre || "-"} ${s.comprador_dni ? `(DNI ${s.comprador_dni})` : ""}`],
              ["Domicilio comprador", s.comprador_domicilio || "-"],
              ["Teléfono comprador", s.comprador_telefono || "-"],
              ["Auto", c ? `${c.marca} ${c.modelo} ${(c as any).version ?? ""} ${c.anio}`.trim() : "-"],
              ["Patente", s.patente || c?.patente || "-"],
              ["Precio", `${s.moneda === "USD" ? "USD " : ""}${formatMoney(Number(s.monto || 0))}`],
              ["Seña", formatMoney(Number(s.sena || 0))],
              ["Forma de pago", s.forma_pago || "-"],
              ["Lugar", s.lugar || "-"],
              ["Fecha", s.fecha || "-"],
            ];
            const faltan = rows.filter(([, v]) => !v || v.trim() === "-").map(([k]) => k);
            return (
              <div className="space-y-3">
                <div className="rounded-md border divide-y text-sm">
                  {rows.map(([k, v]) => (
                    <div key={k} className="flex justify-between gap-3 px-3 py-1.5">
                      <span className="text-muted-foreground">{k}</span>
                      <span className="font-medium text-right break-words">{v || "-"}</span>
                    </div>
                  ))}
                </div>
                {faltan.length > 0 && (
                  <p className="text-xs bg-destructive/10 text-destructive rounded p-2">
                    Faltan completar: {faltan.join(", ")}. Podés generarlo igual o editar la venta.
                  </p>
                )}
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1" onClick={() => { setConfirmOpen(false); setOpen(true); }}>Revisar / editar</Button>
                  <Button className="flex-1" onClick={confirmBoleto}><FileText className="w-4 h-4 mr-2" />Confirmar y generar</Button>
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      <NotificationPhonesCard />

    </div>
  );
}
