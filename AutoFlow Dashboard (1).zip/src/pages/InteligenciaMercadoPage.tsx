import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle2, ExternalLink, Bell, BellOff, Car as CarIcon } from "lucide-react";

type Analysis = any;
type Alert = any;

const SEV_COLOR: Record<string, string> = {
  success: "bg-green-500/15 text-green-700 border-green-500/30",
  warning: "bg-amber-500/15 text-amber-700 border-amber-500/30",
  info: "bg-blue-500/15 text-blue-700 border-blue-500/30",
};

export default function InteligenciaMercadoPage() {
  const { user } = useAuth();
  const [analyses, setAnalyses] = useState<Analysis[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [cars, setCars] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const [{ data: a }, { data: al }, { data: c }] = await Promise.all([
      supabase.from("market_analyses").select("*").order("created_at", { ascending: false }).limit(50),
      supabase.from("market_alerts").select("*").order("created_at", { ascending: false }).limit(50),
      supabase.from("cars").select("id, marca, modelo, version, anio, precio_venta, moneda"),
    ]);
    setAnalyses(a || []);
    setAlerts(al || []);
    const m: Record<string, any> = {};
    (c || []).forEach((x: any) => { m[x.id] = x; });
    setCars(m);
    setLoading(false);
  };
  useEffect(() => { load(); }, [user]);

  const markRead = async (id: string) => {
    await supabase.from("market_alerts").update({ read: true }).eq("id", id);
    setAlerts(alerts.map(a => a.id === id ? { ...a, read: true } : a));
  };
  const markAllRead = async () => {
    const ids = alerts.filter(a => !a.read).map(a => a.id);
    if (!ids.length) return;
    await supabase.from("market_alerts").update({ read: true }).in("id", ids);
    setAlerts(alerts.map(a => ({ ...a, read: true })));
  };

  // Última análisis por auto
  const lastByCar: Record<string, Analysis> = {};
  analyses.forEach(a => { if (!lastByCar[a.car_id]) lastByCar[a.car_id] = a; });
  const cards = Object.values(lastByCar);

  // Oportunidades: autos sobrevaluados / fuera del top
  const opportunities = cards.filter((a: any) => Number(a.diff_pct) > 10 || (a.my_position && a.total_results > 5 && a.my_position > a.total_results * 0.7));

  const unread = alerts.filter(a => !a.read).length;

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2"><TrendingUp className="w-6 h-6" /> Inteligencia de Mercado</h1>
          <p className="text-sm text-muted-foreground">Análisis automático de precios en Mercado Libre y recomendaciones IA por vehículo.</p>
        </div>
        {unread > 0 && (
          <Button variant="outline" onClick={markAllRead}><BellOff className="w-4 h-4" /> Marcar {unread} como leídas</Button>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="p-4">
          <div className="text-xs text-muted-foreground">Vehículos analizados</div>
          <div className="text-2xl font-bold">{cards.length}</div>
        </Card>
        <Card className="p-4">
          <div className="text-xs text-muted-foreground">Oportunidades activas</div>
          <div className="text-2xl font-bold">{opportunities.length}</div>
        </Card>
        <Card className="p-4">
          <div className="text-xs text-muted-foreground">Alertas sin leer</div>
          <div className="text-2xl font-bold">{unread}</div>
        </Card>
        <Card className="p-4">
          <div className="text-xs text-muted-foreground">Análisis totales</div>
          <div className="text-2xl font-bold">{analyses.length}</div>
        </Card>
      </div>

      <Tabs defaultValue="vehiculos">
        <TabsList>
          <TabsTrigger value="vehiculos">Vehículos</TabsTrigger>
          <TabsTrigger value="oportunidades">Oportunidades {opportunities.length > 0 && `(${opportunities.length})`}</TabsTrigger>
          <TabsTrigger value="alertas">Alertas {unread > 0 && <Badge variant="destructive" className="ml-1 text-[10px]">{unread}</Badge>}</TabsTrigger>
        </TabsList>

        <TabsContent value="vehiculos">
          {loading ? <div className="text-muted-foreground text-sm">Cargando…</div> : cards.length === 0 ? (
            <Card className="p-8 text-center text-muted-foreground">
              <CarIcon className="w-10 h-10 mx-auto mb-3 opacity-40" />
              <p>Todavía no hay análisis. Abrí un auto y tocá <b>Analizar mercado</b>.</p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {cards.map((a: any) => {
                const car = cars[a.car_id];
                const cur = a.summary?.currency || car?.moneda || "ARS";
                const cheap = a.diff_pct <= -5;
                const expensive = a.diff_pct >= 10;
                return (
                  <Link to={`/autos/${a.car_id}`} key={a.id}>
                    <Card className="p-4 space-y-2 hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="font-semibold truncate">{car?.marca} {car?.modelo}</div>
                          <div className="text-xs text-muted-foreground truncate">{car?.version || ''} · {car?.anio}</div>
                        </div>
                        <Badge variant={cheap ? "default" : expensive ? "destructive" : "secondary"} className="shrink-0">
                          {a.diff_pct > 0 ? '+' : ''}{a.diff_pct}%
                        </Badge>
                      </div>
                      <div className="grid grid-cols-3 gap-1 text-xs">
                        <div><div className="text-muted-foreground">Min</div><div className="font-medium">{cur} {Math.round(a.price_min).toLocaleString()}</div></div>
                        <div><div className="text-muted-foreground">Prom</div><div className="font-medium">{cur} {Math.round(a.price_avg).toLocaleString()}</div></div>
                        <div><div className="text-muted-foreground">Max</div><div className="font-medium">{cur} {Math.round(a.price_max).toLocaleString()}</div></div>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Mi precio: <b>{cur} {Math.round(a.my_price).toLocaleString()}</b> · Posición {a.my_position}/{a.total_results}
                      </div>
                      <div className="text-xs">{a.competitiveness}</div>
                      <div className="text-xs text-muted-foreground line-clamp-3">{a.recommendation}</div>
                      <div className="text-[10px] text-muted-foreground">{new Date(a.created_at).toLocaleString()}</div>
                    </Card>
                  </Link>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="oportunidades">
          {opportunities.length === 0 ? (
            <Card className="p-8 text-center text-muted-foreground">
              <CheckCircle2 className="w-10 h-10 mx-auto mb-3 opacity-40" />
              <p>No se detectaron oportunidades para revisar.</p>
            </Card>
          ) : (
            <div className="space-y-2">
              {opportunities.map((a: any) => {
                const car = cars[a.car_id];
                const cur = a.summary?.currency || "ARS";
                return (
                  <Link to={`/autos/${a.car_id}`} key={a.id}>
                    <Card className="p-3 flex items-center gap-3 hover:shadow-md">
                      {a.diff_pct > 10 ? <TrendingUp className="w-5 h-5 text-amber-600" /> : <TrendingDown className="w-5 h-5 text-blue-600" />}
                      <div className="flex-1 min-w-0">
                        <div className="font-medium truncate">{car?.marca} {car?.modelo} {car?.anio}</div>
                        <div className="text-xs text-muted-foreground">
                          {a.diff_pct > 10 ? `Sobrevaluado ${a.diff_pct}% vs promedio.` : `Fuera del top: posición ${a.my_position}/${a.total_results}.`}
                          {' '}Sugerido: {cur} {Math.round(a.price_recommended).toLocaleString()}.
                        </div>
                      </div>
                      <Badge variant="outline">{cur} {Math.round(a.my_price).toLocaleString()}</Badge>
                    </Card>
                  </Link>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="alertas">
          {alerts.length === 0 ? (
            <Card className="p-8 text-center text-muted-foreground">
              <Bell className="w-10 h-10 mx-auto mb-3 opacity-40" />
              <p>No hay alertas todavía. Se generan al correr un análisis de mercado.</p>
            </Card>
          ) : (
            <div className="space-y-2">
              {alerts.map(al => (
                <Card key={al.id} className={`p-3 border ${SEV_COLOR[al.severity] || ''} ${al.read ? 'opacity-60' : ''}`}>
                  <div className="flex items-start gap-3">
                    {al.severity === 'warning' ? <AlertTriangle className="w-5 h-5 shrink-0" /> : al.severity === 'success' ? <CheckCircle2 className="w-5 h-5 shrink-0" /> : <Bell className="w-5 h-5 shrink-0" />}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <div className="font-medium">{al.title}</div>
                        <div className="text-[10px] text-muted-foreground shrink-0">{new Date(al.created_at).toLocaleString()}</div>
                      </div>
                      <div className="text-sm">{al.message}</div>
                      {al.data?.item?.permalink && (
                        <a href={al.data.item.permalink} target="_blank" rel="noreferrer" className="text-xs inline-flex items-center gap-1 text-primary mt-1">
                          Ver publicación <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                      <div className="flex items-center gap-2 mt-1">
                        {al.car_id && <Link to={`/autos/${al.car_id}`} className="text-xs text-primary">Ver auto</Link>}
                        {!al.read && <button onClick={() => markRead(al.id)} className="text-xs text-muted-foreground hover:text-foreground">Marcar como leída</button>}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
