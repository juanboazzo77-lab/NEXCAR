import { useMemo } from "react";
import { useSales, useCars, useExpenses } from "@/hooks/use-data";
import { formatCurrency, getSaleMargin } from "@/lib/supabase-helpers";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ShoppingCart, DollarSign, TrendingDown, TrendingUp, Trophy } from "lucide-react";

export default function EstadisticasPage() {
  const { data: sales = [] } = useSales();
  const { data: cars = [] } = useCars();
  const { data: expenses = [] } = useExpenses();

  const totalComprado = cars.reduce((s, c) => s + Number(c.precio_compra), 0);
  const totalVendido = sales.reduce((s, s2) => s + Number(s2.monto), 0);
  const totalGastos = expenses.reduce((s, e) => s + Number(e.monto), 0);
  const margenTotal = totalVendido - totalComprado - totalGastos;

  // Ganancia = monto de venta - precio de compra - gastos del auto
  // Si hubo parte de pago, ese auto recibido genera su propia venta luego (con su precio_compra = valor toma)
  const getMargen = (s: typeof sales[number]) => {
    const car = cars.find(c => c.id === s.car_id);
    const gastosAuto = s.car_id
      ? expenses.filter((e: any) => e.car_id === s.car_id).reduce((sum: number, e: any) => sum + Number(e.monto ?? 0), 0)
      : 0;
    return getSaleMargin({ sale: s, car, expensesTotal: gastosAuto });
  };
  const gananciaAutos = sales.reduce((s, sale) => s + getMargen(sale), 0);

  const ventasPorMes = useMemo(() => {
    const map: Record<string, { count: number; total: number; ganancia: number }> = {};
    sales.forEach(s => {
      const key = s.fecha.substring(0, 7);
      if (!map[key]) map[key] = { count: 0, total: 0, ganancia: 0 };
      map[key].count++;
      map[key].total += Number(s.monto);
      map[key].ganancia += getMargen(s);
    });
    return Object.entries(map).sort((a, b) => b[0].localeCompare(a[0]));
  }, [sales, cars]);

  const rankingVendedores = useMemo(() => {
    const map: Record<string, { count: number; total: number }> = {};
    sales.forEach(s => {
      const v = s.vendedor || "Sin asignar";
      if (!map[v]) map[v] = { count: 0, total: 0 };
      map[v].count++;
      map[v].total += Number(s.monto);
    });
    return Object.entries(map).sort((a, b) => b[1].total - a[1].total);
  }, [sales]);

  return (
    <div className="space-y-4">
      <h1 className="page-header">Estadísticas</h1>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="stat-card"><CardContent className="p-0">
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1"><ShoppingCart className="w-3.5 h-3.5" />Total comprado</div>
          <div className="text-xl font-bold">{formatCurrency(totalComprado)}</div>
        </CardContent></Card>
        <Card className="stat-card"><CardContent className="p-0">
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1"><DollarSign className="w-3.5 h-3.5" />Total vendido</div>
          <div className="text-xl font-bold text-success">{formatCurrency(totalVendido)}</div>
        </CardContent></Card>
        <Card className="stat-card"><CardContent className="p-0">
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1"><TrendingDown className="w-3.5 h-3.5" />Total gastos</div>
          <div className="text-xl font-bold text-destructive">{formatCurrency(totalGastos)}</div>
        </CardContent></Card>
        <Card className="stat-card"><CardContent className="p-0">
          <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1"><TrendingUp className="w-3.5 h-3.5" />Margen general</div>
          <div className={`text-xl font-bold ${margenTotal >= 0 ? "text-success" : "text-destructive"}`}>{formatCurrency(margenTotal)}</div>
        </CardContent></Card>
      </div>

      <Card className="stat-card"><CardContent className="p-0">
        <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1"><TrendingUp className="w-3.5 h-3.5" />Ganancia en autos (venta − compra − parte de pago)</div>
        <div className={`text-2xl font-bold ${gananciaAutos >= 0 ? "text-success" : "text-destructive"}`}>{formatCurrency(gananciaAutos)}</div>
      </CardContent></Card>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-sm">Ventas y ganancia por mes</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {ventasPorMes.map(([month, data]) => (
              <div key={month} className="flex items-center justify-between text-sm">
                <span className="capitalize">{new Date(month + "-01").toLocaleDateString("es-AR", { month: "long", year: "numeric" })}</span>
                <div className="text-right">
                  <div className="font-medium">{formatCurrency(data.total)} <span className="text-muted-foreground text-xs">({data.count})</span></div>
                  <div className={`text-xs font-semibold ${data.ganancia >= 0 ? "text-success" : "text-destructive"}`}>Gan: {formatCurrency(data.ganancia)}</div>
                </div>
              </div>
            ))}
            {ventasPorMes.length === 0 && <p className="text-muted-foreground text-sm">Sin ventas</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Trophy className="w-4 h-4" />Ranking vendedores</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {rankingVendedores.map(([name, data], i) => (
              <div key={name} className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-primary/10 text-primary text-xs flex items-center justify-center font-medium">{i + 1}</span>
                  {name}
                </span>
                <div className="text-right">
                  <span className="font-medium">{formatCurrency(data.total)}</span>
                  <span className="text-muted-foreground ml-2 text-xs">({data.count})</span>
                </div>
              </div>
            ))}
            {rankingVendedores.length === 0 && <p className="text-muted-foreground text-sm">Sin datos</p>}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
