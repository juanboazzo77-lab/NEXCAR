import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  CHANNELS, Channel, statusMeta, toneClass, overallLabel,
  DEFAULT_TEMPLATES, buildVars, renderTemplate,
} from "@/lib/publicaciones";
import { formatMoney } from "@/lib/supabase-helpers";
import { ArrowLeft, ExternalLink, RefreshCw, Rocket, Sparkles, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

const TEXT_FIELD: Record<string, string> = {
  mercadolibre: "ml_text", facebook: "fb_text", instagram: "ig_text",
};

export default function VehiculoDetallePage() {
  const { id = "" } = useParams();
  const qc = useQueryClient();
  const [selected, setSelected] = useState<Channel[]>(["website", "mercadolibre", "facebook", "instagram"]);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [progressOpen, setProgressOpen] = useState(false);
  const [running, setRunning] = useState<Channel[]>([]);
  const [texts, setTexts] = useState<Record<string, string>>({});
  const [listingTypeId, setListingTypeId] = useState("");

  const { data: car } = useQuery({
    queryKey: ["vehiculo", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("cars").select("*").eq("id", id).maybeSingle();
      if (error) throw error;
      return data as any;
    },
  });

  const { data: photos = [] } = useQuery({
    queryKey: ["vehiculo-fotos", id],
    queryFn: async () => {
      const { data } = await supabase.from("car_photos").select("*").eq("car_id", id)
        .order("es_portada", { ascending: false }).order("orden");
      return data ?? [];
    },
  });

  const { data: pubs = [] } = useQuery({
    queryKey: ["vehiculo-pubs", id],
    queryFn: async () => {
      const { data } = await (supabase as any).from("channel_publications").select("*").eq("car_id", id);
      return data ?? [];
    },
  });

  const { data: jobs = [] } = useQuery({
    queryKey: ["vehiculo-jobs", id],
    queryFn: async () => {
      const { data } = await (supabase as any).from("publication_jobs").select("*").eq("car_id", id)
        .order("created_at", { ascending: false }).limit(60);
      return data ?? [];
    },
  });

  const { data: accounts = [] } = useQuery({
    queryKey: ["cuentas-conectadas"],
    queryFn: async () => {
      const { data } = await supabase.from("connected_accounts").select("*").eq("status", "conectado");
      return data ?? [];
    },
  });

  const mlAccount = (accounts as any[]).find((account) => account.platform === "mercadolibre");
  const { data: listingTypes = [], isFetching: loadingListingTypes } = useQuery({
    queryKey: ["ml-listing-types", mlAccount?.id],
    enabled: Boolean(mlAccount?.id),
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke("ml-listing-types", { body: { account_id: mlAccount.id } });
      if (error) throw error;
      return (data?.listing_types || []) as Array<{ listing_type_id: string; name: string; available_quantity: number | null; active: boolean }>;
    },
  });

  useEffect(() => {
    if (!listingTypeId && listingTypes.length > 0) setListingTypeId(listingTypes.find((type) => type.active)?.listing_type_id || listingTypes[0].listing_type_id);
  }, [listingTypeId, listingTypes]);

  // Realtime: actualiza estados sin recargar
  useEffect(() => {
    if (!id) return;
    const channel = supabase
      .channel(`pub-jobs-${id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "publication_jobs", filter: `car_id=eq.${id}` }, () => {
        qc.invalidateQueries({ queryKey: ["vehiculo-jobs", id] });
        qc.invalidateQueries({ queryKey: ["vehiculo-pubs", id] });
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [id, qc]);

  useEffect(() => {
    if (car) setTexts({
      ml_text: car.ml_text ?? "", fb_text: car.fb_text ?? "", ig_text: car.ig_text ?? "",
    });
  }, [car]);

  if (!car) return <p className="text-sm text-muted-foreground">Cargando vehículo...</p>;

  const accountFor = (platform: string) => (accounts as any[]).find((a) => a.platform === platform);
  const isConnected = (ch: Channel) =>
    ch === "website" ? true : !!accountFor(ch === "mercadolibre" ? "mercadolibre" : ch);
  const pubOf = (ch: Channel) => (pubs as any[]).find((p) => p.channel === ch);
  const lastJob = (ch: Channel) => (jobs as any[]).find((j) => j.channel === ch);
  const channelStatus = (ch: Channel) => {
    if (!isConnected(ch)) return "no_conectado";
    if (running.includes(ch)) return "publicando";
    return lastJob(ch)?.status ?? pubOf(ch)?.status ?? "no_publicado";
  };
  const cover = (photos as any[])[0]?.url;

  const generarTextos = () => {
    const vars = buildVars(car);
    const next = { ...texts };
    const faltantes = new Set<string>();
    (["mercadolibre", "facebook", "instagram"] as const).forEach((ch) => {
      const { text, missing } = renderTemplate(DEFAULT_TEMPLATES[ch], vars);
      next[TEXT_FIELD[ch]] = text;
      missing.forEach((m) => faltantes.add(m));
    });
    setTexts(next);
    toast.success("Textos generados desde los datos cargados. Revisalos antes de publicar.");
    if (faltantes.size) toast.warning(`Variables sin dato: ${[...faltantes].join(", ")}`);
  };

  const guardarTextos = async () => {
    const { error } = await supabase.from("cars").update(texts as any).eq("id", id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["vehiculo", id] });
    toast.success("Textos guardados");
  };

  const commonOpts = () => ({
    titulo: `${car.marca} ${car.modelo} ${car.version ?? ""} ${car.anio}`.trim(),
    ml_text: texts.ml_text, fb_text: texts.fb_text, ig_text: texts.ig_text,
    ml_account_id: accountFor("mercadolibre")?.id,
    listing_type_id: listingTypeId || undefined,
    fb_account_id: accountFor("facebook")?.id,
    ig_account_id: accountFor("instagram")?.id,
  });

  const publicarTodo = async () => {
    setConfirmOpen(false);
    setProgressOpen(true);
    setRunning(selected);
    const { data, error } = await supabase.functions.invoke("process-publication-batch", {
      body: { car_id: id, channels: selected, ...commonOpts() },
    });
    setRunning([]);
    qc.invalidateQueries({ queryKey: ["vehiculo-jobs", id] });
    qc.invalidateQueries({ queryKey: ["vehiculo-pubs", id] });
    if (error) return toast.error("No se pudo iniciar la publicación");
    toast.success(overallLabel((data as any)?.overall_status));
  };

  const reintentar = async (ch: Channel) => {
    if (running.includes(ch)) return;
    setRunning((r) => [...r, ch]);
    const job = lastJob(ch);
    const { error } = await supabase.functions.invoke("retry-publication-job", {
      body: { job_id: job?.id, car_id: id, channel: ch, ...commonOpts() },
    });
    setRunning((r) => r.filter((c) => c !== ch));
    qc.invalidateQueries({ queryKey: ["vehiculo-jobs", id] });
    qc.invalidateQueries({ queryKey: ["vehiculo-pubs", id] });
    if (error) toast.error("No se pudo reintentar");
    else toast.success("Reintento finalizado");
  };

  const pausar = async (ch: Channel, estado: "pausado" | "finalizado") => {
    const p = pubOf(ch);
    if (!p) return;
    await (supabase as any).from("channel_publications").update({ status: estado }).eq("id", p.id);
    qc.invalidateQueries({ queryKey: ["vehiculo-pubs", id] });
  };

  const conErrores = CHANNELS.filter((c) => statusMeta(channelStatus(c.id)).tone === "error");

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" asChild><Link to="/vehiculos"><ArrowLeft className="w-4 h-4" /></Link></Button>
          <div>
            <h1 className="text-xl font-semibold">{car.marca} {car.modelo} {car.version ?? ""}</h1>
            <p className="text-sm text-muted-foreground">
              {car.anio} · {car.patente} · {car.precio_venta ? formatMoney(Number(car.precio_venta), car.moneda) : "sin precio"}
            </p>
          </div>
        </div>
        <Button onClick={() => setConfirmOpen(true)} disabled={running.length > 0}>
          <Rocket className="w-4 h-4 mr-2" /> Publicar en todos lados
        </Button>
      </div>

      <Tabs defaultValue="canales">
        <TabsList>
          <TabsTrigger value="canales">Centro de publicaciones</TabsTrigger>
          <TabsTrigger value="textos">Textos</TabsTrigger>
          <TabsTrigger value="historial">Historial</TabsTrigger>
        </TabsList>

        <TabsContent value="canales" className="space-y-3 pt-4">
          {conErrores.length > 0 && (
            <Card className="p-3 flex items-center justify-between gap-3 border-destructive/40 bg-destructive/5">
              <span className="text-sm flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-destructive" />
                {conErrores.length} canal(es) con errores.</span>
              <Button size="sm" variant="outline" onClick={() => conErrores.forEach((c) => reintentar(c.id))}>
                Reintentar todos los errores
              </Button>
            </Card>
          )}
          <div className="grid gap-3 md:grid-cols-2">
            {CHANNELS.map((ch) => {
              const st = channelStatus(ch.id);
              const m = statusMeta(st);
              const pub = pubOf(ch.id);
              const job = lastJob(ch.id);
              const busy = running.includes(ch.id);
              return (
                <Card key={ch.id} className="p-4 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-medium">{ch.label}</p>
                    <span className={cn("text-xs px-2 py-1 rounded border", toneClass(m.tone))}>{m.icon} {m.label}</span>
                  </div>
                  {!isConnected(ch.id) && (
                    <p className="text-xs text-muted-foreground">
                      Integración pendiente de configuración.{" "}
                      <Link to="/canales" className="underline">Conectar cuenta</Link>
                    </p>
                  )}
                  {pub?.published_at && (
                    <p className="text-xs text-muted-foreground">
                      Publicado el {new Date(pub.published_at).toLocaleString("es-AR")}
                    </p>
                  )}
                  {job?.error_message && (
                    <div className="text-xs space-y-1">
                      <p className="text-destructive">{job.error_message}</p>
                      <details className="text-muted-foreground">
                        <summary className="cursor-pointer">Información técnica</summary>
                        <pre className="whitespace-pre-wrap break-all mt-1 text-[10px]">
{`Plataforma: ${ch.label}
Fecha: ${new Date(job.created_at).toLocaleString("es-AR")}
Etapa: ${job.action}
Código: ${job.error_code ?? "—"}
Intentos: ${job.attempt_number}
Respuesta: ${job.technical_error ?? "—"}`}
                        </pre>
                      </details>
                    </div>
                  )}
                  <div className="flex flex-wrap gap-2">
                    {pub?.external_url && (
                      <Button size="sm" variant="outline" asChild>
                        <a href={pub.external_url} target="_blank" rel="noreferrer">
                          <ExternalLink className="w-3.5 h-3.5 mr-1" /> Ver
                        </a>
                      </Button>
                    )}
                    <Button size="sm" variant="outline" disabled={busy || !isConnected(ch.id)} onClick={() => reintentar(ch.id)}>
                      <RefreshCw className={cn("w-3.5 h-3.5 mr-1", busy && "animate-spin")} />
                      {pub?.external_publication_id ? "Actualizar" : "Publicar"}
                    </Button>
                    {m.tone === "error" && (
                      <Button size="sm" variant="secondary" disabled={busy} onClick={() => reintentar(ch.id)}>
                        Reintentar {ch.short}
                      </Button>
                    )}
                    {ch.id === "mercadolibre" && pub && (
                      <>
                        <Button size="sm" variant="ghost" onClick={() => pausar(ch.id, "pausado")}>Pausar</Button>
                        <Button size="sm" variant="ghost" onClick={() => pausar(ch.id, "finalizado")}>Finalizar</Button>
                      </>
                    )}
                    {ch.id === "website" && pub && (
                      <Button size="sm" variant="ghost" onClick={async () => {
                        await supabase.from("cars").update({ mostrar_publico: false }).eq("id", id);
                        await pausar(ch.id, "pausado");
                      }}>Ocultar</Button>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="textos" className="space-y-4 pt-4">
          <div className="flex gap-2">
            <Button variant="outline" onClick={generarTextos}><Sparkles className="w-4 h-4 mr-2" />Generar textos</Button>
            <Button onClick={guardarTextos}>Guardar textos</Button>
          </div>
          {(["mercadolibre", "facebook", "instagram"] as const).map((ch) => (
            <div key={ch} className="space-y-1">
              <label className="text-sm font-medium">
                Texto para {CHANNELS.find((c) => c.id === ch)!.label}
              </label>
              <Textarea rows={8} value={texts[TEXT_FIELD[ch]] ?? ""}
                onChange={(e) => setTexts((t) => ({ ...t, [TEXT_FIELD[ch]]: e.target.value }))} />
            </div>
          ))}
        </TabsContent>

        <TabsContent value="historial" className="pt-4">
          <Card className="divide-y">
            {(jobs as any[]).length === 0 && <p className="p-4 text-sm text-muted-foreground">Sin operaciones todavía.</p>}
            {(jobs as any[]).map((j) => {
              const m = statusMeta(j.status);
              return (
                <div key={j.id} className="p-3 text-sm flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="font-medium">{CHANNELS.find((c) => c.id === j.channel)?.label ?? j.channel} · {j.action}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(j.created_at).toLocaleString("es-AR")} · intento {j.attempt_number}
                      {j.error_message ? ` · ${j.error_message}` : ""}
                    </p>
                  </div>
                  <span className={cn("text-xs px-2 py-1 rounded border", toneClass(m.tone))}>{m.label}</span>
                </div>
              );
            })}
          </Card>
        </TabsContent>
      </Tabs>

      {/* Confirmación con vista previa */}
      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Revisá antes de publicar</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="flex gap-3">
              {cover && <img src={cover} alt="Foto principal" className="w-32 h-24 object-cover rounded" />}
              <div>
                <p className="font-medium">{car.marca} {car.modelo} {car.version ?? ""} {car.anio}</p>
                <p className="text-sm text-muted-foreground">
                  {car.precio_venta ? formatMoney(Number(car.precio_venta), car.moneda) : "sin precio"}
                </p>
              </div>
            </div>
            <div className="space-y-2">
              {CHANNELS.map((ch) => (
                <label key={ch.id} className="flex items-center gap-2 text-sm">
                  <Checkbox checked={selected.includes(ch.id)} disabled={!isConnected(ch.id)}
                    onCheckedChange={(v) => setSelected((s) => v ? [...s, ch.id] : s.filter((c) => c !== ch.id))} />
                  {ch.label}
                  {!isConnected(ch.id) && <span className="text-xs text-muted-foreground">(integración pendiente de configuración)</span>}
                </label>
              ))}
            </div>
            {selected.includes("mercadolibre") && isConnected("mercadolibre") && (
              <div className="space-y-2">
                <Label>Tipo de publicación de Mercado Libre</Label>
                <Select value={listingTypeId} onValueChange={setListingTypeId} disabled={loadingListingTypes || listingTypes.length === 0}>
                  <SelectTrigger><SelectValue placeholder={loadingListingTypes ? "Consultando tu cuenta…" : "Elegí Silver, Gold u otro plan"} /></SelectTrigger>
                  <SelectContent>
                    {listingTypes.map((type) => (
                      <SelectItem key={type.listing_type_id} value={type.listing_type_id} disabled={!type.active}>
                        {type.name}{type.available_quantity != null ? ` · ${type.available_quantity} disponibles` : ""}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {!loadingListingTypes && listingTypes.length === 0 && (
                  <p className="text-xs text-destructive">La cuenta no informó tipos de publicación disponibles. Reconectala desde Conexiones.</p>
                )}
              </div>
            )}
            {(["mercadolibre", "facebook", "instagram"] as const).filter((c) => selected.includes(c)).map((ch) => (
              <div key={ch}>
                <p className="text-xs font-medium mb-1">Vista previa {CHANNELS.find((c) => c.id === ch)!.label}</p>
                <pre className="text-xs bg-muted p-2 rounded whitespace-pre-wrap max-h-40 overflow-y-auto">
                  {texts[TEXT_FIELD[ch]] || "Sin texto cargado"}
                </pre>
              </div>
            ))}
          </div>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setConfirmOpen(false)}>Cancelar</Button>
            <Button variant="outline" onClick={() => setConfirmOpen(false)}>Revisar información</Button>
            <Button onClick={publicarTodo} disabled={selected.length === 0}>Publicar ahora</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Progreso */}
      <Dialog open={progressOpen} onOpenChange={setProgressOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Publicación del vehículo</DialogTitle></DialogHeader>
          <div className="space-y-2">
            {selected.map((ch) => {
              const m = statusMeta(channelStatus(ch));
              return (
                <div key={ch} className="flex items-center justify-between text-sm">
                  <span>{CHANNELS.find((c) => c.id === ch)!.label}</span>
                  <span className={cn("text-xs px-2 py-1 rounded border", toneClass(m.tone))}>{m.icon} {m.label}</span>
                </div>
              );
            })}
          </div>
          <DialogFooter className="gap-2">
            {conErrores.length > 0 && running.length === 0 && (
              <Button variant="outline" onClick={() => conErrores.forEach((c) => reintentar(c.id))}>Reintentar errores</Button>
            )}
            <Button onClick={() => setProgressOpen(false)} disabled={running.length > 0}>Cerrar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
