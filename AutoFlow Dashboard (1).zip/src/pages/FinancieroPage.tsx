import { useMemo, useState } from "react";
import { useSales, useCars, useExpenses } from "@/hooks/use-data";
import { formatCurrency, getSaleMargin } from "@/lib/supabase-helpers";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DollarSign, TrendingDown, TrendingUp, Users, Receipt, Wallet, Target, BarChart3 } from "lucide-react";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, Legend,
  BarChart, Bar, PieChart, Pie, Cell,
} from "recharts";

const MONTHS_SHORT = ["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"];
const PIE_COLORS = ["hsl(var(--primary))", "hsl(var(--chart-2, 173 58% 39%))", "hsl(var(--chart-3, 197 37% 24%))", "hsl(var(--chart-4, 43 74% 66%))", "hsl(var(--chart-5, 27 87% 67%))", "hsl(var(--destructive))", "hsl(var(--muted-foreground))"];

export default function FinancieroPage() {
  const { data: sales = [] } = useSales();
  const { data: cars = [] } = useCars();
  const { data: expenses = [] } = useExpenses();

  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());

  const years = useMemo(() => {
    const set = new Set<number>([now.getFullYear()]);
    sales.forEach(s => s.fecha && set.add(Number(s.fecha.slice(0, 4))));
    expenses.forEach(e => e.fecha && set.add(Number(e.fecha.slice(0, 4))));
    return Array.from(set).sort((a, b) => b - a);
  }, [sales, expenses]);

  const getMargen = (s: typeof sales[number]) => {
    const car = cars.find(c => c.id === s.car_id);
    const gastosAuto = s.car_id
      ? expenses.filter(e => e.car_id === s.car_id).reduce((sum, e) => sum + Number(e.monto ?? 0), 0)
      : 0;
    return getSaleMargin({ sale: s, car, expensesTotal: gastosAuto });
  };

  // Filter to selected year
  const salesYear = useMemo(() => sales.filter(s => s.fecha?.startsWith(String(year))), [sales, year]);
  const expensesYear = useMemo(() => expenses.filter(e => e.fecha?.startsWith(String(year))), [expenses, year]);

  // Current month
  const monthKey = `${year}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const salesMonth = useMemo(() => sales.filter(s => s.fecha?.startsWith(monthKey)), [sales, monthKey]);
  const expensesMonth = useMemo(() => expenses.filter(e => e.fecha?.startsWith(monthKey)), [expenses, monthKey]);

  // KPIs
  const facturacionMensual = salesMonth.reduce((s, x) => s + Number(x.monto ?? 0), 0);
  const facturacionAnual = salesYear.reduce((s, x) => s + Number(x.monto ?? 0), 0);
  const gastosMes = expensesMonth.reduce((s, x) => s + Number(x.monto ?? 0), 0);
  const gastosAnio = expensesYear.reduce((s, x) => s + Number(x.monto ?? 0), 0);
  const gananciaAnual = salesYear.reduce((s, x) => s + getMargen(x), 0);
  const gananciaMes = salesMonth.reduce((s, x) => s + getMargen(x), 0);
  const margenPct = facturacionAnual > 0 ? (gananciaAnual / facturacionAnual) * 100 : 0;

  // Active clients = unique vendedores/clientes con venta en el año
  const clientesActivos = useMemo(() => {
    const set = new Set<string>();
    salesYear.forEach(s => {
      const c = (s.vendedor ?? "").trim();
      if (c) set.add(c.toLowerCase());
    });
    return set.size;
  }, [salesYear]);

  const ticketPromedio = salesYear.length > 0 ? facturacionAnual / salesYear.length : 0;

  // Evolución mensual del año seleccionado
  const evolucion = useMemo(() => {
    const m = Array.from({ length: 12 }, (_, i) => ({
      mes: MONTHS_SHORT[i],
      facturacion: 0,
      ganancia: 0,
      gastos: 0,
    }));
    salesYear.forEach(s => {
      const i = Number(s.fecha.slice(5, 7)) - 1;
      if (i >= 0 && i < 12) {
        m[i].facturacion += Number(s.monto ?? 0);
        m[i].ganancia += getMargen(s);
      }
    });
    expensesYear.forEach(e => {
      const i = Number(e.fecha.slice(5, 7)) - 1;
      if (i >= 0 && i < 12) m[i].gastos += Number(e.monto ?? 0);
    });
    return m;
  }, [salesYear, expensesYear, cars, expenses]);

  // Clientes por categoría (segmentación por ticket)
  const clientesPorCategoria = useMemo(() => {
    const buckets = { Premium: 0, Medio: 0, Básico: 0 };
    const totals: Record<string, number> = {};
    salesYear.forEach(s => {
      const k = (s.vendedor ?? "Sin asignar").trim() || "Sin asignar";
      totals[k] = (totals[k] ?? 0) + Number(s.monto ?? 0);
    });
    Object.values(totals).forEach(v => {
      if (v >= 30_000_000) buckets.Premium++;
      else if (v >= 10_000_000) buckets.Medio++;
      else buckets.Básico++;
    });
    return Object.entries(buckets).map(([name, value]) => ({ name, value }));
  }, [salesYear]);

  // "Servicios más vendidos" = top marca/modelo
  const topModelos = useMemo(() => {
    const map: Record<string, { count: number; total: number }> = {};
    salesYear.forEach(s => {
      const car = cars.find(c => c.id === s.car_id);
      const k = car ? `${car.marca ?? ""} ${car.modelo ?? ""}`.trim() : (s.marca_modelo ?? "Sin datos");
      const key = k || "Sin datos";
      if (!map[key]) map[key] = { count: 0, total: 0 };
      map[key].count++;
      map[key].total += Number(s.monto ?? 0);
    });
    return Object.entries(map)
      .map(([name, v]) => ({ name, ventas: v.count, total: v.total }))
      .sort((a, b) => b.ventas - a.ventas)
      .slice(0, 7);
  }, [salesYear, cars]);

  const tooltipFmt = (v: any) => formatCurrency(Number(v));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-semibold flex items-center gap-2"><BarChart3 className="w-6 h-6" /> Centro Financiero</h1>
          <p className="text-sm text-muted-foreground">Panel automático con métricas y evolución del negocio.</p>
        </div>
        <Select value={String(year)} onValueChange={v => setYear(Number(v))}>
          <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
          <SelectContent>
            {years.map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Kpi icon={<DollarSign className="w-3.5 h-3.5" />} label="Facturación mensual" value={formatCurrency(facturacionMensual)} sub={`${salesMonth.length} ventas`} />
        <Kpi icon={<Wallet className="w-3.5 h-3.5" />} label="Facturación anual" value={formatCurrency(facturacionAnual)} sub={`${salesYear.length} ventas`} />
        <Kpi icon={<TrendingUp className="w-3.5 h-3.5" />} label="Ganancia estimada" value={formatCurrency(gananciaAnual)} sub={`Mes: ${formatCurrency(gananciaMes)}`} positive={gananciaAnual >= 0} />
        <Kpi icon={<TrendingDown className="w-3.5 h-3.5" />} label="Gastos" value={formatCurrency(gastosAnio)} sub={`Mes: ${formatCurrency(gastosMes)}`} negative />
        <Kpi icon={<Target className="w-3.5 h-3.5" />} label="Margen" value={`${margenPct.toFixed(1)}%`} sub={facturacionAnual > 0 ? "sobre facturación anual" : "sin ventas"} positive={margenPct >= 0} />
        <Kpi icon={<Users className="w-3.5 h-3.5" />} label="Clientes activos" value={String(clientesActivos)} sub="en el año seleccionado" />
        <Kpi icon={<Receipt className="w-3.5 h-3.5" />} label="Ticket promedio" value={formatCurrency(ticketPromedio)} sub="por venta" />
        <Kpi icon={<TrendingUp className="w-3.5 h-3.5" />} label="Resultado neto" value={formatCurrency(gananciaAnual - gastosAnio + expensesYear.filter(e => cars.find(c => c.id === e.car_id)).reduce((s, e) => s + Number(e.monto ?? 0), 0))} sub="ganancia − gastos generales" positive={(gananciaAnual - gastosAnio) >= 0} />
      </div>

      {/* Evolución mensual */}
      <Card>
        <CardHeader><CardTitle className="text-sm">Evolución mensual {year}</CardTitle></CardHeader>
        <CardContent>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={evolucion} margin={{ top: 8, right: 16, bottom: 0, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="mes" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickFormatter={(v) => `${(v / 1_000_000).toFixed(1)}M`} />
                <Tooltip formatter={tooltipFmt} contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Line type="monotone" dataKey="facturacion" name="Facturación" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="ganancia" name="Ganancia" stroke="hsl(142 76% 36%)" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="gastos" name="Gastos" stroke="hsl(var(--destructive))" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-4">
        {/* Clientes por categoría */}
        <Card>
          <CardHeader><CardTitle className="text-sm">Clientes por categoría</CardTitle></CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={clientesPorCategoria} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={(e) => `${e.name}: ${e.value}`}>
                    {clientesPorCategoria.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <p className="text-[11px] text-muted-foreground mt-2 text-center">
              Premium ≥ $30M · Medio ≥ $10M · Básico &lt; $10M (acumulado anual por cliente)
            </p>
          </CardContent>
        </Card>

        {/* Top modelos */}
        <Card>
          <CardHeader><CardTitle className="text-sm">Modelos más vendidos</CardTitle></CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topModelos} layout="vertical" margin={{ top: 8, right: 16, bottom: 0, left: 8 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis type="category" dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={11} width={120} />
                  <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                  <Bar dataKey="ventas" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Kpi({ icon, label, value, sub, positive, negative }: { icon: React.ReactNode; label: string; value: string; sub?: string; positive?: boolean; negative?: boolean }) {
  return (
    <Card className="stat-card"><CardContent className="p-0">
      <div className="flex items-center gap-2 text-muted-foreground text-xs mb-1">{icon}{label}</div>
      <div className={`text-xl font-bold ${positive ? "text-success" : negative ? "text-destructive" : ""}`}>{value}</div>
      {sub && <div className="text-[11px] text-muted-foreground mt-0.5">{sub}</div>}
    </CardContent></Card>
  );
}
