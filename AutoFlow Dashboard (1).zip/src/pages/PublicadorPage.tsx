import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCars } from "@/hooks/use-data";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { Upload, Trash2, Sparkles, Share2, Facebook, Instagram, MessageCircle, ShoppingCart, AlertTriangle, Link2, CheckCircle2 } from "lucide-react";
import { formatCurrency } from "@/lib/supabase-helpers";

type Photo = { id: string; url: string; storage_path: string | null; orden: number; es_portada: boolean };
type Account = { id: string; platform: string; account_name: string | null; status: string };

const PLATFORMS = [
  { id: "mercadolibre", name: "Mercado Libre", icon: ShoppingCart, color: "text-yellow-500" },
  { id: "facebook", name: "Facebook Marketplace", icon: Facebook, color: "text-blue-600" },
  { id: "instagram", name: "Instagram", icon: Instagram, color: "text-pink-500" },
  { id: "whatsapp", name: "WhatsApp Business", icon: MessageCircle, color: "text-green-500" },
];

export default function PublicadorPage() {
  const { user } = useAuth();
  const { data: cars = [] } = useCars();
  const { toast } = useToast();
  const stockCars = cars.filter(c => c.estado !== "Vendido");

  const [carId, setCarId] = useState<string>("");
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [descripcion, setDescripcion] = useState("");
  const [precio, setPrecio] = useState<number>(0);
  const [combustible, setCombustible] = useState<string>("Nafta");
  const [transmision, setTransmision] = useState<string>("Manual");
  const [puertas, setPuertas] = useState<number>(5);
  const [condicion, setCondicion] = useState<string>("Usado");
  const [ubicacion, setUbicacion] = useState<string>("");
  const [loadingAI, setLoadingAI] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [publishingAll, setPublishingAll] = useState(false);

  const car = useMemo(() => stockCars.find(c => c.id === carId), [stockCars, carId]);

  useEffect(() => {
    if (!user) return;
    supabase.from("connected_accounts").select("*").eq("user_id", user.id).then(({ data }) => setAccounts(data || []));
  }, [user]);

  useEffect(() => {
    if (!carId) { setPhotos([]); return; }
    supabase.from("car_photos").select("*").eq("car_id", carId).order("orden").then(({ data }) => setPhotos(data || []));
    if (car) setPrecio(Number(car.precio_venta) || 0);
  }, [carId, car]);

  const connectedFor = (p: string) => accounts.find(a => a.platform === p);

  const handleUpload = async (files: FileList | null) => {
    if (!files || !carId || !user) return;
    setUploading(true);
    try {
      for (const file of Array.from(files)) {
        const path = `${user.id}/${carId}/${Date.now()}-${file.name}`;
        const { error: upErr } = await supabase.storage.from("car-photos").upload(path, file);
        if (upErr) throw upErr;
        const { data: pub } = supabase.storage.from("car-photos").getPublicUrl(path);
        await supabase.from("car_photos").insert({
          car_id: carId, user_id: user.id, url: pub.publicUrl, storage_path: path,
          orden: photos.length, es_portada: photos.length === 0,
        });
      }
      const { data } = await supabase.from("car_photos").select("*").eq("car_id", carId).order("orden");
      setPhotos(data || []);
      toast({ title: "Fotos subidas" });
    } catch (e: any) {
      toast({ title: "Error al subir", description: e.message, variant: "destructive" });
    } finally { setUploading(false); }
  };

  const removePhoto = async (ph: Photo) => {
    if (ph.storage_path) await supabase.storage.from("car-photos").remove([ph.storage_path]);
    await supabase.from("car_photos").delete().eq("id", ph.id);
    setPhotos(photos.filter(p => p.id !== ph.id));
  };

  const generarDescripcion = async () => {
    if (!car) return;
    setLoadingAI(true);
    try {
      const km = (car as any).kilometros ? `${Number((car as any).kilometros).toLocaleString("es-AR")} km` : "kilometraje a consultar";
      const prompt = `Generá una descripción de venta atractiva en español argentino para un auto usado. Datos:
- ${car.marca} ${car.modelo} ${car.version || ""} ${car.anio}
- Color: ${car.color || "a consultar"}
- Kilómetros: ${km}
- Precio: ${formatCurrency(precio)}

Incluí: presentación, características destacadas, estado, llamada a la acción. Máximo 6 líneas, con emojis sutiles. Termina invitando a contactar por WhatsApp.`;

      const res = await fetch(`https://zraasslwthywrrekrkuv.supabase.co/functions/v1/generate-description`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}` },
        body: JSON.stringify({ prompt }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Error IA");
      setDescripcion(json.text || "");
    } catch (e: any) {
      toast({ title: "Error generando descripción", description: e.message, variant: "destructive" });
    } finally { setLoadingAI(false); }
  };

  const conectarML = async () => {
    try {
      const res = await fetch(`https://zraasslwthywrrekrkuv.supabase.co/functions/v1/ml-oauth-start`, {
        headers: { Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token}` },
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Error");
      window.open(json.url, "_blank");
    } catch (e: any) {
      toast({ title: "Falta configurar ML", description: e.message, variant: "destructive" });
    }
  };

  const conectarMeta = async () => {
    if (!user) return;
    try {
      const res = await fetch(`https://zraasslwthywrrekrkuv.supabase.co/functions/v1/meta-oauth-start?uid=${user.id}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Error");
      window.open(json.url, "_blank");
      toast({ title: "Aprobá los permisos en Facebook", description: "Al volver actualizá la página." });
    } catch (e: any) {
      toast({ title: "Falta configurar Meta", description: e.message, variant: "destructive" });
    }
  };

  const desconectar = async (platform: string) => {
    if (!user) return;
    await supabase.from("connected_accounts").delete().eq("user_id", user.id).eq("platform", platform);
    setAccounts(accounts.filter(a => a.platform !== platform));
    toast({ title: "Cuenta desconectada" });
  };

  const publicar = async (platform: string): Promise<{ ok: boolean; url?: string; error?: string }> => {
    if (!car) return { ok: false, error: "Sin auto" };
    const texto = descripcion || `${car.marca} ${car.modelo} ${car.anio} - ${formatCurrency(precio)}`;
    const fotosUrls = photos.map(p => p.url);
    const token = (await supabase.auth.getSession()).data.session?.access_token;

    if (platform === "whatsapp") {
      const msg = encodeURIComponent(`${texto}\n\n${fotosUrls.slice(0, 3).join("\n")}`);
      window.open(`https://wa.me/?text=${msg}`, "_blank");
      return { ok: true };
    }

    if (platform === "mercadolibre") {
      if (!connectedFor("mercadolibre")) return { ok: false, error: "ML no conectado" };
      try {
        const res = await fetch(`https://zraasslwthywrrekrkuv.supabase.co/functions/v1/ml-publish`, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({ car_id: carId, descripcion: texto, precio, fotos: fotosUrls, combustible, transmision, puertas, condicion }),
        });
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || "Error");
        await supabase.from("car_publications").insert({
          user_id: user!.id, car_id: carId, platform, status: "publicado",
          external_url: json.permalink, external_id: json.id, descripcion: texto, published_at: new Date().toISOString(),
        });
        await supabase.from("cars").update({ publicado_ml: true }).eq("id", carId);
        return { ok: true, url: json.permalink };
      } catch (e: any) { return { ok: false, error: e.message }; }
    }

    if (platform === "facebook" || platform === "instagram") {
      if (!connectedFor(platform)) {
        if (platform === "facebook") {
          const url = encodeURIComponent(fotosUrls[0] || window.location.origin);
          window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}&quote=${encodeURIComponent(texto)}`, "_blank");
          return { ok: true };
        }
        await navigator.clipboard.writeText(texto);
        return { ok: false, error: "IG no conectado (texto copiado)" };
      }
      try {
        const res = await fetch(`https://zraasslwthywrrekrkuv.supabase.co/functions/v1/meta-publish`, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            platform,
            descripcion: texto,
            fotos: fotosUrls,
            car_id: carId,
            carousel: platform === "instagram" && fotosUrls.length > 1,
          }),
        });
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || "Error");
        await supabase.from("car_publications").insert({
          user_id: user!.id, car_id: carId, platform, status: "publicado",
          external_url: json.url, external_id: json.id, descripcion: texto, published_at: new Date().toISOString(),
        });
        await supabase.from("cars").update(platform === "facebook" ? { publicado_fb: true } : { publicado_ig: true }).eq("id", carId);
        return { ok: true, url: json.url };
      } catch (e: any) { return { ok: false, error: e.message }; }
    }
    return { ok: false, error: "Plataforma desconocida" };
  };

  const publicarOne = async (platform: string) => {
    const r = await publicar(platform);
    toast({ title: r.ok ? "Publicado" : "Error", description: r.url || r.error || "", variant: r.ok ? "default" : "destructive" });
  };

  const publicarEnTodas = async () => {
    if (!car) return;
    setPublishingAll(true);
    const results: string[] = [];
    for (const p of PLATFORMS) {
      const r = await publicar(p.id);
      results.push(`${p.name}: ${r.ok ? "✓" : "✗"}`);
    }
    setPublishingAll(false);
    toast({ title: "Publicación masiva", description: results.join(" · ") });
  };

  return (
    <div className="space-y-4">
      <h1 className="page-header">Publicador</h1>

      <Alert className="border-warning/40 bg-warning/10">
        <AlertTriangle className="h-4 w-4 text-warning" />
        <AlertTitle className="text-warning text-sm">Cómo funciona</AlertTitle>
        <AlertDescription className="text-xs">
          <strong>Mercado Libre</strong>: publicación 100% automática (requiere conectar tu cuenta una sola vez).<br />
          <strong>WhatsApp / Facebook / Instagram</strong>: abre cada red con la descripción y fotos listas — pegás y publicás. Las APIs de Meta requieren cuenta Business + app review (semanas) para publicar sin pasos manuales.
        </AlertDescription>
      </Alert>

      {/* Cuentas conectadas */}
      <Card>
        <CardContent className="p-4 space-y-2">
          <div className="text-sm font-semibold mb-2">Cuentas</div>
          <div className="grid grid-cols-2 gap-2">
            {PLATFORMS.map(p => {
              const acc = connectedFor(p.id);
              return (
                <div key={p.id} className="flex items-center justify-between border rounded-md p-2">
                  <div className="flex items-center gap-2 text-xs">
                    <p.icon className={`w-4 h-4 ${p.color}`} />
                    <div>
                      <div className="font-medium">{p.name}</div>
                      {acc ? (
                        <div className="text-success text-[10px] flex items-center gap-1"><CheckCircle2 className="w-3 h-3" />{acc.account_name || "Conectado"}</div>
                      ) : (
                        <div className="text-muted-foreground text-[10px]">No conectado</div>
                      )}
                    </div>
                  </div>
                  {acc ? (
                    <Button size="sm" variant="ghost" onClick={() => desconectar(p.id)}>Salir</Button>
                  ) : p.id === "mercadolibre" ? (
                    <Button size="sm" variant="outline" onClick={conectarML}><Link2 className="w-3 h-3 mr-1" />Conectar</Button>
                  ) : p.id === "facebook" || p.id === "instagram" ? (
                    <Button size="sm" variant="outline" onClick={conectarMeta}><Link2 className="w-3 h-3 mr-1" />Conectar</Button>
                  ) : (
                    <Badge variant="outline" className="text-[10px]">Manual</Badge>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Auto */}
      <Card>
        <CardContent className="p-4 space-y-3">
          <div>
            <Label className="text-xs">Auto a publicar</Label>
            <Select value={carId} onValueChange={setCarId}>
              <SelectTrigger><SelectValue placeholder="Seleccionar auto..." /></SelectTrigger>
              <SelectContent>
                {stockCars.map(c => (
                  <SelectItem key={c.id} value={c.id}>{c.marca} {c.modelo} {c.anio} · {c.patente}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {car && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Precio publicación</Label>
                  <Input type="number" value={precio} onChange={e => setPrecio(Number(e.target.value))} />
                </div>
                <div>
                  <Label className="text-xs">Ubicación</Label>
                  <Input value={ubicacion} onChange={e => setUbicacion(e.target.value)} placeholder="Ciudad" />
                </div>
                <div>
                  <Label className="text-xs">Combustible</Label>
                  <Select value={combustible} onValueChange={setCombustible}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {["Nafta","Diesel","GNC","Híbrido","Eléctrico"].map(v => <SelectItem key={v} value={v}>{v}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Transmisión</Label>
                  <Select value={transmision} onValueChange={setTransmision}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {["Manual","Automática"].map(v => <SelectItem key={v} value={v}>{v}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Puertas</Label>
                  <Select value={String(puertas)} onValueChange={v => setPuertas(Number(v))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {[2,3,4,5].map(v => <SelectItem key={v} value={String(v)}>{v}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Condición</Label>
                  <Select value={condicion} onValueChange={setCondicion}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {["Usado","Nuevo"].map(v => <SelectItem key={v} value={v}>{v}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Fotos */}
              <div>
                <Label className="text-xs">Fotos (mín. 4 para máxima exposición)</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {photos.map(ph => (
                    <div key={ph.id} className="relative w-20 h-20 rounded-md overflow-hidden border group">
                      <img src={ph.url} alt="" className="w-full h-full object-cover" />
                      <button onClick={() => removePhoto(ph)} className="absolute top-0.5 right-0.5 bg-destructive text-destructive-foreground rounded-full p-0.5 opacity-0 group-hover:opacity-100">
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                  <label className="w-20 h-20 border-2 border-dashed rounded-md flex items-center justify-center cursor-pointer hover:bg-accent text-muted-foreground">
                    <Upload className="w-5 h-5" />
                    <input type="file" multiple accept="image/*" className="hidden" disabled={uploading} onChange={e => handleUpload(e.target.files)} />
                  </label>
                </div>
              </div>

              {/* Descripción */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <Label className="text-xs">Descripción</Label>
                  <Button size="sm" variant="ghost" onClick={generarDescripcion} disabled={loadingAI}>
                    <Sparkles className="w-3 h-3 mr-1" />{loadingAI ? "Generando..." : "Generar con IA"}
                  </Button>
                </div>
                <Textarea rows={6} value={descripcion} onChange={e => setDescripcion(e.target.value)} placeholder="Generá con IA o escribí tu propia descripción" />
              </div>

              {/* Publicar en todas */}
              <Button onClick={publicarEnTodas} disabled={publishingAll} className="w-full" size="lg">
                <Share2 className="w-4 h-4 mr-2" />
                {publishingAll ? "Publicando en todas..." : "Publicar en TODAS las redes"}
              </Button>

              {/* Botones individuales */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                {PLATFORMS.map(p => (
                  <Button key={p.id} variant="outline" onClick={() => publicarOne(p.id)} className="justify-start">
                    <p.icon className={`w-4 h-4 ${p.color}`} />
                    <Share2 className="w-3 h-3 ml-auto" />
                    <span className="text-xs">{p.name}</span>
                  </Button>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
