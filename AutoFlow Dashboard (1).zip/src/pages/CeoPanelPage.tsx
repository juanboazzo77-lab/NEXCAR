import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useIsCeo } from "@/hooks/useIsCeo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Crown, Plus, Building2, Users, BarChart3, Trash2, Edit3, Shield, PauseCircle, PlayCircle, Sparkles } from "lucide-react";
import { PLAN_ORDER, PLANS, fmtLimit, normalizePlan } from "@/lib/plans";
import { toast } from "sonner";

type Agency = { id: string; name: string; slug: string; status: string; plan: string; notes?: string; created_at: string };

export default function CeoPanelPage() {
  const { isCeo, loading } = useIsCeo();
  const [agencies, setAgencies] = useState<Agency[]>([]);
  const [metrics, setMetrics] = useState<any>(null);
  const [users, setUsers] = useState<{ roles: any[]; users: Record<string, any> }>({ roles: [], users: {} });
  const [tab, setTab] = useState("dashboard");
  const [usage, setUsage] = useState<any[]>([]);

  // form agency
  const [newAg, setNewAg] = useState({ name: "", plan: "common", notes: "" });
  const [editAg, setEditAg] = useState<Agency | null>(null);

  // form user
  const [newUser, setNewUser] = useState({ email: "", password: "", role: "employee", agency_id: "" });

  const refresh = async () => {
    const m = await supabase.functions.invoke("ceo-admin", { body: { action: "global_metrics" } });
    if (m.data) { setMetrics(m.data); setAgencies(m.data.agencies); }
    const u = await supabase.functions.invoke("ceo-admin", { body: { action: "list_users" } });
    if (u.data) setUsers(u.data);
    const p = await supabase.functions.invoke("ceo-admin", { body: { action: "plans_usage" } });
    if (p.data?.usage) setUsage(p.data.usage);
  };

  useEffect(() => { if (isCeo) refresh(); }, [isCeo]);

  if (loading) return <div className="p-6 text-muted-foreground">Cargando...</div>;
  if (!isCeo) return (
    <div className="p-6 flex flex-col items-center justify-center text-center gap-3 min-h-[60vh]">
      <Shield className="w-12 h-12 text-muted-foreground" />
      <h2 className="text-xl font-bold">Acceso restringido</h2>
      <p className="text-sm text-muted-foreground">Esta sección es solo para el CEO del sistema.</p>
    </div>
  );

  const createAgency = async () => {
    if (!newAg.name) return toast.error("Nombre requerido");
    const { error } = await supabase.functions.invoke("ceo-admin", { body: { action: "create_agency", ...newAg } });
    if (error) return toast.error(error.message);
    toast.success("Agencia creada");
    setNewAg({ name: "", plan: "common", notes: "" });
    refresh();
  };

  const updateAgency = async () => {
    if (!editAg) return;
    const { error } = await supabase.functions.invoke("ceo-admin", { body: { action: "update_agency", id: editAg.id, name: editAg.name, status: editAg.status, plan: editAg.plan, notes: editAg.notes } });
    if (error) return toast.error(error.message);
    toast.success("Actualizado");
    setEditAg(null);
    refresh();
  };

  const toggleAgencyPause = async (a: Agency) => {
    const next = a.status === "active" ? "suspended" : "active";
    if (next === "suspended" && !confirm(`¿Pausar "${a.name}"? Su catálogo público y el marketplace dejarán de mostrarse, pero conserva todos sus datos en el administrador.`)) return;
    const { error } = await supabase.functions.invoke("ceo-admin", { body: { action: "update_agency", id: a.id, name: a.name, status: next, plan: a.plan, notes: a.notes } });
    if (error) return toast.error(error.message);
    toast.success(next === "suspended" ? "Agencia pausada" : "Agencia reactivada");
    refresh();
  };

  const changePlan = async (a: Agency, plan: string) => {
    const { error } = await supabase.functions.invoke("ceo-admin", { body: { action: "update_agency", id: a.id, name: a.name, status: a.status, plan, notes: a.notes } });
    if (error) return toast.error(error.message);
    toast.success(`Plan de ${a.name}: ${PLANS[normalizePlan(plan)].name}`);
    refresh();
  };

  const deleteAgency = async (id: string) => {
    if (!confirm("¿Eliminar agencia? Esto borra también sus usuarios y datos asociados.")) return;
    const { error } = await supabase.functions.invoke("ceo-admin", { body: { action: "delete_agency", id } });
    if (error) return toast.error(error.message);
    toast.success("Agencia eliminada");
    refresh();
  };

  const createUser = async () => {
    if (!newUser.email || !newUser.password) return toast.error("Email y contraseña requeridos");
    const { error } = await supabase.functions.invoke("ceo-admin", { body: { action: "create_user", ...newUser, agency_id: newUser.agency_id || null } });
    if (error) return toast.error(error.message);
    toast.success("Usuario creado");
    setNewUser({ email: "", password: "", role: "employee", agency_id: "" });
    refresh();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2"><Crown className="w-6 h-6 text-yellow-500" /> Panel CEO</h1>
          <p className="text-sm text-muted-foreground">Administración global del sistema.</p>
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="dashboard"><BarChart3 className="w-4 h-4 mr-2" />Métricas</TabsTrigger>
          <TabsTrigger value="agencies"><Building2 className="w-4 h-4 mr-2" />Agencias</TabsTrigger>
          <TabsTrigger value="users"><Users className="w-4 h-4 mr-2" />Usuarios</TabsTrigger>
          <TabsTrigger value="plans"><Sparkles className="w-4 h-4 mr-2" />Planes</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Stat label="Agencias" value={metrics?.agencies_total ?? "—"} sub={`${metrics?.agencies_active ?? 0} activas`} />
            <Stat label="Stock total" value={metrics?.cars_total ?? "—"} sub={metrics?.valor_stock ? `$${Number(metrics.valor_stock).toLocaleString()}` : ""} />
            <Stat label="Ventas mes" value={metrics?.ventas_mes ?? "—"} sub={metrics?.ventas_total_mes ? `$${Number(metrics.ventas_total_mes).toLocaleString()}` : ""} />
            <Stat label="Ganancia mes" value={metrics ? `$${Number(metrics.ganancia_mes || 0).toLocaleString()}` : "—"} />
          </div>
        </TabsContent>

        <TabsContent value="agencies" className="space-y-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Crear nueva agencia</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-4 gap-2">
              <Input placeholder="Nombre" value={newAg.name} onChange={(e) => setNewAg({ ...newAg, name: e.target.value })} />
              <Select value={newAg.plan} onValueChange={(v) => setNewAg({ ...newAg, plan: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PLAN_ORDER.map((c) => <SelectItem key={c} value={c}>{PLANS[c].name}</SelectItem>)}
                </SelectContent>
              </Select>
              <Input placeholder="Notas (opcional)" value={newAg.notes} onChange={(e) => setNewAg({ ...newAg, notes: e.target.value })} />
              <Button onClick={createAgency}><Plus className="w-4 h-4 mr-2" />Crear</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Agencias ({agencies.length})</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-2">
                {agencies.map((a) => (
                  <div key={a.id} className="flex items-center justify-between p-3 border rounded-md">
                    <div>
                      <div className="font-medium">{a.name} <Badge variant={a.status === "active" ? "default" : "secondary"} className="ml-2">{a.status}</Badge> <Badge variant="outline" className="ml-1">{a.plan}</Badge></div>
                      {a.notes && <div className="text-xs text-muted-foreground mt-1">{a.notes}</div>}
                    </div>
                    <div className="flex gap-2">
                      <Dialog open={editAg?.id === a.id} onOpenChange={(o) => setEditAg(o ? a : null)}>
                        <DialogTrigger asChild><Button size="sm" variant="outline"><Edit3 className="w-4 h-4" /></Button></DialogTrigger>
                        <DialogContent>
                          <DialogHeader><DialogTitle>Editar agencia</DialogTitle></DialogHeader>
                          {editAg && (
                            <div className="space-y-3">
                              <div><Label>Nombre</Label><Input value={editAg.name} onChange={(e) => setEditAg({ ...editAg, name: e.target.value })} /></div>
                              <div><Label>Estado</Label>
                                <Select value={editAg.status} onValueChange={(v) => setEditAg({ ...editAg, status: v })}>
                                  <SelectTrigger><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="active">Activa</SelectItem>
                                    <SelectItem value="trial">Trial</SelectItem>
                                    <SelectItem value="suspended">Suspendida</SelectItem>
                                    <SelectItem value="cancelled">Cancelada</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div><Label>Plan</Label>
                                <Select value={editAg.plan} onValueChange={(v) => setEditAg({ ...editAg, plan: v })}>
                                  <SelectTrigger><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                    {PLAN_ORDER.map((c) => <SelectItem key={c} value={c}>{PLANS[c].name}</SelectItem>)}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div><Label>Notas</Label><Input value={editAg.notes || ""} onChange={(e) => setEditAg({ ...editAg, notes: e.target.value })} /></div>
                              <Button onClick={updateAgency} className="w-full">Guardar</Button>
                            </div>
                          )}
                        </DialogContent>
                      </Dialog>
                      <Select value={normalizePlan(a.plan)} onValueChange={(v) => changePlan(a, v)}>
                        <SelectTrigger className="w-[130px] h-9"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {PLAN_ORDER.map((c) => <SelectItem key={c} value={c}>{PLANS[c].name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <Button
                        size="sm"
                        variant={a.status === "active" ? "secondary" : "default"}
                        onClick={() => toggleAgencyPause(a)}
                        title={a.status === "active" ? "Pausar agencia (se oculta del marketplace y su catálogo)" : "Reactivar agencia"}
                      >
                        {a.status === "active" ? <><PauseCircle className="w-4 h-4 mr-1" />Pausar</> : <><PlayCircle className="w-4 h-4 mr-1" />Reactivar</>}
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => deleteAgency(a.id)}><Trash2 className="w-4 h-4" /></Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Crear usuario</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-5 gap-2">
              <Input placeholder="Email" value={newUser.email} onChange={(e) => setNewUser({ ...newUser, email: e.target.value })} />
              <Input placeholder="Contraseña" type="password" value={newUser.password} onChange={(e) => setNewUser({ ...newUser, password: e.target.value })} />
              <Select value={newUser.role} onValueChange={(v) => setNewUser({ ...newUser, role: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="owner">Owner</SelectItem>
                  <SelectItem value="employee">Empleado</SelectItem>
                  <SelectItem value="ceo">CEO</SelectItem>
                </SelectContent>
              </Select>
              <Select value={newUser.agency_id || "none"} onValueChange={(v) => setNewUser({ ...newUser, agency_id: v === "none" ? "" : v })}>
                <SelectTrigger><SelectValue placeholder="Agencia" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Sin agencia (solo CEO)</SelectItem>
                  {agencies.map((a) => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
                </SelectContent>
              </Select>
              <Button onClick={createUser}><Plus className="w-4 h-4 mr-2" />Crear</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Usuarios y roles</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-2">
                {users.roles.map((r, i) => {
                  const u = users.users[r.user_id];
                  const a = agencies.find((x) => x.id === r.agency_id);
                  return (
                    <div key={i} className="flex items-center justify-between p-3 border rounded-md text-sm">
                      <div>
                        <div className="font-medium">{u?.email || r.user_id}</div>
                        <div className="text-xs text-muted-foreground">{a ? a.name : (r.role === "ceo" ? "Global" : "Sin agencia")}</div>
                      </div>
                      <Badge>{r.role}</Badge>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="plans" className="space-y-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Uso de publicaciones por agencia</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {usage.length === 0 && <p className="text-sm text-muted-foreground">Sin datos todavía.</p>}
              {usage.map((u) => (
                <div key={u.agency_id} className="flex flex-wrap items-center justify-between gap-3 p-3 border rounded-md text-sm">
                  <div>
                    <div className="font-medium">{u.name}</div>
                    <div className="text-xs text-muted-foreground">Estado: {u.status}</div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-xs"><span className="text-muted-foreground">Marketplace</span> <b>{u.marketplace_used}/{fmtLimit(u.max_marketplace)}</b></div>
                    <div className="text-xs"><span className="text-muted-foreground">ORO</span> <b>{u.gold_used}/{fmtLimit(u.max_gold)}</b></div>
                    <div className="text-xs"><span className="text-muted-foreground">PLATA</span> <b>{u.silver_used}/{fmtLimit(u.max_silver)}</b></div>
                    <Select value={normalizePlan(u.plan)} onValueChange={(v) => changePlan({ id: u.agency_id, name: u.name, status: u.status } as any, v)}>
                      <SelectTrigger className="w-[130px] h-9"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {PLAN_ORDER.map((c) => <SelectItem key={c} value={c}>{PLANS[c].name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function Stat({ label, value, sub }: { label: string; value: any; sub?: string }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="text-xs text-muted-foreground">{label}</div>
        <div className="text-2xl font-bold mt-1">{value}</div>
        {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
      </CardContent>
    </Card>
  );
}
