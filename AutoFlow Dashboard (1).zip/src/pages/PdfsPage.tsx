import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Download, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { Car } from "@/lib/supabase-helpers";
import { useAgency } from "@/hooks/useAgency";
import {
  generatePresupuesto, generateBoleto, generateRecibo,
  generateCuotas, generateContrato, generateFichaTecnica,
  generateSimulacionFinanciacion,
  type PersonInfo, type CarInfo
} from "@/lib/pdf-generator";

const emptyPerson: PersonInfo = { nombre: "", dni: "", domicilio: "", telefono: "", email: "", cuit: "" };

function PersonFields({ value, onChange, prefix }: { value: PersonInfo; onChange: (v: PersonInfo) => void; prefix: string }) {
  const set = (k: keyof PersonInfo) => (e: any) => onChange({ ...value, [k]: e.target.value });
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
      <div><Label>{prefix} - Nombre completo *</Label><Input value={value.nombre} onChange={set("nombre")} /></div>
      <div><Label>DNI / CUIT</Label><Input value={value.dni} onChange={set("dni")} /></div>
      <div><Label>Teléfono</Label><Input value={value.telefono} onChange={set("telefono")} /></div>
      <div><Label>Email</Label><Input value={value.email} onChange={set("email")} /></div>
      <div className="md:col-span-2"><Label>Domicilio</Label><Input value={value.domicilio} onChange={set("domicilio")} /></div>
    </div>
  );
}

function CarPicker({ cars, value, onChange }: { cars: Car[]; value: string; onChange: (id: string, auto: CarInfo) => void }) {
  return (
    <div>
      <Label>Seleccionar auto del stock</Label>
      <Select value={value} onValueChange={(id) => {
        const c = cars.find(x => x.id === id);
        if (c) onChange(id, {
          marca: c.marca, modelo: c.modelo, anio: c.anio, version: (c as any).version || "",
          patente: c.patente || "", color: c.color || "", kilometros: (c as any).kilometros || "",
          motor: (c as any).motor || "", chasis: (c as any).chasis || "",
        });
      }}>
        <SelectTrigger><SelectValue placeholder="Elegir auto..." /></SelectTrigger>
        <SelectContent>
          {cars.map(c => (
            <SelectItem key={c.id} value={c.id}>
              {c.marca} {c.modelo} {c.anio} {c.patente ? `- ${c.patente}` : ""}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

function CarFields({ value, onChange }: { value: CarInfo; onChange: (v: CarInfo) => void }) {
  const set = (k: keyof CarInfo) => (e: any) => onChange({ ...value, [k]: e.target.value });
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-3">
      <div><Label>Marca</Label><Input value={value.marca} onChange={set("marca")} /></div>
      <div><Label>Modelo</Label><Input value={value.modelo} onChange={set("modelo")} /></div>
      <div><Label>Año</Label><Input value={String(value.anio || "")} onChange={set("anio")} /></div>
      <div><Label>Versión</Label><Input value={value.version || ""} onChange={set("version")} /></div>
      <div><Label>Patente</Label><Input value={value.patente || ""} onChange={set("patente")} /></div>
      <div><Label>Color</Label><Input value={value.color || ""} onChange={set("color")} /></div>
      <div><Label>Kilómetros</Label><Input value={String(value.kilometros || "")} onChange={set("kilometros")} /></div>
      <div><Label>Motor</Label><Input value={value.motor || ""} onChange={set("motor")} /></div>
      <div><Label>Chasis</Label><Input value={value.chasis || ""} onChange={set("chasis")} /></div>
    </div>
  );
}

export default function PdfsPage() {
  const { agency } = useAgency();
  const agencyName = agency?.name || "tu agencia";
  const [cars, setCars] = useState<Car[]>([]);

  useEffect(() => {
    supabase.from("cars").select("*").order("created_at", { ascending: false })
      .then(({ data }) => setCars((data || []) as Car[]));
  }, []);

  // -------- Presupuesto --------
  const [pCliente, setPCliente] = useState<PersonInfo>({ ...emptyPerson });
  const [pAuto, setPAuto] = useState<CarInfo>({ marca: "", modelo: "", anio: "" });
  const [pPrecio, setPPrecio] = useState(0);
  const [pTransfer, setPTransfer] = useState(0);
  const [pObs, setPObs] = useState("");
  const [pCarId, setPCarId] = useState("");

  // -------- Boleto --------
  const [bVend, setBVend] = useState<PersonInfo>({ ...emptyPerson, nombre: agencyName });
  const [bComp, setBComp] = useState<PersonInfo>({ ...emptyPerson });
  const [bAuto, setBAuto] = useState<CarInfo>({ marca: "", modelo: "", anio: "" });
  const [bPrecio, setBPrecio] = useState(0);
  const [bSena, setBSena] = useState(0);
  const [bPago, setBPago] = useState("Efectivo");
  const [bLugar, setBLugar] = useState("");
  const [bCarId, setBCarId] = useState("");

  // -------- Recibo --------
  const [rDe, setRDe] = useState<PersonInfo>({ ...emptyPerson });
  const [rMonto, setRMonto] = useState(0);
  const [rConcepto, setRConcepto] = useState("");
  const [rPago, setRPago] = useState("Efectivo");

  // -------- Cuotas --------
  const [cCliente, setCCliente] = useState<PersonInfo>({ ...emptyPerson });
  const [cAuto, setCAuto] = useState<CarInfo>({ marca: "", modelo: "", anio: "" });
  const [cCarId, setCCarId] = useState("");
  const [cuotas, setCuotas] = useState<{ numero: number; fecha: string; monto: number; estado: string }[]>(
    [{ numero: 1, fecha: "", monto: 0, estado: "Pendiente" }]
  );
  const [cObs, setCObs] = useState("");

  // -------- Contrato --------
  const [ctTitulo, setCtTitulo] = useState("Contrato de Compra-Venta");
  const [ctVend, setCtVend] = useState<PersonInfo>({ ...emptyPerson, nombre: agencyName });
  const [ctComp, setCtComp] = useState<PersonInfo>({ ...emptyPerson });
  const [ctAuto, setCtAuto] = useState<CarInfo>({ marca: "", modelo: "", anio: "" });
  const [ctCarId, setCtCarId] = useState("");
  const [ctPrecio, setCtPrecio] = useState(0);
  const [ctLugar, setCtLugar] = useState("");
  const [ctClausulas, setCtClausulas] = useState(
    "PRIMERA: El VENDEDOR transfiere al COMPRADOR el vehículo descripto.\n\nSEGUNDA: El precio convenido se abona en este acto.\n\nTERCERA: El COMPRADOR declara haber inspeccionado el vehículo y aceptarlo en el estado en que se encuentra.\n\nCUARTA: Los gastos de transferencia y patentamiento son a cargo del COMPRADOR.\n\nQUINTA: Las partes constituyen domicilio en los indicados y se someten a la jurisdicción de los tribunales ordinarios."
  );

  // -------- Ficha --------
  const [fAuto, setFAuto] = useState<CarInfo>({ marca: "", modelo: "", anio: "" });
  const [fCarId, setFCarId] = useState("");
  const [fPrecio, setFPrecio] = useState(0);
  const [fObs, setFObs] = useState("");

  // -------- Simulación de financiación --------
  const [sCliente, setSCliente] = useState<PersonInfo>({ ...emptyPerson });
  const [sAuto, setSAuto] = useState<CarInfo>({ marca: "", modelo: "", anio: "" });
  const [sCarId, setSCarId] = useState("");
  const [sPrecio, setSPrecio] = useState(0);
  const [sEntrega, setSEntrega] = useState(0);
  const [sFecha, setSFecha] = useState("");
  const [sObs, setSObs] = useState("");
  const [sPlanes, setSPlanes] = useState([{ cuotas: 12, tasaAnual: 60, gastosPorcentaje: 0 }]);

  const totalCuotas = cuotas.reduce((s, c) => s + Number(c.monto || 0), 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2"><FileText className="w-6 h-6 text-primary" /> Generador de PDFs</h1>
        <p className="text-sm text-muted-foreground">Documentos profesionales con la marca de {agencyName}.</p>
      </div>

      <Tabs defaultValue="presupuesto">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="presupuesto">Presupuesto</TabsTrigger>
          <TabsTrigger value="boleto">Boleto C/V</TabsTrigger>
          <TabsTrigger value="recibo">Recibo</TabsTrigger>
          <TabsTrigger value="cuotas">Cuotas</TabsTrigger>
          <TabsTrigger value="financiacion">Financiación</TabsTrigger>
          <TabsTrigger value="contrato">Contrato</TabsTrigger>
          <TabsTrigger value="ficha">Ficha técnica</TabsTrigger>
        </TabsList>

        {/* Presupuesto */}
        <TabsContent value="presupuesto">
          <Card><CardHeader><CardTitle>Presupuesto</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <CarPicker cars={cars} value={pCarId} onChange={(id, a) => { setPCarId(id); setPAuto(a); }} />
              <CarFields value={pAuto} onChange={setPAuto} />
              <div className="border-t pt-4"><PersonFields prefix="Cliente" value={pCliente} onChange={setPCliente} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Precio del vehículo</Label><Input type="number" value={pPrecio} onChange={e => setPPrecio(+e.target.value)} /></div>
                <div><Label>Gastos de transferencia</Label><Input type="number" value={pTransfer} onChange={e => setPTransfer(+e.target.value)} /></div>
              </div>
              <div><Label>Observaciones</Label><Textarea value={pObs} onChange={e => setPObs(e.target.value)} /></div>
              <Button onClick={async () => {
                if (!pCliente.nombre || !pAuto.marca) return toast.error("Completá cliente y auto");
                await generatePresupuesto({ cliente: pCliente, auto: pAuto, precio: pPrecio, transferencia: pTransfer, observaciones: pObs });
                toast.success("PDF generado");
              }}><Download className="w-4 h-4 mr-2" />Generar PDF</Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Boleto */}
        <TabsContent value="boleto">
          <Card><CardHeader><CardTitle>Boleto de Compra-Venta</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <CarPicker cars={cars} value={bCarId} onChange={(id, a) => { setBCarId(id); setBAuto(a); }} />
              <CarFields value={bAuto} onChange={setBAuto} />
              <div className="border-t pt-4"><PersonFields prefix="Vendedor" value={bVend} onChange={setBVend} /></div>
              <div className="border-t pt-4"><PersonFields prefix="Comprador" value={bComp} onChange={setBComp} /></div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div><Label>Precio total</Label><Input type="number" value={bPrecio} onChange={e => setBPrecio(+e.target.value)} /></div>
                <div><Label>Seña</Label><Input type="number" value={bSena} onChange={e => setBSena(+e.target.value)} /></div>
                <div><Label>Forma de pago</Label><Input value={bPago} onChange={e => setBPago(e.target.value)} /></div>
                <div><Label>Lugar</Label><Input value={bLugar} onChange={e => setBLugar(e.target.value)} /></div>
              </div>
              <Button onClick={async () => {
                if (!bComp.nombre || !bAuto.marca) return toast.error("Completá comprador y auto");
                await generateBoleto({ vendedor: bVend, comprador: bComp, auto: bAuto, precio: bPrecio, sena: bSena, formaPago: bPago, lugar: bLugar });
                toast.success("PDF generado");
              }}><Download className="w-4 h-4 mr-2" />Generar PDF</Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Recibo */}
        <TabsContent value="recibo">
          <Card><CardHeader><CardTitle>Recibo</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <PersonFields prefix="Recibí de" value={rDe} onChange={setRDe} />
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Monto</Label><Input type="number" value={rMonto} onChange={e => setRMonto(+e.target.value)} /></div>
                <div><Label>Forma de pago</Label><Input value={rPago} onChange={e => setRPago(e.target.value)} /></div>
              </div>
              <div><Label>Concepto</Label><Textarea value={rConcepto} onChange={e => setRConcepto(e.target.value)} placeholder="Por la suma de pesos... en concepto de..." /></div>
              <Button onClick={async () => {
                if (!rDe.nombre || !rMonto) return toast.error("Completá nombre y monto");
                await generateRecibo({ recibiDe: rDe, monto: rMonto, concepto: rConcepto, formaPago: rPago });
                toast.success("PDF generado");
              }}><Download className="w-4 h-4 mr-2" />Generar PDF</Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Cuotas */}
        <TabsContent value="cuotas">
          <Card><CardHeader><CardTitle>Plan de Cuotas</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <PersonFields prefix="Cliente" value={cCliente} onChange={setCCliente} />
              <div className="border-t pt-4">
                <CarPicker cars={cars} value={cCarId} onChange={(id, a) => { setCCarId(id); setCAuto(a); }} />
                <CarFields value={cAuto} onChange={setCAuto} />
              </div>
              <div className="border-t pt-4">
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-base font-semibold">Cuotas</Label>
                  <Button size="sm" variant="outline" onClick={() => setCuotas([...cuotas, { numero: cuotas.length + 1, fecha: "", monto: 0, estado: "Pendiente" }])}>
                    <Plus className="w-4 h-4 mr-1" />Agregar
                  </Button>
                </div>
                <div className="space-y-2">
                  {cuotas.map((c, i) => (
                    <div key={i} className="grid grid-cols-12 gap-2 items-end">
                      <div className="col-span-1"><Label className="text-xs">N°</Label><Input type="number" value={c.numero} onChange={e => { const n = [...cuotas]; n[i].numero = +e.target.value; setCuotas(n); }} /></div>
                      <div className="col-span-3"><Label className="text-xs">Vencimiento</Label><Input type="date" value={c.fecha} onChange={e => { const n = [...cuotas]; n[i].fecha = e.target.value; setCuotas(n); }} /></div>
                      <div className="col-span-3"><Label className="text-xs">Monto</Label><Input type="number" value={c.monto} onChange={e => { const n = [...cuotas]; n[i].monto = +e.target.value; setCuotas(n); }} /></div>
                      <div className="col-span-4"><Label className="text-xs">Estado</Label><Input value={c.estado} onChange={e => { const n = [...cuotas]; n[i].estado = e.target.value; setCuotas(n); }} /></div>
                      <Button size="icon" variant="ghost" className="col-span-1" onClick={() => setCuotas(cuotas.filter((_, j) => j !== i))}><Trash2 className="w-4 h-4" /></Button>
                    </div>
                  ))}
                </div>
                <div className="text-right text-sm mt-2 font-semibold">Total: ${totalCuotas.toLocaleString("es-AR")}</div>
              </div>
              <div><Label>Observaciones</Label><Textarea value={cObs} onChange={e => setCObs(e.target.value)} /></div>
              <Button onClick={async () => {
                if (!cCliente.nombre) return toast.error("Completá cliente");
                await generateCuotas({ cliente: cCliente, auto: cAuto.marca ? cAuto : undefined, total: totalCuotas, cuotas, observaciones: cObs });
                toast.success("PDF generado");
              }}><Download className="w-4 h-4 mr-2" />Generar PDF</Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Simulación de financiación */}
        <TabsContent value="financiacion">
          <Card><CardHeader><CardTitle>Simulación de financiación</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <CarPicker cars={cars} value={sCarId} onChange={(id, a) => {
                setSCarId(id); setSAuto(a);
                const c = cars.find(x => x.id === id) as any;
                if (c?.precio_venta) { setSPrecio(Number(c.precio_venta)); setSEntrega(Math.round(Number(c.precio_venta) * 0.4)); }
              }} />
              <CarFields value={sAuto} onChange={setSAuto} />
              <div className="border-t pt-4"><PersonFields prefix="Cliente" value={sCliente} onChange={setSCliente} /></div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div><Label>Precio del vehículo</Label><Input type="number" value={sPrecio} onChange={e => setSPrecio(+e.target.value)} /></div>
                <div><Label>Entrega inicial</Label><Input type="number" value={sEntrega} onChange={e => setSEntrega(+e.target.value)} /></div>
                <div><Label>Fecha base</Label><Input type="date" value={sFecha} onChange={e => setSFecha(e.target.value)} /></div>
              </div>
              <div className="border-t pt-4">
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-base font-semibold">Planes a comparar</Label>
                  <Button size="sm" variant="outline" onClick={() => setSPlanes([...sPlanes, { cuotas: 24, tasaAnual: 60, gastosPorcentaje: 0 }])}>
                    <Plus className="w-4 h-4 mr-1" />Agregar plan
                  </Button>
                </div>
                <div className="space-y-2">
                  {sPlanes.map((p, i) => (
                    <div key={i} className="grid grid-cols-12 gap-2 items-end">
                      <div className="col-span-3"><Label className="text-xs">Cuotas</Label><Input type="number" value={p.cuotas} onChange={e => { const n = [...sPlanes]; n[i] = { ...n[i], cuotas: +e.target.value }; setSPlanes(n); }} /></div>
                      <div className="col-span-4"><Label className="text-xs">Tasa anual (%)</Label><Input type="number" value={p.tasaAnual} onChange={e => { const n = [...sPlanes]; n[i] = { ...n[i], tasaAnual: +e.target.value }; setSPlanes(n); }} /></div>
                      <div className="col-span-4"><Label className="text-xs">Gastos adm. (%)</Label><Input type="number" value={p.gastosPorcentaje} onChange={e => { const n = [...sPlanes]; n[i] = { ...n[i], gastosPorcentaje: +e.target.value }; setSPlanes(n); }} /></div>
                      <Button size="icon" variant="ghost" className="col-span-1" onClick={() => setSPlanes(sPlanes.filter((_, j) => j !== i))}><Trash2 className="w-4 h-4" /></Button>
                    </div>
                  ))}
                </div>
              </div>
              <div><Label>Observaciones</Label><Textarea value={sObs} onChange={e => setSObs(e.target.value)} /></div>
              <Button onClick={async () => {
                if (!sPrecio || sPlanes.length === 0) return toast.error("Completá el precio y al menos un plan");
                await generateSimulacionFinanciacion({
                  cliente: sCliente.nombre ? sCliente : undefined,
                  auto: sAuto.marca ? sAuto : undefined,
                  precio: sPrecio, entrega: sEntrega, planes: sPlanes,
                  primeraFecha: sFecha || undefined, observaciones: sObs,
                });
                toast.success("PDF generado");
              }}><Download className="w-4 h-4 mr-2" />Generar PDF</Button>
            </CardContent>
          </Card>
        </TabsContent>



        {/* Contrato */}
        <TabsContent value="contrato">
          <Card><CardHeader><CardTitle>Contrato</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div><Label>Título del contrato</Label><Input value={ctTitulo} onChange={e => setCtTitulo(e.target.value)} /></div>
              <CarPicker cars={cars} value={ctCarId} onChange={(id, a) => { setCtCarId(id); setCtAuto(a); }} />
              <CarFields value={ctAuto} onChange={setCtAuto} />
              <div className="border-t pt-4"><PersonFields prefix="Vendedor" value={ctVend} onChange={setCtVend} /></div>
              <div className="border-t pt-4"><PersonFields prefix="Comprador" value={ctComp} onChange={setCtComp} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Precio</Label><Input type="number" value={ctPrecio} onChange={e => setCtPrecio(+e.target.value)} /></div>
                <div><Label>Lugar</Label><Input value={ctLugar} onChange={e => setCtLugar(e.target.value)} /></div>
              </div>
              <div><Label>Cláusulas</Label><Textarea rows={10} value={ctClausulas} onChange={e => setCtClausulas(e.target.value)} /></div>
              <Button onClick={async () => {
                await generateContrato({ titulo: ctTitulo, vendedor: ctVend, comprador: ctComp, auto: ctAuto, precio: ctPrecio, clausulas: ctClausulas, lugar: ctLugar });
                toast.success("PDF generado");
              }}><Download className="w-4 h-4 mr-2" />Generar PDF</Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Ficha técnica */}
        <TabsContent value="ficha">
          <Card><CardHeader><CardTitle>Ficha Técnica</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <CarPicker cars={cars} value={fCarId} onChange={(id, a) => { setFCarId(id); setFAuto(a); }} />
              <CarFields value={fAuto} onChange={setFAuto} />
              <div><Label>Precio (opcional)</Label><Input type="number" value={fPrecio} onChange={e => setFPrecio(+e.target.value)} /></div>
              <div><Label>Observaciones</Label><Textarea value={fObs} onChange={e => setFObs(e.target.value)} /></div>
              <Button onClick={async () => {
                if (!fAuto.marca) return toast.error("Completá los datos del auto");
                await generateFichaTecnica({ auto: fAuto, precio: fPrecio || undefined, observaciones: fObs });
                toast.success("PDF generado");
              }}><Download className="w-4 h-4 mr-2" />Generar PDF</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
