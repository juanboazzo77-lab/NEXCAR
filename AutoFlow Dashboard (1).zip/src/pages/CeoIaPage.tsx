import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Send, Sparkles, Plus, MessageSquare, RefreshCcw, TrendingUp, DollarSign, Users, AlertCircle, Package } from "lucide-react";
import { toast } from "sonner";

type Msg = { id?: string; role: "user" | "assistant" | "system"; content: string; created_at?: string };
type Conv = { id: string; title: string; updated_at: string };

export default function CeoIaPage() {
  const [convs, setConvs] = useState<Conv[]>([]);
  const [activeConv, setActiveConv] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [summary, setSummary] = useState<any>(null);
  const [loadingSummary, setLoadingSummary] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const loadConvs = async () => {
    const { data } = await supabase.from("ceo_conversations" as any).select("id,title,updated_at").order("updated_at", { ascending: false });
    setConvs((data as any) || []);
  };

  const loadMessages = async (convId: string) => {
    const { data } = await supabase.from("ceo_messages" as any).select("id,role,content,created_at").eq("conversation_id", convId).order("created_at", { ascending: true });
    setMessages((data as any) || []);
  };

  const loadSummary = async () => {
    setLoadingSummary(true);
    try {
      const { data, error } = await supabase.functions.invoke("ceo-daily-summary", { body: {} });
      if (error) throw error;
      setSummary(data);
    } catch (e: any) {
      toast.error("No se pudo generar el resumen: " + (e?.message || e));
    } finally {
      setLoadingSummary(false);
    }
  };

  useEffect(() => { loadConvs(); loadSummary(); }, []);
  useEffect(() => { if (activeConv) loadMessages(activeConv); else setMessages([]); }, [activeConv]);
  useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" }); }, [messages]);

  const send = async () => {
    const text = input.trim();
    if (!text || sending) return;
    setSending(true);
    setMessages((m) => [...m, { role: "user", content: text }]);
    setInput("");
    try {
      const { data, error } = await supabase.functions.invoke("ceo-chat", { body: { conversation_id: activeConv, message: text } });
      if (error) throw error;
      if (!activeConv) setActiveConv(data.conversation_id);
      setMessages((m) => [...m, { role: "assistant", content: data.reply }]);
      loadConvs();
    } catch (e: any) {
      toast.error("Error: " + (e?.message || e));
      setMessages((m) => [...m, { role: "assistant", content: "⚠️ Error al obtener respuesta." }]);
    } finally {
      setSending(false);
    }
  };

  const suggestions = [
    "¿Cuál es mi ganancia estimada este mes?",
    "¿Qué vehículo conviene bajar de precio?",
    "Resumen de ventas y leads",
    "¿Qué canal me trae más leads?",
  ];

  const metrics = summary?.metrics || {};

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2"><Sparkles className="w-6 h-6 text-primary" /> IA Ejecutiva</h1>
          <p className="text-sm text-muted-foreground">Preguntale cualquier cosa sobre tu negocio en lenguaje natural.</p>
        </div>
      </div>

      {/* Panel CEO */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <MetricCard icon={Package} label="Stock" value={metrics.stock_total ?? "—"} />
        <MetricCard icon={DollarSign} label="Ventas mes" value={metrics.ventas_mes ?? "—"} sub={metrics.ventas_total_mes ? `$${Number(metrics.ventas_total_mes).toLocaleString()}` : ""} />
        <MetricCard icon={TrendingUp} label="Ganancia mes" value={metrics.ingresos_mes != null ? `$${Number((metrics.ingresos_mes || 0) - (metrics.egresos_mes || 0)).toLocaleString()}` : "—"} />
        <MetricCard icon={Users} label="Leads 24h" value={metrics.leads_24h ?? "—"} />
        <MetricCard icon={AlertCircle} label="Alertas" value={metrics.alertas_pendientes ?? "—"} />
      </div>

      <Tabs defaultValue="chat">
        <TabsList>
          <TabsTrigger value="chat">Chat IA</TabsTrigger>
          <TabsTrigger value="resumen">Resumen diario</TabsTrigger>
        </TabsList>

        <TabsContent value="chat">
          <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr] gap-4">
            {/* Conversaciones */}
            <Card>
              <CardHeader className="py-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm">Conversaciones</CardTitle>
                  <Button size="sm" variant="ghost" onClick={() => { setActiveConv(null); setMessages([]); }}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-1 max-h-[60vh] overflow-auto">
                {convs.length === 0 && <p className="text-xs text-muted-foreground">Sin conversaciones aún.</p>}
                {convs.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setActiveConv(c.id)}
                    className={`w-full text-left px-2 py-2 rounded text-sm truncate flex items-center gap-2 hover:bg-muted ${activeConv === c.id ? "bg-muted font-medium" : ""}`}
                  >
                    <MessageSquare className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{c.title}</span>
                  </button>
                ))}
              </CardContent>
            </Card>

            {/* Chat */}
            <Card className="flex flex-col h-[70vh]">
              <CardContent className="flex-1 overflow-hidden p-0 flex flex-col">
                <ScrollArea className="flex-1">
                  <div ref={scrollRef} className="p-4 space-y-3">
                    {messages.length === 0 && (
                      <div className="space-y-3">
                        <p className="text-sm text-muted-foreground">Empezá con una pregunta:</p>
                        <div className="flex flex-wrap gap-2">
                          {suggestions.map((s) => (
                            <button key={s} onClick={() => setInput(s)} className="text-xs px-3 py-1.5 rounded-full border hover:bg-muted">
                              {s}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                    {messages.map((m, i) => (
                      <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                        <div className={`max-w-[85%] rounded-lg px-3 py-2 text-sm whitespace-pre-wrap ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                          {m.content}
                        </div>
                      </div>
                    ))}
                    {sending && <div className="text-xs text-muted-foreground">IA pensando…</div>}
                  </div>
                </ScrollArea>
                <div className="border-t p-3 flex gap-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
                    placeholder="Preguntale algo a tu IA ejecutiva..."
                    disabled={sending}
                  />
                  <Button onClick={send} disabled={sending || !input.trim()}>
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="resumen">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Resumen ejecutivo de hoy</CardTitle>
              <Button size="sm" variant="outline" onClick={loadSummary} disabled={loadingSummary}>
                <RefreshCcw className="w-4 h-4 mr-2" /> Actualizar
              </Button>
            </CardHeader>
            <CardContent>
              {loadingSummary && <p className="text-sm text-muted-foreground">Generando resumen...</p>}
              {summary?.summary ? (
                <div className="prose prose-sm max-w-none whitespace-pre-wrap text-sm">{summary.summary}</div>
              ) : (
                !loadingSummary && <p className="text-sm text-muted-foreground">Sin resumen disponible.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function MetricCard({ icon: Icon, label, value, sub }: { icon: any; label: string; value: any; sub?: string }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground"><Icon className="w-4 h-4" /> {label}</div>
        <div className="text-xl font-bold mt-1">{value}</div>
        {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
      </CardContent>
    </Card>
  );
}
