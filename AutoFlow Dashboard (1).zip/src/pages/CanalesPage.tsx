import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, MessageCircle, Instagram, Copy, CheckCircle2, AlertCircle, Clock, Zap, Loader2 } from "lucide-react";
import { formatDate } from "@/lib/supabase-helpers";

declare global { interface Window { FB: any; fbAsyncInit: any; } }

type Account = {
  id: string;
  platform: 'whatsapp' | 'instagram';
  nombre_interno: string;
  responsable: string | null;
  estado: 'conectado' | 'desconectado' | 'pendiente' | 'error';
  external_id: string | null;
  phone_number: string | null;
  ig_username: string | null;
  access_token: string | null;
  waba_id: string | null;
  page_id: string | null;
  fecha_conexion: string | null;
  notas: string | null;
};

const PROJECT_ID = "zraasslwthywrrekrkuv";
const WEBHOOK_URL = `https://${PROJECT_ID}.supabase.co/functions/v1/meta-webhook`;
const VERIFY_TOKEN = "boazzo-meta-verify";

export default function CanalesPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Account | null>(null);
  const [counts, setCounts] = useState<Record<string, { conv: number; leads: number }>>({});
  const [mlAccount, setMlAccount] = useState<any>(null);
  const [fbAccounts, setFbAccounts] = useState<any[]>([]);
  const [igAccounts, setIgAccounts] = useState<any[]>([]);
  const [mlCredentials, setMlCredentials] = useState<{ app_id: string; client_secret: string }>({ app_id: '', client_secret: '' });

  const empty = {
    platform: 'whatsapp' as 'whatsapp' | 'instagram',
    nombre_interno: '',
    responsable: '',
    estado: 'pendiente' as Account['estado'],
    external_id: '',
    phone_number: '',
    ig_username: '',
    access_token: '',
    waba_id: '',
    page_id: '',
    notas: '',
  };
  const [form, setForm] = useState(empty);
  const set = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  const load = async () => {
    setLoading(true);
    const { data } = await (supabase as any).from('channel_accounts').select('*').order('created_at', { ascending: false });
    setAccounts((data ?? []) as Account[]);
    // Conv counts
    const { data: convs } = await (supabase as any).from('inbox_conversations').select('channel_account_id, saved_to_crm');
    const map: Record<string, { conv: number; leads: number }> = {};
    (convs ?? []).forEach((c: any) => {
      const k = c.channel_account_id || 'null';
      map[k] = map[k] || { conv: 0, leads: 0 };
      map[k].conv++;
      if (c.saved_to_crm) map[k].leads++;
    });
    setCounts(map);
    const { data: ca } = await (supabase as any).from('connected_accounts').select('*');
    const mlAccounts = (ca || [])
      .filter((x: any) => x.platform === 'mercadolibre')
      .sort((a: any, b: any) => {
        const aValid = a.status === 'conectado' && (!a.expires_at || new Date(a.expires_at).getTime() > Date.now());
        const bValid = b.status === 'conectado' && (!b.expires_at || new Date(b.expires_at).getTime() > Date.now());
        if (aValid !== bValid) return aValid ? -1 : 1;
        return new Date(b.updated_at || b.created_at).getTime() - new Date(a.updated_at || a.created_at).getTime();
      });
    setMlAccount(mlAccounts[0] || null);
    setFbAccounts((ca || []).filter((x: any) => x.platform === 'facebook'));
    setIgAccounts((ca || []).filter((x: any) => x.platform === 'instagram'));
    const { data: mlc } = await (supabase as any).from('ml_credentials').select('app_id,client_secret').maybeSingle();
    if (mlc) setMlCredentials({ app_id: mlc.app_id || '', client_secret: mlc.client_secret || '' });
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const connected = params.get('meta_connected');
    const error = params.get('meta_error');
    if (!connected && !error) return;
    if (connected) {
      toast({ title: '✓ Meta conectado', description: 'Las páginas de Facebook e Instagram ya están disponibles.' });
      load();
    } else if (error) {
      toast({ title: 'Meta rechazó la conexión', description: error, variant: 'destructive' });
    }
    window.history.replaceState({}, '', window.location.pathname);
  }, []);

  const saveMlCredentials = async () => {
    if (!user) return;
    if (!mlCredentials.app_id.trim()) { toast({ title: 'App ID requerido', variant: 'destructive' }); return; }
    try {
      const { data: existing } = await (supabase as any).from('ml_credentials').select('id').eq('user_id', user.id).maybeSingle();
      const payload = {
        user_id: user.id,
        app_id: mlCredentials.app_id.trim(),
        client_secret: mlCredentials.client_secret.trim(),
      };
      const { error } = existing
        ? await (supabase as any).from('ml_credentials').update(payload).eq('id', existing.id)
        : await (supabase as any).from('ml_credentials').insert(payload);
      if (error) throw error;
      toast({ title: 'Credenciales de Mercado Libre guardadas' });
    } catch (e: any) { toast({ title: 'Error', description: e.message, variant: 'destructive' }); }
  };

  // ---------- Embedded Signup de WhatsApp ----------
  const [esLoading, setEsLoading] = useState(false);
  const [fbReady, setFbReady] = useState(false);
  const [metaCfg, setMetaCfg] = useState<{ app_id: string; wa_config_id: string } | null>(null);
  const sessionInfoRef = useRef<{ waba_id?: string; phone_number_id?: string }>({});

  useEffect(() => {
    // Fetch Meta config (app_id + wa_config_id) desde edge function pública
    (async () => {
      try {
        const r = await fetch(`https://${import.meta.env.VITE_SUPABASE_PROJECT_ID}.supabase.co/functions/v1/meta-config`);
        const j = await r.json();
        if (j.app_id) setMetaCfg({ app_id: j.app_id, wa_config_id: j.wa_config_id || '' });
      } catch {}
    })();

    // Cargar Facebook JS SDK
    if (!document.getElementById('fb-sdk')) {
      const s = document.createElement('script');
      s.id = 'fb-sdk'; s.async = true; s.defer = true; s.crossOrigin = 'anonymous';
      s.src = 'https://connect.facebook.net/en_US/sdk.js';
      document.body.appendChild(s);
    }

    // Listener para WA_EMBEDDED_SIGNUP (devuelve waba_id + phone_number_id)
    const onMsg = (e: MessageEvent) => {
      if (e.origin !== 'https://www.facebook.com' && e.origin !== 'https://web.facebook.com') return;
      try {
        const data = typeof e.data === 'string' ? JSON.parse(e.data) : e.data;
        if (data?.type === 'WA_EMBEDDED_SIGNUP' && data?.event === 'FINISH') {
          sessionInfoRef.current = {
            waba_id: data.data?.waba_id,
            phone_number_id: data.data?.phone_number_id,
          };
        }
      } catch {}
    };
    window.addEventListener('message', onMsg);
    return () => window.removeEventListener('message', onMsg);
  }, []);

  useEffect(() => {
    if (!metaCfg?.app_id) return;
    const tryInit = () => {
      if (window.FB) {
        window.FB.init({ appId: metaCfg.app_id, autoLogAppEvents: true, xfbml: true, version: 'v23.0' });
        setFbReady(true);
      } else { setTimeout(tryInit, 300); }
    };
    tryInit();
  }, [metaCfg]);


  const launchEmbeddedSignup = () => {
    if (!fbReady || !metaCfg) { toast({ title: 'SDK no listo', description: 'Esperá unos segundos y reintentá.', variant: 'destructive' }); return; }
    if (!metaCfg.wa_config_id) { toast({ title: 'Falta configuración', description: 'No está configurado el ID de configuración de WhatsApp (META_WA_CONFIG_ID).', variant: 'destructive' }); return; }
    if (window.self !== window.top) { toast({ title: 'Abrí la app en una pestaña', description: 'Facebook bloquea el login dentro de la vista previa. Abrí la app en una ventana nueva y reintentá.', variant: 'destructive' }); return; }
    sessionInfoRef.current = {};
    setEsLoading(true);
    window.FB.login((response: any) => {
      (async () => {
        try {
          const code = response?.authResponse?.code;
          if (!code) throw new Error('Cancelaste o no se obtuvo el código.');
          let tries = 0;
          while (!sessionInfoRef.current.waba_id && tries < 15) { await new Promise(r => setTimeout(r, 400)); tries++; }
          const { waba_id, phone_number_id } = sessionInfoRef.current;
          if (!waba_id || !phone_number_id) throw new Error('No se recibieron datos de la WABA. Reintentá.');

          const { data: { session } } = await supabase.auth.getSession();
          const r = await fetch(`https://${import.meta.env.VITE_SUPABASE_PROJECT_ID}.supabase.co/functions/v1/meta-embedded-signup`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session?.access_token}` },
            body: JSON.stringify({ code, waba_id, phone_number_id }),
          });
          const j = await r.json();
          if (!r.ok) throw new Error(j.error || 'Error al conectar');
          toast({ title: '✓ WhatsApp conectado', description: j.phone || j.verified_name || 'Listo' });
          load();
        } catch (e: any) {
          toast({ title: 'Error', description: e.message, variant: 'destructive' });
        } finally { setEsLoading(false); }
      })();
    }, {
      config_id: metaCfg.wa_config_id,
      response_type: 'code',
      override_default_response_type: true,
      extras: { setup: {}, featureType: '', sessionInfoVersion: '3' },
    });
  };
  // ---------- Facebook + Instagram (FB JS SDK) ----------
  const [igLoading, setIgLoading] = useState(false);

  const launchFbIgConnect = async () => {
    if (!user) return;
    setIgLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('oauth-meta-start', {
        body: { return_to: window.location.origin },
      });
      if (error) throw error;
      if (!data?.authorizationUrl) throw new Error(data?.error || 'No se pudo iniciar la conexión');
      window.location.assign(data.authorizationUrl);
    } catch (e: any) {
      toast({ title: 'No se pudo abrir Meta', description: e.message, variant: 'destructive' });
      setIgLoading(false);
    }
  };

  // Instagram solo (Instagram Login, sin depender de Facebook)
  const launchIgOnlyConnect = async () => {
    if (!user) return;
    setIgLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('oauth-instagram-start', {
        body: { return_to: window.location.origin },
      });
      if (error) throw error;
      if (!data?.authorizationUrl) throw new Error(data?.error || 'No se pudo iniciar la conexión');
      window.location.assign(data.authorizationUrl);
    } catch (e: any) {
      toast({ title: 'No se pudo abrir Instagram', description: e.message, variant: 'destructive' });
      setIgLoading(false);
    }
  };
  // -------------------------------------------------



  const openNew = () => { setEditing(null); setForm(empty); setOpen(true); };
  const openEdit = (a: Account) => {
    setEditing(a);
    setForm({
      platform: a.platform,
      nombre_interno: a.nombre_interno,
      responsable: a.responsable ?? '',
      estado: a.estado,
      external_id: a.external_id ?? '',
      phone_number: a.phone_number ?? '',
      ig_username: a.ig_username ?? '',
      access_token: a.access_token ?? '',
      waba_id: a.waba_id ?? '',
      page_id: a.page_id ?? '',
      notas: a.notas ?? '',
    });
    setOpen(true);
  };

  const save = async () => {
    if (!form.nombre_interno.trim()) { toast({ title: 'Nombre interno requerido', variant: 'destructive' }); return; }
    const payload: any = {
      ...form,
      fecha_conexion: form.estado === 'conectado' ? new Date().toISOString() : null,
    };
    try {
      if (editing) {
        const { error } = await (supabase as any).from('channel_accounts').update(payload).eq('id', editing.id);
        if (error) throw error;
        toast({ title: 'Cuenta actualizada' });
      } else {
        const { error } = await (supabase as any).from('channel_accounts').insert({ ...payload, user_id: user!.id });
        if (error) throw error;
        toast({ title: 'Cuenta creada' });
      }
      setOpen(false); load();
    } catch (e: any) { toast({ title: 'Error', description: e.message, variant: 'destructive' }); }
  };

  const remove = async (id: string) => {
    if (!confirm('¿Eliminar esta cuenta? Las conversaciones quedan pero sin canal.')) return;
    await (supabase as any).from('channel_accounts').delete().eq('id', id);
    load();
  };

  const estadoBadge = (e: Account['estado']) => {
    const map: Record<string, { c: string; i: any }> = {
      conectado: { c: 'bg-green-500/15 text-green-600 border-green-500/30', i: CheckCircle2 },
      pendiente: { c: 'bg-amber-500/15 text-amber-600 border-amber-500/30', i: Clock },
      desconectado: { c: 'bg-muted text-muted-foreground', i: AlertCircle },
      error: { c: 'bg-destructive/15 text-destructive border-destructive/30', i: AlertCircle },
    };
    const v = map[e];
    const Ic = v.i;
    return <Badge variant="outline" className={v.c}><Ic className="w-3 h-3 mr-1" />{e}</Badge>;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="page-header">Canales conectados</h1>
        <Button size="sm" variant="outline" onClick={openNew}><Plus className="w-4 h-4 mr-1" />Conectar manual (avanzado)</Button>
      </div>

      <Card className="border-green-500/40 bg-gradient-to-br from-green-500/5 to-emerald-500/5">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Zap className="w-4 h-4 text-green-600" />
            Conectar WhatsApp en 1 click
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            Iniciá sesión con Facebook, elegí tu cuenta de WhatsApp Business y tu número.
            Nosotros nos encargamos del token, el webhook y el registro. <strong>Sin pegar nada.</strong>
          </p>
          <Button
            onClick={launchEmbeddedSignup}
            disabled={esLoading || !fbReady || !metaCfg?.wa_config_id}
            className="bg-[#1877F2] hover:bg-[#1565d8] text-white"
          >
            {esLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <MessageCircle className="w-4 h-4 mr-2" />}
            {esLoading ? 'Conectando…' : 'Iniciar sesión con Facebook'}
          </Button>
          {!metaCfg?.wa_config_id && (
            <p className="text-xs text-amber-600">Falta configurar <code>META_WA_CONFIG_ID</code> en los secretos.</p>
          )}
        </CardContent>
      </Card>

      <Card className="border-pink-500/40 bg-gradient-to-br from-pink-500/5 to-blue-500/5">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Instagram className="w-4 h-4 text-pink-600" />
            Redes Sociales — Facebook + Instagram
            {(fbAccounts.length > 0 || igAccounts.length > 0) && (
              <Badge className="bg-green-500/15 text-green-700 border-green-500/30 ml-1"><CheckCircle2 className="w-3 h-3 mr-1" /> Conectado</Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            Iniciá sesión con Meta y autorizá tus páginas y cuentas de Instagram Business. Después podés
            <strong> publicar autos con fotos + descripción</strong> en Facebook, Instagram o ambas.
          </p>

          {(fbAccounts.length > 0 || igAccounts.length > 0) && (
            <div className="space-y-2 rounded-md border bg-background/50 p-3">
              {fbAccounts.map((a: any) => (
                <div key={a.id} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-blue-600" />
                    <span className="font-medium">FB · {a.account_name}</span>
                    <Badge variant="outline" className="text-[10px] bg-green-500/10 text-green-700 border-green-500/30">
                      {a.status === 'conectado' ? 'conectado' : a.status}
                    </Badge>
                    {a.updated_at && <span className="text-xs text-muted-foreground">desde {formatDate(a.updated_at)}</span>}
                  </div>
                  <Button size="sm" variant="ghost" onClick={async () => {
                    if (!confirm(`¿Desconectar Facebook ${a.account_name}?`)) return;
                    await (supabase as any).from('connected_accounts').delete().eq('id', a.id);
                    load();
                  }}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                </div>
              ))}
              {igAccounts.map((a: any) => (
                <div key={a.id} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-pink-600" />
                    <span className="font-medium">IG · @{a.account_name}</span>
                    <Badge variant="outline" className="text-[10px] bg-green-500/10 text-green-700 border-green-500/30">
                      {a.status === 'conectado' ? 'conectado' : a.status}
                    </Badge>
                    {a.updated_at && <span className="text-xs text-muted-foreground">desde {formatDate(a.updated_at)}</span>}
                  </div>
                  <Button size="sm" variant="ghost" onClick={async () => {
                    if (!confirm(`¿Desconectar Instagram @${a.account_name}?`)) return;
                    await (supabase as any).from('connected_accounts').delete().eq('id', a.id);
                    load();
                  }}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                </div>
              ))}
            </div>
          )}

          <div className="grid gap-2 sm:grid-cols-2">
            <Button
              onClick={launchFbIgConnect}
              disabled={igLoading || !fbReady || !metaCfg?.app_id}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {igLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <MessageCircle className="w-4 h-4 mr-2" />}
              {igLoading ? 'Conectando…' : fbAccounts.length > 0 ? 'Reconectar Facebook' : 'Conectar Facebook'}
            </Button>
            <Button
              onClick={launchFbIgConnect}
              disabled={igLoading || !fbReady || !metaCfg?.app_id}
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 text-white"
            >
              {igLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Instagram className="w-4 h-4 mr-2" />}
              {igLoading ? 'Conectando…' : igAccounts.length > 0 ? 'Reconectar Instagram' : 'Conectar Instagram (vía Facebook)'}
            </Button>
          </div>
          <Button
            variant="outline"
            onClick={launchIgOnlyConnect}
            disabled={igLoading}
            className="w-full"
          >
            {igLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Instagram className="w-4 h-4 mr-2" />}
            Conectar solo Instagram (sin Facebook)
          </Button>
          <p className="text-xs text-muted-foreground">
            La opción “vía Facebook” usa la Página vinculada. “Solo Instagram” inicia sesión directo con tu cuenta profesional de Instagram.
          </p>
          {!metaCfg?.app_id && (
            <p className="text-xs text-amber-600">Falta configurar <code>META_APP_ID</code> en los secretos.</p>
          )}

        </CardContent>
      </Card>

      <Card className="border-yellow-500/40 bg-gradient-to-br from-yellow-500/5 to-amber-500/5">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Zap className="w-4 h-4 text-yellow-600" />
            Mercado Libre
            {mlAccount && <Badge className={mlAccount.status === 'conectado' && (!mlAccount.expires_at || new Date(mlAccount.expires_at).getTime() > Date.now()) ? "bg-green-500/15 text-green-700 border-green-500/30 ml-2" : "bg-destructive/15 text-destructive border-destructive/30 ml-2"}><CheckCircle2 className="w-3 h-3 mr-1" /> {mlAccount.status === 'conectado' && (!mlAccount.expires_at || new Date(mlAccount.expires_at).getTime() > Date.now()) ? 'Conectado' : 'Reconexión necesaria'}</Badge>}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {mlAccount ? (
            <>
              <div className="text-sm">
                <div><strong>Usuario:</strong> {mlAccount.meta?.nickname || '—'}</div>
                <div className="text-xs text-muted-foreground">Site: {mlAccount.meta?.site_id || 'MLA'} · Conectado el {new Date(mlAccount.created_at).toLocaleString()}</div>
                {mlAccount.expires_at && new Date(mlAccount.expires_at).getTime() <= Date.now() && !mlAccount.refresh_token && (
                  <p className="mt-2 text-xs text-destructive">La autorización venció y esta conexión anterior no tiene renovación automática. Reconectala ahora.</p>
                )}
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={async () => {
                    if (!confirm('¿Desconectar Mercado Libre?')) return;
                    await (supabase as any).from('connected_accounts').delete().eq('id', mlAccount.id);
                    setMlAccount(null);
                    toast({ title: 'Desconectado' });
                  }}
                >
                  <Trash2 className="w-3.5 h-3.5 mr-1" /> Desconectar
                </Button>
                <Button size="sm" onClick={async () => {
                  try {
                    const { data, error } = await supabase.functions.invoke('oauth-mercadolibre-start', {
                      body: { return_to: window.location.origin },
                    });
                    if (error) throw error;
                    if (!data?.authorizationUrl) throw new Error(data?.error || 'No se pudo iniciar la conexión');
                    window.location.assign(data.authorizationUrl);
                  } catch (error: any) {
                    toast({ title: 'No se pudo reconectar', description: error.message, variant: 'destructive' });
                  }
                }}><Zap className="w-3.5 h-3.5 mr-1" /> Reconectar</Button>
              </div>
            </>
          ) : (
            <>
              <div className="rounded-md border bg-background/50 p-3 space-y-3">
                <div className="text-sm font-medium">Configurar credenciales de Mercado Libre</div>
                <div className="grid gap-2">
                  <div>
                    <Label className="text-xs">App ID de Mercado Libre *</Label>
                    <Input
                      value={mlCredentials.app_id}
                      onChange={e => setMlCredentials(c => ({ ...c, app_id: e.target.value }))}
                      placeholder="Ej: 1234567890"
                    />
                  </div>
                  <div>
                    <Label className="text-xs">Client Secret</Label>
                    <Input
                      type="password"
                      value={mlCredentials.client_secret}
                      onChange={e => setMlCredentials(c => ({ ...c, client_secret: e.target.value }))}
                      placeholder="Solo si querés sobreescribir el global"
                    />
                  </div>
                  <Button size="sm" variant="secondary" onClick={saveMlCredentials}>
                    Guardar credenciales
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Si no cargás nada, se usa el App ID global del proyecto.
                </p>
              </div>
              <p className="text-sm text-muted-foreground">
                Iniciá sesión en Mercado Libre y autorizá la app. Quedan listas las publicaciones automáticas con tus tipos de aviso.
              </p>
              <Button
                onClick={async () => {
                  try {
                    const { data, error } = await supabase.functions.invoke('oauth-mercadolibre-start', {
                      body: { return_to: window.location.origin },
                    });
                    if (error) throw error;
                    if (data?.error) throw new Error(data.error);
                    if (!data?.authorizationUrl) throw new Error('No se pudo iniciar la conexión');
                    window.location.assign(data.authorizationUrl);
                  } catch (e: any) {
                    toast({ title: 'Error conectando Mercado Libre', description: e.message, variant: 'destructive' });
                  }
                }}
                className="bg-yellow-500 hover:bg-yellow-600 text-black"
              >
                <Zap className="w-4 h-4 mr-2" /> Iniciar sesión con Mercado Libre
              </Button>
            </>
          )}
        </CardContent>
      </Card>








      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-sm">Webhook para Meta</CardTitle></CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p className="text-muted-foreground">Pegá esto al configurar el webhook de WhatsApp Business o Instagram en Meta for Developers:</p>
          <div className="flex items-center gap-2 bg-muted/50 rounded p-2 font-mono text-xs">
            <span className="flex-1 break-all">{WEBHOOK_URL}</span>
            <Button size="sm" variant="ghost" onClick={() => { navigator.clipboard.writeText(WEBHOOK_URL); toast({ title: 'Copiado' }); }}><Copy className="w-3 h-3" /></Button>
          </div>
          <div className="flex items-center gap-2 bg-muted/50 rounded p-2 font-mono text-xs">
            <span>Verify token: <strong>{VERIFY_TOKEN}</strong></span>
            <Button size="sm" variant="ghost" onClick={() => { navigator.clipboard.writeText(VERIFY_TOKEN); toast({ title: 'Copiado' }); }}><Copy className="w-3 h-3" /></Button>
          </div>
          <p className="text-xs text-muted-foreground">Suscribite a los campos <code>messages</code> (WhatsApp) y <code>messages</code> (Instagram).</p>
        </CardContent>
      </Card>

      <div className="grid gap-3 sm:grid-cols-2">
        {accounts.map(a => {
          const c = counts[a.id] ?? { conv: 0, leads: 0 };
          const Ic = a.platform === 'whatsapp' ? MessageCircle : Instagram;
          return (
            <Card key={a.id}>
              <CardHeader className="pb-2 flex flex-row items-start justify-between space-y-0">
                <div className="space-y-1">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Ic className={`w-4 h-4 ${a.platform === 'whatsapp' ? 'text-green-600' : 'text-pink-600'}`} />
                    {a.nombre_interno}
                  </CardTitle>
                  <div className="text-xs text-muted-foreground">{a.platform === 'whatsapp' ? a.phone_number : a.ig_username}</div>
                </div>
                <div className="flex items-center gap-1">
                  <Button size="sm" variant="ghost" onClick={() => openEdit(a)}><Pencil className="w-3.5 h-3.5" /></Button>
                  <Button size="sm" variant="ghost" onClick={() => remove(a.id)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex items-center gap-2">{estadoBadge(a.estado)}{a.responsable && <span className="text-xs text-muted-foreground">· {a.responsable}</span>}</div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div><span className="text-muted-foreground">Conversaciones:</span> <strong>{c.conv}</strong></div>
                  <div><span className="text-muted-foreground">Leads:</span> <strong>{c.leads}</strong></div>
                </div>
                {a.fecha_conexion && <div className="text-xs text-muted-foreground">Conectado: {formatDate(a.fecha_conexion)}</div>}
              </CardContent>
            </Card>
          );
        })}
        {!loading && accounts.length === 0 && (
          <Card className="sm:col-span-2"><CardContent className="py-8 text-center text-sm text-muted-foreground">Aún no hay cuentas conectadas.</CardContent></Card>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-auto">
          <DialogHeader><DialogTitle>{editing ? 'Editar canal' : 'Conectar canal'}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label>Plataforma</Label>
                <Select value={form.platform} onValueChange={v => set('platform', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="whatsapp">WhatsApp</SelectItem>
                    <SelectItem value="instagram">Instagram</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Estado</Label>
                <Select value={form.estado} onValueChange={v => set('estado', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pendiente">Pendiente</SelectItem>
                    <SelectItem value="conectado">Conectado</SelectItem>
                    <SelectItem value="desconectado">Desconectado</SelectItem>
                    <SelectItem value="error">Error</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Nombre interno *</Label><Input value={form.nombre_interno} onChange={e => set('nombre_interno', e.target.value)} placeholder="WhatsApp Ventas Juan" /></div>
            <div><Label>Responsable</Label><Input value={form.responsable} onChange={e => set('responsable', e.target.value)} placeholder="Juan Pérez" /></div>
            {form.platform === 'whatsapp' ? (
              <>
                <div><Label>Número de teléfono</Label><Input value={form.phone_number} onChange={e => set('phone_number', e.target.value)} placeholder="+54 11 1234 5678" /></div>
                <div><Label>Phone Number ID (Meta) *</Label><Input value={form.external_id} onChange={e => set('external_id', e.target.value)} placeholder="123456789012345" /></div>
                <div><Label>WABA ID</Label><Input value={form.waba_id} onChange={e => set('waba_id', e.target.value)} /></div>
                <div><Label>Access Token (System User)</Label><Input type="password" value={form.access_token} onChange={e => set('access_token', e.target.value)} /></div>
              </>
            ) : (
              <>
                <div><Label>Usuario Instagram</Label><Input value={form.ig_username} onChange={e => set('ig_username', e.target.value)} placeholder="@miempresa" /></div>
                <div><Label>Instagram User ID *</Label><Input value={form.external_id} onChange={e => set('external_id', e.target.value)} placeholder="17841400000000000" /></div>
                <div><Label>Page ID (Facebook)</Label><Input value={form.page_id} onChange={e => set('page_id', e.target.value)} /></div>
                <div><Label>Page Access Token</Label><Input type="password" value={form.access_token} onChange={e => set('access_token', e.target.value)} /></div>
              </>
            )}
            <Button onClick={save} className="w-full">{editing ? 'Actualizar' : 'Guardar'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
