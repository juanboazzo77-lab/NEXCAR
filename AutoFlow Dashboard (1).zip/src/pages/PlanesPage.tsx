import { Link } from "react-router-dom";
import { Check, Lock, Crown, Star } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { usePlan } from "@/hooks/usePlan";
import { FEATURE_LABELS, FeatureKey, PLANS, PLAN_ORDER, fmtLimit } from "@/lib/plans";

const FEATURE_ROWS: FeatureKey[] = [
  "financiero", "cotizador", "pdfs", "turnos", "stats",
  "ia_ventas", "ia_documentos", "boleto", "vendedor", "duenio", "proveedor",
];

export default function PlanesPage() {
  const { planCode } = usePlan();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Planes</h1>
        <p className="text-sm text-muted-foreground">Compará las funciones incluidas en cada plan de suscripción.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {PLAN_ORDER.map((code) => {
          const p = PLANS[code];
          const actual = code === planCode;
          const recomendado = code === "advanced";
          return (
            <Card key={code} className={recomendado ? "border-primary shadow-md" : undefined}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    {code === "pro" && <Crown className="w-4 h-4 text-yellow-500" />}
                    {code === "advanced" && <Star className="w-4 h-4 text-primary" />}
                    Plan {p.name}
                  </CardTitle>
                  {actual && <Badge>Tu plan</Badge>}
                  {!actual && recomendado && <Badge variant="secondary">Recomendado</Badge>}
                </div>
                {/* Espacio reservado para precios y contratación */}
                <div className="text-sm text-muted-foreground mt-1">Precio a confirmar</div>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="grid grid-cols-3 gap-2 text-center">
                  <Metric label="Marketplace" value={fmtLimit(p.max_marketplace)} />
                  <Metric label="ORO" value={String(p.max_gold)} />
                  <Metric label="PLATA" value={p.max_marketplace == null ? "∞" : String(p.max_marketplace - p.max_gold)} />
                </div>
                <ul className="space-y-1">
                  {FEATURE_ROWS.map((f) => (
                    <li key={f} className="flex items-center gap-2">
                      {p.features[f]
                        ? <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                        : <Lock className="w-4 h-4 text-muted-foreground shrink-0" />}
                      <span className={p.features[f] ? "" : "text-muted-foreground line-through"}>{FEATURE_LABELS[f]}</span>
                    </li>
                  ))}
                </ul>
                <Button className="w-full" variant={actual ? "outline" : recomendado ? "default" : "secondary"} disabled={actual} asChild={!actual}>
                  {actual ? <span>Plan actual</span> : <Link to="/mi-agencia">Solicitar upgrade</Link>}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Comparación rápida</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left border-b">
                <th className="py-2 pr-4 font-medium">Función</th>
                {PLAN_ORDER.map((c) => <th key={c} className="py-2 px-3 font-medium">{PLANS[c].name}</th>)}
              </tr>
            </thead>
            <tbody>
              <Row label="Publicaciones Marketplace" values={PLAN_ORDER.map((c) => fmtLimit(PLANS[c].max_marketplace))} />
              <Row label="Publicaciones ORO" values={PLAN_ORDER.map((c) => String(PLANS[c].max_gold))} />
              <Row label="Prioridad en Marketplace" values={PLAN_ORDER.map((c) => (PLANS[c].features.marketplace_priority ? "Sí" : "No"))} />
              {FEATURE_ROWS.map((f) => (
                <Row key={f} label={FEATURE_LABELS[f]} values={PLAN_ORDER.map((c) => (PLANS[c].features[f] ? "Sí" : "No"))} />
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border p-2">
      <div className="text-[10px] uppercase text-muted-foreground">{label}</div>
      <div className="font-bold">{value}</div>
    </div>
  );
}

function Row({ label, values }: { label: string; values: string[] }) {
  return (
    <tr className="border-b last:border-0">
      <td className="py-2 pr-4">{label}</td>
      {values.map((v, i) => (
        <td key={i} className={`py-2 px-3 ${v === "No" ? "text-muted-foreground" : ""}`}>{v}</td>
      ))}
    </tr>
  );
}
