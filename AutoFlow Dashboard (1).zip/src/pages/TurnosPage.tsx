import { Card, CardContent } from "@/components/ui/card";
import { ExternalLink, CalendarCheck } from "lucide-react";

type Turno = { label: string; url: string; desc: string };

const GRUPOS: { titulo: string; items: Turno[] }[] = [
  {
    titulo: "Registro Automotor (DNRPA)",
    items: [
      { label: "DIRECCIÓN NACIONAL", url: "https://www2.jus.gov.ar/dnrpa-site/#!/", desc: "Sitio oficial DNRPA: turnos, trámites e informes" },
      { label: "Formularios / Solicitudes Tipo", url: "https://www.dnrpa.gov.ar/portal_dnrpa/form-libres2.php", desc: "Descarga de formularios oficiales" },
    ],
  },
  {
    titulo: "VTV (Verificación Técnica)",
    items: [
      { label: "VTV Provincia de Buenos Aires", url: "https://vtv.gba.gob.ar/", desc: "Sacar turno VTV en Prov. de Bs. As." },
    ],
  },
  {
    titulo: "Verificación Policial (VPA)",
    items: [
      { label: "VPA Provincia de Bs. As.", url: "https://vpa.mseg.gba.gov.ar/", desc: "Turnos de verificación policial en la Provincia" },
    ],
  },
  {
    titulo: "Patentes / Impuesto automotor",
    items: [
      { label: "ARBA (Prov. de Bs. As.)", url: "https://www.arba.gov.ar/", desc: "Impuesto automotor Provincia" },
      { label: "AGIP Patentes (CABA)", url: "https://www.agip.gob.ar/impuestos/patentes-sobre-vehiculos-en-general", desc: "Impuesto de patentes Ciudad" },
    ],
  },
  {
    titulo: "Infracciones",
    items: [
      { label: "Consulta de infracciones", url: "https://www.argentina.gob.ar/seguridadvial/licencianacional/consulta-de-infracciones", desc: "Multas e infracciones de tránsito" },
    ],
  },
];


export default function TurnosPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-header flex items-center gap-2"><CalendarCheck className="w-5 h-5" />Turnos</h1>
        <p className="text-sm text-muted-foreground">Accesos directos a sitios oficiales para trámites y turnos de autos en Argentina.</p>
      </div>

      {GRUPOS.map(grupo => (
        <div key={grupo.titulo} className="space-y-2">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">{grupo.titulo}</h2>
          <div className="grid sm:grid-cols-2 gap-3">
            {grupo.items.map(link => (
              <a key={link.url} href={link.url} target="_blank" rel="noopener noreferrer">
                <Card className="hover:border-primary/50 transition-colors cursor-pointer h-full">
                  <CardContent className="p-4 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="text-sm font-medium truncate">{link.label}</div>
                      <div className="text-xs text-muted-foreground">{link.desc}</div>
                    </div>
                    <ExternalLink className="w-4 h-4 text-muted-foreground shrink-0" />
                  </CardContent>
                </Card>
              </a>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
