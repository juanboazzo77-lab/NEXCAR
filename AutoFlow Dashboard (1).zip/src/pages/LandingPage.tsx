import { useNavigate } from "react-router-dom";
import { usePublicSettings } from "./public/PublicLayout";
import { Briefcase, Store } from "lucide-react";

export default function LandingPage() {
  const navigate = useNavigate();
  const s = usePublicSettings();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white flex flex-col">
      <header className="px-6 py-5 flex items-center gap-3">
        <div className="font-semibold tracking-tight">{s.nombre_agencia}</div>
      </header>


      <main className="flex-1 grid place-items-center px-6 pb-16">
        <div className="w-full max-w-3xl text-center">
          <h1 className="text-3xl sm:text-5xl font-bold tracking-tight">
            Bienvenido a NEXCAR
          </h1>
          <p className="mt-3 text-slate-300 text-base sm:text-lg">
            Encontra el auto que tanto buscas
          </p>

          <div className="mt-10 flex justify-center">
            <button
              onClick={() => navigate("/marketplace")}
              className="group w-full max-w-md rounded-2xl bg-white text-slate-900 p-7 text-left hover:scale-[1.02] transition shadow-xl"
            >
              <div className="w-12 h-12 rounded-xl bg-emerald-500 text-white grid place-items-center mb-4">
                <Store className="w-6 h-6" />
              </div>
              <div className="text-xl font-semibold">Sí, soy cliente</div>
              <p className="text-sm text-slate-600 mt-1">
                Entrá al Marketplace y mirá los vehículos de todas las agencias.
              </p>
              <div className="mt-5 text-sm font-medium text-emerald-600 group-hover:translate-x-1 transition">
                Ir al Marketplace →
              </div>
            </button>
          </div>





          <button
            onClick={() => navigate("/login")}
            className="mt-8 inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white underline underline-offset-4 transition"
          >
            <Briefcase className="w-3.5 h-3.5" />
            Soy administrador de una agencia
          </button>
        </div>
      </main>
    </div>
  );
}
