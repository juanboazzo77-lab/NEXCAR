import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, Car as CarIcon } from "lucide-react";

type Car = any;

const STATUS_COLORS: Record<string, string> = {
  borrador: "bg-muted text-muted-foreground",
  publicando: "bg-blue-500/15 text-blue-600",
  publicado: "bg-green-500/15 text-green-600",
  error: "bg-red-500/15 text-red-600",
  pausado: "bg-amber-500/15 text-amber-600",
};

export default function AutosPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [cars, setCars] = useState<Car[]>([]);
  const [photos, setPhotos] = useState<Record<string, string>>({});
  const [pubs, setPubs] = useState<Record<string, Record<string, string>>>({});
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [fMarca, setFMarca] = useState("all");
  const [fEstado, setFEstado] = useState("all");
  const [fPlat, setFPlat] = useState("all");

  const load = async () => {
    setLoading(true);
    const { data: c } = await supabase.from("cars").select("*").order("created_at", { ascending: false });
    setCars(c || []);
    const ids = (c || []).map((x: any) => x.id);
    if (ids.length) {
      const { data: ph } = await supabase.from("car_photos").select("car_id, url, es_portada, orden").in("car_id", ids).order("es_portada", { ascending: false }).order("orden");
      const map: Record<string, string> = {};
      (ph || []).forEach((p: any) => { if (!map[p.car_id]) map[p.car_id] = p.url; });
      setPhotos(map);
      const { data: vp } = await supabase.from("vehicle_publications").select("car_id, platform, status").in("car_id", ids);
      const pm: Record<string, Record<string, string>> = {};
      (vp || []).forEach((p: any) => { pm[p.car_id] = pm[p.car_id] || {}; pm[p.car_id][p.platform] = p.status; });
      setPubs(pm);
    }
    setLoading(false);
  };
  useEffect(() => { load(); }, [user]);

  const marcas = Array.from(new Set(cars.map(c => c.marca).filter((m): m is string => !!m && m.trim() !== ""))).sort();
  const filtered = cars.filter(c => {
    if (q && !`${c.marca} ${c.modelo} ${c.version || ''} ${c.patente || ''}`.toLowerCase().includes(q.toLowerCase())) return false;
    if (fMarca !== "all" && c.marca !== fMarca) return false;
    if (fEstado !== "all" && c.estado !== fEstado) return false;
    if (fPlat !== "all") {
      const s = pubs[c.id]?.[fPlat];
      if (!s) return false;
    }
    return true;
  });

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Publicador de Autos</h1>
          <p className="text-sm text-muted-foreground">Cargá un vehículo una sola vez y publicalo automáticamente en Mercado Libre, Instagram y Facebook.</p>
        </div>
        <Button onClick={() => navigate("/autos/nuevo")}><Plus className="w-4 h-4" /> Nuevo auto</Button>
      </div>

      <Card className="p-3 flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={e => setQ(e.target.value)} placeholder="Buscar marca, modelo, patente…" className="pl-9" />
        </div>
        <Select value={fMarca} onValueChange={setFMarca}>
          <SelectTrigger className="w-36"><SelectValue placeholder="Marca" /></SelectTrigger>
          <SelectContent><SelectItem value="all">Todas las marcas</SelectItem>{marcas.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={fEstado} onValueChange={setFEstado}>
          <SelectTrigger className="w-40"><SelectValue placeholder="Estado" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los estados</SelectItem>
            <SelectItem value="Disponible">Disponible</SelectItem>
            <SelectItem value="Reservado">Reservado</SelectItem>
            <SelectItem value="Vendido">Vendido</SelectItem>
            <SelectItem value="Pausado">Pausado</SelectItem>
          </SelectContent>
        </Select>
        <Select value={fPlat} onValueChange={setFPlat}>
          <SelectTrigger className="w-40"><SelectValue placeholder="Plataforma" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas plataformas</SelectItem>
            <SelectItem value="mercadolibre">Mercado Libre</SelectItem>
            <SelectItem value="instagram">Instagram</SelectItem>
            <SelectItem value="facebook">Facebook</SelectItem>
          </SelectContent>
        </Select>
      </Card>

      {loading ? <div className="text-muted-foreground text-sm">Cargando…</div> : filtered.length === 0 ? (
        <Card className="p-8 text-center text-muted-foreground">
          <CarIcon className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p>No hay autos cargados todavía.</p>
          <Button onClick={() => navigate("/autos/nuevo")} className="mt-3"><Plus className="w-4 h-4" /> Cargar primer auto</Button>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {filtered.map(c => (
            <Link to={`/autos/${c.id}`} key={c.id}>
              <Card className="overflow-hidden hover:shadow-md transition-shadow">
                <div className="aspect-video bg-muted relative">
                  {photos[c.id] ? <img src={photos[c.id]} className="w-full h-full object-cover" alt={c.modelo} /> : <CarIcon className="w-10 h-10 text-muted-foreground absolute inset-0 m-auto" />}
                </div>
                <div className="p-3 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="font-semibold truncate">{c.marca} {c.modelo}</div>
                      <div className="text-xs text-muted-foreground truncate">{c.version || '—'} · {c.anio} · {c.kilometros ? `${c.kilometros.toLocaleString()} km` : '—'}</div>
                    </div>
                    <Badge variant="outline" className="text-xs">{c.estado}</Badge>
                  </div>
                  <div className="text-lg font-bold">{c.precio_venta ? `${c.moneda || 'ARS'} ${Number(c.precio_venta).toLocaleString()}` : '—'}</div>
                  <div className="flex flex-wrap gap-1">
                    {(['mercadolibre', 'instagram', 'facebook'] as const).map(p => {
                      const s = pubs[c.id]?.[p];
                      const label = p === 'mercadolibre' ? 'ML' : p === 'instagram' ? 'IG' : 'FB';
                      return <Badge key={p} className={`text-[10px] ${s ? STATUS_COLORS[s] || '' : 'bg-muted text-muted-foreground'}`} variant="secondary">{label} · {s || 'sin publicar'}</Badge>;
                    })}
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
