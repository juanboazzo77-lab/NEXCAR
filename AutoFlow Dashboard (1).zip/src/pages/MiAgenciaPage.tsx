import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAgency } from "@/hooks/useAgency";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Building2, Copy, ExternalLink, Save } from "lucide-react";
import PlanUsageCard from "@/components/PlanUsageCard";
import { toast } from "sonner";

export default function MiAgenciaPage() {
  const { agency, subscription, loading, reload } = useAgency();
  const [form, setForm] = useState<any>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => { if (agency) setForm({ ...agency }); }, [agency?.id]);

  if (loading) return <div className="p-6 text-muted-foreground">Cargando...</div>;
  if (!agency || !form) {
    return (
      <div className="p-6 flex flex-col items-center justify-center text-center gap-3 min-h-[60vh]">
        <Building2 className="w-12 h-12 text-muted-foreground" />
        <h2 className="text-xl font-bold">Sin agencia asignada</h2>
        <p className="text-sm text-muted-foreground">Tu usuario todavía no está vinculado a una agencia.</p>
      </div>
    );
  }

  const set = (k: string, v: any) => setForm((f: any) => ({ ...f, [k]: v }));

  const save = async () => {
    setSaving(true);
    const { error } = await supabase.from("agencies").update({
      name: form.name,
      descripcion: form.descripcion,
      logo_url: form.logo_url,
      direccion: form.direccion,
      ciudad: form.ciudad,
      provincia: form.provincia,
      lat: form.lat === "" || form.lat == null ? null : Number(form.lat),
      lng: form.lng === "" || form.lng == null ? null : Number(form.lng),
      telefono: form.telefono,
      whatsapp: form.whatsapp,
      email: form.email,
      instagram_url: form.instagram_url,
      facebook_url: form.facebook_url,
      tiktok_url: form.tiktok_url,
      website_url: form.website_url,
      horarios: form.horarios,
      marketplace_visible: !!form.marketplace_visible,
    }).eq("id", agency.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Datos de la agencia guardados");
    reload();
  };

  const publicUrl = `${window.location.origin}/agencia/${agency.slug || agency.id}`;

  const useMyLocation = () => {
    if (!navigator.geolocation) return toast.error("Geolocalización no disponible");
    navigator.geolocation.getCurrentPosition(
      (p) => { set("lat", p.coords.latitude); set("lng", p.coords.longitude); toast.success("Ubicación tomada"); },
      () => toast.error("No pudimos obtener la ubicación")
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2"><Building2 className="w-6 h-6" /> Mi agencia</h1>
          <p className="text-sm text-muted-foreground">Datos públicos, ubicación y suscripción.</p>
        </div>
        <Button onClick={save} disabled={saving}><Save className="w-4 h-4 mr-2" />{saving ? "Guardando..." : "Guardar"}</Button>
      </div>

      <PlanUsageCard />

      <Card>
        <CardHeader><CardTitle className="text-base">Tu catálogo público</CardTitle></CardHeader>
        <CardContent className="flex flex-wrap items-center gap-2">
          <code className="text-xs bg-muted px-3 py-2 rounded-md break-all flex-1 min-w-[240px]">{publicUrl}</code>
          <Button variant="outline" size="sm" onClick={() => { navigator.clipboard.writeText(publicUrl); toast.success("Link copiado"); }}>
            <Copy className="w-4 h-4 mr-2" />Copiar
          </Button>
          <Button variant="outline" size="sm" asChild>
            <a href={publicUrl} target="_blank" rel="noreferrer"><ExternalLink className="w-4 h-4 mr-2" />Abrir</a>
          </Button>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Identidad</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div><Label>Nombre</Label><Input value={form.name || ""} onChange={(e) => set("name", e.target.value)} /></div>
            <div><Label>Logo (URL)</Label><Input value={form.logo_url || ""} onChange={(e) => set("logo_url", e.target.value)} /></div>
            <div><Label>Descripción</Label><Textarea rows={3} value={form.descripcion || ""} onChange={(e) => set("descripcion", e.target.value)} /></div>
            <div><Label>Horarios</Label><Input value={form.horarios || ""} onChange={(e) => set("horarios", e.target.value)} /></div>
            <div className="flex items-center justify-between rounded-md border p-3">
              <div>
                <div className="text-sm font-medium">Mostrar en el marketplace</div>
                <div className="text-xs text-muted-foreground">Tu stock aparece en el buscador general de todas las agencias.</div>
              </div>
              <Switch checked={!!form.marketplace_visible} onCheckedChange={(v) => set("marketplace_visible", v)} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Contacto y ubicación</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div><Label>WhatsApp</Label><Input value={form.whatsapp || ""} onChange={(e) => set("whatsapp", e.target.value)} placeholder="+549..." /></div>
              <div><Label>Teléfono</Label><Input value={form.telefono || ""} onChange={(e) => set("telefono", e.target.value)} /></div>
            </div>
            <div><Label>Email</Label><Input value={form.email || ""} onChange={(e) => set("email", e.target.value)} /></div>
            <div><Label>Dirección</Label><Input value={form.direccion || ""} onChange={(e) => set("direccion", e.target.value)} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Ciudad</Label><Input value={form.ciudad || ""} onChange={(e) => set("ciudad", e.target.value)} /></div>
              <div><Label>Provincia</Label><Input value={form.provincia || ""} onChange={(e) => set("provincia", e.target.value)} /></div>
            </div>
            <div className="grid grid-cols-3 gap-3 items-end">
              <div><Label>Latitud</Label><Input value={form.lat ?? ""} onChange={(e) => set("lat", e.target.value)} /></div>
              <div><Label>Longitud</Label><Input value={form.lng ?? ""} onChange={(e) => set("lng", e.target.value)} /></div>
              <Button variant="outline" onClick={useMyLocation}>Usar mi ubicación</Button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Instagram</Label><Input value={form.instagram_url || ""} onChange={(e) => set("instagram_url", e.target.value)} /></div>
              <div><Label>Facebook</Label><Input value={form.facebook_url || ""} onChange={(e) => set("facebook_url", e.target.value)} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>TikTok</Label><Input value={form.tiktok_url || ""} onChange={(e) => set("tiktok_url", e.target.value)} /></div>
              <div><Label>Sitio web</Label><Input value={form.website_url || ""} onChange={(e) => set("website_url", e.target.value)} /></div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Suscripción</CardTitle></CardHeader>
        <CardContent className="flex flex-wrap items-center gap-3 text-sm">
          <Badge variant={subscription?.status === "active" ? "default" : "secondary"}>{subscription?.status || "sin suscripción"}</Badge>
          <span className="font-medium">{subscription?.plan?.name || agency.plan || "—"}</span>
          {subscription?.current_period_end && (
            <span className="text-muted-foreground">
              Renueva el {new Date(subscription.current_period_end).toLocaleDateString("es-AR")}
            </span>
          )}
          {subscription?.plan?.max_vehicles != null && (
            <span className="text-muted-foreground">· Hasta {subscription.plan.max_vehicles} vehículos</span>
          )}
        </CardContent>
      </Card>

      <div className="sticky bottom-0 z-10 -mx-4 px-4 py-3 bg-background/90 backdrop-blur border-t flex items-center justify-end gap-3">
        <span className="text-xs text-muted-foreground mr-auto">Acordate de guardar los cambios antes de salir.</span>
        <Button size="lg" onClick={save} disabled={saving}>
          <Save className="w-4 h-4 mr-2" />{saving ? "Guardando..." : "Guardar cambios"}
        </Button>
      </div>
    </div>
  );
}
