import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useAgency } from "@/hooks/useAgency";
import { useToast } from "@/hooks/use-toast";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ExternalLink, Globe, Save, Plus, X } from "lucide-react";

export default function SitioPublicoPage() {
  const { user } = useAuth();
  const { agency, loading: agencyLoading } = useAgency();
  const { toast } = useToast();
  const [s, setS] = useState<any>({
    whatsapp_number: "+5491165361978",
    transferencia_porcentaje: 4,
    mostrar_vendidos: false,
    nombre_agencia: "Grupo Boazzo",
    logo_url: "",
    financiacion_activa: true,
    financiacion_tasa: 75,
    financiacion_cuotas_max: 60,
    financiacion_gastos_porcentaje: 0,
    nosotros_historia: "",
    nosotros_mision: "",
    nosotros_valores: "",
    nosotros_fotos: [],
    horarios: "",
    direccion: "",
    mapa_embed_url: "",
    telefono: "",
    email: "",
    instagram_url: "",
    facebook_url: "",
    tiktok_url: "",
    motivos: [],
    is_default: true,
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (agencyLoading) return;
    (async () => {
      let q = supabase.from("public_settings").select("*");
      // Cada agencia configura su propio sitio público
      q = agency?.id ? q.eq("agency_id", agency.id) : q.order("is_default", { ascending: false });
      const { data } = await q.limit(1).maybeSingle();
      if (data) {
        const d: any = data;
        setS((prev: any) => ({ ...prev, ...d, nosotros_fotos: Array.isArray(d.nosotros_fotos) ? d.nosotros_fotos : [], motivos: Array.isArray(d.motivos) ? d.motivos : [] }));
      }
    })();
  }, [agency?.id, agencyLoading]);

  const save = async () => {
    setLoading(true);
    const payload = { ...s, owner_user_id: s.owner_user_id || user?.id, agency_id: s.agency_id || agency?.id || null };
    let r;
    if (s.id) r = await supabase.from("public_settings").update(payload).eq("id", s.id).select().single();
    else r = await supabase.from("public_settings").insert({ ...payload, is_default: !agency?.id }).select().single();
    setLoading(false);
    if (r.error) return toast({ title: "Error", description: r.error.message, variant: "destructive" });
    setS({ ...s, ...r.data });
    toast({ title: "Configuración guardada" });
  };

  const publicUrl = `${window.location.origin}${agency?.slug ? `/agencia/${agency.slug}` : "/catalogo"}`;

  const set = (k: string, v: any) => setS({ ...s, [k]: v });

  return (
    <div className="space-y-4 max-w-4xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold flex items-center gap-2"><Globe className="w-5 h-5" /> Sitio público</h1>
          <p className="text-sm text-muted-foreground">Configurá el catálogo público de vehículos.</p>
        </div>
        <a href={publicUrl} target="_blank" rel="noreferrer">
          <Button variant="outline"><ExternalLink className="w-4 h-4" /> Ver sitio</Button>
        </a>
      </div>

      <Tabs defaultValue="general">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="financiacion">Financiación</TabsTrigger>
          <TabsTrigger value="nosotros">Sobre nosotros</TabsTrigger>
          <TabsTrigger value="motivos">¿Por qué elegirnos?</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card className="p-4 space-y-4 mt-2">
            <div><Label>Nombre de la agencia</Label><Input value={s.nombre_agencia || ""} onChange={(e) => set("nombre_agencia", e.target.value)} /></div>
            <div><Label>Logo (URL)</Label><Input value={s.logo_url || ""} onChange={(e) => set("logo_url", e.target.value)} placeholder="https://..." /></div>
            <div><Label>WhatsApp</Label><Input value={s.whatsapp_number || ""} onChange={(e) => set("whatsapp_number", e.target.value)} /></div>
            <div className="grid sm:grid-cols-2 gap-3">
              <div><Label>Teléfono</Label><Input value={s.telefono || ""} onChange={(e) => set("telefono", e.target.value)} /></div>
              <div><Label>Email</Label><Input value={s.email || ""} onChange={(e) => set("email", e.target.value)} /></div>
            </div>
            <div><Label>Dirección</Label><Input value={s.direccion || ""} onChange={(e) => set("direccion", e.target.value)} /></div>
            <div><Label>Horarios</Label><Input value={s.horarios || ""} onChange={(e) => set("horarios", e.target.value)} /></div>
            <div><Label>Mapa (URL embed Google Maps)</Label><Input value={s.mapa_embed_url || ""} onChange={(e) => set("mapa_embed_url", e.target.value)} placeholder="https://www.google.com/maps/embed?pb=..." /></div>
            <div className="grid sm:grid-cols-3 gap-3">
              <div><Label>Instagram</Label><Input value={s.instagram_url || ""} onChange={(e) => set("instagram_url", e.target.value)} /></div>
              <div><Label>Facebook</Label><Input value={s.facebook_url || ""} onChange={(e) => set("facebook_url", e.target.value)} /></div>
              <div><Label>TikTok</Label><Input value={s.tiktok_url || ""} onChange={(e) => set("tiktok_url", e.target.value)} /></div>
            </div>
            <div><Label>% transferencia estimada</Label><Input type="number" step="0.1" value={s.transferencia_porcentaje ?? 4} onChange={(e) => set("transferencia_porcentaje", Number(e.target.value))} /></div>
            <div className="flex items-center justify-between">
              <div><Label>Mostrar autos vendidos</Label><p className="text-xs text-muted-foreground">Marcados como tales.</p></div>
              <Switch checked={!!s.mostrar_vendidos} onCheckedChange={(v) => set("mostrar_vendidos", v)} />
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="financiacion">
          <Card className="p-4 space-y-4 mt-2">
            <div className="flex items-center justify-between">
              <div><Label>Mostrar simulador de financiación</Label><p className="text-xs text-muted-foreground">Aparece en cada ficha de auto.</p></div>
              <Switch checked={!!s.financiacion_activa} onCheckedChange={(v) => set("financiacion_activa", v)} />
            </div>
            <div className="grid sm:grid-cols-3 gap-3">
              <div><Label>Tasa anual %</Label><Input type="number" step="0.1" value={s.financiacion_tasa ?? 75} onChange={(e) => set("financiacion_tasa", Number(e.target.value))} /></div>
              <div><Label>Cuotas máximas</Label><Input type="number" value={s.financiacion_cuotas_max ?? 60} onChange={(e) => set("financiacion_cuotas_max", Number(e.target.value))} /></div>
              <div><Label>Gastos admin. %</Label><Input type="number" step="0.1" value={s.financiacion_gastos_porcentaje ?? 0} onChange={(e) => set("financiacion_gastos_porcentaje", Number(e.target.value))} /></div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="nosotros">
          <Card className="p-4 space-y-4 mt-2">
            <div><Label>Historia</Label><Textarea rows={4} value={s.nosotros_historia || ""} onChange={(e) => set("nosotros_historia", e.target.value)} /></div>
            <div><Label>Misión</Label><Textarea rows={3} value={s.nosotros_mision || ""} onChange={(e) => set("nosotros_mision", e.target.value)} /></div>
            <div><Label>Valores</Label><Textarea rows={3} value={s.nosotros_valores || ""} onChange={(e) => set("nosotros_valores", e.target.value)} /></div>
            <ListEditor label="Fotos del local / equipo (URLs)" placeholder="https://..."
              items={s.nosotros_fotos} onChange={(v) => set("nosotros_fotos", v)} />
          </Card>
        </TabsContent>

        <TabsContent value="motivos">
          <Card className="p-4 space-y-4 mt-2">
            <ListEditor label="Motivos para elegirnos" placeholder="Ej: Atención personalizada"
              items={s.motivos} onChange={(v) => set("motivos", v)} />
          </Card>
        </TabsContent>
      </Tabs>

      <Button onClick={save} disabled={loading}><Save className="w-4 h-4" /> Guardar todo</Button>

      <Card className="p-4 text-sm space-y-2">
        <div className="font-medium">Atajos rápidos</div>
        <div className="text-muted-foreground space-y-1">
          <div>• <Link to="/tasaciones" className="underline">Ver tasaciones</Link> recibidas desde el sitio.</div>
          <div>• <Link to="/alertas" className="underline">Ver alertas de clientes</Link> que buscan un auto.</div>
          <div>• <Link to="/faq-admin" className="underline">Editar Preguntas Frecuentes</Link>.</div>
        </div>
      </Card>
    </div>
  );
}

function ListEditor({ label, placeholder, items, onChange }: { label: string; placeholder: string; items: string[]; onChange: (v: string[]) => void }) {
  return (
    <div>
      <Label>{label}</Label>
      <div className="space-y-2 mt-1">
        {items.map((it, i) => (
          <div key={i} className="flex gap-2">
            <Input value={it} onChange={(e) => onChange(items.map((x, j) => j === i ? e.target.value : x))} placeholder={placeholder} />
            <Button variant="outline" size="icon" onClick={() => onChange(items.filter((_, j) => j !== i))}><X className="w-4 h-4" /></Button>
          </div>
        ))}
        <Button variant="outline" size="sm" onClick={() => onChange([...items, ""])}><Plus className="w-4 h-4" /> Agregar</Button>
      </div>
    </div>
  );
}
