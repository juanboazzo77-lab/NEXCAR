import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Eye, Heart, MessageSquare, Clock, TrendingUp, RefreshCw, Lightbulb, AlertTriangle } from "lucide-react";
import { useStockIntelligence } from "@/hooks/use-stock-intelligence";

const money = (v: number) => `$ ${Math.round(v || 0).toLocaleString("es-AR")}`;

export default function StockIntelligencePage() {
  const { cars, rotation, totals, loading, reload } = useStockIntelligence();
  const [q, setQ] = useState("");
  const [orden, setOrden] = useState<"dias" | "views" | "consultas">("dias");

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    return cars
      .filter((c) => c.estado !== "Vendido")
      .filter((c) => !t || `${c.marca} ${c.modelo} ${c.version || ""} ${c.patente || ""}`.toLowerCase().includes(t))
      .sort((a, b) =>
        orden === "views" ? b.views - a.views : orden === "consultas" ? b.consultas - a.consultas : b.dias - a.dias
      );
  }, [cars, q, orden]);

  const kpis = [
    { label: "Vehículos en stock", value: totals.vehiculos, icon: TrendingUp },
    { label: "Visualizaciones", value: totals.views.toLocaleString("es-AR"), icon: Eye },
    { label: "Favoritos", value: totals.favoritos, icon: Heart },
    { label: "Consultas", value: totals.consultas, icon: MessageSquare },
    { label: "Días promedio en stock", value: totals.diasPromedio, icon: Clock },
    { label: "Clavados (+60 días)", value: totals.clavados, icon: AlertTriangle },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2"><TrendingUp className="h-6 w-6 text-primary" /> Inteligencia de stock</h1>
          <p className="text-sm text-muted-foreground">Cómo se comporta cada vehículo publicado y qué conviene hacer con él.</p>
        </div>
        <Button variant="outline" onClick={reload} disabled={loading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} /> Actualizar
        </Button>
      </div>

      <div className="grid gap-3 grid-cols-2 lg:grid-cols-6">
        {kpis.map((k) => (
          <Card key={k.label}>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-xs text-muted-foreground"><k.icon className="h-3.5 w-3.5" />{k.label}</div>
              <div className="text-2xl font-bold mt-1">{k.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="vehiculos">
        <TabsList>
          <TabsTrigger value="vehiculos">Por vehículo</TabsTrigger>
          <TabsTrigger value="rotacion">Ranking de rotación</TabsTrigger>
        </TabsList>

        <TabsContent value="vehiculos" className="space-y-4 pt-4">
          <div className="flex gap-2 flex-wrap">
            <Input className="max-w-xs" placeholder="Buscar marca, modelo o patente" value={q} onChange={(e) => setQ(e.target.value)} />
            {(["dias", "views", "consultas"] as const).map((o) => (
              <Button key={o} size="sm" variant={orden === o ? "default" : "outline"} onClick={() => setOrden(o)}>
                {o === "dias" ? "Más días" : o === "views" ? "Más visitas" : "Más consultas"}
              </Button>
            ))}
          </div>

          {loading && <p className="text-sm text-muted-foreground">Cargando datos...</p>}
          {!loading && !filtered.length && <p className="text-sm text-muted-foreground">No hay vehículos para mostrar.</p>}

          <div className="grid gap-3">
            {filtered.map((c) => (
              <Card key={c.id}>
                <CardContent className="p-4 grid gap-3 lg:grid-cols-[1.2fr_auto_1.4fr] items-start">
                  <div>
                    <div className="font-semibold">{[c.marca, c.modelo, c.version, c.anio].filter(Boolean).join(" ")}</div>
                    <div className="text-xs text-muted-foreground">
                      {c.patente || "Sin patente"} · {c.precio_venta ? `${c.moneda === "USD" ? "USD" : "$"} ${Math.round(c.precio_venta).toLocaleString("es-AR")}` : "Sin precio"}
                    </div>
                    <div className="mt-2 flex gap-1.5 flex-wrap">
                      <Badge variant={c.dias >= 60 ? "destructive" : "secondary"}>Publicado hace {c.dias} días</Badge>
                      {c.marketplace_tier === "gold" && <Badge className="bg-amber-500 text-white hover:bg-amber-500">ORO</Badge>}
                      {!c.mostrar_publico && <Badge variant="outline">No visible</Badge>}
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-4 text-center">
                    {[
                      { v: c.views.toLocaleString("es-AR"), l: "visitas" },
                      { v: c.favoritos, l: "favoritos" },
                      { v: c.consultas, l: "consultas" },
                      { v: c.reservas, l: "reservas" },
                    ].map((m) => (
                      <div key={m.l}>
                        <div className="text-lg font-bold">{m.v}</div>
                        <div className="text-[11px] text-muted-foreground">{m.l}</div>
                      </div>
                    ))}
                  </div>

                  <ul className="space-y-1">
                    {c.sugerencias.map((s, i) => (
                      <li key={i} className="text-xs flex gap-1.5 text-muted-foreground">
                        <Lightbulb className="h-3.5 w-3.5 shrink-0 text-amber-500 mt-0.5" />{s}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="rotacion" className="pt-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Qué modelos rotan más rápido</CardTitle></CardHeader>
            <CardContent className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-muted-foreground border-b">
                    <th className="py-2">Modelo</th>
                    <th className="py-2 text-right">Vendidos</th>
                    <th className="py-2 text-right">Días prom. hasta venta</th>
                    <th className="py-2 text-right">Margen promedio</th>
                    <th className="py-2 text-right">En stock hoy</th>
                  </tr>
                </thead>
                <tbody>
                  {rotation.map((r) => (
                    <tr key={r.key} className="border-b last:border-0">
                      <td className="py-2 font-medium">{r.marca} {r.modelo}</td>
                      <td className="py-2 text-right">{r.vendidos}</td>
                      <td className="py-2 text-right">{r.vendidos ? r.diasPromedio : "—"}</td>
                      <td className="py-2 text-right">{r.margenPromedio ? money(r.margenPromedio) : "—"}</td>
                      <td className="py-2 text-right">{r.enStock}</td>
                    </tr>
                  ))}
                  {!rotation.length && <tr><td colSpan={5} className="py-4 text-muted-foreground">Sin datos todavía.</td></tr>}
                </tbody>
              </table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
