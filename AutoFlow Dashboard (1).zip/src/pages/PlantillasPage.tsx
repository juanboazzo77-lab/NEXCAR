import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, Copy } from "lucide-react";

type T = { id: string; categoria: string; titulo: string; contenido: string; shortcut: string | null };

const CATEGORIAS = [
  "Saludo inicial", "Consulta por página web", "Consulta por automatizaciones", "Consulta por IA",
  "Solicitud de información", "Envío de propuesta", "Seguimiento", "Objeciones", "Cierre", "Postventa"
];

export default function PlantillasPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [items, setItems] = useState<T[]>([]);
  const [filter, setFilter] = useState<string>("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<T | null>(null);
  const [form, setForm] = useState({ categoria: CATEGORIAS[0], titulo: '', contenido: '', shortcut: '' });
  const set = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  const load = async () => {
    const { data } = await (supabase as any).from('message_templates').select('*').order('categoria').order('titulo');
    setItems((data ?? []) as T[]);
  };
  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => filter === 'all' ? items : items.filter(i => i.categoria === filter), [items, filter]);
  const grouped = useMemo(() => {
    const map: Record<string, T[]> = {};
    filtered.forEach(i => { (map[i.categoria] = map[i.categoria] || []).push(i); });
    return map;
  }, [filtered]);

  const openNew = () => { setEditing(null); setForm({ categoria: CATEGORIAS[0], titulo: '', contenido: '', shortcut: '' }); setOpen(true); };
  const openEdit = (t: T) => { setEditing(t); setForm({ categoria: t.categoria, titulo: t.titulo, contenido: t.contenido, shortcut: t.shortcut ?? '' }); setOpen(true); };

  const save = async () => {
    if (!form.titulo.trim() || !form.contenido.trim()) { toast({ title: 'Título y contenido requeridos', variant: 'destructive' }); return; }
    const payload = { ...form, shortcut: form.shortcut || null };
    if (editing) await (supabase as any).from('message_templates').update(payload).eq('id', editing.id);
    else await (supabase as any).from('message_templates').insert({ ...payload, user_id: user!.id });
    setOpen(false); load();
  };
  const remove = async (id: string) => { if (!confirm('¿Eliminar?')) return; await (supabase as any).from('message_templates').delete().eq('id', id); load(); };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="page-header">Plantillas</h1>
        <Button size="sm" onClick={openNew}><Plus className="w-4 h-4 mr-1" />Nueva plantilla</Button>
      </div>

      <Select value={filter} onValueChange={setFilter}>
        <SelectTrigger className="sm:w-64"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Todas las categorías</SelectItem>
          {CATEGORIAS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
        </SelectContent>
      </Select>

      <div className="space-y-4">
        {Object.entries(grouped).map(([cat, list]) => (
          <div key={cat} className="space-y-2">
            <div className="flex items-center gap-2"><Badge variant="outline">{cat}</Badge><span className="text-xs text-muted-foreground">{list.length}</span></div>
            <div className="grid gap-2 sm:grid-cols-2">
              {list.map(t => (
                <Card key={t.id}>
                  <CardHeader className="pb-2 flex flex-row items-start justify-between space-y-0">
                    <CardTitle className="text-sm">{t.titulo}{t.shortcut && <span className="ml-2 text-xs text-muted-foreground">/{t.shortcut}</span>}</CardTitle>
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => { navigator.clipboard.writeText(t.contenido); toast({ title: 'Copiado' }); }}><Copy className="w-3.5 h-3.5" /></Button>
                      <Button size="sm" variant="ghost" onClick={() => openEdit(t)}><Pencil className="w-3.5 h-3.5" /></Button>
                      <Button size="sm" variant="ghost" onClick={() => remove(t.id)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                    </div>
                  </CardHeader>
                  <CardContent className="text-xs text-muted-foreground whitespace-pre-wrap">{t.contenido}</CardContent>
                </Card>
              ))}
            </div>
          </div>
        ))}
        {filtered.length === 0 && <Card><CardContent className="py-8 text-center text-sm text-muted-foreground">Sin plantillas. Creá la primera para que la IA pueda sugerirlas.</CardContent></Card>}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? 'Editar plantilla' : 'Nueva plantilla'}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Categoría</Label>
              <Select value={form.categoria} onValueChange={v => set('categoria', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CATEGORIAS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Título</Label><Input value={form.titulo} onChange={e => set('titulo', e.target.value)} /></div>
            <div><Label>Atajo (opcional)</Label><Input value={form.shortcut} onChange={e => set('shortcut', e.target.value)} placeholder="saludo, propuesta..." /></div>
            <div><Label>Contenido</Label><Textarea rows={5} value={form.contenido} onChange={e => set('contenido', e.target.value)} /></div>
            <Button onClick={save} className="w-full">{editing ? 'Actualizar' : 'Guardar'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
