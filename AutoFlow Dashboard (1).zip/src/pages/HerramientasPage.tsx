import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ExternalLink, Bell } from "lucide-react";

const LINKS = [
  { label: "DIRECCIÓN NACIONAL", url: "https://www2.jus.gov.ar/dnrpa-site/#!/", desc: "DNRPA: turnos, trámites e informes" },
  { label: "Consulta de multas", url: "https://www.argentina.gob.ar/seguridadvial/licencianacional/consulta-de-infracciones", desc: "Infracciones de tránsito" },
];


export default function HerramientasPage() {
  return (
    <div className="space-y-4">
      <h1 className="page-header">Herramientas</h1>

      <div className="grid sm:grid-cols-2 gap-3">
        {LINKS.map(link => (
          <a key={link.url} href={link.url} target="_blank" rel="noopener noreferrer">
            <Card className="hover:border-primary/50 transition-colors cursor-pointer">
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium">{link.label}</div>
                  <div className="text-xs text-muted-foreground">{link.desc}</div>
                </div>
                <ExternalLink className="w-4 h-4 text-muted-foreground" />
              </CardContent>
            </Card>
          </a>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Bell className="w-4 h-4" />Alertas de cuotas</CardTitle></CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">Las alertas de cuotas vencidas se mostrarán automáticamente en la sección de Ventas cuando un pago esté pendiente.</p>
        </CardContent>
      </Card>
    </div>
  );
}
