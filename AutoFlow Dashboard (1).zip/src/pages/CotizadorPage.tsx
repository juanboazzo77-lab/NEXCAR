import { ExternalLink } from "lucide-react";

const CALC_URL = "https://app.emaautos.com/calculatorForm/e338e935-8b57-48bf-8300-a1d88916b2a4";

export default function CotizadorPage() {
  return (
    <div className="space-y-4 h-full flex flex-col">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Cotizador de financiación</h1>
          <p className="text-sm text-muted-foreground">
            Simulador oficial de EMA Autos — precios exactos y aptitud crediticia.
          </p>
        </div>
        <a
          href={CALC_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-3 py-2 rounded-md bg-primary text-primary-foreground text-sm hover:opacity-90"
        >
          Abrir en pestaña nueva <ExternalLink className="w-4 h-4" />
        </a>
      </div>

      <div className="flex-1 min-h-[calc(100vh-180px)] rounded-lg overflow-hidden border bg-card">
        <iframe
          src={CALC_URL}
          title="Cotizador EMA Autos"
          className="w-full h-full"
          style={{ minHeight: "calc(100vh - 180px)" }}
          allow="clipboard-write"
        />
      </div>
    </div>
  );
}
