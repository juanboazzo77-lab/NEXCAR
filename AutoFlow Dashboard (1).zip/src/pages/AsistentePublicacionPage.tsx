import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useAgency } from "@/hooks/useAgency";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles, Upload, Trash2, Loader2, Wand2, Rocket, AlertTriangle, Copy } from "lucide-react";

type Photo = { id: string; url: string; storage_path: string | null; orden: number; es_portada: boolean };

const empty = {
  patente: "", vin: "", marca: "", modelo: "", version: "", anio: new Date().getFullYear(),
  kilometros: "", color: "", condicion: "Usado", precio_venta: "", moneda: "ARS", ubicacion: "", notas: "",
};

export default function AsistentePublicacionPage() {
  const { user } = useAuth();
  const { agency } = useAgency();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [form, setForm] = useState<any>(empty);
  const [carId, setCarId] = useState<string | null>(null);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [uploading, setUploading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [ai, setAi] = useState<any>(null);
  const [stock, setStock] = useState<any[]>([]);
  const [loadingCar, setLoadingCar] = useState(false);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase
        .from("cars")
        .select("id, patente, marca, modelo, version, anio, estado")
        .neq("estado", "vendido")
        .order("created_at", { ascending: false })
        .limit(300);
      setStock(data || []);
    })();
  }, [user, agency?.id]);

  /** Carga un auto ya existente del stock (evita cargarlo dos veces). */
  const cargarDesdeStock = async (id: string) => {
    if (id === "__nuevo__") {
      setCarId(null); setForm(empty); setPhotos([]); setAi(null);
      return;
    }
    setLoadingCar(true);
    try {
      const { data: c, error } = await supabase.from("cars").select("*").eq("id", id).single();
      if (error || !c) throw new Error(error?.message || "No se encontró el vehículo");
      setCarId(c.id);
      setForm({
        patente: c.patente || "", vin: c.vin || "", marca: c.marca || "", modelo: c.modelo || "",
        version: c.version || "", anio: c.anio || new Date().getFullYear(),
        kilometros: c.kilometros ?? "", color: c.color || "", condicion: c.condicion || "Usado",
        precio_venta: c.precio_venta ?? "", moneda: c.moneda || "ARS",
        ubicacion: c.ubicacion || "", notas: c.descripcion_manual || "",
      });
      const { data: ph } = await supabase.from("car_photos").select("*").eq("car_id", c.id)
        .order("es_portada", { ascending: false }).order("orden");
      setPhotos((ph as any) || []);
      setAi(null);
      toast({ title: "Vehículo cargado", description: "Se usan los datos y fotos que ya tenías en stock" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally { setLoadingCar(false); }
  };

  const set = (k: string, v: any) => setForm((f: any) => ({ ...f, [k]: v }));
  const setAiField = (k: string, v: any) => setAi((a: any) => ({ ...a, [k]: v }));
  const setFicha = (k: string, v: any) => setAi((a: any) => ({ ...a, ficha: { ...a.ficha, [k]: v } }));

  const basePayload = () => ({
    user_id: user!.id,
    agency_id: agency?.id ?? null,
    patente: (form.patente || `SIN-${Date.now()}`).toUpperCase(),
    vin: form.vin || null,
    marca: form.marca,
    modelo: form.modelo,
    version: form.version || null,
    anio: Number(form.anio),
    kilometros: form.kilometros ? Number(form.kilometros) : null,
    color: form.color || null,
    condicion: form.condicion || "Usado",
    precio_venta: form.precio_venta ? Number(form.precio_venta) : null,
    moneda: form.moneda || "ARS",
    ubicacion: form.ubicacion || agency?.ciudad || null,
    descripcion_manual: form.notas || null,
  });

  /** Crea (o devuelve) el borrador del auto para poder subirle fotos. */
  const ensureCar = async (): Promise<string | null> => {
    if (carId) return carId;
    if (!form.marca || !form.modelo || !form.anio) {
      toast({ title: "Faltan datos", description: "Marca, modelo y año son obligatorios", variant: "destructive" });
      return null;
    }
    const { data, error } = await supabase.from("cars").insert(basePayload() as any).select("id").single();
    if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); return null; }
    setCarId(data.id);
    return data.id;
  };

  const uploadPhotos = async (files: FileList | null) => {
    if (!files?.length) return;
    const cid = await ensureCar();
    if (!cid) return;
    setUploading(true);
    try {
      const base = photos.length;
      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        if (f.size > 10 * 1024 * 1024) { toast({ title: "Foto muy grande", description: `${f.name} supera 10MB` }); continue; }
        const path = `${user!.id}/${cid}/${Date.now()}-${i}-${f.name.replace(/[^a-zA-Z0-9.-]/g, "_")}`;
        const { error } = await supabase.storage.from("car-photos").upload(path, f);
        if (error) { toast({ title: "Error subiendo", description: error.message, variant: "destructive" }); continue; }
        const { data: pub } = supabase.storage.from("car-photos").getPublicUrl(path);
        await supabase.from("car_photos").insert({
          user_id: user!.id, car_id: cid, url: pub.publicUrl, storage_path: path,
          orden: base + i, es_portada: base === 0 && i === 0,
        });
      }
      const { data: ph } = await supabase.from("car_photos").select("*").eq("car_id", cid).order("es_portada", { ascending: false }).order("orden");
      setPhotos((ph as any) || []);
    } finally { setUploading(false); }
  };

  const delPhoto = async (p: Photo) => {
    if (p.storage_path) await supabase.storage.from("car-photos").remove([p.storage_path]);
    await supabase.from("car_photos").delete().eq("id", p.id);
    setPhotos(photos.filter(x => x.id !== p.id));
  };

  const generar = async () => {
    if (!form.marca || !form.modelo || !form.anio) {
      toast({ title: "Faltan datos", description: "Marca, modelo y año son obligatorios", variant: "destructive" });
      return;
    }
    setGenerating(true);
    try {
      const { data, error } = await supabase.functions.invoke("asistente-publicacion", {
        body: { ...form, agencia: agency?.name, fotos: photos.length },
      });
      if (error) throw new Error((data as any)?.error || error.message);
      if ((data as any)?.error) throw new Error((data as any).error);
      setAi(data);
      toast({ title: "Listo", description: "Revisá los textos y publicá" });
    } catch (e: any) {
      toast({ title: "No se pudo generar", description: e.message, variant: "destructive" });
    } finally { setGenerating(false); }
  };

  const guardar = async (irAPublicar: boolean) => {
    if (!ai) return;
    setSaving(true);
    try {
      const cid = await ensureCar();
      if (!cid) return;
      const f = ai.ficha || {};
      const payload: any = {
        ...basePayload(),
        version: form.version || f.version || null,
        color: form.color || f.color || null,
        carroceria: f.carroceria || null,
        combustible: f.combustible || null,
        transmision: f.transmision || null,
        motor: f.motor || null,
        cilindrada: f.cilindrada || null,
        potencia: f.potencia || null,
        traccion: f.traccion || null,
        puertas: f.puertas || null,
        cilindros: f.cilindros || null,
        direccion_asistida: f.direccion_asistida || null,
        equipamiento: ai.equipamiento || [],
        descripcion_publica: ai.descripcion_publica || null,
        ml_text: ai.ml_text || null,
        fb_text: ai.fb_text || null,
        ig_text: ai.ig_text || null,
      };
      delete payload.user_id;
      const { error } = await supabase.from("cars").update(payload).eq("id", cid);
      if (error) throw new Error(error.message);
      await supabase.from("ai_generated_descriptions").insert({
        user_id: user!.id, car_id: cid,
        titulo: ai.titulo, ml_desc: ai.ml_text, ig_caption: ai.ig_text, fb_caption: ai.fb_text,
        hashtags: ai.hashtags || [],
      } as any);
      toast({ title: "Guardado", description: "El vehículo quedó listo para publicar" });
      if (irAPublicar) navigate(`/publicador-pro/${cid}`);
    } catch (e: any) {
      toast({ title: "Error al guardar", description: e.message, variant: "destructive" });
    } finally { setSaving(false); }
  };

  const copiar = (t: string) => { navigator.clipboard.writeText(t || ""); toast({ title: "Copiado" }); };

  const fichaFields: [string, string][] = [
    ["version", "Versión"], ["carroceria", "Carrocería"], ["combustible", "Combustible"],
    ["transmision", "Transmisión"], ["motor", "Motor"], ["cilindrada", "Cilindrada"],
    ["potencia", "Potencia"], ["traccion", "Tracción"], ["puertas", "Puertas"],
    ["cilindros", "Cilindros"], ["color", "Color"], ["direccion_asistida", "Dirección"],
  ];

  const textFields: [string, string, number][] = [
    ["descripcion_publica", "Descripción para el catálogo", 5],
    ["ml_text", "Mercado Libre / Marketplace", 10],
    ["fb_text", "Facebook", 5],
    ["ig_text", "Instagram", 4],
    ["whatsapp_text", "WhatsApp", 4],
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Sparkles className="h-6 w-6 text-primary" /> Asistente de publicación con IA
        </h1>
        <p className="text-muted-foreground text-sm">
          Cargá los datos básicos y las fotos: la IA arma título, ficha técnica y todos los textos. Vos revisás y publicás.
        </p>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Usar un auto del stock</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          <Label>Elegí un vehículo ya cargado (o creá uno nuevo)</Label>
          <Select value={carId ?? "__nuevo__"} onValueChange={cargarDesdeStock} disabled={loadingCar}>
            <SelectTrigger className="max-w-xl">
              <SelectValue placeholder="Seleccionar vehículo del stock" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__nuevo__">+ Cargar un auto nuevo</SelectItem>
              {stock.map(c => (
                <SelectItem key={c.id} value={c.id}>
                  {[c.marca, c.modelo, c.version, c.anio].filter(Boolean).join(" ")}{c.patente ? ` — ${c.patente}` : ""}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            {loadingCar ? "Cargando vehículo..." : "Si lo elegís del stock, se reutilizan sus datos y fotos: no se duplica el auto."}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">1. Datos básicos</CardTitle></CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div><Label>Patente / Dominio</Label><Input value={form.patente} onChange={e => set("patente", e.target.value.toUpperCase())} placeholder="AB123CD" /></div>
          <div><Label>VIN / Chasis</Label><Input value={form.vin} onChange={e => set("vin", e.target.value)} /></div>
          <div><Label>Marca *</Label><Input value={form.marca} onChange={e => set("marca", e.target.value)} /></div>
          <div><Label>Modelo *</Label><Input value={form.modelo} onChange={e => set("modelo", e.target.value)} /></div>
          <div><Label>Versión</Label><Input value={form.version} onChange={e => set("version", e.target.value)} /></div>
          <div><Label>Año *</Label><Input type="number" value={form.anio} onChange={e => set("anio", e.target.value)} /></div>
          <div><Label>Kilómetros</Label><Input type="number" value={form.kilometros} onChange={e => set("kilometros", e.target.value)} /></div>
          <div><Label>Color</Label><Input value={form.color} onChange={e => set("color", e.target.value)} /></div>
          <div>
            <Label>Condición</Label>
            <Select value={form.condicion} onValueChange={v => set("condicion", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="Usado">Usado</SelectItem><SelectItem value="Nuevo">Nuevo</SelectItem></SelectContent>
            </Select>
          </div>
          <div><Label>Precio</Label><Input type="number" value={form.precio_venta} onChange={e => set("precio_venta", e.target.value)} /></div>
          <div>
            <Label>Moneda</Label>
            <Select value={form.moneda} onValueChange={v => set("moneda", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="ARS">ARS</SelectItem><SelectItem value="USD">USD</SelectItem></SelectContent>
            </Select>
          </div>
          <div><Label>Ubicación</Label><Input value={form.ubicacion} onChange={e => set("ubicacion", e.target.value)} placeholder={agency?.ciudad || ""} /></div>
          <div className="sm:col-span-2 lg:col-span-4">
            <Label>Notas para la IA (estado, detalles, extras)</Label>
            <Textarea rows={3} value={form.notas} onChange={e => set("notas", e.target.value)} placeholder="Único dueño, service al día, cubiertas nuevas, full full..." />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">2. Fotos</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <label className="inline-flex">
            <input type="file" accept="image/*" multiple className="hidden" onChange={e => uploadPhotos(e.target.files)} />
            <span className={`inline-flex items-center gap-2 rounded-md border px-4 py-2 text-sm cursor-pointer hover:bg-muted ${uploading ? "opacity-60 pointer-events-none" : ""}`}>
              {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} Subir fotos
            </span>
          </label>
          {photos.length > 0 && (
            <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-8 gap-2">
              {photos.map(p => (
                <div key={p.id} className="relative group">
                  <img src={p.url} alt="Foto del vehículo" loading="lazy" className="h-24 w-full object-cover rounded-md border" />
                  <Button size="icon" variant="destructive" className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100" onClick={() => delPhoto(p)}>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex justify-center">
        <Button size="lg" onClick={generar} disabled={generating}>
          {generating ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Wand2 className="h-4 w-4 mr-2" />}
          Generar publicación con IA
        </Button>
      </div>

      {ai && (
        <Card>
          <CardHeader><CardTitle className="text-base">3. Revisá y publicá</CardTitle></CardHeader>
          <CardContent className="space-y-5">
            {ai.faltantes && (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Datos que conviene completar</AlertTitle>
                <AlertDescription>{ai.faltantes}</AlertDescription>
              </Alert>
            )}

            <div>
              <Label>Título</Label>
              <Input value={ai.titulo || ""} maxLength={60} onChange={e => setAiField("titulo", e.target.value)} />
            </div>

            <div>
              <Label className="mb-2 block">Ficha técnica</Label>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {fichaFields.map(([k, label]) => (
                  <div key={k}>
                    <Label className="text-xs text-muted-foreground">{label}</Label>
                    <Input value={(ai.ficha?.[k] ?? "") as any} onChange={e => setFicha(k, e.target.value)} />
                  </div>
                ))}
              </div>
            </div>

            {!!(ai.equipamiento || []).length && (
              <div>
                <Label className="mb-2 block">Equipamiento detectado</Label>
                <div className="flex flex-wrap gap-2">
                  {ai.equipamiento.map((e: string, i: number) => (
                    <Badge key={i} variant="secondary" className="cursor-pointer" onClick={() => setAiField("equipamiento", ai.equipamiento.filter((_: string, j: number) => j !== i))}>
                      {e} ✕
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {textFields.map(([k, label, rows]) => (
              <div key={k}>
                <div className="flex items-center justify-between">
                  <Label>{label}</Label>
                  <Button variant="ghost" size="sm" onClick={() => copiar(ai[k])}><Copy className="h-3 w-3 mr-1" /> Copiar</Button>
                </div>
                <Textarea rows={rows} value={ai[k] || ""} onChange={e => setAiField(k, e.target.value)} />
              </div>
            ))}

            {!!(ai.hashtags || []).length && (
              <div className="text-sm text-muted-foreground">{ai.hashtags.join(" ")}</div>
            )}

            <div className="flex flex-wrap gap-3 pt-2">
              <Button variant="outline" onClick={() => guardar(false)} disabled={saving}>
                {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null} Guardar en stock
              </Button>
              <Button onClick={() => guardar(true)} disabled={saving}>
                <Rocket className="h-4 w-4 mr-2" /> Guardar y publicar
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
