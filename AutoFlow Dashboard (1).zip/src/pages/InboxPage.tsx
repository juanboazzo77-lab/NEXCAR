import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  MessageCircle, Instagram, Sparkles, Send, Archive, EyeOff, UserPlus, Search,
  Bot, Wand2, BookText, Brain, Plus, Loader2, ChevronLeft
} from "lucide-react";

type Conv = {
  id: string;
  platform: 'whatsapp' | 'instagram' | 'manual';
  channel_account_id: string | null;
  contact_name: string | null;
  contact_handle: string | null;
  external_contact_id: string | null;
  last_message_text: string | null;
  last_message_at: string | null;
  unread_count: number;
  estado: string;
  tags: string[];
  vendedor_asignado: string | null;
  lead_score: number | null;
  lead_classification: string | null;
  archived: boolean;
  ignored: boolean;
  saved_to_crm: boolean;
  lead_id: string | null;
};
type Msg = { id: string; direction: 'in' | 'out'; body: string | null; sent_at: string };
type Analysis = {
  resumen: string | null; intencion: string | null; servicio_interes: string | null;
  problema: string | null; nivel_interes: string | null; nivel_urgencia: string | null;
  presupuesto: string | null; objeciones: string | null; proximos_pasos: string | null;
  probabilidad_cierre: number | null; lead_score: number | null; clasificacion: string | null;
};

const ESTADOS = ['nuevo', 'contactado', 'interesado', 'propuesta_enviada', 'negociacion', 'ganado', 'perdido'];
const estadoColor = (e: string) => ({
  nuevo: 'bg-blue-500/15 text-blue-600 border-blue-500/30',
  contactado: 'bg-cyan-500/15 text-cyan-600 border-cyan-500/30',
  interesado: 'bg-amber-500/15 text-amber-600 border-amber-500/30',
  propuesta_enviada: 'bg-purple-500/15 text-purple-600 border-purple-500/30',
  negociacion: 'bg-orange-500/15 text-orange-600 border-orange-500/30',
  ganado: 'bg-green-500/15 text-green-600 border-green-500/30',
  perdido: 'bg-destructive/15 text-destructive border-destructive/30',
}[e] ?? '');

export default function InboxPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [convs, setConvs] = useState<Conv[]>([]);
  const [active, setActive] = useState<Conv | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [loading, setLoading] = useState(true);
  const [filterPlatform, setFilterPlatform] = useState('all');
  const [filterEstado, setFilterEstado] = useState('all');
  const [filterView, setFilterView] = useState<'inbox' | 'archived' | 'crm'>('inbox');
  const [search, setSearch] = useState('');
  const [reply, setReply] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const [newOpen, setNewOpen] = useState(false);
  const [askOpen, setAskOpen] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [askQ, setAskQ] = useState('');
  const [askA, setAskA] = useState('');
  const [showDetail, setShowDetail] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  const loadConvs = async () => {
    setLoading(true);
    const { data } = await (supabase as any)
      .from('inbox_conversations')
      .select('*')
      .order('last_message_at', { ascending: false, nullsFirst: false });
    setConvs((data ?? []) as Conv[]);
    setLoading(false);
  };

  const loadMessages = async (convId: string) => {
    const { data } = await (supabase as any)
      .from('inbox_messages').select('*').eq('conversation_id', convId).order('sent_at');
    setMessages((data ?? []) as Msg[]);
    const { data: an } = await (supabase as any)
      .from('conversation_analyses').select('*').eq('conversation_id', convId).order('created_at', { ascending: false }).limit(1).maybeSingle();
    setAnalysis(an as Analysis | null);
    setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
  };

  useEffect(() => { loadConvs(); }, []);
  useEffect(() => {
    if (!active) return;
    loadMessages(active.id);
    if (active.unread_count > 0) (supabase as any).from('inbox_conversations').update({ unread_count: 0 }).eq('id', active.id).then(() => loadConvs());
  }, [active?.id]);

  // realtime
  useEffect(() => {
    const ch = (supabase as any).channel('inbox-rt')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'inbox_conversations' }, () => loadConvs())
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'inbox_messages' }, (p: any) => {
        if (active && p.new.conversation_id === active.id) loadMessages(active.id);
      })
      .subscribe();
    return () => { (supabase as any).removeChannel(ch); };
  }, [active?.id]);

  const filtered = useMemo(() => {
    return convs.filter(c => {
      if (filterView === 'inbox' && (c.archived || c.ignored)) return false;
      if (filterView === 'archived' && !c.archived) return false;
      if (filterView === 'crm' && !c.saved_to_crm) return false;
      if (filterPlatform !== 'all' && c.platform !== filterPlatform) return false;
      if (filterEstado !== 'all' && c.estado !== filterEstado) return false;
      if (search) {
        const s = search.toLowerCase();
        if (!`${c.contact_name ?? ''} ${c.contact_handle ?? ''} ${c.last_message_text ?? ''} ${c.vendedor_asignado ?? ''} ${(c.tags ?? []).join(' ')}`.toLowerCase().includes(s)) return false;
      }
      return true;
    });
  }, [convs, filterView, filterPlatform, filterEstado, search]);

  const updateConv = async (id: string, patch: Partial<Conv>) => {
    await (supabase as any).from('inbox_conversations').update(patch).eq('id', id);
    loadConvs();
    if (active?.id === id) setActive({ ...active, ...patch } as Conv);
  };

  const convertToLead = async (c: Conv) => {
    setBusy('lead');
    try {
      const { data: lead, error } = await (supabase as any).from('leads').insert({
        user_id: user!.id,
        nombre: c.contact_name ?? c.contact_handle ?? 'Sin nombre',
        telefono: c.platform === 'whatsapp' ? (c.external_contact_id ?? c.contact_handle) : null,
        canal: c.platform === 'whatsapp' ? 'WhatsApp' : c.platform === 'instagram' ? 'Instagram' : 'Otro',
        estado: 'Nuevo',
        fecha_contacto: new Date().toISOString().split('T')[0],
        notas: `Importado del Inbox. Último mensaje: ${c.last_message_text ?? ''}`,
      }).select().single();
      if (error) throw error;
      await updateConv(c.id, { saved_to_crm: true, lead_id: lead.id });
      toast({ title: 'Convertido a Lead' });
    } catch (e: any) { toast({ title: 'Error', description: e.message, variant: 'destructive' }); }
    setBusy(null);
  };

  const callAi = async (action: string, payload: any) => {
    const { data: sess } = await supabase.auth.getSession();
    const token = sess.session?.access_token;
    const res = await fetch(`https://zraasslwthywrrekrkuv.supabase.co/functions/v1/inbox-ai`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...payload }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error ?? 'Error IA');
    return data;
  };

  const analyze = async () => {
    if (!active) return;
    setBusy('analyze');
    try {
      const { analysis: a } = await callAi('analyze', { conversation_id: active.id });
      setAnalysis(a);
      loadConvs();
      toast({ title: 'Análisis listo' });
    } catch (e: any) { toast({ title: 'Error', description: e.message, variant: 'destructive' }); }
    setBusy(null);
  };

  const generateReply = async () => {
    if (!active) return;
    setBusy('reply');
    try {
      const { reply: r } = await callAi('reply', { conversation_id: active.id });
      setReply(r);
    } catch (e: any) { toast({ title: 'Error', description: e.message, variant: 'destructive' }); }
    setBusy(null);
  };

  const recommendTpl = async () => {
    if (!active) return;
    setBusy('recommend');
    try {
      const r = await callAi('recommend', { conversation_id: active.id });
      setReply(r.personalized || r.template?.contenido || '');
      toast({ title: `Plantilla sugerida: ${r.template?.titulo ?? ''}` });
    } catch (e: any) { toast({ title: 'Error', description: e.message, variant: 'destructive' }); }
    setBusy(null);
  };

  const sendMsg = async () => {
    if (!active || !reply.trim()) return;
    setBusy('send');
    try {
      if (active.platform === 'manual' || !active.channel_account_id) {
        // Manual: solo registrar
        await (supabase as any).from('inbox_messages').insert({
          user_id: user!.id, conversation_id: active.id, direction: 'out', body: reply, sent_at: new Date().toISOString(),
        });
        await (supabase as any).from('inbox_conversations').update({ last_message_text: reply, last_message_at: new Date().toISOString() }).eq('id', active.id);
      } else {
        const { data: sess } = await supabase.auth.getSession();
        const res = await fetch(`https://zraasslwthywrrekrkuv.supabase.co/functions/v1/send-whatsapp-message`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${sess.session?.access_token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ conversation_id: active.id, text: reply }),
        });
        const d = await res.json();
        if (!res.ok) throw new Error(d.error);
      }
      setReply('');
      loadMessages(active.id); loadConvs();
      toast({ title: 'Enviado' });
    } catch (e: any) { toast({ title: 'Error', description: e.message, variant: 'destructive' }); }
    setBusy(null);
  };

  const askAi = async () => {
    if (!askQ.trim() || selected.size === 0) return;
    setBusy('ask');
    try {
      const { answer } = await callAi('ask', { conversation_ids: Array.from(selected), question: askQ });
      setAskA(answer);
    } catch (e: any) { toast({ title: 'Error', description: e.message, variant: 'destructive' }); }
    setBusy(null);
  };

  // Nueva conversación manual
  const [newForm, setNewForm] = useState({ contact_name: '', contact_handle: '', body: '' });
  const createManual = async () => {
    if (!newForm.contact_name.trim()) return;
    const { data: conv, error } = await (supabase as any).from('inbox_conversations').insert({
      user_id: user!.id, platform: 'manual', contact_name: newForm.contact_name, contact_handle: newForm.contact_handle,
      last_message_text: newForm.body || null, last_message_at: new Date().toISOString(), estado: 'nuevo',
    }).select().single();
    if (error) { toast({ title: 'Error', description: error.message, variant: 'destructive' }); return; }
    if (newForm.body) {
      await (supabase as any).from('inbox_messages').insert({ user_id: user!.id, conversation_id: conv.id, direction: 'in', body: newForm.body, sent_at: new Date().toISOString() });
    }
    setNewForm({ contact_name: '', contact_handle: '', body: '' }); setNewOpen(false); loadConvs();
  };

  const toggleSel = (id: string) => {
    const s = new Set(selected);
    s.has(id) ? s.delete(id) : s.add(id);
    setSelected(s);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h1 className="page-header">Inbox Comercial</h1>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => setAskOpen(true)} disabled={selected.size === 0}><Brain className="w-4 h-4 mr-1" />Preguntar IA ({selected.size})</Button>
          <Button size="sm" onClick={() => setNewOpen(true)}><Plus className="w-4 h-4 mr-1" />Nueva</Button>
        </div>
      </div>

      {/* KPIs Dashboard Comercial */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
        <Card><CardHeader className="pb-1 pt-3 px-3"><CardTitle className="text-[11px] text-muted-foreground font-normal">Activas</CardTitle></CardHeader><CardContent className="px-3 pb-3"><div className="text-xl font-bold">{convs.filter(c => !c.archived && !c.ignored).length}</div></CardContent></Card>
        <Card><CardHeader className="pb-1 pt-3 px-3"><CardTitle className="text-[11px] text-muted-foreground font-normal">Nuevos</CardTitle></CardHeader><CardContent className="px-3 pb-3"><div className="text-xl font-bold text-blue-600">{convs.filter(c => c.estado === 'nuevo' && !c.archived && !c.ignored).length}</div></CardContent></Card>
        <Card><CardHeader className="pb-1 pt-3 px-3"><CardTitle className="text-[11px] text-muted-foreground font-normal">Propuestas</CardTitle></CardHeader><CardContent className="px-3 pb-3"><div className="text-xl font-bold text-purple-600">{convs.filter(c => c.estado === 'propuesta_enviada' || c.estado === 'negociacion').length}</div></CardContent></Card>
        <Card><CardHeader className="pb-1 pt-3 px-3"><CardTitle className="text-[11px] text-muted-foreground font-normal">Ganadas</CardTitle></CardHeader><CardContent className="px-3 pb-3"><div className="text-xl font-bold text-green-600">{convs.filter(c => c.estado === 'ganado').length}</div></CardContent></Card>
        <Card><CardHeader className="pb-1 pt-3 px-3"><CardTitle className="text-[11px] text-muted-foreground font-normal">Calientes IA</CardTitle></CardHeader><CardContent className="px-3 pb-3"><div className="text-xl font-bold text-orange-600">{convs.filter(c => c.lead_classification === 'caliente').length}</div></CardContent></Card>
      </div>


      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input className="pl-8" placeholder="Buscar nombre, teléfono, palabras clave..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <Select value={filterView} onValueChange={(v: any) => setFilterView(v)}>
          <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="inbox">Bandeja</SelectItem>
            <SelectItem value="crm">Guardadas (CRM)</SelectItem>
            <SelectItem value="archived">Archivadas</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterPlatform} onValueChange={setFilterPlatform}>
          <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas</SelectItem>
            <SelectItem value="whatsapp">WhatsApp</SelectItem>
            <SelectItem value="instagram">Instagram</SelectItem>
            <SelectItem value="manual">Manual</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterEstado} onValueChange={setFilterEstado}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los estados</SelectItem>
            {ESTADOS.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="grid lg:grid-cols-[320px_1fr] gap-3 min-h-[60vh]">
        {/* Lista */}
        <div className={`border rounded-lg overflow-auto max-h-[75vh] ${active && showDetail ? 'hidden lg:block' : ''}`}>
          {loading && <div className="p-4 text-sm text-muted-foreground">Cargando...</div>}
          {!loading && filtered.length === 0 && <div className="p-4 text-sm text-muted-foreground">Sin conversaciones.</div>}
          {filtered.map(c => {
            const Ic = c.platform === 'whatsapp' ? MessageCircle : c.platform === 'instagram' ? Instagram : Bot;
            const isActive = active?.id === c.id;
            return (
              <div key={c.id} className={`flex gap-2 p-2 border-b cursor-pointer hover:bg-accent/50 ${isActive ? 'bg-accent' : ''}`} onClick={() => { setActive(c); setShowDetail(true); }}>
                <Checkbox checked={selected.has(c.id)} onCheckedChange={() => toggleSel(c.id)} onClick={e => e.stopPropagation()} className="mt-1" />
                <Ic className={`w-4 h-4 mt-1 shrink-0 ${c.platform === 'whatsapp' ? 'text-green-600' : c.platform === 'instagram' ? 'text-pink-600' : 'text-muted-foreground'}`} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1">
                    <div className="font-medium text-sm truncate flex-1">{c.contact_name ?? c.contact_handle ?? 'Sin nombre'}</div>
                    {c.unread_count > 0 && <Badge className="h-4 px-1.5 text-[10px]">{c.unread_count}</Badge>}
                  </div>
                  <div className="text-xs text-muted-foreground truncate">{c.last_message_text ?? '—'}</div>
                  <div className="flex items-center gap-1 mt-1">
                    <Badge variant="outline" className={`text-[10px] h-4 px-1 ${estadoColor(c.estado)}`}>{c.estado}</Badge>
                    {c.lead_classification && <Badge variant="outline" className="text-[10px] h-4 px-1">{c.lead_classification}{c.lead_score ? ` ${c.lead_score}` : ''}</Badge>}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Detalle */}
        {active ? (
          <div className={`border rounded-lg flex flex-col max-h-[75vh] ${!showDetail ? 'hidden lg:flex' : 'flex'}`}>
            <div className="p-3 border-b flex items-center gap-2 flex-wrap">
              <Button size="sm" variant="ghost" className="lg:hidden" onClick={() => setShowDetail(false)}><ChevronLeft className="w-4 h-4" /></Button>
              <div className="flex-1 min-w-0">
                <div className="font-semibold truncate">{active.contact_name ?? active.contact_handle}</div>
                <div className="text-xs text-muted-foreground">{active.platform} · {active.contact_handle ?? ''}</div>
              </div>
              <Select value={active.estado} onValueChange={v => updateConv(active.id, { estado: v })}>
                <SelectTrigger className="w-40 h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>{ESTADOS.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}</SelectContent>
              </Select>
            </div>

            <div className="p-2 border-b flex gap-1 flex-wrap">
              <Button size="sm" variant="outline" onClick={analyze} disabled={busy === 'analyze'}>{busy === 'analyze' ? <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 mr-1" />}Analizar</Button>
              <Button size="sm" variant="outline" onClick={generateReply} disabled={busy === 'reply'}>{busy === 'reply' ? <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" /> : <Wand2 className="w-3.5 h-3.5 mr-1" />}Generar respuesta</Button>
              <Button size="sm" variant="outline" onClick={recommendTpl} disabled={busy === 'recommend'}>{busy === 'recommend' ? <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" /> : <BookText className="w-3.5 h-3.5 mr-1" />}Plantilla IA</Button>
              {!active.saved_to_crm && <Button size="sm" variant="outline" onClick={() => convertToLead(active)} disabled={busy === 'lead'}><UserPlus className="w-3.5 h-3.5 mr-1" />A Lead</Button>}
              <Button size="sm" variant="outline" onClick={() => updateConv(active.id, { archived: !active.archived })}><Archive className="w-3.5 h-3.5 mr-1" />{active.archived ? 'Desarchivar' : 'Archivar'}</Button>
              <Button size="sm" variant="outline" onClick={() => updateConv(active.id, { ignored: !active.ignored })}><EyeOff className="w-3.5 h-3.5 mr-1" />{active.ignored ? 'Restaurar' : 'Ignorar'}</Button>
            </div>

            {analysis && (
              <div className="p-3 border-b bg-muted/30 text-xs space-y-1">
                <div className="flex items-center gap-2"><Sparkles className="w-3.5 h-3.5 text-primary" /><strong>Resumen IA</strong>
                  {analysis.lead_score != null && <Badge variant="outline">Lead Score {analysis.lead_score}/100</Badge>}
                  {analysis.clasificacion && <Badge variant="outline">{analysis.clasificacion}</Badge>}
                </div>
                <div>{analysis.resumen}</div>
                <div className="grid grid-cols-2 gap-x-3 text-muted-foreground">
                  {analysis.intencion && <div><strong>Busca:</strong> {analysis.intencion}</div>}
                  {analysis.servicio_interes && <div><strong>Servicio:</strong> {analysis.servicio_interes}</div>}
                  {analysis.nivel_interes && <div><strong>Interés:</strong> {analysis.nivel_interes}</div>}
                  {analysis.nivel_urgencia && <div><strong>Urgencia:</strong> {analysis.nivel_urgencia}</div>}
                  {analysis.presupuesto && <div><strong>Presupuesto:</strong> {analysis.presupuesto}</div>}
                  {analysis.probabilidad_cierre != null && <div><strong>Cierre:</strong> {analysis.probabilidad_cierre}%</div>}
                  {analysis.objeciones && <div className="col-span-2"><strong>Objeciones:</strong> {analysis.objeciones}</div>}
                  {analysis.proximos_pasos && <div className="col-span-2"><strong>Próximos pasos:</strong> {analysis.proximos_pasos}</div>}
                </div>
              </div>
            )}

            <div className="flex-1 overflow-auto p-3 space-y-2">
              {messages.map(m => (
                <div key={m.id} className={`flex ${m.direction === 'out' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[75%] rounded-lg px-3 py-2 text-sm ${m.direction === 'out' ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                    <div className="whitespace-pre-wrap">{m.body}</div>
                    <div className="text-[10px] opacity-70 mt-1">{new Date(m.sent_at).toLocaleString()}</div>
                  </div>
                </div>
              ))}
              <div ref={bottomRef} />
            </div>

            <div className="p-2 border-t space-y-2">
              <Textarea rows={2} value={reply} onChange={e => setReply(e.target.value)} placeholder="Escribí o generá una respuesta..." />
              <div className="flex justify-end">
                <Button size="sm" onClick={sendMsg} disabled={!reply.trim() || busy === 'send'}>
                  {busy === 'send' ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Send className="w-4 h-4 mr-1" />}Enviar
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <Card className="hidden lg:flex items-center justify-center text-muted-foreground text-sm"><CardContent className="pt-6">Seleccioná una conversación</CardContent></Card>
        )}
      </div>

      {/* Nueva manual */}
      <Dialog open={newOpen} onOpenChange={setNewOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Nueva conversación manual</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Input placeholder="Nombre del contacto" value={newForm.contact_name} onChange={e => setNewForm(f => ({ ...f, contact_name: e.target.value }))} />
            <Input placeholder="Teléfono / @usuario" value={newForm.contact_handle} onChange={e => setNewForm(f => ({ ...f, contact_handle: e.target.value }))} />
            <Textarea rows={4} placeholder="Pegá el chat o el último mensaje" value={newForm.body} onChange={e => setNewForm(f => ({ ...f, body: e.target.value }))} />
            <Button onClick={createManual} className="w-full">Crear</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Preguntar IA */}
      <Dialog open={askOpen} onOpenChange={setAskOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader><DialogTitle>Preguntar IA sobre {selected.size} chat{selected.size === 1 ? '' : 's'} seleccionado{selected.size === 1 ? '' : 's'}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <Textarea rows={3} placeholder="¿Qué buscan estos clientes? ¿Cuáles tienen intención de compra? ¿Quién mencionó presupuesto?" value={askQ} onChange={e => setAskQ(e.target.value)} />
            <Button onClick={askAi} disabled={busy === 'ask' || !askQ.trim()}>
              {busy === 'ask' ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Brain className="w-4 h-4 mr-1" />}Preguntar
            </Button>
            {askA && <Card><CardContent className="pt-4 text-sm whitespace-pre-wrap">{askA}</CardContent></Card>}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
