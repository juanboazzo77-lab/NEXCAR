import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { CHANNELS, Channel, VEHICLE_STATUS, callFn, channelLabel, money, previewText } from "@/lib/publisher";
import { ArrowLeft, ArrowUp, ArrowDown, Star, Trash2, Loader2, Search } from "lucide-react";
import VehicleCatalogPicker from "@/components/publisher/VehicleCatalogPicker";
import SocialCopyEditor from "@/components/publisher/SocialCopyEditor";

const BUCKET = "car-photos";

type ListingType = { listing_type_id: string; name: string; available_quantity: number | null; used_quantity?: number };
const FALLBACK_LISTING_TYPES: ListingType[] = [
  { listing_type_id: "free", name: "Gratis", available_quantity: null },
  { listing_type_id: "bronze", name: "Bronce", available_quantity: null },
  { listing_type_id: "silver", name: "Plata", available_quantity: null },
  { listing_type_id: "gold", name: "Oro", available_quantity: null },
  { listing_type_id: "gold_premium", name: "Oro Premium", available_quantity: null },
];

export default function PublisherVehiculoPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [vehicle, setVehicle] = useState<any>(null);
  const [media, setMedia] = useState<any[]>([]);
  const [pubs, setPubs] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [attrsSpec, setAttrsSpec] = useState<any[]>([]);
  const [catResults, setCatResults] = useState<any[]>([]);
  const [validation, setValidation] = useState<any>(null);
  const [channels, setChannels] = useState<Channel[]>(["mercadolibre", "instagram", "facebook"]);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmWord, setConfirmWord] = useState("");
  const [token, setToken] = useState<string | null>(null);
  const [publishing, setPublishing] = useState(false);
  const [listingTypes, setListingTypes] = useState<ListingType[]>([]);
  const [loadingLT, setLoadingLT] = useState(false);
  const timer = useRef<number | null>(null);

  const load = useCallback(async () => {
    const [v, m, p] = await Promise.all([
      supabase.from("vehicles").select("*").eq("id", id!).maybeSingle(),
      supabase.from("vehicle_media").select("*").eq("vehicle_id", id!).order("sort_order"),
      supabase.from("publications").select("*").eq("vehicle_id", id!),
    ]);
    if (!v.data) { toast.error("El auto no existe"); navigate("/publicador-pro"); return; }
    setVehicle(v.data);
    setMedia(m.data || []);
    setPubs(p.data || []);
  }, [id, navigate]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (vehicle?.ml_category_id) {
      callFn("ml-category-attributes", { category_id: vehicle.ml_category_id })
        .then((d) => setAttrsSpec(d.attributes || []))
        .catch(() => setAttrsSpec([]));
    }
  }, [vehicle?.ml_category_id]);

  // Cupos reales de publicación de la cuenta de Mercado Libre, por categoría
  const loadListingTypes = useCallback(async () => {
    setLoadingLT(true);
    try {
      const data = await callFn("ml-listing-types", { category_id: vehicle?.ml_category_id || undefined });
      setListingTypes(data.listing_types || []);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoadingLT(false);
    }
  }, [vehicle?.ml_category_id]);

  useEffect(() => { if (vehicle?.ml_category_id) loadListingTypes(); }, [vehicle?.ml_category_id, loadListingTypes]);


  // Autosave del borrador
  const patch = (changes: Record<string, any>) => {
    setVehicle((prev: any) => ({ ...prev, ...changes }));
    setValidation(null);
    setToken(null);
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = window.setTimeout(async () => {
      setSaving(true);
      const { error } = await supabase.from("vehicles").update(changes as never).eq("id", id!);
      setSaving(false);
      if (error) toast.error(error.message);
    }, 700);
  };

  const upload = async (files: FileList | null) => {
    if (!files?.length || !vehicle) return;
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) return;
    for (const file of Array.from(files)) {
      if (!/^image\/(jpeg|png|webp)$/.test(file.type)) { toast.error(`${file.name}: usá JPG, PNG o WEBP`); continue; }
      if (file.size > 8 * 1024 * 1024) { toast.error(`${file.name}: supera los 8 MB`); continue; }
      // El bucket exige que la primera carpeta sea el id del usuario (política de seguridad).
      const path = `${userData.user.id}/publisher/${vehicle.id}/${crypto.randomUUID()}-${file.name.replace(/[^\w.-]/g, "_")}`;
      const { error } = await supabase.storage.from(BUCKET).upload(path, file);
      if (error) { toast.error(error.message); continue; }
      const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(path);
      await supabase.from("vehicle_media").insert({
        vehicle_id: vehicle.id, user_id: userData.user.id, storage_path: path,
        public_url: pub.publicUrl, sort_order: media.length, is_cover: media.length === 0,
      });
    }
    await load();
  };

  const move = async (index: number, dir: -1 | 1) => {
    const next = [...media];
    const target = index + dir;
    if (target < 0 || target >= next.length) return;
    [next[index], next[target]] = [next[target], next[index]];
    setMedia(next);
    await Promise.all(next.map((m, i) => supabase.from("vehicle_media").update({ sort_order: i }).eq("id", m.id)));
  };

  const setCover = async (mediaId: string) => {
    await supabase.from("vehicle_media").update({ is_cover: false }).eq("vehicle_id", vehicle.id);
    await supabase.from("vehicle_media").update({ is_cover: true }).eq("id", mediaId);
    await load();
  };

  const removeMedia = async (m: any) => {
    await supabase.storage.from(BUCKET).remove([m.storage_path]);
    await supabase.from("vehicle_media").delete().eq("id", m.id);
    await load();
  };

  const predict = async () => {
    try {
      const q = [vehicle.brand, vehicle.model, vehicle.trim, vehicle.vehicle_year].filter(Boolean).join(" ");
      const data = await callFn("ml-category-predict", { q });
      setCatResults(data.results || []);
      if (data.suggested) patch({ ml_category_id: data.suggested.category_id });
    } catch (e) { toast.error((e as Error).message); }
  };

  const attrValue = (attrId: string) =>
    (vehicle.ml_attributes || []).find((a: any) => a.id === attrId) || null;

  const setAttr = (spec: any, value: string) => {
    const list = (vehicle.ml_attributes || []).filter((a: any) => a.id !== spec.id);
    if (value) {
      const option = (spec.values || []).find((v: any) => v.id === value || v.name === value);
      list.push(option ? { id: spec.id, value_id: option.id, value_name: option.name } : { id: spec.id, value_name: value });
    }
    patch({ ml_attributes: list });
  };

  const validate = async () => {
    try {
      const data = await callFn("validate-vehicle-publication", { vehicleId: id, channels });
      setValidation(data);
      setToken(data.confirmationToken);
      if (data.ok) toast.success("Listo para publicar");
      else toast.error("Faltan datos obligatorios");
      return data;
    } catch (e) { toast.error((e as Error).message); return null; }
  };

  const openConfirm = async () => {
    const data = await validate();
    if (data?.ok) { setConfirmWord(""); setConfirmOpen(true); }
  };

  const publish = async () => {
    if (confirmWord.trim().toUpperCase() !== "PUBLICAR" || publishing) return;
    setPublishing(true);
    try {
      const res = await callFn("publish-vehicle", { vehicleId: id, channels, confirmationToken: token });
      for (const r of res.results || []) {
        if (r.status === "published") toast.success(`${channelLabel(r.channel)}: publicado`);
        else if (r.status === "partial") toast.warning(`${channelLabel(r.channel)}: ${r.message}`);
        else toast.error(`${channelLabel(r.channel)}: ${r.message}`);
      }
      setConfirmOpen(false);
      setToken(null);
      await load();
    } catch (e) { toast.error((e as Error).message); }
    setPublishing(false);
  };

  const marcarVendido = async (action: "none" | "paused" | "closed") => {
    try {
      const res = await callFn("mark-vehicle-sold", { vehicleId: id, mercadolibreAction: action });
      if (res.mercadolibre?.error) toast.warning(res.mercadolibre.error);
      toast.success("Marcado como vendido");
      await load();
    } catch (e) { toast.error((e as Error).message); }
  };

  if (!vehicle) return <p className="text-muted-foreground">Cargando…</p>;

  const field = (key: string, label: string, type = "text") => (
    <div className="space-y-1">
      <Label>{label}</Label>
      <Input type={type} value={vehicle[key] ?? ""}
        onChange={(e) => patch({ [key]: type === "number" ? (e.target.value === "" ? null : Number(e.target.value)) : e.target.value })} />
    </div>
  );

  const loc = vehicle.location || {};
  const setLoc = (k: string, v: string) => patch({ location: { ...loc, [k]: v } });

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate("/publicador-pro")}><ArrowLeft className="h-4 w-4" /></Button>
          <div>
            <h1 className="text-2xl font-bold">{vehicle.title || "Nuevo auto"}</h1>
            <p className="text-sm text-muted-foreground">
              {saving ? "Guardando…" : "Borrador guardado automáticamente"}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Select value={vehicle.status} onValueChange={(v) => patch({ status: v })}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              {Object.entries(VEHICLE_STATUS).map(([k, l]) => <SelectItem key={k} value={k}>{l}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={validate}>Validar</Button>
          <Button onClick={openConfirm}>Publicar</Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {CHANNELS.map((c) => {
          const p = pubs.find((x) => x.channel === c.id);
          return (
            <label key={c.id} className="flex items-center gap-2 rounded-lg border px-3 py-2 text-sm">
              <Checkbox checked={channels.includes(c.id)}
                onCheckedChange={(v) => setChannels((prev) => v ? [...new Set([...prev, c.id])] : prev.filter((x) => x !== c.id))} />
              {c.label}
              {p && <Badge variant="outline">{p.status}</Badge>}
            </label>
          );
        })}
      </div>

      {validation && (
        <Card className={validation.ok ? "border-emerald-500/40" : "border-destructive/40"}>
          <CardHeader><CardTitle className="text-base">{validation.ok ? "Todo listo" : "Faltan datos"}</CardTitle></CardHeader>
          <CardContent className="space-y-2 text-sm">
            {validation.issues?.map((i: any) => (
              (i.missing.length || i.warnings.length) ? (
                <div key={i.channel}>
                  <p className="font-medium">{i.channel === "general" ? "General" : channelLabel(i.channel)}</p>
                  {i.missing.map((m: string) => <p key={m} className="text-destructive">· {m}</p>)}
                  {i.warnings.map((w: string) => <p key={w} className="text-amber-600">· {w}</p>)}
                </div>
              ) : null
            ))}
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="datos">
        <TabsList className="flex-wrap h-auto">
          <TabsTrigger value="datos">Datos</TabsTrigger>
          <TabsTrigger value="ficha">Ficha técnica</TabsTrigger>
          <TabsTrigger value="fotos">Fotos ({media.length})</TabsTrigger>
          <TabsTrigger value="ml">Mercado Libre</TabsTrigger>
          <TabsTrigger value="textos">Textos</TabsTrigger>
          <TabsTrigger value="preview">Vista previa</TabsTrigger>
        </TabsList>

        <TabsContent value="datos">
          <Card><CardContent className="grid gap-4 pt-6 md:grid-cols-2">
            {field("internal_title", "Título interno")}
            {field("title", "Título comercial (máx. 60)")}
            <div className="space-y-1">
              <Label>Condición</Label>
              <Select value={vehicle.condition} onValueChange={(v) => patch({ condition: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="used">Usado</SelectItem>
                  <SelectItem value="new">Nuevo</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <VehicleCatalogPicker vehicle={vehicle} patch={patch} />

            {field("price", "Precio", "number")}
            <div className="space-y-1">
              <Label>Moneda</Label>
              <Select value={vehicle.currency_id} onValueChange={(v) => patch({ currency_id: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="ARS">ARS</SelectItem><SelectItem value="USD">USD</SelectItem></SelectContent>
              </Select>
            </div>
            {field("mileage_km", "Kilometraje", "number")}
            <div className="flex items-center justify-between rounded-lg border p-3">
              <Label>Acepta permuta</Label>
              <Switch checked={vehicle.accepts_trade} onCheckedChange={(v) => patch({ accepts_trade: v })} />
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <Label>Financiación</Label>
              <Switch checked={vehicle.financing} onCheckedChange={(v) => patch({ financing: v })} />
            </div>
            {vehicle.financing && field("initial_payment", "Anticipo", "number")}
            <div className="space-y-1 md:col-span-2">
              <Label>Descripción</Label>
              <Textarea rows={6} value={vehicle.description ?? ""} onChange={(e) => patch({ description: e.target.value })} />
            </div>
            <div className="space-y-1 md:col-span-2">
              <Label>Observaciones internas</Label>
              <Textarea rows={3} value={vehicle.observations ?? ""} onChange={(e) => patch({ observations: e.target.value })} />
            </div>
            <div className="space-y-1"><Label>Dirección</Label><Input value={loc.address ?? ""} onChange={(e) => setLoc("address", e.target.value)} /></div>
            <div className="space-y-1"><Label>Ciudad</Label><Input value={loc.city ?? ""} onChange={(e) => setLoc("city", e.target.value)} /></div>
            <div className="space-y-1"><Label>Provincia</Label><Input value={loc.state ?? ""} onChange={(e) => setLoc("state", e.target.value)} /></div>
            <div className="space-y-1"><Label>Código postal</Label><Input value={loc.zip ?? ""} onChange={(e) => setLoc("zip", e.target.value)} /></div>
            <div className="space-y-1"><Label>Contacto (teléfono)</Label>
              <Input value={vehicle.contact?.phone ?? ""} onChange={(e) => patch({ contact: { ...(vehicle.contact || {}), phone: e.target.value } })} /></div>
            <div className="space-y-1"><Label>Contacto (WhatsApp)</Label>
              <Input value={vehicle.contact?.whatsapp ?? ""} onChange={(e) => patch({ contact: { ...(vehicle.contact || {}), whatsapp: e.target.value } })} /></div>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="ficha">
          <Card><CardContent className="grid gap-4 pt-6 md:grid-cols-2">
            {field("body_type", "Carrocería")}
            {field("doors", "Puertas", "number")}
            {field("passengers", "Pasajeros", "number")}
            {field("fuel_type", "Combustible")}
            {field("transmission", "Transmisión")}
            {field("engine", "Motor")}
            {field("power", "Potencia")}
            {field("traction", "Tracción")}
            {field("exterior_color", "Color exterior")}
            {field("interior_color", "Color interior")}
            {field("license_plate", "Patente (privada)")}
            {field("vin", "VIN (privado)")}
            <p className="text-xs text-muted-foreground md:col-span-2">Patente y VIN nunca se incluyen en los textos publicados.</p>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="fotos">
          <Card><CardContent className="space-y-4 pt-6">
            <Input type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={(e) => upload(e.target.files)} />
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {media.map((m, i) => (
                <div key={m.id} className="rounded-lg border p-2 space-y-2">
                  <img src={m.public_url} alt={m.alt_text || `Foto ${i + 1}`} className="h-40 w-full rounded object-cover" loading="lazy" />
                  <Input placeholder="Texto alternativo" value={m.alt_text ?? ""}
                    onChange={async (e) => {
                      const value = e.target.value;
                      setMedia((prev) => prev.map((x) => x.id === m.id ? { ...x, alt_text: value } : x));
                      await supabase.from("vehicle_media").update({ alt_text: value }).eq("id", m.id);
                    }} />
                  <div className="flex items-center justify-between">
                    {m.is_cover ? <Badge>Portada</Badge>
                      : <Button variant="ghost" size="sm" onClick={() => setCover(m.id)}><Star className="h-4 w-4 mr-1" />Portada</Button>}
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" onClick={() => move(i, -1)}><ArrowUp className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => move(i, 1)}><ArrowDown className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => removeMedia(m)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="ml">
          <Card><CardContent className="space-y-4 pt-6">
            <div className="flex flex-wrap items-end gap-3">
              <div className="space-y-1">
                <Label>Categoría</Label>
                <Input value={vehicle.ml_category_id ?? ""} onChange={(e) => patch({ ml_category_id: e.target.value })} placeholder="MLA1744" />
              </div>
              <Button variant="outline" onClick={predict}><Search className="h-4 w-4 mr-2" />Detectar categoría</Button>
              <div className="space-y-1">
                <Label>Tipo de aviso (cupos de tu cuenta)</Label>
                <div className="flex gap-2">
                  <Select value={vehicle.ml_listing_type_id ?? "silver"} onValueChange={(v) => patch({ ml_listing_type_id: v })}>
                    <SelectTrigger className="w-72"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {(listingTypes.length ? listingTypes : FALLBACK_LISTING_TYPES).map((lt) => (
                        <SelectItem key={lt.listing_type_id} value={lt.listing_type_id} disabled={lt.available_quantity === 0}>
                          {lt.name} · {lt.available_quantity == null ? "cupos ilimitados" : `${lt.available_quantity} disponibles`}
                          {lt.used_quantity ? ` (usados ${lt.used_quantity})` : ""}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button variant="outline" onClick={loadListingTypes} disabled={loadingLT}>
                    {loadingLT ? <Loader2 className="h-4 w-4 animate-spin" /> : "Ver mis cupos"}
                  </Button>
                </div>
              </div>
            </div>

            {!!catResults.length && (
              <div className="space-y-1 text-sm">
                {catResults.map((c) => (
                  <button key={c.category_id} onClick={() => patch({ ml_category_id: c.category_id })}
                    className="block w-full rounded border p-2 text-left hover:bg-accent/40">
                    {c.category_name} <span className="text-muted-foreground">({c.category_id} · {c.domain_name})</span>
                    {!c.is_vehicle && <Badge variant="outline" className="ml-2">No es de vehículos</Badge>}
                  </button>
                ))}
              </div>
            )}

            <div className="grid gap-4 md:grid-cols-2">
              {attrsSpec.filter((a) => a.required).concat(attrsSpec.filter((a) => !a.required).slice(0, 20)).map((spec) => {
                const current = attrValue(spec.id);
                return (
                  <div key={spec.id} className="space-y-1">
                    <Label>{spec.name}{spec.required && <span className="text-destructive"> *</span>}</Label>
                    {spec.values?.length ? (
                      <Select value={current?.value_id || current?.value_name || ""} onValueChange={(v) => setAttr(spec, v)}>
                        <SelectTrigger><SelectValue placeholder="Elegir…" /></SelectTrigger>
                        <SelectContent className="max-h-72">
                          {spec.values.map((v: any) => <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    ) : (
                      <Input value={current?.value_name ?? ""} onChange={(e) => setAttr(spec, e.target.value)} placeholder={spec.hint || ""} />
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="textos">
          <SocialCopyEditor vehicle={vehicle} patch={patch} />

        </TabsContent>

        <TabsContent value="preview">
          <Tabs defaultValue="mercadolibre">
            <TabsList>{CHANNELS.map((c) => <TabsTrigger key={c.id} value={c.id}>{c.label}</TabsTrigger>)}</TabsList>
            {CHANNELS.map((c) => (
              <TabsContent key={c.id} value={c.id}>
                <Card><CardContent className="space-y-3 pt-6">
                  <p className="font-medium">{vehicle.title}</p>
                  <p className="text-lg font-bold">{money(vehicle.price, vehicle.currency_id)}</p>
                  {media[0] && <img src={media[0].public_url} alt={vehicle.title} className="max-h-72 rounded object-cover" />}
                  <pre className="whitespace-pre-wrap text-sm">{previewText(vehicle, c.id)}</pre>
                </CardContent></Card>
              </TabsContent>
            ))}
          </Tabs>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader><CardTitle className="text-base">Marcar como vendido</CardTitle></CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={() => marcarVendido("paused")}>Vendido y pausar en Mercado Libre</Button>
          <Button variant="outline" onClick={() => marcarVendido("closed")}>Vendido y finalizar en Mercado Libre</Button>
          <Button variant="ghost" onClick={() => marcarVendido("none")}>Sólo marcar vendido</Button>
          <p className="w-full text-xs text-muted-foreground">Las publicaciones de Instagram y Facebook no se borran automáticamente.</p>
        </CardContent>
      </Card>

      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar publicación</DialogTitle>
            <DialogDescription>Revisá antes de enviar. Algunos avisos de Mercado Libre pueden tener costo.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 text-sm">
            <p><strong>Canales:</strong> {channels.map(channelLabel).join(", ")}</p>
            <p><strong>Precio:</strong> {money(vehicle.price, vehicle.currency_id)}</p>
            <p><strong>Fotos:</strong> {media.length}</p>
            <p><strong>Tipo de aviso ML:</strong> {vehicle.ml_listing_type_id || "silver"}</p>
            <div className="space-y-1 pt-2">
              <Label>Escribí PUBLICAR para confirmar</Label>
              <Input value={confirmWord} onChange={(e) => setConfirmWord(e.target.value)} placeholder="PUBLICAR" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmOpen(false)}>Cancelar</Button>
            <Button onClick={publish} disabled={publishing || confirmWord.trim().toUpperCase() !== "PUBLICAR"}>
              {publishing && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}Publicar ahora
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
