import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { toast } from "sonner";
import { callFn } from "@/lib/publisher";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle2, XCircle, RefreshCw, Loader2, Plug, Unplug, AlertTriangle, Copy } from "lucide-react";

type Check = { id: string; label: string; ok: boolean; detail: string; fix?: string };
type MetaPage = { id: string; name: string; masked_id: string; selected: boolean; instagram: { username?: string; masked_id: string } | null };
type MetaHealth = {
  connected: boolean; pages: MetaPage[];
  facebook: { ok: boolean; message: string };
  instagram: { ok: boolean; message: string };
  missingScopes?: string[]; appMode?: string | null;
};

const copy = (t: string) => { navigator.clipboard.writeText(t); toast.success("Copiado"); };

function StatusPill({ ok, children }: { ok: boolean; children: React.ReactNode }) {
  return (
    <Badge variant="outline" className={ok
      ? "bg-emerald-500/10 text-emerald-600 border-emerald-500/30"
      : "bg-destructive/10 text-destructive border-destructive/30"}>
      {children}
    </Badge>
  );
}

export default function PublisherConexionesPage() {
  const [checks, setChecks] = useState<Check[]>([]);
  const [publishing, setPublishing] = useState(true);
  const [meta, setMeta] = useState<MetaHealth | null>(null);
  const [mlTest, setMlTest] = useState<{ ok: boolean; message: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const [diag, health] = await Promise.all([
        callFn("integrations-diagnostics", {}),
        callFn("connections-manager", { action: "meta_health" }),
      ]);
      setChecks(diag.checks || []);
      setPublishing(!!diag.publishingEnabled);
      setMeta(health);
    } catch (e) { toast.error((e as Error).message); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  // Resultado del OAuth: verificamos contra el backend y limpiamos la URL.
  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    const provider = p.get("provider");
    if (!provider) return;
    const connected = p.get("connected") === "1";
    const err = p.get("error");
    window.history.replaceState({}, "", window.location.pathname);

    const errors: Record<string, string> = {
      token_exchange_failed: "No pudimos completar la conexión con Mercado Libre. Revisá la Redirect URI y volvé a intentar.",
      token_verification_failed: "Mercado Libre no validó el token. Volvé a conectar la cuenta.",
      missing_credentials: "Faltan el App ID o el Client Secret de Mercado Libre.",
      authorization_failed: "Meta no autorizó la conexión. Revisá el diagnóstico y volvé a intentar.",
      page_selection_required: "Elegí la Página de Facebook donde querés publicar para terminar la conexión.",
      unexpected_error: "Ocurrió un error inesperado al conectar.",
    };

    if (!connected) {
      toast.error(errors[err ?? ""] ?? "No pudimos completar la conexión.");
      return;
    }
    if (provider === "mercadolibre") {
      (async () => {
        try {
          const r = await callFn("connections-manager", { action: "test_mercadolibre" });
          setMlTest({ ok: true, message: `Mercado Libre conectado — ${r.message}` });
          toast.success(`Mercado Libre conectado — ${r.message}`);
        } catch (e) {
          setMlTest({ ok: false, message: (e as Error).message });
          toast.error((e as Error).message);
        }
        load();
      })();
      return;
    }
    if (p.get("ig") === "0") {
      toast.warning("Esta Página no tiene una cuenta profesional de Instagram vinculada. Vinculala desde Meta Business Suite y volvé a intentarlo.");
    } else {
      toast.success("Facebook conectado");
    }
  }, []);

  const connect = async (provider: "mercadolibre" | "meta") => {
    setBusy(provider);
    try {
      const fn = provider === "mercadolibre" ? "oauth-mercadolibre-start" : "oauth-meta-start";
      const { data, error } = await supabase.functions.invoke(fn, {
        body: { return_to: window.location.origin },
      });
      if (error) throw new Error(error.message);
      if (data?.error) throw new Error(data.error);
      window.location.href = data.authorizationUrl;
    } catch (e) { toast.error((e as Error).message); setBusy(null); }
  };

  const testMl = async () => {
    setBusy("test-ml");
    try {
      const r = await callFn("connections-manager", { action: "test_mercadolibre" });
      setMlTest({ ok: true, message: r.message });
      toast.success(r.message);
    } catch (e) {
      setMlTest({ ok: false, message: (e as Error).message });
      toast.error((e as Error).message);
    }
    setBusy(null);
  };

  const disconnect = async (platform: "mercadolibre" | "meta") => {
    setBusy(`off-${platform}`);
    try {
      await callFn("connections-manager", { action: "disconnect", platform });
      setMlTest(null);
      toast.success("Cuenta desconectada");
      await load();
    } catch (e) { toast.error((e as Error).message); }
    setBusy(null);
  };

  const selectPage = async (pageId: string) => {
    setBusy(`page-${pageId}`);
    try {
      setMeta(await callFn("connections-manager", { action: "select_page", page_id: pageId }));
      toast.success("Página elegida");
      load();
    } catch (e) { toast.error((e as Error).message); }
    setBusy(null);
  };

  const check = (id: string) => checks.find((c) => c.id === id);
  const mlAccount = check("ml_account");
  const mlReady = !!check("ml_credentials")?.ok;
  const mlConnected = !!mlAccount?.ok;
  const metaReady = !!check("meta_credentials")?.ok;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Conexiones</h1>
          <p className="text-sm text-muted-foreground">Te guiamos paso a paso. Nunca mostramos ni pedimos tokens.</p>
        </div>
        <Button variant="outline" onClick={load} disabled={loading}>
          {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
          Actualizar
        </Button>
      </div>

      {!publishing && (
        <Card className="border-amber-500/40 bg-amber-500/5">
          <CardContent className="pt-6 text-sm flex gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
            Modo prueba activo: podés validar y ver la vista previa, pero no se publica nada real hasta activar la publicación.
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Mercado Libre */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base">Mercado Libre</CardTitle>
            <StatusPill ok={mlConnected}>
              {!mlReady ? "Falta configurar la app" : mlConnected ? "Conectado" : "No conectado"}
            </StatusPill>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <p className="text-muted-foreground">{mlAccount?.detail}</p>
            {mlTest && (
              <p className={mlTest.ok ? "text-emerald-600" : "text-destructive"}>{mlTest.message}</p>
            )}
            <div className="flex flex-wrap gap-2">
              <Button size="sm" onClick={() => connect("mercadolibre")} disabled={busy === "mercadolibre"}>
                <Plug className="h-4 w-4 mr-2" />{mlConnected ? "Reconectar" : "Conectar"}
              </Button>
              <Button size="sm" variant="outline" onClick={testMl} disabled={!mlConnected || busy === "test-ml"}>
                {busy === "test-ml" ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}Probar conexión
              </Button>
              <Button size="sm" variant="ghost" onClick={() => disconnect("mercadolibre")} disabled={!mlConnected}>
                <Unplug className="h-4 w-4 mr-2" />Desconectar
              </Button>
            </div>
            <Accordion type="single" collapsible>
              <AccordionItem value="guia" className="border-b-0">
                <AccordionTrigger className="text-sm py-2">Cómo configurar la app</AccordionTrigger>
                <AccordionContent className="space-y-2 text-muted-foreground">
                  <p>1. Creá una aplicación en Mercado Libre Developers.</p>
                  <p>2. Copiá el App ID y el Secret Key a la configuración del sistema (nunca al navegador).</p>
                  <p>3. Registrá esta Redirect URI, exactamente igual:</p>
                  <div className="flex items-center gap-2 bg-muted rounded p-2 break-all">
                    <code className="text-xs flex-1">{check("ml_redirect")?.detail}</code>
                    <Button size="icon" variant="ghost" onClick={() => copy(check("ml_redirect")?.detail || "")}>
                      <Copy className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                  <p>4. Volvé acá y tocá “Conectar”.</p>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </CardContent>
        </Card>

        {/* Facebook */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base">Facebook</CardTitle>
            <StatusPill ok={!!meta?.facebook.ok}>
              {!metaReady ? "Falta configurar la app" : meta?.facebook.ok ? "Conectado" : "No conectado"}
            </StatusPill>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <p className={meta?.facebook.ok ? "text-emerald-600" : "text-muted-foreground"}>
              {meta?.facebook.message ?? "—"}
            </p>

            {!!meta?.pages?.length && (
              <div className="space-y-2">
                <p className="font-medium">Elegí dónde publicar en Facebook</p>
                {meta.pages.map((p) => (
                  <div key={p.id} className="flex items-center justify-between gap-2 rounded border p-2">
                    <div>
                      <p className="font-medium">{p.name}</p>
                      <p className="text-xs text-muted-foreground">
                        ID {p.masked_id} · {p.instagram ? `Instagram @${p.instagram.username ?? "vinculado"}` : "Sin Instagram profesional"}
                      </p>
                    </div>
                    <Button size="sm" variant={p.selected ? "secondary" : "outline"}
                      disabled={p.selected || busy === `page-${p.id}`} onClick={() => selectPage(p.id)}>
                      {p.selected ? "En uso" : "Usar esta Página"}
                    </Button>
                  </div>
                ))}
              </div>
            )}

            <div className="flex flex-wrap gap-2">
              <Button size="sm" onClick={() => connect("meta")} disabled={busy === "meta"}>
                <Plug className="h-4 w-4 mr-2" />{meta?.facebook.ok ? "Reconectar Facebook" : "Conectar Facebook"}
              </Button>
              <Button size="sm" variant="outline" onClick={load} disabled={loading}>Probar conexión</Button>
              <Button size="sm" variant="ghost" onClick={() => disconnect("meta")} disabled={!meta?.connected}>
                <Unplug className="h-4 w-4 mr-2" />Desconectar
              </Button>
            </div>

            <Accordion type="single" collapsible>
              <AccordionItem value="guia" className="border-b-0">
                <AccordionTrigger className="text-sm py-2">Cómo configurar la app de Meta</AccordionTrigger>
                <AccordionContent className="space-y-2 text-muted-foreground">
                  <p>1. Creá una app en Meta for Developers con Facebook Login para empresas.</p>
                  <p>2. Agregá esta URL exacta en “Valid OAuth Redirect URIs”:</p>
                  <div className="flex items-center gap-2 bg-muted rounded p-2 break-all">
                    <code className="text-xs flex-1">{check("meta_redirect")?.detail}</code>
                    <Button size="icon" variant="ghost" onClick={() => copy(check("meta_redirect")?.detail || "")}>
                      <Copy className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                  <p>3. Tenés que administrar una Página de Facebook.</p>
                  <p>4. Si la app está en modo desarrollo, sólo funciona con roles de la app.</p>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </CardContent>
        </Card>

        {/* Instagram */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base">Instagram</CardTitle>
            <StatusPill ok={!!meta?.instagram.ok}>
              {!metaReady ? "Falta configurar la app" : meta?.instagram.ok ? "Conectado" : "No conectado"}
            </StatusPill>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <p className={meta?.instagram.ok ? "text-emerald-600" : "text-muted-foreground"}>
              {meta?.instagram.message ?? "—"}
            </p>

            {!!meta?.missingScopes?.length && (
              <p className="text-amber-600">Faltan permisos: {meta.missingScopes.join(", ")}. Tocá “Reconectar y autorizar permisos”.</p>
            )}

            <div className="flex flex-wrap gap-2">
              <Button size="sm" onClick={() => connect("meta")} disabled={busy === "meta"}>
                <Plug className="h-4 w-4 mr-2" />{meta?.instagram.ok ? "Reconectar Instagram" : "Conectar Instagram"}
              </Button>
              <Button size="sm" variant="outline" onClick={load} disabled={loading}>Probar conexión</Button>
              <Button size="sm" variant="ghost" onClick={() => disconnect("meta")} disabled={!meta?.connected}>
                <Unplug className="h-4 w-4 mr-2" />Desconectar
              </Button>
            </div>

            <Accordion type="single" collapsible>
              <AccordionItem value="guia" className="border-b-0">
                <AccordionTrigger className="text-sm py-2">Cómo conectar Instagram</AccordionTrigger>
                <AccordionContent className="space-y-2 text-muted-foreground">
                  <p>1. Instagram debe ser cuenta profesional (Empresa o Creador).</p>
                  <p>2. Tiene que estar vinculada a una Página de Facebook que administres.</p>
                  <p>3. Al conectar, autorizá los permisos de Instagram (publicación de contenido).</p>
                  <p>4. Volvé acá y tocá “Probar conexión”.</p>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </CardContent>
        </Card>
      </div>


      {/* Diagnóstico */}
      <Card>
        <CardHeader><CardTitle className="text-base">Diagnóstico de integraciones</CardTitle></CardHeader>
        <CardContent className="space-y-2 text-sm">
          {loading && !checks.length && <p className="text-muted-foreground">Revisando…</p>}
          {checks.map((c) => (
            <div key={c.id} className="flex items-start gap-2 border-b last:border-b-0 py-2">
              {c.ok
                ? <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                : <XCircle className="h-4 w-4 text-destructive shrink-0 mt-0.5" />}
              <div className="min-w-0">
                <p className="font-medium">{c.label}</p>
                <p className="text-muted-foreground break-all">{c.detail}</p>
                {!c.ok && c.fix && <p className="text-amber-600">Solución: {c.fix}</p>}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
