import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { CHANNELS, VEHICLE_STATUS, money, pubStatus } from "@/lib/publisher";
import { Plus, RefreshCw, Link2, History } from "lucide-react";

export default function PublicadorProPage() {
  const navigate = useNavigate();
  const [vehicles, setVehicles] = useState<any[]>([]);
  const [pubs, setPubs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");

  const load = async () => {
    setLoading(true);
    const [v, p] = await Promise.all([
      supabase.from("vehicles").select("*").order("updated_at", { ascending: false }),
      supabase.from("publications").select("*"),
    ]);
    if (v.error) toast.error(v.error.message);
    setVehicles(v.data || []);
    setPubs(p.data || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return vehicles;
    return vehicles.filter((v) =>
      [v.title, v.brand, v.model, v.trim, v.internal_title].filter(Boolean).join(" ").toLowerCase().includes(term));
  }, [vehicles, q]);

  const crear = async () => {
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) return;
    const { data, error } = await supabase.from("vehicles")
      .insert({ user_id: userData.user.id, title: "Nuevo auto" }).select("id").single();
    if (error) return toast.error(error.message);
    navigate(`/publicador-pro/${data.id}`);
  };

  const stats = {
    total: vehicles.length,
    publicados: new Set(pubs.filter((p) => p.status === "published").map((p) => p.vehicle_id)).size,
    fallidos: pubs.filter((p) => p.status === "failed").length,
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Publicador multicanal</h1>
          <p className="text-sm text-muted-foreground">Cargá el auto una vez y publicalo en Mercado Libre, Instagram y Facebook.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={load}><RefreshCw className="h-4 w-4 mr-2" />Actualizar</Button>
          <Button variant="outline" asChild><Link to="/publicador-pro/publicaciones"><History className="h-4 w-4 mr-2" />Publicaciones</Link></Button>
          <Button variant="outline" asChild><Link to="/publicador-pro/conexiones"><Link2 className="h-4 w-4 mr-2" />Conexiones</Link></Button>
          <Button onClick={crear}><Plus className="h-4 w-4 mr-2" />Nuevo auto</Button>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        {[["Autos cargados", stats.total], ["Con publicación activa", stats.publicados], ["Errores por resolver", stats.fallidos]].map(([l, v]) => (
          <Card key={l as string}><CardContent className="pt-6">
            <p className="text-sm text-muted-foreground">{l as string}</p>
            <p className="text-2xl font-bold">{v as number}</p>
          </CardContent></Card>
        ))}
      </div>

      <Input placeholder="Buscar por marca, modelo o título…" value={q} onChange={(e) => setQ(e.target.value)} className="max-w-sm" />

      <Card>
        <CardHeader><CardTitle>Autos</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          {loading && <p className="text-sm text-muted-foreground">Cargando…</p>}
          {!loading && !filtered.length && <p className="text-sm text-muted-foreground">Todavía no cargaste ningún auto.</p>}
          {filtered.map((v) => (
            <Link key={v.id} to={`/publicador-pro/${v.id}`}
              className="flex flex-wrap items-center justify-between gap-3 rounded-lg border p-4 hover:bg-accent/40 transition-colors">
              <div>
                <p className="font-medium">{v.title || "Sin título"}</p>
                <p className="text-sm text-muted-foreground">
                  {[v.brand, v.model, v.trim, v.vehicle_year].filter(Boolean).join(" ")} · {money(v.price, v.currency_id)}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant="outline">{VEHICLE_STATUS[v.status] ?? v.status}</Badge>
                {CHANNELS.map((c) => {
                  const p = pubs.find((x) => x.vehicle_id === v.id && x.channel === c.id);
                  const meta = pubStatus(p?.status);
                  return <Badge key={c.id} variant="outline" className={meta.tone}>{c.label}: {meta.label}</Badge>;
                })}
              </div>
            </Link>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
