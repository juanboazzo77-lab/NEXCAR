import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Collapsible, CollapsibleContent, CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { toast } from "sonner";
import { callFn, channelLabel, pubStatus } from "@/lib/publisher";
import { RefreshCw, RotateCcw, ExternalLink } from "lucide-react";

export default function PublisherPublicacionesPage() {
  const [rows, setRows] = useState<any[]>([]);
  const [vehicles, setVehicles] = useState<Record<string, any>>({});
  const [busy, setBusy] = useState<string | null>(null);

  const load = async () => {
    const [p, v] = await Promise.all([
      supabase.from("publications").select("*").order("updated_at", { ascending: false }),
      supabase.from("vehicles").select("id,title,brand,model"),
    ]);
    setRows(p.data || []);
    setVehicles(Object.fromEntries((v.data || []).map((x) => [x.id, x])));
  };

  useEffect(() => { load(); }, []);

  const sync = async () => {
    setBusy("sync");
    try { await callFn("sync-publication-status", {}); toast.success("Estados sincronizados"); await load(); }
    catch (e) { toast.error((e as Error).message); }
    setBusy(null);
  };

  const retry = async (row: any) => {
    setBusy(row.id);
    try {
      const res = await callFn("publish-vehicle", {
        vehicleId: row.vehicle_id, channels: [row.channel], retry: true,
      });
      const r = res.results?.[0];
      if (r?.status === "published") toast.success(`${channelLabel(row.channel)}: publicado`);
      else toast.error(r?.message || "No se pudo reintentar");
      await load();
    } catch (e) { toast.error((e as Error).message); }
    setBusy(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Publicaciones</h1>
          <p className="text-sm text-muted-foreground">Historial por canal, con reintento del canal que falló.</p>
        </div>
        <Button variant="outline" onClick={sync} disabled={busy === "sync"}>
          <RefreshCw className="h-4 w-4 mr-2" />Sincronizar estados
        </Button>
      </div>

      <Card>
        <CardHeader><CardTitle>Historial</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          {!rows.length && <p className="text-sm text-muted-foreground">Todavía no hay publicaciones.</p>}
          {rows.map((row) => {
            const meta = pubStatus(row.status);
            const vehicle = vehicles[row.vehicle_id];
            return (
              <div key={row.id} className="rounded-lg border p-4 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <Link to={`/publicador-pro/${row.vehicle_id}`} className="font-medium hover:underline">
                      {vehicle?.title || "Auto"} <span className="text-muted-foreground">· {channelLabel(row.channel)}</span>
                    </Link>
                    <p className="text-xs text-muted-foreground">
                      Intentos: {row.attempts} · {new Date(row.updated_at).toLocaleString("es-AR")}
                      {row.external_id ? ` · ID ${row.external_id}` : ""}
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge variant="outline" className={meta.tone}>{meta.label}</Badge>
                    {row.external_url && (
                      <Button variant="outline" size="sm" asChild>
                        <a href={row.external_url} target="_blank" rel="noreferrer"><ExternalLink className="h-4 w-4 mr-1" />Ver</a>
                      </Button>
                    )}
                    {["failed", "partial"].includes(row.status) && (
                      <Button size="sm" onClick={() => retry(row)} disabled={busy === row.id}>
                        <RotateCcw className="h-4 w-4 mr-1" />Reintentar
                      </Button>
                    )}
                  </div>
                </div>
                {row.error_message && <p className="text-sm text-destructive">{row.error_message}</p>}
                {row.response_snapshot && (
                  <Collapsible>
                    <CollapsibleTrigger className="text-xs text-muted-foreground underline">Ver respuesta técnica</CollapsibleTrigger>
                    <CollapsibleContent>
                      <pre className="mt-2 max-h-64 overflow-auto rounded bg-muted p-3 text-xs">
                        {JSON.stringify(row.response_snapshot, null, 2)}
                      </pre>
                    </CollapsibleContent>
                  </Collapsible>
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}
