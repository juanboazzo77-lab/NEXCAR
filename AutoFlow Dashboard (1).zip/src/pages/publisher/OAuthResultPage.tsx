import { useEffect } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle2, XCircle } from "lucide-react";

const PROVIDERS: Record<string, string> = {
  mercadolibre: "Mercado Libre",
  meta: "Facebook e Instagram",
};

export default function OAuthResultPage() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const provider = params.get("provider") ?? "";
  const success = params.get("success") === "1";
  const message = params.get("message");
  const account = params.get("account");
  const pages = params.get("pages");

  useEffect(() => {
    if (!success) return;
    const t = setTimeout(() => navigate("/publicador-pro/conexiones", { replace: true }), 2500);
    return () => clearTimeout(t);
  }, [success, navigate]);

  return (
    <div className="min-h-[60vh] flex items-center justify-center p-6">
      <Card className="max-w-md w-full">
        <CardContent className="pt-8 pb-6 text-center space-y-4">
          {success ? (
            <CheckCircle2 className="h-12 w-12 mx-auto text-emerald-600" />
          ) : (
            <XCircle className="h-12 w-12 mx-auto text-destructive" />
          )}
          <h1 className="text-xl font-bold">
            {success
              ? `${PROVIDERS[provider] ?? "Cuenta"} conectado`
              : `No pudimos conectar ${PROVIDERS[provider] ?? "la cuenta"}`}
          </h1>
          <p className="text-sm text-muted-foreground">
            {success
              ? account
                ? `Conectado como: ${account}`
                : pages
                  ? `Encontramos ${pages} Página(s). Elegí en cuál querés publicar.`
                  : "Ya podés seguir configurando la publicación."
              : message || "Volvé a intentarlo desde Conexiones."}
          </p>
          <Button asChild className="w-full">
            <Link to="/publicador-pro/conexiones">Volver a Conexiones</Link>
          </Button>
          {success && <p className="text-xs text-muted-foreground">Te llevamos solos en unos segundos…</p>}
        </CardContent>
      </Card>
    </div>
  );
}
