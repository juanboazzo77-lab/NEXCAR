import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useAgency } from "@/hooks/useAgency";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Handshake, Plus, MessageSquare, Trash2, Phone, Building2, Lock } from "lucide-react";

const emptyReq = {
  marca: "", modelo: "", version: "", anio_desde: "", anio_hasta: "", km_max: "",
  presupuesto_max: "", moneda: "ARS", detalle: "", contacto_nombre: "", contacto_telefono: "",
};

export default function RedB2BPage() {
  const { user } = useAuth();
  const { agency } = useAgency();
  const { toast } = useToast();

  const [requests, setRequests] = useState<any[]>([]);
  const [offers, setOffers] = useState<any[]>([]);
  const [agencies, setAgencies] = useState<Record<string, string>>({});
  const [cars, setCars] = useState<any[]>([]);
  const [form, setForm] = useState<any>(emptyReq);
  const [open, setOpen] = useState(false);
  const [offerFor, setOfferFor] = useState<string | null>(null);
  const [offer, setOffer] = useState<any>({ car_id: "", mensaje: "", precio: "", moneda: "ARS", contacto_telefono: "" });
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [r, o, a, c] = await Promise.all([
      (supabase as any).from("b2b_requests").select("*").order("created_at", { ascending: false }),
      (supabase as any).from("b2b_offers").select("*").order("created_at", { ascending: false }),
      supabase.from("agencies").select("id, name"),
      supabase.from("cars").select("id, marca, modelo, version, anio, patente, precio_venta, moneda, b2b_disponible, b2b_precio, estado").neq("estado", "Vendido").order("created_at", { ascending: false }),
    ]);
    setRequests(r.data || []);
    setOffers(o.data || []);
    setAgencies(Object.fromEntries(((a.data as any[]) || []).map((x) => [x.id, x.name])));
    setCars((c.data as any[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const misAutosB2B = useMemo(() => cars.filter((c) => c.b2b_disponible), [cars]);

  const crearPedido = async () => {
    if (!agency?.id || !user) { toast({ title: "Necesitás una agencia asignada", variant: "destructive" }); return; }
    if (!form.marca && !form.modelo) { toast({ title: "Indicá al menos marca o modelo", variant: "destructive" }); return; }
    const { error } = await (supabase as any).from("b2b_requests").insert({
      agency_id: agency.id, user_id: user.id,
      marca: form.marca || null, modelo: form.modelo || null, version: form.version || null,
      anio_desde: form.anio_desde ? Number(form.anio_desde) : null,
      anio_hasta: form.anio_hasta ? Number(form.anio_hasta) : null,
      km_max: form.km_max ? Number(form.km_max) : null,
      presupuesto_max: form.presupuesto_max ? Number(form.presupuesto_max) : null,
      moneda: form.moneda, detalle: form.detalle || null,
      contacto_nombre: form.contacto_nombre || null,
      contacto_telefono: form.contacto_telefono || agency.whatsapp || agency.telefono || null,
    });
    if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); return; }
    setForm(emptyReq); setOpen(false); toast({ title: "Pedido publicado en la red B2B" });
    load();
  };

  const cambiarEstado = async (id: string, estado: string) => {
    await (supabase as any).from("b2b_requests").update({ estado }).eq("id", id);
    load();
  };

  const borrarPedido = async (id: string) => {
    await (supabase as any).from("b2b_requests").delete().eq("id", id);
    load();
  };

  const responder = async (requestId: string) => {
    if (!agency?.id || !user) return;
    const { error } = await (supabase as any).from("b2b_offers").insert({
      request_id: requestId, agency_id: agency.id, user_id: user.id,
      car_id: offer.car_id || null, mensaje: offer.mensaje || null,
      precio: offer.precio ? Number(offer.precio) : null, moneda: offer.moneda,
      contacto_telefono: offer.contacto_telefono || agency.whatsapp || agency.telefono || null,
    });
    if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); return; }
    setOffer({ car_id: "", mensaje: "", precio: "", moneda: "ARS", contacto_telefono: "" });
    setOfferFor(null);
    toast({ title: "Respuesta enviada" });
    load();
  };

  const toggleB2B = async (car: any, value: boolean) => {
    const { error } = await supabase.from("cars").update({ b2b_disponible: value } as any).eq("id", car.id);
    if (error) { toast({ title: "Error", description: error.message, variant: "destructive" }); return; }
    setCars((prev) => prev.map((c) => (c.id === car.id ? { ...c, b2b_disponible: value } : c)));
  };

  const setB2BPrecio = async (car: any, precio: string) => {
    await supabase.from("cars").update({ b2b_precio: precio ? Number(precio) : null } as any).eq("id", car.id);
    setCars((prev) => prev.map((c) => (c.id === car.id ? { ...c, b2b_precio: precio ? Number(precio) : null } : c)));
  };

  const offersOf = (rid: string) => offers.filter((o) => o.request_id === rid);
  const abiertos = requests.filter((r) => r.estado === "abierto");
  const mios = requests.filter((r) => r.agency_id === agency?.id);
  const carLabel = (id: string) => {
    const c = cars.find((x) => x.id === id);
    return c ? [c.marca, c.modelo, c.version, c.anio].filter(Boolean).join(" ") : "Vehículo";
  };

  const RequestCard = ({ r, own }: { r: any; own: boolean }) => {
    const os = offersOf(r.id);
    return (
      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div>
              <div className="font-semibold">
                Busco {[r.marca, r.modelo, r.version].filter(Boolean).join(" ")}
                {r.anio_desde || r.anio_hasta ? ` ${r.anio_desde || ""}${r.anio_hasta ? `-${r.anio_hasta}` : ""}` : ""}
              </div>
              <div className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                <Building2 className="h-3 w-3" /> {agencies[r.agency_id] || "Agencia"} · {new Date(r.created_at).toLocaleDateString("es-AR")}
              </div>
            </div>
            <div className="flex gap-2 items-center">
              <Badge variant={r.estado === "abierto" ? "default" : "secondary"}>{r.estado}</Badge>
              {own && (
                <>
                  <Button size="sm" variant="outline" onClick={() => cambiarEstado(r.id, r.estado === "abierto" ? "cerrado" : "abierto")}>
                    {r.estado === "abierto" ? "Cerrar" : "Reabrir"}
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => borrarPedido(r.id)}><Trash2 className="h-4 w-4" /></Button>
                </>
              )}
            </div>
          </div>

          <div className="text-sm text-muted-foreground space-y-1">
            {r.presupuesto_max && <div>Presupuesto hasta {r.moneda === "USD" ? "USD" : "$"} {Number(r.presupuesto_max).toLocaleString("es-AR")}</div>}
            {r.km_max && <div>Hasta {Number(r.km_max).toLocaleString("es-AR")} km</div>}
            {r.detalle && <p className="whitespace-pre-wrap">{r.detalle}</p>}
            {r.contacto_telefono && (
              <a className="inline-flex items-center gap-1 text-primary" href={`https://wa.me/${String(r.contacto_telefono).replace(/\D/g, "")}`} target="_blank" rel="noreferrer">
                <Phone className="h-3.5 w-3.5" /> {r.contacto_nombre || "Contactar"} por WhatsApp
              </a>
            )}
          </div>

          {os.length > 0 && (
            <div className="border-t pt-2 space-y-2">
              <div className="text-xs font-semibold text-muted-foreground">{os.length} respuesta(s)</div>
              {os.map((o) => (
                <div key={o.id} className="text-sm rounded-md bg-muted/50 p-2">
                  <div className="font-medium">{agencies[o.agency_id] || "Agencia"}{o.car_id ? ` · ${carLabel(o.car_id)}` : ""}</div>
                  {o.precio && <div className="text-xs">{o.moneda === "USD" ? "USD" : "$"} {Number(o.precio).toLocaleString("es-AR")}</div>}
                  {o.mensaje && <p className="text-xs text-muted-foreground whitespace-pre-wrap">{o.mensaje}</p>}
                  {o.contacto_telefono && (
                    <a className="text-xs text-primary" href={`https://wa.me/${String(o.contacto_telefono).replace(/\D/g, "")}`} target="_blank" rel="noreferrer">WhatsApp</a>
                  )}
                </div>
              ))}
            </div>
          )}

          {!own && r.estado === "abierto" && (
            <div className="border-t pt-3">
              {offerFor === r.id ? (
                <div className="grid gap-2 sm:grid-cols-2">
                  <div className="sm:col-span-2">
                    <Label className="text-xs">Vehículo que ofrecés (opcional)</Label>
                    <Select value={offer.car_id || "__none__"} onValueChange={(v) => setOffer({ ...offer, car_id: v === "__none__" ? "" : v })}>
                      <SelectTrigger><SelectValue placeholder="Elegir de mi stock" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none__">Sin vehículo puntual</SelectItem>
                        {cars.map((c) => (
                          <SelectItem key={c.id} value={c.id}>{[c.marca, c.modelo, c.version, c.anio].filter(Boolean).join(" ")}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div><Label className="text-xs">Precio entre agencias</Label><Input type="number" value={offer.precio} onChange={(e) => setOffer({ ...offer, precio: e.target.value })} /></div>
                  <div><Label className="text-xs">Tu WhatsApp</Label><Input value={offer.contacto_telefono} onChange={(e) => setOffer({ ...offer, contacto_telefono: e.target.value })} placeholder={agency?.whatsapp || ""} /></div>
                  <div className="sm:col-span-2"><Label className="text-xs">Mensaje</Label><Textarea rows={2} value={offer.mensaje} onChange={(e) => setOffer({ ...offer, mensaje: e.target.value })} /></div>
                  <div className="sm:col-span-2 flex gap-2">
                    <Button size="sm" onClick={() => responder(r.id)}>Enviar respuesta</Button>
                    <Button size="sm" variant="ghost" onClick={() => setOfferFor(null)}>Cancelar</Button>
                  </div>
                </div>
              ) : (
                <Button size="sm" variant="outline" onClick={() => setOfferFor(r.id)}>
                  <MessageSquare className="h-4 w-4 mr-2" /> Tengo uno
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2"><Handshake className="h-6 w-6 text-primary" /> Red B2B entre agencias</h1>
          <p className="text-sm text-muted-foreground flex items-center gap-1">
            <Lock className="h-3.5 w-3.5" /> Sector privado: los clientes del catálogo público no ven nada de esto.
          </p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-2" /> Publicar pedido</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Busco un vehículo para un cliente</DialogTitle></DialogHeader>
            <div className="grid gap-3 sm:grid-cols-2">
              <div><Label>Marca</Label><Input value={form.marca} onChange={(e) => setForm({ ...form, marca: e.target.value })} placeholder="Toyota" /></div>
              <div><Label>Modelo</Label><Input value={form.modelo} onChange={(e) => setForm({ ...form, modelo: e.target.value })} placeholder="Corolla" /></div>
              <div><Label>Versión</Label><Input value={form.version} onChange={(e) => setForm({ ...form, version: e.target.value })} placeholder="XEI" /></div>
              <div className="grid grid-cols-2 gap-2">
                <div><Label>Año desde</Label><Input type="number" value={form.anio_desde} onChange={(e) => setForm({ ...form, anio_desde: e.target.value })} /></div>
                <div><Label>Año hasta</Label><Input type="number" value={form.anio_hasta} onChange={(e) => setForm({ ...form, anio_hasta: e.target.value })} /></div>
              </div>
              <div><Label>Km máximo</Label><Input type="number" value={form.km_max} onChange={(e) => setForm({ ...form, km_max: e.target.value })} /></div>
              <div className="grid grid-cols-[1fr_auto] gap-2">
                <div><Label>Presupuesto</Label><Input type="number" value={form.presupuesto_max} onChange={(e) => setForm({ ...form, presupuesto_max: e.target.value })} /></div>
                <div>
                  <Label>Moneda</Label>
                  <Select value={form.moneda} onValueChange={(v) => setForm({ ...form, moneda: v })}>
                    <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="ARS">ARS</SelectItem><SelectItem value="USD">USD</SelectItem></SelectContent>
                  </Select>
                </div>
              </div>
              <div><Label>Contacto</Label><Input value={form.contacto_nombre} onChange={(e) => setForm({ ...form, contacto_nombre: e.target.value })} /></div>
              <div><Label>WhatsApp</Label><Input value={form.contacto_telefono} onChange={(e) => setForm({ ...form, contacto_telefono: e.target.value })} placeholder={agency?.whatsapp || ""} /></div>
              <div className="sm:col-span-2"><Label>Detalle</Label><Textarea rows={3} value={form.detalle} onChange={(e) => setForm({ ...form, detalle: e.target.value })} placeholder="Color claro, service oficial, permuto..." /></div>
            </div>
            <Button onClick={crearPedido}>Publicar en la red</Button>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="red">
        <TabsList>
          <TabsTrigger value="red">Pedidos de la red ({abiertos.length})</TabsTrigger>
          <TabsTrigger value="mios">Mis pedidos ({mios.length})</TabsTrigger>
          <TabsTrigger value="stock">Mi stock B2B ({misAutosB2B.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="red" className="pt-4 space-y-3">
          {loading && <p className="text-sm text-muted-foreground">Cargando...</p>}
          {!loading && !abiertos.length && <p className="text-sm text-muted-foreground">Todavía no hay pedidos abiertos en la red.</p>}
          {abiertos.map((r) => <RequestCard key={r.id} r={r} own={r.agency_id === agency?.id} />)}
        </TabsContent>

        <TabsContent value="mios" className="pt-4 space-y-3">
          {!mios.length && <p className="text-sm text-muted-foreground">Todavía no publicaste pedidos.</p>}
          {mios.map((r) => <RequestCard key={r.id} r={r} own />)}
        </TabsContent>

        <TabsContent value="stock" className="pt-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Vehículos disponibles para operar entre agencias</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {cars.map((c) => (
                <div key={c.id} className="flex items-center justify-between gap-3 border-b last:border-0 py-2 flex-wrap">
                  <div>
                    <div className="text-sm font-medium">{[c.marca, c.modelo, c.version, c.anio].filter(Boolean).join(" ")}</div>
                    <div className="text-xs text-muted-foreground">{c.patente || "Sin patente"}</div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Input
                      className="w-36" type="number" placeholder="Precio B2B"
                      defaultValue={c.b2b_precio ?? ""}
                      onBlur={(e) => setB2BPrecio(c, e.target.value)}
                    />
                    <div className="flex items-center gap-2 text-xs">
                      <Switch checked={!!c.b2b_disponible} onCheckedChange={(v) => toggleB2B(c, v)} />
                      Disponible B2B
                    </div>
                  </div>
                </div>
              ))}
              {!cars.length && <p className="text-sm text-muted-foreground">No tenés vehículos en stock.</p>}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
