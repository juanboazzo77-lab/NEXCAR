import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { ChevronLeft, ChevronRight, Plus, Trash2, Calendar as CalIcon, Mail } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";
import { useCalendarEvents, useUpsertCalendarEvent, useDeleteCalendarEvent, type CalendarEvent } from "@/hooks/use-calendar";
import { useSales, useCars } from "@/hooks/use-data";
import { formatCurrency } from "@/lib/supabase-helpers";
import { NotificationPhonesCard } from "@/components/NotificationPhonesCard";

type EventType = "reunion" | "tarea" | "cobro" | "contrato" | "vencimiento" | "otro";

const TYPE_META: Record<string, { label: string; color: string; ring: string }> = {
  reunion:     { label: "Reunión",      color: "bg-blue-500 text-white",    ring: "border-blue-500" },
  tarea:       { label: "Tarea",        color: "bg-amber-500 text-white",   ring: "border-amber-500" },
  cobro:       { label: "Cobro",        color: "bg-emerald-500 text-white", ring: "border-emerald-500" },
  contrato:    { label: "Contrato",     color: "bg-purple-500 text-white",  ring: "border-purple-500" },
  vencimiento: { label: "Vencimiento",  color: "bg-rose-500 text-white",    ring: "border-rose-500" },
  otro:        { label: "Otro",         color: "bg-slate-500 text-white",   ring: "border-slate-500" },
};

const MONTHS = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
const DOW = ["Lun","Mar","Mié","Jue","Vie","Sáb","Dom"];

type DerivedEvent = {
  id: string;
  fecha: string; // YYYY-MM-DD
  hora?: string | null;
  titulo: string;
  descripcion?: string | null;
  tipo: EventType;
  auto?: boolean;
  source?: string;
};

function toISO(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function addMonths(iso: string, n: number) {
  const [y, m, d] = iso.split("T")[0].split("-").map(Number);
  const dt = new Date(y, (m - 1) + n, d);
  return toISO(dt);
}

export default function CalendarioPage() {
  const today = new Date();
  const [cursor, setCursor] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [filter, setFilter] = useState<string>("all");
  const [selected, setSelected] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Partial<CalendarEvent> | null>(null);

  const { data: events = [] } = useCalendarEvents();
  const { data: sales = [] } = useSales();
  const { data: cars = [] } = useCars();
  const upsert = useUpsertCalendarEvent();
  const remove = useDeleteCalendarEvent();

  const carById = useMemo(() => Object.fromEntries(cars.map(c => [c.id, c])), [cars]);

  // Auto-derived events: contratos (sale.fecha) + cuotas proyectadas
  const derived: DerivedEvent[] = useMemo(() => {
    const out: DerivedEvent[] = [];
    for (const s of sales) {
      if (!s.fecha) continue;
      const car = s.car_id ? carById[s.car_id] : null;
      const auto = car ? `${car.marca ?? ""} ${car.modelo ?? ""} ${car.patente ?? ""}`.trim() : (s.marca_modelo ?? s.patente ?? "Auto");
      out.push({
        id: `sale-${s.id}`,
        fecha: s.fecha,
        titulo: `Contrato / Entrega – ${auto}`,
        descripcion: `Venta a ${s.vendedor ?? "cliente"} por ${formatCurrency(Number(s.monto ?? 0))}`,
        tipo: "contrato",
        auto: true,
        source: "venta",
      });
      const cuotas = Number(s.cuotas ?? 0);
      const montoFin = Number(s.monto_financiar ?? 0);
      if (cuotas > 0 && montoFin > 0) {
        const monto = montoFin / cuotas;
        for (let i = 1; i <= cuotas; i++) {
          out.push({
            id: `cuota-${s.id}-${i}`,
            fecha: addMonths(s.fecha, i),
            titulo: `Cuota ${i}/${cuotas} – ${auto}`,
            descripcion: `Cobro estimado: ${formatCurrency(monto)}`,
            tipo: "cobro",
            auto: true,
            source: "cuota",
          });
        }
      }
    }
    return out;
  }, [sales, carById]);

  const allEvents: DerivedEvent[] = useMemo(() => {
    const manual: DerivedEvent[] = events.map(e => ({
      id: e.id,
      fecha: e.fecha,
      hora: e.hora,
      titulo: e.titulo,
      descripcion: e.descripcion,
      tipo: (e.tipo as EventType) || "otro",
      auto: false,
    }));
    const merged = [...manual, ...derived];
    if (filter === "all") return merged;
    return merged.filter(e => e.tipo === filter);
  }, [events, derived, filter]);

  const byDay = useMemo(() => {
    const m: Record<string, DerivedEvent[]> = {};
    for (const e of allEvents) {
      (m[e.fecha] ||= []).push(e);
    }
    return m;
  }, [allEvents]);

  // Build grid (Mon-Sun)
  const cells = useMemo(() => {
    const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
    const dow = (first.getDay() + 6) % 7; // 0 = Monday
    const daysInMonth = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
    const arr: { date: Date | null; iso: string | null }[] = [];
    for (let i = 0; i < dow; i++) arr.push({ date: null, iso: null });
    for (let d = 1; d <= daysInMonth; d++) {
      const dt = new Date(cursor.getFullYear(), cursor.getMonth(), d);
      arr.push({ date: dt, iso: toISO(dt) });
    }
    while (arr.length % 7 !== 0) arr.push({ date: null, iso: null });
    return arr;
  }, [cursor]);

  const monthEvents = useMemo(() => {
    const start = toISO(new Date(cursor.getFullYear(), cursor.getMonth(), 1));
    const end = toISO(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0));
    return allEvents
      .filter(e => e.fecha >= start && e.fecha <= end)
      .sort((a, b) => a.fecha.localeCompare(b.fecha));
  }, [allEvents, cursor]);

  const handleSave = async () => {
    if (!editing?.titulo || !editing?.fecha) {
      toast({ title: "Falta título o fecha", variant: "destructive" });
      return;
    }
    try {
      await upsert.mutateAsync(editing as any);
      toast({ title: editing.id ? "Evento actualizado" : "Evento creado" });
      setOpen(false);
      setEditing(null);
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("¿Eliminar evento?")) return;
    await remove.mutateAsync(id);
    toast({ title: "Evento eliminado" });
  };

  const openNew = (iso?: string) => {
    setEditing({
      titulo: "",
      descripcion: "",
      fecha: iso ?? toISO(new Date()),
      hora: null,
      tipo: "reunion",
      recordatorio_email: false,
      email_destino: "",
    });
    setOpen(true);
  };

  const openEdit = (ev: CalendarEvent) => {
    setEditing(ev);
    setOpen(true);
  };

  const todayISO = toISO(today);
  const selectedEvents = selected ? (byDay[selected] ?? []) : [];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold flex items-center gap-2">
            <CalIcon className="w-6 h-6" /> Calendario Ejecutivo
          </h1>
          <p className="text-sm text-muted-foreground">Reuniones, vencimientos, contratos, tareas y cobros.</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los tipos</SelectItem>
              {Object.entries(TYPE_META).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={() => openNew()}><Plus className="w-4 h-4" /> Nuevo evento</Button>
        </div>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <CardTitle className="capitalize">
            {MONTHS[cursor.getMonth()]} {cursor.getFullYear()}
          </CardTitle>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="icon" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={() => setCursor(new Date(today.getFullYear(), today.getMonth(), 1))}>Hoy</Button>
            <Button variant="outline" size="icon" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-px bg-border rounded-md overflow-hidden text-xs">
            {DOW.map(d => (
              <div key={d} className="bg-muted px-2 py-1 font-medium text-muted-foreground text-center">{d}</div>
            ))}
            {cells.map((c, i) => {
              const evs = c.iso ? (byDay[c.iso] ?? []) : [];
              const isToday = c.iso === todayISO;
              const isSelected = c.iso === selected;
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => c.iso && setSelected(c.iso)}
                  onDoubleClick={() => c.iso && openNew(c.iso)}
                  className={cn(
                    "bg-card min-h-[96px] p-1.5 text-left align-top flex flex-col gap-1 transition-colors hover:bg-accent/50",
                    !c.date && "bg-muted/40 cursor-default",
                    isSelected && "ring-2 ring-primary ring-inset",
                  )}
                  disabled={!c.date}
                >
                  {c.date && (
                    <div className={cn(
                      "text-[11px] font-medium w-6 h-6 flex items-center justify-center rounded-full",
                      isToday ? "bg-primary text-primary-foreground" : "text-foreground"
                    )}>
                      {c.date.getDate()}
                    </div>
                  )}
                  <div className="flex flex-col gap-0.5 overflow-hidden">
                    {evs.slice(0, 3).map(e => (
                      <span
                        key={e.id}
                        className={cn("truncate rounded px-1 py-0.5 text-[10px] leading-tight", TYPE_META[e.tipo]?.color ?? "bg-slate-500 text-white")}
                        title={e.titulo}
                      >
                        {e.hora ? e.hora.slice(0,5) + " " : ""}{e.titulo}
                      </span>
                    ))}
                    {evs.length > 3 && <span className="text-[10px] text-muted-foreground">+{evs.length - 3} más</span>}
                  </div>
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">{selected ? `Eventos del ${selected}` : "Seleccioná un día"}</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {selected && selectedEvents.length === 0 && (
              <p className="text-sm text-muted-foreground">No hay eventos. <button className="underline" onClick={() => openNew(selected)}>Agregar uno</button></p>
            )}
            {selectedEvents.map(e => {
              const manual = events.find(x => x.id === e.id);
              return (
                <div key={e.id} className={cn("border-l-4 rounded p-3 bg-card flex items-start justify-between gap-3", TYPE_META[e.tipo]?.ring)}>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant="secondary" className={TYPE_META[e.tipo]?.color}>{TYPE_META[e.tipo]?.label}</Badge>
                      {e.hora && <span className="text-xs text-muted-foreground">{e.hora.slice(0,5)}</span>}
                      {e.auto && <Badge variant="outline" className="text-[10px]">Auto</Badge>}
                      {manual?.recordatorio_email && <Mail className="w-3 h-3 text-muted-foreground" />}
                    </div>
                    <div className="font-medium text-sm mt-1">{e.titulo}</div>
                    {e.descripcion && <div className="text-xs text-muted-foreground whitespace-pre-wrap">{e.descripcion}</div>}
                  </div>
                  {manual && (
                    <div className="flex flex-col gap-1">
                      <Button size="sm" variant="outline" onClick={() => openEdit(manual)}>Editar</Button>
                      <Button size="sm" variant="ghost" onClick={() => handleDelete(manual.id)}><Trash2 className="w-3 h-3" /></Button>
                    </div>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Resumen del mes</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-1 max-h-[400px] overflow-auto">
              {monthEvents.length === 0 && <p className="text-sm text-muted-foreground">Sin eventos este mes.</p>}
              {monthEvents.map(e => (
                <div key={e.id} className="flex items-center gap-2 text-sm py-1 border-b last:border-0">
                  <span className="text-xs text-muted-foreground w-16 shrink-0">{e.fecha.slice(5)}</span>
                  <span className={cn("w-2 h-2 rounded-full shrink-0", TYPE_META[e.tipo]?.color)} />
                  <span className="truncate">{e.titulo}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <NotificationPhonesCard />

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editing?.id ? "Editar evento" : "Nuevo evento"}</DialogTitle></DialogHeader>
          {editing && (
            <div className="space-y-3">
              <div>
                <Label>Título</Label>
                <Input value={editing.titulo ?? ""} onChange={e => setEditing({ ...editing, titulo: e.target.value })} />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-1">
                  <Label>Tipo</Label>
                  <Select value={(editing.tipo as string) ?? "reunion"} onValueChange={v => setEditing({ ...editing, tipo: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(TYPE_META).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Fecha</Label>
                  <Input type="date" value={editing.fecha ?? ""} onChange={e => setEditing({ ...editing, fecha: e.target.value })} />
                </div>
                <div>
                  <Label>Hora</Label>
                  <Input type="time" value={editing.hora ?? ""} onChange={e => setEditing({ ...editing, hora: e.target.value || null })} />
                </div>
              </div>
              <div>
                <Label>Descripción / notas</Label>
                <Textarea rows={3} value={editing.descripcion ?? ""} onChange={e => setEditing({ ...editing, descripcion: e.target.value })} />
              </div>
              <div className="border rounded p-3 space-y-2 bg-muted/30">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="rec"
                    checked={!!editing.recordatorio_email}
                    onCheckedChange={(v) => setEditing({ ...editing, recordatorio_email: !!v })}
                  />
                  <Label htmlFor="rec" className="cursor-pointer">Recordarme por email un día antes</Label>
                </div>
                {editing.recordatorio_email && (
                  <Input
                    type="email"
                    placeholder="email@destino.com"
                    value={editing.email_destino ?? ""}
                    onChange={e => setEditing({ ...editing, email_destino: e.target.value })}
                  />
                )}
                <p className="text-[11px] text-muted-foreground">
                  Para activar el envío real de emails hace falta configurar el dominio de email del proyecto (te aviso después cómo).
                </p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button onClick={handleSave} disabled={upsert.isPending}>Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
