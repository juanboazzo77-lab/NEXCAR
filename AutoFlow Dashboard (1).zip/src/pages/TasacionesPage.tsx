import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { RefreshCw, MessageCircle } from "lucide-react";
import { useAgency } from "@/hooks/useAgency";

const ESTADOS = ["Pendiente", "En revisión", "Tasado", "Oferta enviada", "Finalizado"];

const buildWhatsappLink = (t: any, agencyName: string) => {
  const tel = String(t?.cliente_telefono || "").replace(/\D/g, "");
  if (!tel) return null;
  const phone = tel.startsWith("54") ? tel : `54${tel.replace(/^0/, "")}`;
  const auto = [t.marca, t.modelo, t.version, t.anio].filter(Boolean).join(" ");
  const lineas = [
    `Hola ${t.cliente_nombre || ""}, buenas! Te contacto de ${agencyName} porque nos pasaste los datos de tu vehículo para tasación.`,
    "",
    `Vehículo: ${auto || "—"}`,
    t.kilometros ? `Kilómetros: ${Number(t.kilometros).toLocaleString("es-AR")} km` : null,
    t.combustible ? `Combustible: ${t.combustible}` : null,
    t.caja ? `Caja: ${t.caja}` : null,
    t.estado_general ? `Estado general: ${t.estado_general}` : null,
    t.precio_pretendido ? `Precio pretendido: $ ${Number(t.precio_pretendido).toLocaleString("es-AR")}` : null,
    t.observaciones ? `Observaciones: ${t.observaciones}` : null,
    "",
    "¿Seguís interesado en tasarlo o entregarlo en parte de pago?",
  ].filter(Boolean);
  return `https://wa.me/${phone}?text=${encodeURIComponent(lineas.join("\n"))}`;
};

export default function TasacionesPage() {
  const { agency } = useAgency();
  const agencyName = agency?.name || "la agencia";
  const { toast } = useToast();
  const [items, setItems] = useState<any[]>([]);
  const [sel, setSel] = useState<any>(null);
  const [filterEstado, setFilterEstado] = useState("");

  const load = () => supabase.from("trade_in_requests").select("*").order("created_at", { ascending: false })
    .then(({ data }) => {
      setItems(data || []);
      window.dispatchEvent(new Event("tasaciones-change"));
    });
  useEffect(() => { load(); }, []);

  const updateEstado = async (id: string, estado: string) => {
    await supabase.from("trade_in_requests").update({ estado }).eq("id", id);
    toast({ title: "Estado actualizado" });
    load();
    if (sel?.id === id) setSel({ ...sel, estado });
  };

  const saveNotas = async () => {
    if (!sel) return;
    await supabase.from("trade_in_requests").update({ notas_internas: sel.notas_internas }).eq("id", sel.id);
    toast({ title: "Notas guardadas" });
    load();
  };

  const del = async (id: string) => {
    if (!confirm("¿Eliminar esta solicitud?")) return;
    await supabase.from("trade_in_requests").delete().eq("id", id);
    setSel(null); load();
  };

  const filtered = filterEstado ? items.filter((i) => i.estado === filterEstado) : items;


  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h1 className="text-xl font-bold flex items-center gap-2"><RefreshCw className="w-5 h-5" /> Tasaciones</h1>
        <select value={filterEstado} onChange={(e) => setFilterEstado(e.target.value)} className="px-3 py-2 rounded-lg border bg-card text-sm">
          <option value="">Todos los estados</option>
          {ESTADOS.map((e) => <option key={e} value={e}>{e}</option>)}
        </select>
      </div>

      <div className="grid lg:grid-cols-[1fr_1.5fr] gap-4">
        <div className="bg-card rounded-lg border divide-y">
          {filtered.length === 0 && <div className="p-6 text-center text-sm text-muted-foreground">Sin solicitudes.</div>}
          {filtered.map((t) => (
            <button key={t.id} onClick={() => setSel(t)}
              className={`w-full text-left p-3 hover:bg-muted/40 transition ${sel?.id === t.id ? "bg-muted/40" : ""}`}>
              <div className="flex items-center justify-between gap-2">
                <div className="font-medium text-sm">{t.marca} {t.modelo} {t.anio || ""}</div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-muted">{t.estado}</span>
              </div>
              <div className="text-xs text-muted-foreground">{t.cliente_nombre} · {t.cliente_telefono || t.cliente_email || "—"}</div>
              <div className="text-[11px] text-muted-foreground">{new Date(t.created_at).toLocaleString("es-AR")}</div>
            </button>
          ))}
        </div>

        {sel ? (
          <div className="bg-card rounded-lg border p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-semibold">{sel.marca} {sel.modelo} {sel.version || ""} {sel.anio || ""}</h2>
                <div className="text-xs text-muted-foreground">{new Date(sel.created_at).toLocaleString("es-AR")}</div>
              </div>
              <select value={sel.estado} onChange={(e) => updateEstado(sel.id, e.target.value)}
                className="px-3 py-1.5 rounded-lg border bg-background text-sm">
                {ESTADOS.map((e) => <option key={e} value={e}>{e}</option>)}
              </select>
            </div>

            {buildWhatsappLink(sel, agencyName) && (
              <a href={buildWhatsappLink(sel, agencyName)!} target="_blank" rel="noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition">
                <MessageCircle className="w-4 h-4" /> Contactar por WhatsApp
              </a>
            )}



            <div className="grid sm:grid-cols-2 gap-2 text-sm">
              <Info k="Cliente" v={sel.cliente_nombre} />
              <Info k="Teléfono" v={sel.cliente_telefono} />
              <Info k="Email" v={sel.cliente_email} />
              <Info k="Km" v={sel.kilometros?.toLocaleString("es-AR")} />
              <Info k="Combustible" v={sel.combustible} />
              <Info k="Caja" v={sel.caja} />
              <Info k="Estado general" v={sel.estado_general} />
              <Info k="Precio pretendido" v={sel.precio_pretendido ? `$ ${Number(sel.precio_pretendido).toLocaleString("es-AR")}` : "—"} />
            </div>

            {sel.observaciones && (
              <div>
                <div className="text-xs text-muted-foreground mb-1">Observaciones</div>
                <div className="text-sm bg-muted/40 p-3 rounded">{sel.observaciones}</div>
              </div>
            )}

            {Array.isArray(sel.fotos) && sel.fotos.length > 0 && (
              <div>
                <div className="text-xs text-muted-foreground mb-1">Fotos</div>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                  {sel.fotos.map((u: string, i: number) => (
                    <a key={i} href={u} target="_blank" rel="noreferrer" className="aspect-square bg-muted rounded overflow-hidden block">
                      <img src={u} className="w-full h-full object-cover" />
                    </a>
                  ))}
                </div>
              </div>
            )}

            <div>
              <div className="text-xs text-muted-foreground mb-1">Notas internas</div>
              <textarea value={sel.notas_internas || ""} onChange={(e) => setSel({ ...sel, notas_internas: e.target.value })}
                rows={4} className="w-full px-3 py-2 rounded-lg border bg-background text-sm" />
              <div className="mt-2 flex gap-2">
                <button onClick={saveNotas} className="px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-sm">Guardar notas</button>
                <button onClick={() => del(sel.id)} className="px-3 py-1.5 rounded-lg border text-sm text-destructive">Eliminar</button>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-card rounded-lg border p-6 text-center text-sm text-muted-foreground">Seleccioná una solicitud para ver el detalle.</div>
        )}
      </div>
    </div>
  );
}

function Info({ k, v }: any) {
  return <div><div className="text-[11px] text-muted-foreground">{k}</div><div>{v || "—"}</div></div>;
}
