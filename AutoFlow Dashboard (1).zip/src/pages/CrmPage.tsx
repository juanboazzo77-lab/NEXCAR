import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { formatCurrency, formatDate } from "@/lib/supabase-helpers";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Pencil, MessageCircle, Phone, ShoppingCart, Facebook, Instagram, Mail, User, Bell, BellRing } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { NotificationPhonesCard } from "@/components/NotificationPhonesCard";

type Lead = {
  id: string;
  user_id: string;
  nombre: string;
  telefono: string | null;
  canal: string | null;
  auto_interes: string | null;
  presupuesto: number | null;
  tipo_auto: string | null;
  estado: string;
  notas: string | null;
  fecha_contacto: string;
  ultimo_contacto: string | null;
};

const CANALES = ["WhatsApp", "Mercado Libre", "Instagram", "Facebook", "Llamada", "Email", "Presencial", "Otro"];
const ESTADOS = ["Nuevo", "En conversación", "Cita agendada", "Negociando", "Cerrado", "Perdido"];
const TIPOS_AUTO = ["Sedán", "Hatchback", "SUV", "Pickup", "Coupé", "Cabriolet", "Furgón", "Minivan", "Otro"];

const canalIcon = (canal: string | null) => {
  switch (canal) {
    case "WhatsApp": return <MessageCircle className="w-4 h-4 text-green-500" />;
    case "Mercado Libre": return <ShoppingCart className="w-4 h-4 text-yellow-500" />;
    case "Instagram": return <Instagram className="w-4 h-4 text-pink-500" />;
    case "Facebook": return <Facebook className="w-4 h-4 text-blue-600" />;
    case "Llamada": return <Phone className="w-4 h-4 text-sky-500" />;
    case "Email": return <Mail className="w-4 h-4 text-muted-foreground" />;
    default: return <User className="w-4 h-4 text-muted-foreground" />;
  }
};

const estadoColor = (estado: string) => {
  switch (estado) {
    case "Nuevo": return "bg-blue-500/15 text-blue-600 border-blue-500/30";
    case "En conversación": return "bg-amber-500/15 text-amber-600 border-amber-500/30";
    case "Cita agendada": return "bg-purple-500/15 text-purple-600 border-purple-500/30";
    case "Negociando": return "bg-orange-500/15 text-orange-600 border-orange-500/30";
    case "Cerrado": return "bg-green-500/15 text-green-600 border-green-500/30";
    case "Perdido": return "bg-destructive/15 text-destructive border-destructive/30";
    default: return "";
  }
};

export default function CrmPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [filterEstado, setFilterEstado] = useState<string>("all");
  const [filterCanal, setFilterCanal] = useState<string>("all");

  const emptyForm = {
    nombre: "",
    telefono: "",
    canal: "WhatsApp",
    auto_interes: "",
    presupuesto: 0,
    tipo_auto: "",
    estado: "Nuevo",
    notas: "",
    fecha_contacto: new Date().toISOString().split("T")[0],
    ultimo_contacto: "",
  };
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const set = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  const load = async () => {
    setLoading(true);
    const { data, error } = await (supabase as any)
      .from("leads")
      .select("*")
      .order("fecha_contacto", { ascending: false });
    if (error) toast({ title: "Error", description: error.message, variant: "destructive" });
    else setLeads(data as Lead[]);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const openNew = () => {
    setEditingId(null);
    setForm(emptyForm);
    setOpen(true);
  };

  const openEdit = (l: Lead) => {
    setEditingId(l.id);
    setForm({
      nombre: l.nombre,
      telefono: l.telefono ?? "",
      canal: l.canal ?? "WhatsApp",
      auto_interes: l.auto_interes ?? "",
      presupuesto: Number(l.presupuesto) || 0,
      tipo_auto: l.tipo_auto ?? "",
      estado: l.estado,
      notas: l.notas ?? "",
      fecha_contacto: l.fecha_contacto,
      ultimo_contacto: l.ultimo_contacto ?? "",
    });
    setOpen(true);
  };

  const save = async () => {
    if (!form.nombre.trim()) {
      toast({ title: "Falta el nombre", variant: "destructive" });
      return;
    }
    const payload: any = {
      ...form,
      ultimo_contacto: form.ultimo_contacto || null,
      presupuesto: Number(form.presupuesto) || 0,
    };
    try {
      if (editingId) {
        const { error } = await (supabase as any).from("leads").update(payload).eq("id", editingId);
        if (error) throw error;
        toast({ title: "Contacto actualizado" });
      } else {
        const { error } = await (supabase as any).from("leads").insert({ ...payload, user_id: user!.id });
        if (error) throw error;
        toast({ title: "Contacto agregado" });
      }
      setOpen(false);
      setEditingId(null);
      setForm(emptyForm);
      load();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    }
  };

  const remove = async (id: string) => {
    if (!confirm("¿Eliminar este contacto?")) return;
    const { error } = await (supabase as any).from("leads").delete().eq("id", id);
    if (error) toast({ title: "Error", description: error.message, variant: "destructive" });
    else load();
  };

  const filtered = useMemo(() => {
    return leads.filter(l =>
      (filterEstado === "all" || l.estado === filterEstado) &&
      (filterCanal === "all" || l.canal === filterCanal)
    );
  }, [leads, filterEstado, filterCanal]);

  const stats = useMemo(() => ({
    total: leads.length,
    abiertos: leads.filter(l => !["Cerrado", "Perdido"].includes(l.estado)).length,
    cerrados: leads.filter(l => l.estado === "Cerrado").length,
  }), [leads]);

  const ESTADOS_CERRADOS = ["Cerrado", "Perdido"];
  const daysSince = (dateStr: string) => {
    const [y, m, d] = dateStr.split("T")[0].split("-").map(Number);
    const past = new Date(y, m - 1, d);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return Math.floor((today.getTime() - past.getTime()) / 86400000);
  };
  const needsRecontact = (l: Lead) => {
    if (ESTADOS_CERRADOS.includes(l.estado)) return false;
    const ref = l.ultimo_contacto || l.fecha_contacto;
    return daysSince(ref) >= 2;
  };
  const pendingRecontact = useMemo(() => leads.filter(needsRecontact), [leads]);

  const markContacted = async (id: string) => {
    const today = new Date().toISOString().split("T")[0];
    const { error } = await (supabase as any).from("leads").update({ ultimo_contacto: today }).eq("id", id);
    if (error) toast({ title: "Error", description: error.message, variant: "destructive" });
    else { toast({ title: "Marcado como contactado hoy" }); load(); }
  };

  const waLink = (tel: string) => `https://wa.me/${tel.replace(/[^0-9]/g, "")}`;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="page-header">CRM / Contactos</h1>
        <Button size="sm" onClick={openNew}><Plus className="w-4 h-4 mr-1" />Nuevo contacto</Button>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Total</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{stats.total}</div></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Abiertos</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold text-amber-600">{stats.abiertos}</div></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Cerrados</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold text-green-600">{stats.cerrados}</div></CardContent></Card>
      </div>

      {pendingRecontact.length > 0 && (
        <Card className="border-amber-500/40 bg-amber-500/10">
          <CardHeader className="pb-2 flex flex-row items-center gap-2 space-y-0">
            <BellRing className="w-5 h-5 text-amber-600" />
            <CardTitle className="text-sm">Recontactar ({pendingRecontact.length}) — pasaron 2+ días sin contacto</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5">
            {pendingRecontact.map(l => {
              const ref = l.ultimo_contacto || l.fecha_contacto;
              const d = daysSince(ref);
              return (
                <div key={l.id} className="flex items-center justify-between gap-2 text-sm border-b border-amber-500/20 last:border-0 pb-1.5 last:pb-0">
                  <div className="min-w-0 flex-1">
                    <div className="font-medium truncate">{l.nombre} <span className="text-xs text-muted-foreground">· hace {d}d</span></div>
                    {l.auto_interes && <div className="text-xs text-muted-foreground truncate">{l.auto_interes}</div>}
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {l.telefono && (
                      <Button asChild size="sm" variant="outline" className="h-7 px-2">
                        <a href={waLink(l.telefono)} target="_blank" rel="noopener noreferrer"><MessageCircle className="w-3.5 h-3.5 text-green-600" /></a>
                      </Button>
                    )}
                    <Button size="sm" variant="outline" className="h-7 px-2 text-xs" onClick={() => markContacted(l.id)}>Hecho</Button>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      <div className="flex flex-col sm:flex-row gap-2">
        <Select value={filterEstado} onValueChange={setFilterEstado}>
          <SelectTrigger className="sm:w-48"><SelectValue placeholder="Estado" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los estados</SelectItem>
            {ESTADOS.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterCanal} onValueChange={setFilterCanal}>
          <SelectTrigger className="sm:w-48"><SelectValue placeholder="Canal" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los canales</SelectItem>
            {CANALES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-lg border overflow-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nombre</TableHead>
              <TableHead>Canal</TableHead>
              <TableHead>Teléfono</TableHead>
              <TableHead>Auto / Tipo</TableHead>
              <TableHead className="text-right">Presupuesto</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead>Fecha</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map(l => (
              <TableRow key={l.id}>
                <TableCell className="font-medium text-sm"><span className="flex items-center gap-1.5">{needsRecontact(l) && <Bell className="w-3.5 h-3.5 text-amber-600" />}{l.nombre}</span></TableCell>
                <TableCell><span className="flex items-center gap-1.5 text-sm" title={l.canal ?? ""}>{canalIcon(l.canal)}<span className="hidden md:inline">{l.canal}</span></span></TableCell>
                <TableCell className="text-sm">
                  {l.telefono ? (
                    <a href={waLink(l.telefono)} target="_blank" rel="noopener noreferrer" className="text-green-600 hover:underline">{l.telefono}</a>
                  ) : <span className="text-muted-foreground">-</span>}
                </TableCell>
                <TableCell className="text-sm">
                  <div>{l.auto_interes || <span className="text-muted-foreground">-</span>}</div>
                  {l.tipo_auto && <div className="text-xs text-muted-foreground">{l.tipo_auto}</div>}
                </TableCell>
                <TableCell className="text-right text-sm">{l.presupuesto ? formatCurrency(Number(l.presupuesto)) : <span className="text-muted-foreground">-</span>}</TableCell>
                <TableCell><Badge variant="outline" className={estadoColor(l.estado)}>{l.estado}</Badge></TableCell>
                <TableCell className="text-sm text-muted-foreground">{formatDate(l.fecha_contacto)}</TableCell>
                <TableCell className="text-right whitespace-nowrap">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(l)}><Pencil className="w-3.5 h-3.5" /></Button>
                  <Button variant="ghost" size="sm" onClick={() => remove(l.id)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                </TableCell>
              </TableRow>
            ))}
            {filtered.length === 0 && (
              <TableRow><TableCell colSpan={8} className="text-center text-muted-foreground text-sm">{loading ? "Cargando..." : "Sin contactos"}</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-auto">
          <DialogHeader><DialogTitle>{editingId ? "Editar contacto" : "Nuevo contacto"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Nombre *</Label><Input value={form.nombre} onChange={e => set("nombre", e.target.value)} /></div>
            <div className="grid grid-cols-2 gap-2">
              <div><Label>Canal</Label>
                <Select value={form.canal} onValueChange={v => set("canal", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{CANALES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Teléfono</Label><Input value={form.telefono} onChange={e => set("telefono", e.target.value)} placeholder="11 1234 5678" /></div>
            </div>
            <div><Label>Auto que pregunta</Label><Input value={form.auto_interes} onChange={e => set("auto_interes", e.target.value)} placeholder="Ej: VW Gol Trend 2018" /></div>
            <div className="grid grid-cols-2 gap-2">
              <div><Label>Tipo de auto que busca</Label>
                <Select value={form.tipo_auto} onValueChange={v => set("tipo_auto", v)}>
                  <SelectTrigger><SelectValue placeholder="-" /></SelectTrigger>
                  <SelectContent>{TIPOS_AUTO.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Presupuesto</Label><Input type="number" value={form.presupuesto} onChange={e => set("presupuesto", Number(e.target.value))} /></div>
            </div>
            <div><Label>Estado</Label>
              <Select value={form.estado} onValueChange={v => set("estado", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{ESTADOS.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div><Label>Fecha contacto</Label><Input type="date" value={form.fecha_contacto} onChange={e => set("fecha_contacto", e.target.value)} /></div>
              <div><Label>Último contacto</Label><Input type="date" value={form.ultimo_contacto} onChange={e => set("ultimo_contacto", e.target.value)} /></div>
            </div>
            <div><Label>Notas</Label><Textarea rows={3} value={form.notas} onChange={e => set("notas", e.target.value)} placeholder="Detalles de la conversación, requisitos, seguimientos..." /></div>
          </div>
          <Button onClick={save} className="w-full">{editingId ? "Actualizar" : "Guardar"}</Button>
        </DialogContent>
      </Dialog>
      <NotificationPhonesCard />

    </div>
  );
}
