import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Bell } from "lucide-react";
import { NotificationPhonesCard } from "@/components/NotificationPhonesCard";

const ESTADOS = ["Activa", "Notificada", "Cerrada"];

export default function AlertasPage() {
  const { toast } = useToast();
  const [items, setItems] = useState<any[]>([]);
  const load = () => supabase.from("vehicle_alerts").select("*").order("created_at", { ascending: false }).then(({ data }) => setItems(data || []));
  useEffect(() => { load(); }, []);

  const upd = async (id: string, patch: any) => { await supabase.from("vehicle_alerts").update(patch).eq("id", id); load(); };
  const del = async (id: string) => { if (!confirm("Eliminar este aviso?")) return; await supabase.from("vehicle_alerts").delete().eq("id", id); load(); };

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold flex items-center gap-2"><Bell className="w-5 h-5" /> Alertas de clientes</h1>
      <p className="text-sm text-muted-foreground">Clientes que pidieron ser avisados cuando ingrese un vehículo específico.</p>

      <div className="bg-card border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-xs">
            <tr>
              <th className="p-2 text-left">Fecha</th>
              <th className="p-2 text-left">Cliente</th>
              <th className="p-2 text-left">Contacto</th>
              <th className="p-2 text-left">Busca</th>
              <th className="p-2 text-left">Presupuesto</th>
              <th className="p-2 text-left">Estado</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 && <tr><td colSpan={7} className="p-6 text-center text-muted-foreground">Sin alertas.</td></tr>}
            {items.map((a) => (
              <tr key={a.id} className="border-t">
                <td className="p-2 text-xs">{new Date(a.created_at).toLocaleDateString("es-AR")}</td>
                <td className="p-2">{a.cliente_nombre}</td>
                <td className="p-2 text-xs">{[a.cliente_telefono, a.cliente_whatsapp, a.cliente_email].filter(Boolean).join(" · ") || "—"}</td>
                <td className="p-2">{[a.marca, a.modelo, a.anio_aprox].filter(Boolean).join(" ") || a.observaciones || "—"}</td>
                <td className="p-2">{a.presupuesto ? `$ ${Number(a.presupuesto).toLocaleString("es-AR")}` : "—"}</td>
                <td className="p-2">
                  <select value={a.estado} onChange={(e) => upd(a.id, { estado: e.target.value })}
                    className="px-2 py-1 rounded border bg-background text-xs">
                    {ESTADOS.map((e) => <option key={e} value={e}>{e}</option>)}
                  </select>
                </td>
                <td className="p-2 text-right">
                  <button onClick={() => del(a.id)} className="text-xs text-destructive">Eliminar</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <NotificationPhonesCard />

    </div>
  );
}
