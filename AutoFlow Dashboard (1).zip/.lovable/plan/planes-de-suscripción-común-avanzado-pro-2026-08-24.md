# Planes de suscripción (Común / Avanzado / Pro)

## Qué ya existe hoy
- Tabla `agencies` con columna `plan` (texto libre: trial/standard/premium) y `status`.
- Tabla `plans` (code, name, price_monthly, max_vehicles, max_users, marketplace_enabled, advanced_stats, `features jsonb`, active) y `subscriptions` (agency_id, plan_id, status) — creadas pero prácticamente sin uso en el código.
- `useAgency()` ya trae agencia + suscripción + plan.
- Marketplace y catálogos leen la vista `cars_public` filtrando `mostrar_publico = true`, `agency_marketplace_visible`, estado Disponible/Reservado. La publicación en Marketplace ya es el flag `cars.mostrar_publico`.
- Módulos existentes que se van a "gatear" (ninguno se toca por dentro): Financiero, Cotizador, PDFs, Turnos, Estadísticas, IA de ventas (`parse-venta`), lectura de DNI (`extract-dni`), boleto de compraventa (`pdf-generator`), campos `duenio`/`proveedor` en Stock y `vendedor` en Ventas.
- Panel CEO (`CeoPanelPage` + edge function `ceo-admin`) ya crea/edita agencias con un campo plan textual.

## Arquitectura propuesta

### 1. Catálogo de planes centralizado
Un único origen de verdad: filas en `plans` (códigos `common`, `advanced`, `pro`) con `features jsonb` y nuevas columnas `max_marketplace` (null = ilimitado) y `max_gold`. Espejo tipado en `src/lib/plans.ts` para la UI, leyendo overrides desde la base. Cambiar un límite en el futuro = editar una fila, sin tocar componentes.

Features por plan (matriz del pedido): `financiero`, `cotizador`, `pdfs`, `turnos`, `stats`, `ia_ventas`, `ia_documentos`, `boleto`, `vendedor`, `duenio`, `proveedor`, `marketplace_priority`.

### 2. Base de datos
- `plans`: agregar `max_marketplace int null`, `max_gold int not null default 0`; insertar/actualizar las 3 filas.
- `agencies`: `plan` pasa a guardar `common | advanced | pro` (migración de valores actuales: trial/standard → advanced, premium → pro, Grupo Boazzo → pro).
- `cars`: nueva columna `marketplace_tier text default 'silver'` (`gold`/`silver`).
- Funciones en esquema `private`: `plan_of_agency(agency_id)`, `plan_limit(agency_id, key)`, `plan_feature(agency_id, key)`.
- Trigger `BEFORE INSERT/UPDATE ON cars`:
  - si se activa `mostrar_publico` y ya se alcanzó `max_marketplace` → error con mensaje del plan;
  - si `marketplace_tier='gold'` y no hay cupo ORO (o el plan tiene 0) → error / degradación a silver;
  - plan sin feature `duenio`/`proveedor` → fuerza esos campos a NULL.
- Trigger `BEFORE INSERT/UPDATE ON sales`: plan sin feature `vendedor` → fuerza `vendedor` a NULL.
- Solo el CEO puede cambiar `agencies.plan` (política ya existente + validación en `ceo-admin`).
- Vista `cars_public`: se recrea igual pero exponiendo `marketplace_tier` (y degradando a `silver` si el plan de la agencia no tiene prioridad).

### 3. Límites y cupos
El conteo se hace siempre sobre vehículos con `mostrar_publico = true` y estado Disponible/Reservado, así los vendidos liberan cupo automáticamente (incluido el cupo ORO). Vista/función `agency_plan_usage(agency_id)` devuelve `{marketplace_used, gold_used, silver_used, limites}` para paneles y CEO.

### 4. ORO / PLATA en Marketplace
El orden se calcula **después** de aplicar búsqueda, marca, provincia, precio, año, ubicación y radio: dentro del conjunto ya filtrado y ordenado por relevancia/criterio elegido, los ORO suben al tope de su grupo comparable. Los PLATA siguen apareciendo normalmente. Badge discreto "DESTACADO" en la card, sin cambiar el diseño actual.

### 5. Permisos en el frontend (sin `if plan===` disperso)
- `src/lib/plans.ts`: matriz de features y límites.
- `usePlan()`: devuelve `plan`, `can(feature)`, `limits`, `usage`.
- `<FeatureGate feature="pdfs">`: si no está incluido muestra la pantalla "Esta función no está incluida en tu Plan X" + botón "Ver planes".
- `App.tsx`: cada ruta gateada se envuelve con `FeatureGate` (los componentes no se modifican).
- `AppLayout`: los ítems bloqueados se muestran con candado (no se eliminan).

### 6. Seguridad real (backend)
- Triggers de base (arriba) → una agencia Común no puede saltar el límite llamando la API directamente.
- Helper `_shared/plan-guard.ts` en edge functions: `requireFeature(userId, 'ia_ventas')` aplicado a `parse-venta`, `extract-dni`, `generate-description*`, `generate-social-copy`, `inbox-ai`.
- Aislamiento multiagencia actual intacto.

### 7. Upgrades / downgrades
Nunca se borra nada. Al bajar de plan: los vehículos publicados de más siguen existiendo y visibles hasta que la agencia los retire, pero no se puede publicar ninguno nuevo hasta estar dentro del límite (mensaje explícito). Al bajar a Común los ORO pasan a comportarse como PLATA; de Pro a Avanzado se conservan los 10 ORO más recientes y el resto pasa a PLATA.

### 8. Paneles
- **Mi agencia**: bloque "Plan actual" con contadores `Marketplace 28/35`, `ORO 8/10`, `PLATA 20/25`, lista de funciones ✓ / 🔒 y botón "Mejorar plan" → `/planes`.
- **Stock**: botón para marcar/desmarcar ORO por vehículo, con mensaje al agotar cupo.
- **Panel CEO**: en cada agencia, selector de plan (Común/Avanzado/Pro) + uso en vivo (Marketplace, ORO, PLATA, límites, estado de suscripción).
- **/planes**: pantalla comparativa de los 3 planes, Avanzado como recomendado, con espacio reservado para precios y botón de contratación (sin precios inventados).

## Etapas de implementación
1. Migración de base: columnas de `plans`, seed de los 3 planes, `cars.marketplace_tier`, funciones y triggers, vista `cars_public` con tier, función de uso.
2. Núcleo frontend: `src/lib/plans.ts`, `usePlan()`, `FeatureGate`, página `/planes`.
3. Gates en rutas y sidebar (Financiero, Cotizador, PDFs, Turnos, Stats).
4. Gates dentro de Ventas (IA, DNI, boleto, vendedor) y Stock (dueño/proveedor, botón ORO).
5. Marketplace: badge ORO y prioridad post-filtros.
6. Paneles: Mi agencia (uso del plan) y Panel CEO (asignar plan + ver uso).
7. Guard de plan en las edge functions de IA.
