# Plataforma multiagencia (SaaS) sobre el sistema actual

## Cómo está hoy (análisis)

- **Aislamiento actual:** casi todo (cars, sales, leads, gastos, caja, inbox, publicaciones, calendario, fotos) se filtra por `user_id` con RLS. Funciona, pero ata los datos a una persona, no a una agencia.
- **Ya existe base multiagencia parcial:** tabla `agencies` (2 filas), `user_roles` con `agency_id` y enum `app_role` (ceo, owner, employee), y funciones internas `is_ceo`, `has_role`, `get_user_agency`, `is_staff`. El panel `/ceo` ya existe (242 líneas) pero es básico.
- **Público:** `/catalogo` y subpáginas (favoritos, comparar, tasación, alerta, nosotros, FAQ) leen `cars` con `mostrar_publico`, más `public_settings` (una sola fila, global) y `public_faqs`.
- **Datos actuales:** 101 autos, 3 usuarios, 3 leads. Todo pertenece a Grupo Boazzo.
- **Vehículos:** dos modelos conviven — `cars` (el que usa todo el sistema real) y `vehicles` (Publicador Pro). El trabajo se centra en `cars`.

## Qué cambia (y qué NO)

NO se toca: diseño, componentes, formularios, PDFs, publicadores, IA, inbox, cuotas, ni el flujo de trabajo actual. Todo el panel sigue igual; solo cambia **de dónde** salen los datos (agencia en vez de usuario).

## Etapa 1 — Base de datos y seguridad

- Ampliar `agencies`: logo, descripción, dirección, ciudad, provincia, lat/lng, teléfono, WhatsApp, email, redes, horarios, estado, plan, fecha de alta, slug único.
- Agregar `agency_id` a las tablas de negocio (cars, sales, sale_payments, car_expenses, cash_movements, leads, calendar_events, car_photos, car_documentation, inbox_*, publicaciones, public_settings, public_faqs, tasaciones, alertas...).
- **Backfill seguro:** crear/normalizar la agencia "Grupo Boazzo" y asignar `agency_id` a los 101 autos y a todos los registros existentes según su `user_id`. Nada se borra.
- Trigger que completa `agency_id` automáticamente al insertar (según la agencia del usuario) para que ningún formulario actual se rompa.
- RLS: se **agregan** políticas por agencia (`agency_id = private.get_user_agency(auth.uid())`) manteniendo las de `user_id` durante la transición, y luego se dejan solo las de agencia. `super_admin` (rol CEO actual) mantiene acceso global.
- Nuevo rol `agency_admin` en el enum, más `private.is_agency_admin()`.

## Etapa 2 — Usuarios y roles por agencia

- Cada usuario pertenece a una agencia vía `user_roles.agency_id` (salvo el CEO global).
- Pantalla "Usuarios" dentro del panel de la agencia: invitar/crear empleado, cambiar rol, desactivar. Reutiliza los componentes de tablas actuales.

## Etapa 3 — Catálogo público por agencia

- Nueva ruta `/agencia/:slug` que reutiliza **exactamente** `PublicCatalogPage` y sus subpáginas, filtrando por la agencia del slug (WhatsApp, logo, nombre y FAQ de esa agencia).
- Solo vehículos disponibles; los vendidos no se muestran en esta vista.
- En el panel: tarjeta "Tu link público" con copiar / compartir por WhatsApp, Instagram, Facebook.

## Etapa 4 — Marketplace general

- Ruta pública `/marketplace` (y la portada ofrece el acceso) con el stock disponible de todas las agencias activas, mismo estilo visual del catálogo actual.
- Cada tarjeta muestra la agencia dueña; el detalle del vehículo lleva al contacto de esa agencia.
- Vista de solo lectura mediante una vista pública que expone únicamente campos públicos (nunca precio de compra, notas internas, proveedor, dueño).

## Etapa 5 — Búsqueda por zona y radio

- Filtros: marca, modelo, versión, año desde/hasta, precio, km, combustible, transmisión, carrocería, provincia, ciudad (se mantienen los actuales y se agregan los que faltan).
- Selector de ubicación + radio (10/25/50/100/200 km, provincia, país), calculado por distancia contra las coordenadas de cada agencia.
- Si no hay resultados, sugerencia automática de ampliar el radio.

## Etapa 6 — Comparador multiagencia

- Se extiende el comparador existente para admitir vehículos de distintas agencias, mostrando la agencia y un botón "Consultar a la agencia" por columna.

## Etapa 7 — Leads con asignación automática

- Toda consulta desde marketplace o catálogo se guarda con el `agency_id` del vehículo, visible solo para esa agencia (y para el CEO).

## Etapa 8 — Panel CEO / Super Admin

- Se amplía `/ceo`: listado y alta/edición de agencias, activar/suspender, ver plan y suscripción, usuarios por agencia, vehículos totales/disponibles/vendidos, leads por agencia y métricas globales.

## Etapa 9 — Planes y suscripciones (estructura)

- Tablas `plans` y `subscriptions` (estado: trial, active, past_due, suspended, cancelled; inicio, vencimiento, agencia, límites: máx. vehículos, máx. usuarios, features, aparición en marketplace).
- Sin cobro real todavía: queda listo para conectar un proveedor de pagos más adelante.

## Notas técnicas

- Todo el aislamiento es real a nivel base de datos (RLS + funciones `security definer`), no solo en el frontend.
- Cero lógica hardcodeada por agencia: Grupo Boazzo pasa a ser simplemente el tenant #1.
- Las migraciones son aditivas; no hay `DROP` de columnas de datos. Antes de cualquier cambio irreversible te aviso.
- Rutas nuevas: `/agencia/:slug` (+ subrutas), `/marketplace`, `/marketplace/:id`, `/ceo/agencias/:id`, `/usuarios`.

## Orden de ejecución

Empiezo por la Etapa 1 (migración + backfill + RLS) y te aviso al terminar cada etapa para que la revises en el preview antes de seguir.
